import fs from 'node:fs';import {spawn} from 'node:child_process';import path from 'node:path';import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));const preview=process.argv.includes('--preview'),seconds=preview?3:15;
const pages=await(await fetch('http://127.0.0.1:9222/json/list')).json();const page=pages.find(p=>p.type==='page');const ws=new WebSocket(page.webSocketDebuggerUrl);await new Promise(r=>ws.onopen=r);
let seq=0;const waiting=new Map();ws.onmessage=e=>{const o=JSON.parse(e.data);if(o.id){const p=waiting.get(o.id);waiting.delete(o.id);o.error?p.reject(Error(JSON.stringify(o.error))):p.resolve(o.result)}};
function cmd(method,params={}){return new Promise((resolve,reject)=>{let id=++seq;waiting.set(id,{resolve,reject});ws.send(JSON.stringify({id,method,params}));setTimeout(()=>{if(waiting.delete(id))reject(Error('Timeout '+method))},15000).unref()})}
await cmd('Page.enable');await cmd('Page.navigate',{url:'http://127.0.0.1:8765/illustrated-first15.html?t=1'});
for(let i=0;i<60;i++){const r=await cmd('Runtime.evaluate',{expression:'typeof render',returnByValue:true});if(r.result.value==='function')break;await new Promise(r=>setTimeout(r,100))}
await cmd('Runtime.evaluate',{expression:'document.fonts.ready',awaitPromise:true});
const audio=process.env.NARRATION_FILE||'/workspace/attachments/11de1409-a110-4a32-9431-b491a0f54883/ZombTLOU.mp3';
const output=path.join(root,preview?'movement-preview.mp4':'zombtlou-illustrated-first15.mp4');
const ff=spawn('ffmpeg',['-y','-v','error','-f','image2pipe','-framerate','24','-i','-','-i',audio,'-map','0:v:0','-map','1:a:0','-t',String(seconds),'-c:v','libx264','-threads','2','-preset','fast','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','256k','-movflags','+faststart',output],{stdio:['pipe','inherit','inherit']});
const done=new Promise((resolve,reject)=>ff.on('close',c=>c?reject(Error('FFmpeg '+c)):resolve()));
for(let i=0;i<seconds*24;i++){const r=await cmd('Runtime.evaluate',{expression:`render(${i/24});C.toDataURL('image/jpeg',.96)`,returnByValue:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));const b=Buffer.from(r.result.value.split(',')[1],'base64');if(!ff.stdin.write(b))await new Promise(r=>ff.stdin.once('drain',r));if(i%120===0)console.log(`${i}/${seconds*24} frames`)}
ff.stdin.end();await done;ws.close();console.log('Written '+output);
