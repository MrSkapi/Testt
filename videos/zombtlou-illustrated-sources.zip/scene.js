const canvas=document.getElementById('scene'),g=canvas.getContext('2d');
const W=1920,H=1080,D=15,INK='#2c2d2d';
const clamp=x=>Math.max(0,Math.min(1,x));const ease=x=>{x=clamp(x);return x*x*(3-2*x)};
let seed=97621;function rand(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296}
function path(points,fill,stroke=INK,lw=3,close=true){g.beginPath();g.moveTo(...points[0]);for(const p of points.slice(1))g.lineTo(...p);if(close)g.closePath();if(fill){g.fillStyle=fill;g.fill()}if(stroke){g.strokeStyle=stroke;g.lineWidth=lw;g.lineJoin='round';g.lineCap='round';g.stroke()}}
function line(x,y,X,Y,c=INK,w=3){path([[x,y],[X,Y]],null,c,w,false)}
function rect(x,y,w,h,fill,r=2,stroke=INK,lw=3){g.beginPath();g.roundRect(x,y,w,h,r);if(fill){g.fillStyle=fill;g.fill()}if(stroke){g.strokeStyle=stroke;g.lineWidth=lw;g.stroke()}}
function ellipse(x,y,rx,ry,fill,stroke=INK,lw=3){g.beginPath();g.ellipse(x,y,rx,ry,0,0,Math.PI*2);if(fill){g.fillStyle=fill;g.fill()}if(stroke){g.strokeStyle=stroke;g.lineWidth=lw;g.stroke()}}
function text(s,x,y,size=25,c=INK,bold=false){g.font=`${bold?'700':'400'} ${size}px "DejaVu Sans",Arial,sans-serif`;g.fillStyle=c;g.fillText(s,x,y)}
function hatch(x,y,w,h,n=30,color='#292d2b38'){for(let i=0;i<n;i++){const xx=x+(i*17.79)%w,yy=y+(i*7.23)%h;line(xx,yy,xx+7,yy-10,color,1)}}
// Static scanned-paper grain. Texture never swims or flickers between frames.
const paper=document.createElement('canvas');paper.width=W;paper.height=H;
const pg=paper.getContext('2d'),data=pg.createImageData(W,H);
for(let i=0;i<data.data.length;i+=4){let k=rand();const v=k>.5?239:43;data.data[i]=v;data.data[i+1]=v;data.data[i+2]=v;data.data[i+3]=Math.floor(2+rand()*9)}pg.putImageData(data,0,0);
const wall=document.createElement('canvas');wall.width=W;wall.height=H;const wg=wall.getContext('2d');
for(let i=0;i<180;i++){wg.strokeStyle=i%3?'#333a3620':'#d6d8c519';wg.lineWidth=.7+rand()*2;const x=rand()*1920,y=rand()*750;wg.beginPath();wg.moveTo(x,y);wg.lineTo(x+rand()*4,y+50+rand()*300);wg.stroke()}
function plant(){rect(527,666,133,19,'#775b44');line(538,685,528,808,'#69503c',7);line(650,685,655,809,'#69503c',7);path([[563,597],[629,597],[619,667],[574,667]],'#a56b46');rect(557,587,77,16,'#ba895d',4);
 for(const [x,y]of [[545,462],[578,432],[608,449],[643,471],[662,515],[537,525]]){path([[596,592],[x,y],[x+12,y+45]],'#657f51',INK,2)}hatch(568,636,50,25,12)}
function room(t){g.fillStyle='#8c9896';g.fillRect(0,0,W,H);g.drawImage(wall,0,0);
 // Dado, skirting, wooden boards and the oval woven rug.
 rect(-10,486,1940,14,'#cecebf',0,INK,2);g.fillStyle='#808f8d';g.fillRect(0,501,W,244);rect(-10,746,1940,19,'#d6d1c1',0,INK,2);hatch(0,748,1920,14,150);
 g.fillStyle='#a8835f';g.fillRect(0,765,W,315);
 for(let j=0;j<6;j++){let y=778+j*53;line(0,y,W,y,'#7e63494a',2);for(let i=0;i<7;i++){let x=i*320+(j%2?160:0);line(x,y,x,y+53,'#7e63494a',2);line(x+20,y+33,x+280,y+31,'#c29a6b50',1)}}
 ellipse(960,923,392,130,'#c5b99a');ellipse(960,923,345,103,null,'#998a6d',8);hatch(650,967,600,46,100,'#695c4645');
 // Framed mountain drawing.
 rect(535,165,127,148,'#463e33');rect(546,176,105,124,'#d2cbbb',0,INK,2);ellipse(620,207,10,10,'#c1ac69',INK,1);path([[548,283],[578,236],[599,260],[615,235],[647,279],[647,297],[548,297]],'#7e9470',INK,2);
 // Window silhouettes, two mustard curtains, pencil-shaded edges.
 line(687,69,1238,69,INK,7);ellipse(680,69,8,8,INK);ellipse(1245,69,8,8,INK);
 rect(709,91,504,402,'#d7d5c6',0,INK,3);rect(725,106,472,371,'#929fb6',0,INK,2);
 for(let i=0;i<5;i++){let x=727+i*105;path([[x,474],[x,359],[x+50,312+(i%2)*20],[x+102,361],[x+102,474]],i%2?'#969298':'#8e8c93',INK,2)}
 rect(950,109,10,367,'#d6d3c4',2,INK,2);rect(722,316,479,10,'#d6d3c4',2,INK,2);
 path([[692,65],[789,65],[791,492],[687,492]],'#b39b4a');path([[1134,65],[1230,65],[1237,492],[1136,492]],'#b39b4a');
 for(let i=0;i<4;i++){line(710+i*20,70,706+i*20,487,'#8d793e85',1.5);line(1150+i*20,70,1148+i*20,487,'#8d793e85',1.5)}hatch(776,89,13,390,55);hatch(1138,99,13,385,55);hatch(724,480,475,12,65);
 plant();
 // Tall floor lamp; no simulated light cones or bloom.
 ellipse(1295,824,47,13,'#363838');line(1293,817,1293,453,'#61543f',8);path([[1237,329],[1335,329],[1357,434],[1214,434]],'#d9ccb0',INK,3);hatch(1223,419,125,15,27,'#8b80664a');
 // Sofa: linework, seat seam and crosshatching instead of gradients.
 rect(661,494,604,286,'#813d48',40);rect(683,509,560,171,'#9d535d',31);rect(686,671,554,56,'#a35b63',12);line(694,689,1230,689,'#71343f',2);line(966,527,966,672,'#81404b',2);
 rect(621,555,108,228,'#944b56',37);rect(1203,555,108,228,'#944b56',37);line(629,587,721,587,'#74333e',2);line(1211,587,1302,587,'#74333e',2);
 rect(632,778,15,18,'#343432',2);rect(1280,779,15,18,'#343432',2);hatch(733,710,461,20,85,'#59313b50');hatch(640,742,70,25,16);
}
function knee(a,b,A,B,side){const dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy);if(d>A+B+.01)throw Error('Unreachable joint');const q=(A*A-B*B+d*d)/(2*d),h=Math.sqrt(Math.max(0,A*A-q*q));return[a[0]+dx*q/d+side*dy*h/d,a[1]+dy*q/d-side*dx*h/d]}
function arm(a,b,side){const k=knee(a,b,78,76,side);line(...a,...k,INK,25);line(...k,...b,INK,25);line(...a,...k,'#ad7650',18);line(...k,...b,'#ad7650',18);ellipse(...a,9,9,'#b27c56',INK,2)}
function cap(){// fitted to the head, with a low brim and two panel seams
 g.beginPath();g.moveTo(-65,-26);g.bezierCurveTo(-70,-70,-32,-81,1,-80);g.bezierCurveTo(40,-80,61,-57,65,-42);g.quadraticCurveTo(-7,-50,-65,-26);g.closePath();g.fillStyle='#4c8580';g.fill();g.lineWidth=2.5;g.strokeStyle=INK;g.stroke();
 g.beginPath();g.moveTo(-65,-26);g.quadraticCurveTo(4,-52,65,-42);g.quadraticCurveTo(94,-42,101,-31);g.quadraticCurveTo(95,-24,83,-29);g.quadraticCurveTo(34,-43,-23,-26);g.closePath();g.fillStyle='#3f7773';g.fill();g.stroke();line(-11,-78,17,-47,INK,1.5);hatch(-54,-48,27,15,12,'#253b3440')}
function actor(t){
 // Seated, front-facing: pelvis on cushion; feet contact the floor behind the table.
 line(941,693,932,751,INK,10);line(932,751,939,809,INK,10);line(939,809,963,809,INK,11);
 line(994,693,1001,749,INK,10);line(1001,749,997,809,INK,10);line(997,809,1022,809,INK,11);
 path([[917,549],[1004,549],[1024,577],[1029,698],[903,698],[905,576]],'#ad7650',INK,3);
 // Hood and pocket shapes follow the simple coat construction in the reference.
 path([[926,551],[947,544],[980,544],[1000,551],[989,579],[968,565],[946,579]],'#94613f',INK,2);
 path([[945,552],[969,568],[990,552],[980,578],[953,578]],'#3a3832',INK,2);
 path([[934,636],[993,636],[1006,670],[924,670]],'#a36c48',INK,2);line(942,575,943,607,'#d5c6a8',2);line(988,574,988,608,'#d5c6a8',2);hatch(910,683,115,13,28,'#58432d55');
 const lift=ease((t-.8)/1.7);const py=621-34*lift,px=970;
 const left=[px-4,py+60],right=[px+55,py+60];arm([917,565],left,-1);arm([1004,565],right,1);
 phoneBack(px,py,52,81);ellipse(...left,11,11,'#26272b');ellipse(...right,11,11,'#26272b');
 // Head touches collar; no visible neck, no independent floating motion.
 g.save();g.translate(964,482);const amused=t>=9.34&&t<13.2;g.rotate(amused?-.02:0);
 ellipse(0,0,67,67,'#eee7da',INK,3);
 path([[-63,-25],[-61,0],[-54,-14],[-51,-28],[-22,-32],[-12,-23],[1,-35],[16,-26],[53,-35],[58,-1],[64,-18],[59,-47]],'#29282a',null);
 const blink=t%4.1>3.96;
 for(const x of [-16,16]){if(blink)line(x-4,0,x+4,0,INK,3);else rect(x-5,-7,10,25,'#282830',5,null)}
 if(t>=13.3){line(-23,-17,-10,-20,INK,2);line(10,-20,23,-17,INK,2);g.beginPath();g.moveTo(-7,34);g.quadraticCurveTo(0,30,7,34);g.stroke()}
 else if(amused){g.beginPath();g.moveTo(-10,31);g.quadraticCurveTo(0,40,12,30);g.strokeStyle=INK;g.lineWidth=2.5;g.stroke()}
 // Tiny restrained mouth only when needed, as in the supplied example.
 cap();hatch(-41,46,77,9,12,'#6e6b5b28');g.restore();
}
function table(){rect(754,826,419,24,'#967650',3,INK,3);rect(772,851,14,99,'#896546',0,INK,2);rect(1138,850,14,100,'#896546',0,INK,2);hatch(797,936,323,13,42);rect(825,786,40,43,'#d6d2c9',5,INK,2);g.beginPath();g.arc(869,804,9,-Math.PI/2,Math.PI/2);g.strokeStyle=INK;g.lineWidth=2;g.stroke()}
function phoneBack(x,y,w,h){rect(x,y,w,h,'#343942',5,INK,2);rect(x+5,y+5,17,24,'#272b32',3,null);ellipse(x+10,y+12,3,3,'#728078',INK,1);ellipse(x+17,y+22,3,3,'#728078',INK,1)}
function wrap(s,x,y,width,size=29,c=INK,bold=false){let row='',yy=y;g.font=`${bold?'700':'400'} ${size}px "DejaVu Sans",Arial,sans-serif`;for(const w of s.split(' ')){if(g.measureText(row+w).width>width&&row){text(row.trim(),x,yy,size,c,bold);yy+=size*1.36;row=''}row+=w+' '}if(row)text(row.trim(),x,yy,size,c,bold);return yy}
const msgs=[
 {at:0,who:'Rex',s:'WHEN THE SQUAD SAYS “ONE MORE GAME”',meme:true,h:127},
 {at:1.80,who:'Maya',s:'Pineapple on pizza is a crime.',h:102},
 {at:5.24,who:'SporeLoser',s:"Buy respirators. Spare filters. Water. Don't wait for an announcement.",warn:true,h:186},
 {at:9.34,who:'You',s:'😂',h:104,you:true},
 {at:10.74,who:'You',s:'Do the filters improve my aim?',h:170,you:true}
];
function smile(x,y){ellipse(x,y,18,18,'#c6a65e',INK,1.4);line(x-9,y-5,x-5,y-7,INK,2);line(x+5,y-7,x+9,y-5,INK,2);g.beginPath();g.arc(x,y+2,9,0,Math.PI);g.stroke()}
function phoneInsert(t){
 // Shoulder, two hands and the full phone share one rigid prop space.
 g.save();g.translate(405,0);g.scale(1.03,1.03);
 path([[23,1080],[52,759],[126,687],[212,713],[333,1080]],'#ad7650',INK,4);hatch(55,817,170,200,45,'#60492d30');
 rect(312,80,582,904,'#343942',37,INK,4);rect(333,107,540,849,'#dbdbcf',21,INK,2);rect(531,117,150,14,'#343942',7,null);
 text('THE SQUAD',360,182,29,INK,true);text('4 MEMBERS',360,213,17,'#5d675f');line(345,232,862,232,'#6a6e62',2);
 const active=msgs.filter(m=>t>=m.at),total=active.reduce((v,m)=>v+m.h+15,0);const newest=active.at(-1);const target=Math.max(0,total-610),previous=Math.max(0,total-(newest?.h||0)-15-610);const scroll=previous+(target-previous)*ease((t-(newest?.at||0))/.4);
 let y=253-scroll;
 g.save();g.beginPath();g.rect(342,242,519,617);g.clip();
 for(const m of active){const x=m.you?401:352,w=m.you?441:486;rect(x,y,w,m.h,m.you?'#c6d1c0':m.warn?'#c5c8b6':'#ece9dd',8,'#555b54',1.5);text(m.who,x+14,y+28,20,m.warn?'#586c51':'#59616b',true);
 if(m.meme){text('ONE MORE GAME',x+18,y+66,23,INK,true);ellipse(x+400,y+73,21,21,'#eee7da',INK,2);rect(x+391,y+68,5,10,INK,2,null);rect(x+404,y+68,5,10,INK,2,null);line(x+395,y+85,x+409,y+85,INK,2);text('...3 HOURS LATER',x+18,y+100,20,'#66645c')}
 else if(m.s==='😂')smile(x+42,y+65);
 else wrap(m.s,x+14,y+65,w-28,27,INK);
 if(m.you&&m.at>10&&t>=13.24){rect(x+14,y+m.h-44,83,34,'#d5d5be',12,'#6e7466',1);smile(x+34,y+m.h-27);text('3',x+62,y+m.h-19,22,INK,true)}
 y+=m.h+15;}
 g.restore();rect(350,886,505,43,'#efecdf',18,'#a0a395',1);text(t>=13.24?'SporeLoser has not reacted.':'Message the squad…',367,914,21,'#646c60');rect(529,940,153,4,'#797c71',2,null);
 ellipse(305,744,29,27,'#282830',INK,3);ellipse(902,761,28,26,'#282830',INK,3);g.restore();
}
const cues=[ [.08,1.70,'Five days before the outbreak,'],[1.78,3.55,'the warning arrives between a meme'],[3.58,5.10,'and an argument about pizza.'],[5.25,6.44,'Buy respirators.'],[6.48,7.40,'Spare filters.'],[7.44,8.05,'Water.'],[8.12,9.34,"Don't wait for an announcement."],[9.34,10.72,'You send a laughing emoji.'],[10.74,12.98,'Then you ask whether the filters\nimprove your aim.'],[13.24,14.28,'Three people react.'],[14.38,15,'The man who'] ];
function subtitles(t){const q=cues.find(q=>t>=q[0]&&t<q[1]);if(!q)return;g.font='700 35px "DejaVu Sans",Arial,sans-serif';const lines=q[2].split('\n'),height=lines.length*44+10,max=Math.max(...lines.map(s=>g.measureText(s).width));rect(960-max/2-15,928-height,max+30,height,'#101012',0,null);for(let i=0;i<lines.length;i++){const w=g.measureText(lines[i]).width;text(lines[i],960-w/2,928-height+37+i*44,35,'#f4f1e9',true)}}
function render(t){g.clearRect(0,0,W,H);
 if((t>=3.55&&t<8.12)||(t>=10.74&&t<14.28)){room(t);g.fillStyle='#8c98967a';g.fillRect(0,0,W,H);phoneInsert(t)}
 else{g.save();const medium=t>=8.12;const z=medium?2.17:1.0+.018*t;const cx=960,cy=medium?567:540;g.translate(960,540);g.scale(z,z);g.translate(-cx,-cy);room(t);actor(t);table();g.restore()}
 // The reference has matte colour, fine ink contours, static paper and pencil hatching.
 g.drawImage(paper,0,0);subtitles(t);
}
window.render=render;window.C=canvas;
const fixed=new URLSearchParams(location.search).get('t');let time=0,playing=fixed===null,last;
const button=document.getElementById('play'),seek=document.getElementById('seek');
function update(){seek.value=time;button.textContent=playing?'Pause':'Play';document.getElementById('clock').textContent=time.toFixed(1)+' / 15.0 s'}
button.onclick=()=>{if(time>=D)time=0;playing=!playing;update()};seek.oninput=()=>{time=+seek.value;render(time);update()};document.getElementById('replay').onclick=()=>{time=0;playing=true};
function frame(now){if(last!==undefined&&playing)time=Math.min(D,time+(now-last)/1000);last=now;if(time>=D)playing=false;render(time);update();requestAnimationFrame(frame)}
if(fixed!==null){time=Math.min(D,Math.max(0,+fixed||0));render(time);update()}else requestAnimationFrame(frame);
