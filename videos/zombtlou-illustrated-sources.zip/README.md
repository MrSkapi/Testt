# Illustrated survival story — 15-second style study

Rebuilt from the user's uploaded video reference: flat frontal room staging, dusty blue-grey walls, mustard curtains, muted burgundy sofa, warm wooden floor, thin charcoal contours, pencil hatching and stable paper texture. The protagonist keeps the established teal cap and rust-orange clothing. There are no photographic backgrounds, gradients, lens bloom, deep vignette or blurred foregrounds.

The user-supplied narration is preserved from 00:00 to 00:15 without speed changes. White bold English subtitles on small black rectangles follow the supplied narration. Timing data is in `cues` inside `scene.js`.

Files:
- `illustrated-first15.html`: standalone editable Canvas scene and playback controls; browser preview is silent.
- `scene.js`: drawing functions, stable texture, fixed-length arm solver, phone UI, shot timing, subtitles.
- `build.py`: regenerates the standalone HTML from scene.js.
- `render.mjs`: 24 fps renderer and original-audio muxer. `--preview` renders the first three seconds.

Rendering requires Node.js with built-in WebSocket, Python 3, FFmpeg, and Chromium:
1. Run `python3 build.py` in this directory.
2. Serve this directory: `python3 -m http.server 8765 --bind 127.0.0.1`.
3. Launch headless Chromium with `--remote-debugging-port=9222` and a writable dedicated `--user-data-dir`.
4. Set `NARRATION_FILE` to the local path of ZombTLOU.mp3 and run `node render.mjs`.

The renderer uses 1920×1080, 24 fps, H.264 and AAC. The scene is newly drawn in code; no frames or audio from the style-reference recording are used in the delivered MP4.
