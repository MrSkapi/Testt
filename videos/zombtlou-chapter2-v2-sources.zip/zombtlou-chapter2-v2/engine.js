/* Full chapter animation. Same drawing language and actor construction as the
   approved 30-second test; every shot has its own action controller. */
const SHOTS=DATA.shots;
const PROFILES={
 hero:{top:P.orange,hat:true},daniel:{top:'#c4cdb7',hat:false,hair:'#36302e',daniel:true},
 dad:{top:'#3d6e89',hat:false,hair:'#929b96'},mum:{top:'#a5606d',hat:false,hair:'#514238',female:true},
 girl:{top:'#c5a54c',hat:false,hair:'#594331',female:true},clerk:{top:'#4d8668',hat:false,hair:'#5d4a36'},
 mara:{top:'#b3c9b1',hat:false,hair:'#644d3e',female:true,daniel:true},
 infected:{top:'#bcc6ac',hat:false,hair:'#576154',skin:'#b4c197',daniel:true},
 patient:{top:'#85b2b0',hat:false,hair:'#5b6151',skin:'#b4c197'},driver:{top:'#496f80',hat:false,hair:'#554635'}
};
function activeAt(list,t){let lo=0,hi=list.length-1;while(lo<=hi){const m=(lo+hi)>>1;if(t<list[m].start)hi=m-1;else if(t>=list[m].end)lo=m+1;else return list[m]}return null}
function localTime(t){return Math.max(0,t-(CURRENT_SHOT?.start||0))}
function shadeColor(c,f=.76){const n=parseInt(c.slice(1),16);return '#'+[n>>16,(n>>8)&255,n&255].map(x=>Math.round(x*f).toString(16).padStart(2,'0')).join('')}
function wordPulse(t){const w=activeAt(WORDS,t);return w?Math.sin(Math.PI*clamp((t-w.start)/(w.end-w.start))):0}
function quotedSpeaker(s){
 if(['dadcall','dad'].includes(s.action))return'dad';
 if(['mumcall','mother'].includes(s.action))return'mum';
 if(['sistertalk','sister'].includes(s.action))return'girl';
 if(s.action==='familylaugh')return'all';
 return null;
}
function person(x,ground,s=1,o={}){
 const t=window.T,u=localTime(t),a=CURRENT_SHOT?.action||'',id=o.cast||'hero',pr=PROFILES[id],p=o.pose||'stand';
 let mood=o.expr==='amused'?'amused':['worried','shock','tired'].includes(o.expr)?'concerned':'neutral';
 if(a==='familylaugh')mood='laugh';
 const cycle=.5+.5*Math.sin(u*1.7+(id==='hero'?0:1.6));
 const opts={...pr,mood,look:id==='hero'?[4,5]:[-3,2],head:Math.sin(t*1.1+(id==='girl'?2:0))*.012,
  trim:shadeColor(pr.top),hands:null,lean:0};
 opts.talk=(quotedSpeaker(CURRENT_SHOT||{})===id||quotedSpeaker(CURRENT_SHOT||{})==='all')?wordPulse(t)*.7:0;
 let lh=[-65-3*cycle,-218-3*cycle],rh=[65+4*cycle,-218-3*cycle];
 const walking=['walk','carrywalk'].includes(p),wt=o.time??u;
 if(walking){opts.walk=1;opts.wt=wt;opts.dir=o.dir||1}
 if(['phone','carryphone'].includes(p)){
  opts.phone=true;opts.raise=1;opts.phoneAngle=Math.sin(t*.8)*.025;
  opts.tap=beat(u,1.1,.4)*.7+beat(u,3.2,.4)*.4;
 }
 if(p==='call'){
  lh=[-83,-430];rh=[65+Math.sin(u*1.3)*12,-228-9*cycle];
  opts.held=(L,R)=>phoneBack(L[0]-21,L[1]-39,28,65);
 }
 if(p==='point'||p==='tool'||p==='torch'){
  const q=ease(u/.65);rh=mixp([65,-218],[130,-320],q);
  rh[1]-=Math.sin(u*2)*4;
  if(p==='torch')opts.held=(L,R)=>{
   torch(...R,.8);if(o.beam){path([[R[0]+55,R[1]-10],[R[0]+425,R[1]-80],[R[0]+425,R[1]+80],[R[0]+55,R[1]+10]],'#f5d98430',null)}
  };
  if(p==='tool')opts.held=(L,R)=>{line(...R,R[0]+28,R[1]-20,'#a5b1a2',7);ellipse(R[0]+29,R[1]-21,11,6,'#829b93',P.ink,2)};
 }
 if(['carry','carrywalk','bag'].includes(p)){
  const sway=walking?Math.sin(wt*2*Math.PI/1.3)*1.5:Math.sin(t*1.2)*1.1;
  lh=[-42,-225+sway];rh=[50,-225+sway];
  const kind=p==='bag'?'bag':o.item||'water';
  opts.held=(L,R)=>{
   const xx=(L[0]+R[0])/2-37.5,yy=(L[1]+R[1])/2-5;
   if(kind==='water')water(xx,yy,.98);
   if(kind==='bag')bag(xx-9,yy,.95);
   if(kind==='pot'){
    path([[xx-3,yy],[xx+79,yy],[xx+62,yy+75],[xx+12,yy+75]],'#b27a43',P.ink,3);
    path([[xx+37,yy],[xx+7,yy-68],[xx+39,yy-39],[xx+70,yy-77],[xx+58,yy-13]],'#61935d',P.ink,2);
   }
  };
 }
 if(p==='holdmask'){
  lh=[-35,-278];rh=[42,-278];opts.held=(L,R)=>mask((L[0]+R[0])/2,(L[1]+R[1])/2,.8);
 }
 if(p==='remote'){
  rh=[80,-250-3*cycle];opts.held=(L,R)=>{rect(R[0]-10,R[1]-34,21,60,'#364c56',3,P.ink,2);ellipse(R[0],R[1]-23,3,3,P.yellow,null)};
 }
 if(!opts.phone){
  if(p==='stand'&&['family','dad','sister','mother','sistertalk','showvideo'].includes(a)){
   const talk=quotedSpeaker(CURRENT_SHOT||{})===id,raise=talk?ease(u/.7)*(20+20*cycle):4*cycle;
   rh=[65+raise*.5,-218-raise];
  }
  if(p!=='walk')opts.hands=[lh,rh];
 }
 if(o.hands)opts.hands=[o.hands[0]||lh,o.hands[1]||rh];
 if(id==='infected'||id==='patient'){
  opts.hands=o.hands||[[-75+9*Math.sin(u*2),-304],[110+8*Math.cos(u*2),-325]];
  opts.headX=13;opts.head=.07+Math.sin(u*1.6)*.025;opts.lean=.018;
 }
 if(a==='heavy'){opts.bounce=Math.sin(u*2.7)*1.1;opts.head=.045;opts.mood='concerned'}
 if(a==='reaction'){opts.head=-.015+Math.sin(u*1.4)*.018;opts.phoneAngle=-.035+ease(u/1.2)*.045}
 if(ground>1000&&['girlfit','fitgap'].includes(a)){ground=924;opts.kneel=142}
 actor(x,ground,s,t,opts);
 const actualHands=opts.hands||[[-13,-294],[46,-291]];
 return{left:[x+actualHands[0][0]*s,ground+actualHands[0][1]*s],right:[x+actualHands[1][0]*s,ground+actualHands[1][1]*s]};
}

/* Correct perspective: near-house door is adult-height, near cars are about
   three quarters of an adult's height. Far buildings share their own ground. */
function exterior(t,parents=false){
 g.fillStyle=t>680?'#71899a':'#81a7b0';g.fillRect(-500,-500,W+1000,H+1000);
 rect(-500,640,W+1000,440,'#688762',0,null);
 house(1185,230,.60,true);line(1160,640,1700,640,'#3f695751',7);
 house(-80,-327,1.8,parents);line(-100,887,952,887,'#314f4870',7);
 path([[349,886],[632,886],[889,1080],[390,1080]],'#c1aa7c',P.ink,2);
 rect(925,890,1500,230,'#61777b',0,null);line(926,890,2300,890,'#d2c59d',5);
 car(977,586,2.0);line(851,706,851,886,'#456851',7);rect(812,683,83,50,'#4e8290',8,P.ink,2);text(parents?'12':'7',840,718,23,P.cream,true);
 shakeHatch(10,901,1880,170,95,'#233c3b20');
}
function parking(t){
 g.fillStyle='#80a2ae';g.fillRect(-500,-500,W+1000,H+1000);rect(-500,605,W+1000,475,'#768a70',0,null);
 rect(80,90,1000,570,'#a8b192',3,P.ink,3);rect(129,185,862,185,'#345f68',4,P.ink,2);inkText('SAFETY / HOUSEHOLD',554,292,46,P.cream,'center');
 for(let i=0;i<4;i++){rect(138+i*218,398,184,264,'#5c8d89',2,P.ink,2);line(152+i*218,432,303+i*218,432,'#a7bfa5',2)}
 rect(-500,814,W+1000,400,'#81908a',0,null);line(-100,1017,2100,1017,'#e6d5a6',6);
 car(1022,638,2.0,true);
 for(let i=0;i<3;i++)water(1555+i*87,886,.9);
}
function street(t){
 g.fillStyle='#7e9da9';g.fillRect(-500,-500,W+1000,H+1000);rect(-500,783,W+1000,350,'#657a80',0,null);
 for(let i=0;i<4;i++){
  rect(-100+i*540,-160,515,952,['#b2a47b','#829e93','#688f9e'][i%3],1,P.ink,3);
  for(let j=0;j<2;j++)windowPane(-57+i*540+j*236,75,188,244,false,.08);
  rect(38+i*540,414,192,378,'#416c71',0,P.ink,2);rect(53+i*540,436,161,201,'#81b1b1',0,P.ink,1);ellipse(208+i*540,659,7,7,'#d5c18c',P.ink,1);
 }
 line(-500,796,2500,796,'#cbbfa0',7);for(let i=0;i<6;i++)rect(763+i*99,929,60,100,'#d5ccaa',0,null);
 car(1415,626,1.8);line(698,511,698,913,P.ink,6);rect(674,438,49,100,'#3d6464',8,P.ink,2);ellipse(698,463,11,11,'#c1ba58',P.ink,1);
}
const bgCache=new Map();
function drawBackground(loc,t){
 const night=t>435&&t<483||t>650,parents=loc==='parents'||loc==='parentsdoor';
 const key=loc+'|'+night+'|'+(t>500),cached=bgCache.get(key);
 if(cached){g.drawImage(cached,0,0);}
 else{
  const save=CURRENT_SHOT;CURRENT_SHOT={action:'none'};
  g.save();g.fillStyle='#7e9da1';g.fillRect(-600,-500,W+1200,H+1000);
  if(loc==='workroom')room(t);
  else legacyBackground(loc,t);
  g.restore();CURRENT_SHOT=save;
  const c=document.createElement('canvas');c.width=W;c.height=H;c.getContext('2d').drawImage(C,0,0);bgCache.set(key,c);
 }
 shakeHatch(35,40,1850,550,95,'#223b3c20');shakeHatch(15,828,1880,200,50,'#27372f1a');dust(t,['lab','store'].includes(loc));
}
function worldBackground(loc,t){
 // Cached sets are rendered in world coordinates, before the camera transform.
 const target=g.getTransform();g.setTransform(1,0,0,1,0,0);drawBackground(loc,t);g.setTransform(target);
}
function background(loc,t){drawBackground(loc,t)}

function popItem(at,t,x,y,fn,from=70,hand=false){
 const u=clamp((t-at)/.55);if(!u)return;
 g.save();g.globalAlpha=clamp(u*3);g.translate(x+from*(1-out(u)),y-18*(1-out(u)));fn();g.restore();
 // A cuff and black hand bring the item down onto the table, then withdraw.
 if(hand&&u<1){const q=out(u),hx=x+from*(1-q)+23,hy=y-16*(1-q);
  path([[hx+50,1120],[hx+47,hy+51],[hx+12,hy-2],[hx-12,hy+18],[hx+12,hy+69],[hx-5,1120]],P.orange,P.ink,3);
  ellipse(hx,hy+9,15,16,P.ink,P.ink,1);
 }
}
function tableBase(s,t){
 rect(212,179,1495,733,'#b18352',7,P.ink,3);rect(238,203,1443,684,'#b99162',3,'#805d3d',1.5);
 shakeHatch(244,212,1428,661,180,'#6841252a');
 rect(287,233,1325,88,P.paper,4,P.ink,2);inkText(s.title,323,290,35,'#3a5e58');
}
function paperWrite(s,t,lines=null){
 const u=t-s.start,ls=lines||(s.detail||'Water\nFood\nFilters').split('\n');
 rect(493,343,938,499,P.paper,3,P.ink,3);line(560,385,560,808,'#b6744c77',2);
 let py=425;
 for(let i=0;i<ls.length;i++){
  const q=clamp((u-.2-i*.75)/.7),str=ls[i].slice(0,Math.floor(ls[i].length*q));
  text(str,594,py,32,'#3e675d',true);line(579,py+17,1374,py+17,'#9eac8d60',1);py+=Math.min(104,338/Math.max(1,ls.length-1));
 }
 const row=Math.min(ls.length-1,Math.max(0,Math.floor((u-.2)/.75))),q=clamp((u-.2-row*.75)/.7);
 if(u<ls.length*.75+.65){const yy=425+row*Math.min(104,338/Math.max(1,ls.length-1)),xx=594+Math.min(680,ls[row].length*17*q);
  path([[xx+270,1120],[xx+74,yy+73],[xx+31,yy+23],[xx+7,yy+35],[xx+47,yy+104],[xx+185,1120]],P.orange,P.ink,3);
  ellipse(xx+15,yy+30,19,18,P.ink,null);line(xx+13,yy+34,xx,yy+3,'#b94f35',6);line(xx,yy+3,xx-3,yy-3,P.ink,2);
 }
}
function gearInsert(s,t){
 const a=s.action,u=t-s.start;tableBase(s,t);
 if(['notebook','receipt','motherlist','evidence'].includes(a)){paperWrite(s,t);return}
 const placed=(i,x,y,fn)=>popItem(s.start+.16+i*.63,t,x,y,fn,i%2?90:-90,true);
 if(['mask','counter','pack'].includes(a)){
  if(a==='pack'){
   bag(1154,623,2.0);rect(1163,631,178,72,'#2e4b42',5,P.ink,2);
   for(let i=0;i<3;i++){
    const q=ease((u-.4-i*.7)/.65);const x=lerp(571+i*151,1228+i*9,q),y=lerp(472,690,q);
    if(q<1)popItem(s.start+.1+i*.12,t,x,y,()=>mask(0,0,1.12),-40);
   }
   filter(893,473,1.2);filter(1001,473,1.2);bag(1154,688,2.0);
   inkText('3 RESPIRATORS',497,793,31,'#f1e2b9');
  }else{
   placed(0,666,509,()=>mask(0,0,2.2));placed(1,903,425,()=>filter(0,0,1.7));placed(2,1082,425,()=>filter(0,0,1.7));
   const q=ease((u-1.2)/1.3);line(575,655,575+720*q,655,'#52795d',4);wrap(s.detail||'Correct filters. Individual fit.',524,734,890,31,'#345b50',true);
  }
 }else if(['water','inventoryfull','parentwater','waterplan','calculate'].includes(a)){
  const n=a==='inventoryfull'?6:5;for(let i=0;i<n;i++)placed(i,416+i*180,441+(i%2)*29,()=>water(0,0,1.5));
  if(['waterplan','calculate'].includes(a)){
   popItem(s.start+.6,t,694,656,()=>{rect(0,0,752,159,P.paper,3,P.ink,2);inkText('3 PEOPLE / SEVERAL DAYS',31,53,32,'#3f6858');inkText('ABOUT 1 GALLON EACH DAILY',31,107,29,'#6b7a52')},-40);
  }
 }else if(['food','emptycans','pantry'].includes(a)){
  for(let i=0;i<6;i++)placed(i,438+i*171,443+(i%2)*41,()=>{
   if(a!=='pantry')can(0,0,1.65,a==='emptycans');else{
    rect(9,-13,24,16,'#a9824b',2,P.ink,1);path([[9,2],[0,24],[0,120],[47,120],[47,24],[32,2]],'#3d644a',P.ink,2);rect(1,50,45,40,'#d1c19c',1,P.ink,1);text('WINE',4,75,14,'#556246',true);
   }
  });
  if(a==='food')popItem(s.start+1.9,t,1190,692,()=>{rect(0,0,108,120,'#be8b4f',12,P.ink,2);rect(-2,-14,112,20,'#526c54',4,P.ink,2);text('PEANUT',10,52,20,P.paper,true);text('BUTTER',11,81,20,P.paper,true)},-50);
 }else if(a==='opener'){
  placed(0,680,509,()=>{const angle=-.22+Math.sin(u*3.7)*.16;g.save();g.rotate(angle);line(-50,-35,58,58,'#436b66',24);ellipse(-63,-48,26,26,'#b9c4a4',P.ink,3);line(-45,-48,77,4,'#608d72',17);g.restore()});
  placed(1,1120,426,()=>{rect(0,0,173,209,'#91a67f',17,P.ink,3);line(85,207,145,261,'#365649',5)});
  inkText('MANUAL',614,764,36,'#3c6254');inkText('ELECTRIC',1083,764,36,'#3c6254');
  if(u>1.1){const q=out((u-1.1)/.5);line(1071,801,1071+254*q,701,'#b3543d',5)}
 }else if(a==='tablegear'){
  placed(0,430,468,()=>{radio(0,0,1.7);g.save();g.translate(48,97);g.rotate(ease(u/2)*2);line(-8,0,8,0,P.yellow,3);g.restore()});
  placed(1,833,455,()=>{rect(0,0,170,139,'#d0caa0',10,P.ink,3);line(42,68,125,68,'#b85b45',21);line(84,25,84,111,'#b85b45',21)});
  placed(2,1130,460,()=>filter(0,0,1.5));placed(3,1280,460,()=>filter(0,0,1.5));
 }else if(['bag','keys','takekeys'].includes(a)){
  placed(0,490,425,()=>bag(0,0,2));
  const pickup=a==='takekeys'?ease((u-.25)/.8):0;const xx=lerp(1025,1195,pickup),yy=lerp(571,441,pickup);
  keys(xx,yy,3);phoneBack(1280,466,97,159);
  if(a==='takekeys'){
   const hx=xx+8,hy=yy+10;path([[1390,1110],[1288,820],[hx+15,hy+30],[hx-12,hy+35],[1230,856],[1298,1110]],P.orange,P.ink,4);ellipse(hx,hy,22,21,P.ink,null);keys(xx,yy,3);
  }
 }else if(a==='inventory'){
  placed(0,463,455,()=>bottle(0,0,2));placed(1,585,455,()=>bottle(0,0,2));placed(2,843,566,()=>torch(0,0,1.8));
  placed(3,1120,438,()=>rect(0,0,136,199,'#84a9a8',8,P.ink,3));inkText('DEAD BATTERIES',752,776,33,'#a3543b');
 }else if(a==='handreview'){
  legacyGearInsert(s,t);const q=clamp((u-.3)/1.6);g.beginPath();g.ellipse(920,567,184,138,0,0,Math.PI*2*q);g.strokeStyle='#bb7043';g.lineWidth=5;g.stroke();
 }else legacyGearInsert(s,t);
}

function drawRoute(points,q,color,width){
 const lens=points.slice(1).map((p,i)=>Math.hypot(p[0]-points[i][0],p[1]-points[i][1]));let remain=lens.reduce((a,b)=>a+b,0)*clamp(q);
 for(let i=0;i<lens.length&&remain>0;i++){const frac=Math.min(1,remain/lens[i]),p=mixp(points[i],points[i+1],frac);line(...points[i],...p,color,width);remain-=lens[i]}
}
function mapScene(s,t){
 const u=t-s.start;tableBase(s,t);rect(298,344,1316,502,P.paper,3,P.ink,2);
 if(['map','exposuremap'].includes(s.action)){
  for(let i=0;i<5;i++)for(let j=0;j<3;j++)rect(357+i*240,388+j*128,158,72,'#b9c59b',3,'#779a7d',1.5);
  const pts=[[414,712],[640,712],[640,519],[1054,519],[1054,425],[1451,425]];
  drawRoute(pts,out(u/2.3),'#497b75',13);
  const markers=[[480,701,'FACILITY'],[914,521,'TOWN'],[1339,654,'PARENTS’ JUNCTION']];
  markers.slice(0,s.action==='exposuremap'?3:2).forEach(([x,y,name],i)=>{
   const q=clamp((u-.4-i*.65)/.75);if(!q)return;
   g.beginPath();g.ellipse(x,y,103,62,0,0,Math.PI*2*q);g.strokeStyle=i===2?'#bd643d':'#a0793c';g.lineWidth=4;g.stroke();
   popItem(s.start+.5+i*.65,t,x-78,y+98,()=>inkText(name,0,0,24,'#355e55'),0);
  });
  if(s.action==='exposuremap'){
   const q=out((u-2.3)/1.4);drawRoute([[916,522],[1100,522],[1100,651],[1260,651]],q,'#bd643d',6);
   if(u>3.2){const x=lerp(916,1260,clamp((u-3.2)/2.2));rect(x-25,498,58,29,'#507987',5,P.ink,2);ellipse(x-11,528,7,7,P.ink,null);ellipse(x+16,528,7,7,P.ink,null)}
  }
 }else if(['split','exitplan','distance'].includes(s.action)){
  rect(461,382,818,375,null,3,'#4e7a69',5);line(837,382,837,609,'#4e7a69',4);line(461,605,1108,605,'#4e7a69',4);
  inkText('KITCHEN',493,440,28,'#3b6a5e');inkText('STORE ROOM',898,440,28,'#3b6a5e');inkText('REAR EXIT',497,699,28,'#3b6a5e');
  popItem(s.start+.2,t,541,481,()=>water(0,0,.75),-55);popItem(s.start+.8,t,1013,481,()=>water(0,0,.75),55);
  drawRoute([[791,671],[1352,671]],out((u-.5)/1.4),'#c08938',7);path([[1333,655],[1361,671],[1333,687]],null,'#c08938',4,false);
  if(s.action==='distance')inkText('20 YARDS',930,818,45,'#8d6d36','center');
 }else if(s.action==='calendar'){
  for(let i=0;i<5;i++){
   popItem(s.start+.12+i*.28,t,440+i*222,443,()=>{rect(0,0,171,230,'#d9c99d',5,P.ink,2);rect(0,0,171,46,'#447b79',3,P.ink,1);inkText(String(5-i),85,160,80,'#9e5c37','center')},0);
  }
  popItem(s.start+1.8,t,785,795,()=>inkText('POSSIBLY SOONER',0,0,36,'#9d5139'),0);
 }else if(s.action==='privacy'){
  inkText('PUBLIC POST / PREVIEW',393,414,33,'#355d5b');rect(385,448,1125,219,'#c7cea8',5,'#789c7e',2);text('Family home · location sharing',418,499,29,'#416851',true);
  for(let j=0;j<3;j++)rect(418,541+j*36,780-j*139,10,'#739579',2,null);
  const q=out((u-1.5)/.6);rect(1235,720,231,65,'#a15f42',5,P.ink,2);inkText('CLOSE',1350,764,30,P.cream,'center');
  if(q>0){ellipse(1333,751,20,20,P.ink,null);g.globalAlpha=1-q*.65;line(390,672,390+1106*q,459,'#b55b3c',5);g.globalAlpha=1}
 }else paperWrite(s,t);
}

function screen(s,t){
 const u=t-s.start,span=s.end-s.start;
 g.fillStyle='#19313c5c';g.fillRect(0,0,W,H);
 const prev=SHOTS[Math.max(0,SHOTS.indexOf(s)-1)];
 const globalPush=.045*Math.sin(t*.115),z=1.01+globalPush+.05*clamp(u/Math.min(4,span));
 g.save();g.translate(960,480);g.scale(z,z);g.rotate(-.018+.008*Math.sin(t*.09));g.translate(-960,-480);
 path([[548,1110],[588,751],[652,689],[706,737],[689,1110]],P.orange,P.ink,4);path([[1382,1110],[1349,755],[1290,711],[1239,749],[1273,1110]],P.orange,P.ink,4);
 rect(622,51,682,912,'#1d2f3b',42,P.ink,5);rect(641,72,644,869,'#e4dcca',27,P.ink,2);
 g.save();g.beginPath();g.roundRect(641,72,644,869,27);g.clip();
 rect(641,72,644,130,'#294f63',0,null);rect(838,78,248,17,'#1d2f3b',9,null);
 wrap(s.title,674,144,585,27,P.cream,true,1.1);line(669,184,1253,184,'#89afa2',1);
 shakeHatch(658,213,606,630,70,'#6d60471a');
 const incoming=s.action==='incoming';
 if(incoming){
  c2DadAvatar(t);inkText('DAD',960,497,55,'#2d5c60','center');inkText('INCOMING CALL',960,551,27,'#628678','center');
  for(const [xx,col]of [[818,'#bd624f'],[1093,'#5a9c73']]){const pul=.5+.5*Math.sin(u*5);ellipse(xx,712,46+4*pul,46+4*pul,col,P.ink,2);skCurve([[xx-19,702],[xx-3,723],[xx+6,723],[xx+21,701]],P.cream,7)}
 }else if(s.action==='typing'){
  let str=s.detail||'';
  if(s.id==='s051'){
   const joke='Is this a new game?';str=u<.85?joke.slice(0,Math.floor(joke.length*u/.85)):u<1.25?joke.slice(0,Math.floor(joke.length*(1-(u-.85)/.4))):s.detail.slice(0,Math.floor(s.detail.length*clamp((u-1.25)/1.4)));
  }else str=str.slice(0,Math.floor(str.length*clamp((u-.2)/Math.min(2.6,span*.65))));
  cardEnter(s.start,t,()=>{rect(670,332,588,285,'#cbdcc9',15,'#638c78',2);wrap(str,697,390,531,29,'#345e52',true,1.42)});
  if(u<Math.min(2.9,span*.8))for(let i=0;i<3;i++)ellipse(722+i*24,717-Math.max(0,Math.sin(u*5-i*.5))*6,5,5,'#568e79',null);
  else inkText(s.detail.includes('No answer')?'NO ANSWER':'DRAFT',1185,797,20,'#839a83','right');
 }else{
  const rows=(s.detail||'').split('\n');let yy=233;
  const delays=rows.map((_,i)=>s.start+.13+i*Math.min(1.35,Math.max(.42,span/(rows.length+1))));
  for(let i=0;i<rows.length;i++){
   const str=rows[i],at=delays[i],height=str.includes('@MUSHROOM')?151:Math.max(105,58+Math.ceil(str.length/36)*34);
   const Y=yy;cardEnter(at,t,()=>{
    rect(670,Y,588,height,i%2?'#d1dce0':'#cbdcc9',14,i%2?'#7798a2':'#719579',1.5);
    if(str.includes('@MUSHROOM')){const q=back((t-at)/.5);g.save();g.translate(960,Y+82);g.scale(q,q);g.rotate(Math.sin((t-at)*4)*.025);mushroom(0,0,1.3);g.restore()}
    else{const n=Math.floor(str.length*clamp((t-at)/Math.min(1.2,Math.max(.35,str.length/35))));wrap(str.slice(0,n),694,Y+43,540,27,'#34574d',false,1.34)}
   });yy+=height+17;
  }
  if(s.title.includes('UPLOAD')){
   rect(701,759,517,13,'#b4c7b0',7,null);rect(701,759,517*clamp(u/(span-.2)),13,'#5a9982',7,null);
  }
  if(s.title.includes('UNAVAILABLE')){drawRoute([[886,617],[1016,747]],out((u-.7)/.4),'#b9694a',8);drawRoute([[1016,617],[886,747]],out((u-1.1)/.4),'#b9694a',8)}
 }
 rect(665,859,597,58,'#f2ead9',22,'#a8ada0',1.5);text(incoming?'Swipe to answer':s.action==='typing'?'Message draft…':'Message…',693,896,22,'#77867c');line(889,929,1034,929,'#60777d',5);
 g.restore();ellipse(635,707,36,43,P.ink,P.ink,2);ellipse(1286,740,35,43,P.ink,P.ink,2);
 if(s.action==='typing'){const tap=beat(u,.4,.22)+beat(u,.9,.22)+beat(u,1.5,.22)+beat(u,2.1,.22);ellipse(1253-tap*17,777-tap*45,21,26,P.ink,null)}
 g.restore();
}

function videoFrame(s,t,kind){
 const u=t-s.start,bus=kind==='bus';
 rect(246,91,1428,854,'#274853',21,P.ink,4);rect(269,115,1382,752,'#6e9d93',3,P.ink,2);inkText(s.title,299,161,26,P.cream);
 g.save();g.beginPath();g.rect(290,185,1338,649);g.clip();g.translate(290,185);g.scale(1338/1920,649/1080);
 const a=s.action;
 let focal=bus?{x:1110,y:652,z:1.1}:a==='replay'?{x:1380,y:481,z:2.1}:a==='pullreplay'?{x:790,y:595,z:2.1}:a==='pull'?{x:821,y:658,z:1.45}:a==='impact'?{x:1294,y:514,z:1.6}:a==='harris'?{x:1313,y:523,z:1.5}:{x:1040,y:540,z:1.12};
 if(bus&&s.id==='s066')focal={x:1010,y:677,z:1.4};
 if(bus&&['s067','s068'].includes(s.id))focal={x:1200,y:679,z:1.35};
 const zz=focal.z+.035*clamp(u/Math.max(1,s.end-s.start));
 g.translate(960,540);g.scale(zz,zz);g.translate(-focal.x,-focal.y);
 if(bus){
  street(t);const v=t-294.41;
  const ix=850+Math.min(239,Math.max(0,v)*44);
  person(ix,940,.86,{cast:'patient',pose:v<5?'walk':'point',time:Math.max(0,v)*.75,expr:'shock',hands:v>=5?[[-85,-345],[129,-330]]:null});
  person(1202,940,.85,{cast:'driver',time:t,hands:[[-140+20*Math.sin(v*2),-328],null],expr:'worried'});
  person(1426,940,.86,{cast:'clerk',time:t,hands:[[-135,-330+15*Math.sin(v*2)],null],expr:'worried'});
  // Window bars stay within this saved video, never across the outer room.
  line(21,0,21,1080,'#304b58',24);line(1021,0,1021,1080,'#37546144',13);
  if(v>9)path([[0,900],[1920,900],[1920,1080],[0,1080]],'#4b6264',null);
 }else{
  lab(t);
  g.save();g.beginPath();g.rect(1263,293,271,292);g.clip();
  const hit=['impact','pull'].includes(s.action),cycle=(t-173.89)%1.25,reach=hit?Math.pow(Math.max(0,Math.sin(cycle/1.25*Math.PI*2)),3):.2+.2*Math.sin(u*1.7);
  person(1400-22*ease(u/2),824,.88,{cast:'infected',time:t,hands:[[-80-24*reach,-320-40*reach],[105-42*reach,-310-53*reach]],expr:'shock'});g.restore();
  line(1268,300,1530,582,'#deead32f',3);line(1270,580,1511,309,'#c7e1d52f',2);
  for(let i=0;i<11;i++)line(1270+(i*37)%236,312+(i*79)%246,1281+(i*37)%236,320+(i*79)%246,'#42695b3f',1.5);
  const pulling=['pull','pullreplay'].includes(s.action),shift=pulling?ease(u/1.4)*69:0;
  person(834-shift,905,1,{cast:'daniel',pose:'phone',time:t,expr:'shock'});
  person(641-shift,905,.96,{cast:'mara',time:t,expr:'worried',hands:[[-59,-233],[146+Math.sin(u*10)*(s.action==='pullreplay'?2:0),-334]]});
  if(s.action==='impact'){
   const phase=(t-173.89)%1.25;if(phase>.27&&phase<.58){
    const q=(phase-.27)/.31,L=[-80-24*reach,-320-40*reach],angle=.018;
    const contactX=1400-22*ease(u/2)+.88*(L[0]*Math.cos(angle)-L[1]*Math.sin(angle));
    const contactY=824+.88*(Math.sin(t*2.2)*.9+L[0]*Math.sin(angle)+L[1]*Math.cos(angle));
    g.save();g.beginPath();g.rect(1263,293,271,292);g.clip();g.globalAlpha=1-q;
    ellipse(contactX,contactY,10+32*q,9+28*q,null,'#d4dec4',2);g.restore();
   }
  }
  if(s.action==='replay'){
   const q=clamp(u/1.2);g.beginPath();g.ellipse(1390,448,106,101,0,0,q*Math.PI*2);g.strokeStyle='#c28b42';g.lineWidth=5;g.stroke();
  }
  if(s.action==='videoend'){const q=ease(u/.7);g.fillStyle=`rgba(30,54,59,${q})`;g.fillRect(0,0,W,H);if(q>.7)inkText('VIDEO ENDED',960,540,59,P.cream,'center')}
 }
 g.restore();rect(300,851,1321,7,'#86aa93',4,null);rect(300,851,1321*clamp(u/Math.max(.5,s.end-s.start)),7,'#d5b250',4,null);text(bus?'PUBLIC VIDEO / SAVED COPY':'DANIEL / SAVED VIDEO',300,904,22,'#c3d1b2',true);
}

function familyScene(s,t){
 const a=s.action,u=t-s.start;
 let hx=710,hy=909,heroPose='stand',heroHands=null;
 if(['bagtable','phoneface'].includes(a))hx=a==='bagtable'?820:930;
 if(a==='showvideo')heroPose='phone';
 if(a==='bagtable'){
  const lift=ease(u/.9),release=ease((u-1.0)/.65),L=mixp([36,-240],[36,-302],lift),R=mixp([94,-240],[94,-302],lift);
  const lh=mixp(L,[-65,-218],release),rh=mixp(R,[65,-218],release);
  actor(hx,hy,.94,t,{...PROFILES.hero,hands:[lh,rh],mood:'concerned',look:[5,5],held:u<1.05?(l,r)=>bag(16,-240-62*lift,.94):null});
  if(u>=1.05)bag(835,625,.884);
 }else if(a==='phoneface'){
  const q=ease(u/1.0);actor(hx,hy,.94,t,{...PROFILES.hero,hands:[[-65,-224],[lerp(46,59,q),lerp(-291,-210,q)]],mood:'concerned',held:(l,r)=>{
   g.save();g.translate(...r);g.rotate(lerp(-.1,Math.PI/2,q));phoneBack(-6,-30,40,69);g.restore();
  }});
 }else person(hx,hy,.94,{pose:heroPose,time:t,expr:a==='familylaugh'?'amused':'worried'});
 if(!['sister','sisterpeek','schoolbag'].includes(a))person(1161,911,.91,{cast:'dad',pose:a==='dad'?'remote':'stand',time:t,expr:a==='familylaugh'?'amused':'worried'});
 person(1490,913,.86,{cast:'mum',pose:a==='motherlist'?'point':'stand',time:t,expr:a==='familylaugh'?'amused':'worried'});
 if(['sister','family','familylaugh','schoolbag','sisterpeek'].includes(a)){
  const x=a==='sisterpeek'?1690-u*66.666*.63:1324;
  person(x,924,.63,{cast:'girl',pose:a==='sisterpeek'?'walk':a==='schoolbag'?'bag':'stand',dir:-1,time:a==='sisterpeek'?u:t,expr:a==='familylaugh'?'amused':'worried'});
 }
 if(a==='showvideo'){
  rect(914,619,270,149,'#315c65',9,P.ink,2);rect(928,632,242,110,'#8eb8a2',2,P.ink,1);text('SAVED VIDEO',945,667,21,'#345c5c',true);line(945,710,945+209*clamp(u/Math.max(.5,s.end-s.start)),710,'#ba9943',5);
 }
 if(a==='watercarry')person(334+u*66.666*.85,916,.85,{cast:'dad',pose:'carrywalk',time:u,item:'water'});
}

function sceneDraw(s,t){
 const a=s.action,u=t-s.start;
 if(['screen','typing','incoming'].includes(a)){screen(s,t);return}
 if(['labvideo','harris','impact','pull','pullreplay','replay','videoend'].includes(a)){videoFrame(s,t,'lab');return}
 if(['busvideo','busafter'].includes(a)){videoFrame(s,t,'bus');return}
 if(['map','split','exitplan','distance','privacy','evidence','exposuremap','calendar'].includes(a)){mapScene(s,t);return}
 if(['mask','counter','pack','water','food','opener','receipt','notebook','tablegear','inventory','inventoryfull','emptycans','handreview','motherlist','waterplan','calculate','pantry','bag','keys','takekeys','parentwater','shelves'].includes(a)){gearInsert({...s,action:a==='shelves'?'parentwater':a},t);return}
 if(['family','bagtable','familylaugh','dad','sister','sisterpeek','showvideo','phoneface','schoolbag','watercarry','mother'].includes(a)&&s.location==='parents'){familyScene(s,t);return}
 if(a==='fitting'){
  const removing=s.id==='s063',q=removing?ease(u/.8):0,lift=removing?ease((u-1.2)/.8):0;
  const lh=mixp([-35,-278],[-35,-407],lift),rh=removing?mixp(mixp([38,-437],[115,-319],q),[42,-407],lift):[42,-278];
  actor(797,894,1.05,t,{...PROFILES.hero,hands:[lh,rh],mood:'neutral',look:[2,5],heldFront:(L,R)=>{
   mask(4,lerp(-278,-407,lift),.8);
   if(removing&&u<1.2){g.save();g.globalAlpha=1-ease((u-.9)/.3);g.translate(R[0]-38,R[1]-3);rect(-28,-3,24,17,P.ink,4,null);rect(4,-3,24,17,P.ink,4,null);line(-4,3,4,3,P.ink,3);g.restore()}
  }});
  person(1190,887,1,{cast:'clerk',pose:'point',time:t});return;
 }
 if(a==='culture'){
  person(861,910,1,{cast:'daniel',pose:'point',time:t,expr:'worried'});
  const q=out(u/.6);rect(1088,298,606,401,P.paper,5,P.ink,3);inkText('INCIDENT REPORT',1122,353,32,'#355d59');
  ['CONFUSION','AGGRESSION','BITING'].forEach((v,i)=>popItem(s.start+.15+i*.8,t,1123,422+i*80,()=>inkText(v,0,0,31,i===2?'#a85339':'#466c57'),0));
  drawRoute([[1119,665],[1601,665]],out((u-3)/1.5),'#bb8343',5);return;
 }
 if(a==='tap'){
  water(514,642,.45);const q=.4+.6*Math.sin(u*8)**2;line(531,630,531,637,'#b9dbe7',3);ellipse(531,640,4+q*2,1.7,'#dae4c3',null);
  person(640,890,.85,{time:t,hands:[[-128,-288+Math.sin(u*2)*3],null]});return;
 }
 if(a==='extinguisher'){
  const move=ease(u/1.1),release=ease((u-1.3)/.6),hand=mixp([60,-230],[130,-340],move);
  function fire(x,y){rect(x-17,y+17,35,95,'#bd513c',8,P.ink,2);rect(x-7,y+1,14,19,'#546f5f',2,P.ink,1.5);line(x-14,y,x+18,y,'#485e53',5);rect(x-11,y+46,23,28,P.paper,2,P.ink,1);skCurve([[x+16,y+22],[x+44,y+29],[x+40,y+65],[x+35,y+87]],P.ink,4)}
  actor(920,910,1,t,{...PROFILES.hero,hands:[[-65,-218],mixp(hand,[65,-218],release)],mood:'neutral',held:u<1.3?(L,R)=>fire(...R):null});
  if(u>=1.3)fire(1050,570);paperCard(1136,329,361,123,'KEEP ACCESS CLEAR',[]);return;
 }
 if(a==='door'){
  const q=lerp(.35,1,ease(u/1.1));rect(1703,294,143,518,'#315b58',0,P.ink,2);
  const left=1846-143*q;path([[left,294],[1846,294],[1846,812],[left,812]],'#a68a53',P.ink,2);const knob=1846-124*q;ellipse(knob,569,7,7,'#496c57',P.ink,1);
  person(1630,890,.9,{hands:[null,[(knob-1630)/.9,(569-890)/.9]],time:t,expr:'worried'});return;
 }
 if(a==='repair'||a==='gate'){
  const q=a==='repair'?Math.sin(u*5):0,hand=[130,-340+q*9];
  person(940,890,.8,{pose:a==='repair'?'tool':'stand',hands:[[-65,-232],hand],time:t,expr:'worried'});
  rect(1052,587,32,33,'#657b57',2,P.ink,2);if(a==='repair'&&q<-.5){const r=(q+.5)*-4;ellipse(1067,602,10+r,9+r,null,'#d9c27b',1.5)}return;
 }
 if(a==='blind'){
  const q=ease(u/1.8);windowPane(180,190,420,350,true,q);line(620,211,620,560+60*q,P.ink,2);ellipse(620,566+60*q,4,7,'#a29354',P.ink,1);
  person(774,912,.95,{hands:[[(620-774)/.95,(566+60*q-912)/.95],null],time:t,expr:'worried'});return;
 }
 if(a==='arrival'){
  const q=ease(u/.9);rect(782,247,295,568,'#476b63',0,P.ink,2);const edge=782+295*(1-.65*q);path([[782,247],[edge,247+31*q],[edge,815+31*q],[782,815]],'#a58653',P.ink,3);
  person(620+u*66.666*.86,902,.86,{pose:'carrywalk',item:'bag',time:u});person(1134,887,.92,{cast:'dad',pose:'remote',time:t});return;
 }
 if(a==='delivery'){
  person(1170+u*66.666*.78,905,.78,{cast:'driver',pose:'walk',time:u});person(1632,905,.72,{cast:'clerk',time:t});return;
 }
 if(a==='touch'||a==='sistertalk'||a==='hand'){
  person(900,910,.95,{time:t,expr:'worried'});
  const girl=a!=='touch',x=a==='touch'?1115:a==='hand'?1047:1230,ss=girl?.62:.89;
  let target=a==='touch'?[-181,-314]:a==='hand'?[-154,-338]:null;
  if(target){const q=ease(u/.7);target=mixp([-65,-218],target,q)}
  person(x,915,ss,{cast:girl?'girl':'mum',time:t,hands:target?[target,null]:null,expr:'worried'});return;
 }
 if(a==='mother'&&s.location==='parentsdoor'){
  person(900,910,.95,{time:t,expr:'worried'});person(1115,915,.89,{cast:'mum',pose:'point',time:t,expr:'worried'});return;
 }
 if(a==='drive'){
  rect(188,183,1545,619,'#365965',21,P.ink,4);rect(221,218,1479,444,'#7fa2a6',9,P.ink,3);
  g.save();g.beginPath();g.rect(225,222,1470,435);g.clip();path([[811,220],[1104,220],[1573,660],[343,660]],'#526c76',null);
  for(let j=0;j<6;j++){const y=225+(j*94+u*112)%560;rect(926,y,31+(y-225)*.06,37+(y-225)*.04,'#e0d4a9',0,null)}g.restore();
  rect(268,678,1380,177,'#3d5a63',9,P.ink,2);ellipse(608,759,104,73,null,'#203d4a',20);phoneBack(1265,710,70,109);return;
 }
 if(a==='neighbor'||a==='neighborhelp'){
  person(1440,925,.86,{cast:'driver',time:t,expr:'worried',hands:[[-61,-218],[64,-219]]});
  if(a==='neighborhelp')person(1190+u*66.666*.82,925,.82,{cast:'clerk',pose:'walk',time:u,expr:'worried'});return;
 }
 legacyAction(s,t);
}

const INSERTS=new Set(['screen','typing','incoming','map','split','exitplan','distance','privacy','evidence','exposuremap','calendar','mask','counter','pack','water','food','opener','receipt','notebook','tablegear','inventory','inventoryfull','emptycans','handreview','motherlist','waterplan','calculate','pantry','bag','keys','takekeys','parentwater','shelves','labvideo','harris','impact','pull','pullreplay','replay','videoend','busvideo','busafter']);
function sceneCamera(s,t){
 const i=SHOTS.indexOf(s),u=t-s.start,d=s.end-s.start;
 let first=i,last=i;
 while(first>0&&SHOTS[first-1].location===s.location&&INSERTS.has(SHOTS[first-1].action)===INSERTS.has(s.action))first--;
 while(last+1<SHOTS.length&&SHOTS[last+1].location===s.location&&INSERTS.has(SHOTS[last+1].action)===INSERTS.has(s.action))last++;
 const start=SHOTS[first].start,end=SHOTS[last].end,q=clamp((t-start)/(end-start));
 if(INSERTS.has(s.action))return{z:1.01+.035*q,cx:960+Math.sin(t*.09)*8,cy:535};
 if(s.action==='dad')return{z:1.55+.07*q,cx:1140+Math.sin(t*.07)*10,cy:654};
 if(s.action==='heavy')return{z:1.35+.06*q,cx:1053,cy:714};
 if(['sistertalk','hand','touch'].includes(s.action))return{z:1.38+.05*q,cx:1040,cy:654};
 if(s.action==='phone'&&['workroom','bedroom','kitchen'].includes(s.location))return{z:1.32+.07*q,cx:969,cy:635};
 const right=['parents','garden','lab'].includes(s.location),z=1.035+.12*q;
 const margin=960-960/z;
 return{z,cx:Math.min(960+margin-4,960+(right?35:0)+40*q),cy:540+12*q};
}
function fullKaraoke(t){
 const c=activeAt(CAPTIONS,t);if(!c)return;
 g.save();let size=c.words.length>5?67:73;g.font=`700 ${size}px Fredoka,"DejaVu Sans",sans-serif`;
 let widths=c.words.map(w=>g.measureText(w.text.toUpperCase()).width),space=g.measureText(' ').width,total=widths.reduce((a,b)=>a+b,0)+(widths.length-1)*space;
 if(total>1740){const f=1740/total;size*=f;g.font=`700 ${size}px Fredoka,"DejaVu Sans",sans-serif`;widths=c.words.map(w=>g.measureText(w.text.toUpperCase()).width);space=g.measureText(' ').width;total=widths.reduce((a,b)=>a+b,0)+(widths.length-1)*space}
 let x=(W-total)/2;const active=c.words.findIndex(w=>t>=w.start&&t<w.end),rise=6*(1-out((t-c.start)/.12));
 g.lineJoin='round';g.lineWidth=11;g.strokeStyle='#20242a';g.shadowColor='#111c2560';g.shadowOffsetY=4;
 for(let i=0;i<c.words.length;i++){const str=c.words[i].text.toUpperCase();g.strokeText(str,x,987+rise);g.fillStyle=i===active?P.yellow:'#f4f1e9';g.fillText(str,x,987+rise);x+=widths[i]+space}g.restore();
}
function karaoke(t){fullKaraoke(t)}
window.renderErrors=[];
const sceneBackdrop=document.createElement('canvas');sceneBackdrop.width=W;sceneBackdrop.height=H;
const sceneBG=sceneBackdrop.getContext('2d');
function render(t){
 if(stateDepth!==0)throw Error('Unbalanced frame start '+stateDepth);
 t=Math.min(D-.00001,Math.max(0,t));window.T=t;g.save();g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,W,H);
 try{
  CURRENT_SHOT=activeAt(SHOTS,t);
  if(t<3.12)opening(t);
  else if(t<5.2)chatBase(t,'early');
  else if(t<9.3)chatBase(t,'warning');
  else if(t<10.72)reaction(t);
  else if(t<14.35)chatBase(t,'reply');
  else if(t<18.05)chatBase(t,'profile');
  else if(t<21.25)identity(t);
  else if(t<24.8)labAction(t);
  else if(t<27)macro(t);
  else if(t<34.13)returnRoom(t);
  else{
   const s=CURRENT_SHOT,cam=sceneCamera(s,t);
   const videoActions=['labvideo','harris','impact','pull','pullreplay','replay','videoend'],isBus=['busvideo','busafter'].includes(s.action);
   const setLocation=videoActions.includes(s.action)?'workroom':isBus?'parking':s.location;
   // Cache only the set, with an identity transform. It then moves as a whole
   // under the camera, preserving house/car/person scale and contact points.
   g.save();drawBackground(setLocation,t);g.restore();
   sceneBG.clearRect(0,0,W,H);sceneBG.drawImage(C,0,0);
   camera(cam.cx,cam.cy,cam.z,()=>{
    g.fillStyle='#71939b';g.fillRect(-300,-300,W+600,H+600);g.drawImage(sceneBackdrop,0,0);
    sceneDraw(s,t);
   });
  }
  if(stateDepth!==1)throw Error('Unbalanced scene state '+stateDepth);
  finish(t);
 }catch(e){window.renderErrors.push({t,id:CURRENT_SHOT?.id,error:String(e)});throw e}finally{g.restore()}
}
window.C=canvas;
