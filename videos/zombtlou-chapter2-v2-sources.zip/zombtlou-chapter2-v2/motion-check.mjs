import fs from 'node:fs';import {connect} from './cdp.mjs';
const {cmd,ws}=await connect(9261),ranges=[[190.51,192.87],[196.11,205],[209.36,212.03],[216.76,224.07],[229.48,245.31],[245.31,265.0],[339.91,341.51],[352.03,355.0],[370.95,384.0],[400.03,417.6]],errors=[];
let n=0;for(const [a,b] of ranges)for(let t=a+.01;t<b;t+=.125){const r=await cmd('Runtime.evaluate',{expression:`render(${t})`,returnByValue:true});n++;if(r.exceptionDetails){errors.push({t,error:r.exceptionDetails.exception.description.split('\n')[0]});await cmd('Runtime.evaluate',{expression:'while(stateDepth>0)g.restore()'});}}
fs.writeFileSync('qc/motion-check.json',JSON.stringify({samples:n,errors},null,2));console.log('Motion samples',n,'errors',errors);ws.close();
