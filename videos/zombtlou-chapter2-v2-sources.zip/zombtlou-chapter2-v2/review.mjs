import fs from 'node:fs';import {connect} from './cdp.mjs';
fs.mkdirSync('qc',{recursive:true});
const {cmd,ws}=await connect(+(process.env.CDP_PORT||9260));
const data=JSON.parse(fs.readFileSync('timeline.json','utf8'));
let times=process.argv.slice(2).map(Number);
if(!times.length)times=data.shots.flatMap(s=>[s.start+.03,s.start+(s.end-s.start)*.52,s.end-.03]);
const errors=[];let j=0;
for(const t of times){
 const r=await cmd('Runtime.evaluate',{expression:`render(${t});C.toDataURL('image/jpeg',.90)`,returnByValue:true});
 if(r.exceptionDetails){errors.push({t,error:r.exceptionDetails});await cmd('Runtime.evaluate',{expression:'while(stateDepth>0)g.restore()'});continue}
 const s=data.shots.find(s=>t>=s.start&&t<s.end);
 const tag=String(j).padStart(3,'0');fs.writeFileSync(`qc/${tag}-${s?.id||'intro'}-${t.toFixed(2)}.jpg`,Buffer.from(r.result.value.split(',')[1],'base64'));
 if(++j%24===0)console.log('REVIEW',j,'/',times.length,'t',t.toFixed(2));
}
const q=await cmd('Runtime.evaluate',{expression:'JSON.stringify({audit,errors:window.renderErrors,stateDepth})',returnByValue:true});console.log(q.result.value,errors);fs.writeFileSync('qc/review-audit.json',JSON.stringify({runtime:q.result.value,errors},null,2));ws.close();if(errors.length)process.exitCode=1;
