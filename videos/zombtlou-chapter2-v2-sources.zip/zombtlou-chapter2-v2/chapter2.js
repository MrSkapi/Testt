/* Chapter 2: rescue, the return, and an uncertain exposure. All actor and prop
   motion is evaluated in the original narration's timebase. */
const C2={floor:960,mask:78.70,home:417.60,food:437.80,dawn:467.10};
const LAD={x:980,y:960,angle:-1.42,length:620,width:44};
const firstShot=a=>SHOTS.find(s=>s.action===a);
const at=a=>firstShot(a)?.start||0;
const phase=(t,start,d)=>clamp((t-start)/Math.max(.001,d));
const done=(t,a,d=.8)=>ease((t-a)/d);
const black='#24272c';
function c2Actor(id,x,ground,s,t,o={}){
 const shot=CURRENT_SHOT||{},isFlash=shot.flashback,pr=PROFILES[id]||PROFILES.hero;
 let masked=o.mask??(id==='girl'?t<C2.food:id==='hero'?t>=C2.mask:false);
 if(isFlash&&['dadprotect'].includes(shot.action))masked=id==='girl';
 const opts={...pr,trim:shadeColor(pr.top),mood:'concerned',head:0,naturalArms:true,backpack:id==='hero'&&t>=102.83&&t<C2.home,look:[id==='hero'?4:-3,3],...o};
 if(opts.walk){opts.stride=1.6;opts.wt=(o.wt??t)/1.6;}
 if(shot.speaker===id&&!masked)opts.talk=wordPulse(t)*.6;
 const front=o.heldFront;
 opts.heldFront=(L,R)=>{
  if(masked)mask(0,-407,.8);
  if(id==='hero'&&t>=at('latchcut')){
   if(t>=C2.home&&!(shot.flashback&&t>500)){g.save();g.translate(...R);g.rotate(-.35);rect(-6,-7,12,14,'#d4c7a4',2,black,1);g.restore()}
   else line(R[0]-4,R[1]-3,R[0]+4,R[1]+3,'#9d4938',2);
  }
  if(o.bloodSleeve){const p=mixp([-48,-359],L,.79);line(p[0]-4,p[1]-5,p[0]+6,p[1]+4,'#733c37',8)}
  if(front)front(L,R);
 };
 const pose=actor(x,ground,s,t,opts);if(window.poseFrames)window.poseFrames.push({id,x,y:ground,scale:s,...pose});
}
function phoneEar(id,x,y,s,t,o={}){
 c2Actor(id,x,y,s,t,{hands:[[-83,-430],[66,-226]],look:[-3,1],held:(L,R)=>phoneBack(L[0]-21,L[1]-39,28,65),...o});
}
function worldHands(x,y,s,targets,lean=0,extra=0){
 const by=Math.sin(window.T*2.2)*.9+extra,c=Math.cos(lean),sn=Math.sin(lean);
 return targets.map(p=>{if(!p)return null;const dx=(p[0]-x)/s,dy=(p[1]-y)/s-by;return[dx*c+dy*sn,-dx*sn+dy*c]});
}
function goActor(id,x,y,s,t,start,dir=1,fast=false,o={}){
 const period=fast?.70:1.3,v=52/(period*.6);
 c2Actor(id,x+dir*(t-start)*v*s,y,s,t,{walk:1,wt:t-start,period,dir,...o});
}
function firstAid(x,y,s=1,open=false){g.save();g.translate(x,y);g.scale(s,s);rect(-49,-30,98,72,'#d8d1ad',8,black,2);rect(-12,-43,25,15,null,3,black,3);line(-23,3,23,3,'#ba5944',13);line(0,-20,0,26,'#ba5944',13);if(open){g.save();g.translate(0,-30);g.rotate(-.6);rect(-48,-46,96,46,'#a3b6a1',5,black,2);g.restore();ellipse(74,21,19,12,'#ded4b2',black,1.5);line(58,34,92,42,'#b5b797',7)}g.restore()}
function coat(x,y,s,col,blood=false){g.save();g.translate(x,y);g.scale(s,s);path([[-39,-60],[-65,-39],[-98,23],[-73,37],[-43,-8],[-47,89],[48,89],[43,-8],[72,39],[98,23],[65,-39],[37,-60]],col,black,3);line(1,-39,1,84,shadeColor(col),3);if(blood)ellipse(-70,26,12,7,'#6b3935',null);g.restore()}
function palm(x,y,s=1,o={}){
 g.save();g.translate(x,y);g.scale(s,s);ellipse(0,18,68,70,black,black,3);
 for(let i=0;i<4;i++){const xx=-43+i*28;line(xx,1,xx,-76+(i===0?16:0),black,23)}
 line(-48,31,-89,-6,black,27);rect(-46,65,91,125,o.cuff||P.orange,5,black,3);
 if(o.fingerCut){ellipse(39,-66,8,10,'#b9b49e',null);line(44,-62,51,-55,'#a7503d',3)}
 if(o.cut)line(-25,20,24,2,'#a6513e',6);
 if(o.bandage){g.save();g.rotate(-.38);rect(-40,1,81,48,'#d8cba9',5,black,2);rect(-18,8,36,35,'#b8b59b',3,'#8f9580',1);g.restore()}
 if(o.stain)ellipse(-22,106,22,12,'#6b3835',null);g.restore();
}
function ladder(x,y,L=LAD.length,angle=LAD.angle,width=LAD.width){
 g.save();g.translate(x,y);g.rotate(angle);for(const yy of [-width/2,width/2]){line(0,yy,L,yy,black,12);line(0,yy,L,yy,'#bda47a',7)}
 for(let d=32;d<L-12;d+=32){line(d,-width/2,d,width/2,black,9);line(d,-width/2,d,width/2,'#d5bb8a',5)}g.restore();
}
function lp(h,side=0){return[LAD.x+Math.cos(LAD.angle)*h-Math.sin(LAD.angle)*side,LAD.y+Math.sin(LAD.angle)*h+Math.cos(LAD.angle)*side]}
function rung(h,leg,offset){const z=h/64+leg*.5,c=Math.floor(z),q=z-c;return c*64+offset-leg*32+(q>.58?64*ease((q-.58)/.42):0)}
function climber(id,h,t,o={}){
 const s=id==='girl'?.454:.72,side=id==='girl'?18:-32,lean=id==='girl'?.07:-.09,root=lp(h);root[0]+=side;
 const feet=[0,1].map(i=>{const p=lp(rung(h,i,32),i?10:-10);return[(p[0]-root[0])/s,(p[1]-root[1])/s]});
 const handOffset=id==='girl'?160:256;
 const wh=[0,1].map(i=>{const H=rung(h,i,handOffset),p=lp(Math.min(LAD.length,H),i?19:-19),over=clamp((H-LAD.length)/64);
  const frame=id==='girl'?[1090+(i?8:-8),root[1]-350*s+(i?15:0)]:[i?1090:948,root[1]-350*s];return p;
 });
 if(o.worldHands){wh[0]=o.worldHands[0]||wh[0];wh[1]=o.worldHands[1]||wh[1]}
 const hands=worldHands(...root,s,wh,lean,-Math.sin(t*2.2)*.9+16);
 c2Actor(id,root[0],root[1],s,t,{feet,hands,lean,still:true,bounce:16,look:[id==='girl'?-3:3,5],...o});
 return{root,feet,hands,worldHands:wh};
}
function descentH(t){
 const begin=at('descend'),stop=at('descentstop'),resume=SHOTS.find(s=>s.action==='descend'&&s.start>stop).start,end=at('ladderoff');
 if(t<stop)return lerp(400,300,phase(t,begin,stop-begin));
 if(t<resume)return 300;
 return lerp(300,0,phase(t,resume,end-resume));
}
function windowActors(t,o={}){
 const seated=o.seated??t>=at('girlsit'),gy=seated?450:370;
 g.save();g.beginPath();g.rect(936,44,311,326);if(seated)g.rect(935,350,320,165);g.clip();
 const hands=o.hands|| (seated?[[-80,-224],[38,-319]]:[[-65,-220],[65,-220]]);
 c2Actor('girl',1065,gy,.454,t,{hands,mask:true,mood:o.cry?'concerned':'neutral',cry:!!o.cry,bloodSleeve:t>at('takehand'),...o});g.restore();
}
function smallDoor(x,y,w,h,q=0,col='#a18352'){
 rect(x,y,w,h,'#243d45',0,black,3);const ww=w*(1-.72*q);path([[x,y],[x+ww,y+25*q],[x+ww,y+h+25*q],[x,y+h]],col,black,3);ellipse(x+ww-26,y+h*.52+14*q,7,7,'#d2b574',black,1);
}
function nightFloor(wall='#527b83',low='#305a67',floorCol='#9c7b54'){
 g.fillStyle=wall;g.fillRect(-500,-500,W+1000,H+1000);rect(-500,515,W+1000,405,low,0,null);rect(-500,921,W+1000,500,floorCol,0,null);line(-500,920,2500,920,'#b2ae8c',5);
 for(let i=0;i<8;i++)line(i*280,923,i*290-100,1150,'#493f3333',1.5);
}
function shutter(q,keepGlass=false){
 if(!keepGlass)rect(194,204,393,319,'#203746',0,black,2);const hh=319*q;rect(194,204,393,hh,'#537782',0,black,2);
 for(let yy=213;yy<204+hh;yy+=18){line(199,yy,581,yy,'#2d505e',2);line(200,yy+3,580,yy+3,'#95aaa466',1)}line(195,204+hh,586,204+hh,'#b4b7a2',5);
}
function homeSet(t){
 kitchen(700,false);rect(1686,275,177,537,'#42646b',0,black,2);rect(1699,307,150,456,'#9b8860',2,black,2);line(1699,512,1848,512,'#36555b',15);rect(1762,497,30,32,'#a7af92',2,black,2);
 const q=t<at('shadowrun')?.5:t<at('shutterclose')?.58:t<at('callhero')?lerp(.58,1,phase(t,at('shutterclose'),at('callhero')-at('shutterclose'))):1;
 shutter(q);water(1120,836,.85);water(1215,836,.85);can(1100,656,.9);can(1180,656,.9);
 path([[350,523],[790,919],[1190,919],[470,523]],'#e6b45709',null);
}
function gardenSet(t){
 g.fillStyle='#253f57';g.fillRect(-500,-500,W+1000,H+1000);rect(-500,885,W+1000,500,'#456d59',0,null);
 rect(608,-175,1230,1130,'#8c987d',2,black,4);for(let yy=-165;yy<955;yy+=55)line(612,yy,1836,yy,'#58766866',1.5);
 rect(924,30,335,350,'#d9c79d',2,black,4);rect(938,44,307,326,'#ac9870',0,black,2);
 rect(711,555,330,286,'#d3c39a',1,black,3);rect(725,569,302,258,'#bbab7c',0,black,2);line(877,570,877,825,'#617a70',7);
 rect(1378,475,267,480,'#c4b68f',1,black,3);smallDoor(1393,490,237,465,0,'#8e7452');
 line(593,958,1853,958,'#263f3d88',7);path([[690,960],[1110,960],[1310,1120],[510,1120]],'#9c9472',black,2);
 // Shed and fence establish an actual footing and distinct depth planes.
 rect(35,590,442,365,'#8c6a46',1,black,3);path([[12,590],[260,493],[497,590]],'#405b58',black,3);for(let i=0;i<8;i++)line(48+i*54,599,48+i*54,950,'#5d523a',2);
 rect(167,675,184,280,'#776346',0,black,2);ellipse(317,815,6,6,'#c7b683',black,1);
 for(let i=0;i<6;i++)ellipse(190+i*280,947,70,19,'#244b4655',null);
}
function windowPaneC2(t,open=0){
 g.save();const c=1-.78*open;rect(938,44,153*c,326,'#7ca5ad22',0,'#d9c99e',6);
 line(946,203,938+153*c-8,203,'#d2c29b',5);line(938+153*c-12,252,938+153*c-12,278,'#4f675c',4);
 rect(1091,44,153,326,'#80a9ae16',0,'#d9c99e',6);line(1091,203,1244,203,'#d2c29b',5);g.restore();
}
function sisterSet(t){
 nightFloor('#807b70','#5c7569','#a4895b');smallDoor(153,227,280,693,0,'#8b7252');
 rect(521,663,690,180,'#705d66',9,black,3);line(559,843,559,920,'#594d46',13);line(1173,843,1173,920,'#594d46',13);rect(537,625,655,94,'#af9b82',12,black,2);rect(570,642,218,62,'#d8cdb3',13,black,2);path([[800,649],[1190,649],[1190,785],[810,767]],'#6d8c87',black,2);
 windowPane(1290,153,430,431,true,.05);rect(638,205,378,235,'#a7a37a',3,black,2);inkText('WEEKEND RAID',827,253,30,'#3d615a','center');
 for(let i=0;i<5;i++)line(679,300+i*20,930-i*25,300+i*20,'#678269',3);
 rect(1566,638,245,281,'#55796d',3,black,3);rect(1584,656,209,105,'#7b9680',1,black,1.5);line(1663,690,1720,690,black,3);
}
function hallSet(t){
 nightFloor('#6f8c85','#365f68','#91754f');smallDoor(185,229,426,692,0,'#8c6b49');
 rect(790,186,598,734,'#354b50',0,black,4);rect(816,208,548,712,'#506762',0,black,2);rect(852,278,472,432,'#576f67',0,black,2);
 // The hallway cabinet rests across the doorway, not in mid-air.
 rect(737,580,713,337,'#866c48',4,black,4);rect(760,603,667,287,'#a48755',3,black,2);for(let i=0;i<3;i++){rect(777+i*213,619,191,254,'#96784e',2,'#624e37',1.5);ellipse(947+i*213,727,5,5,black,null)}
 rect(1519,290,263,381,'#a69a73',3,black,2);inkText('HOME',1650,350,34,'#496a59','center');firstAid(1620,880,.9,true);
}
function fenceSet(t,lights=true){
 g.fillStyle='#263f55';g.fillRect(-500,-500,W+1000,H+1000);rect(-500,862,W+1000,500,'#58716c',0,null);
 for(let i=0;i<5;i++){rect(-100+i*468,212,445,650,['#6c887c','#496e78','#847e61'][i%3],1,black,3);rect(-62+i*468,317,368,545,'#3c6069',1,black,2);for(let j=0;j<6;j++)line(-54+i*468,335+j*78,297+i*468,335+j*78,'#8aa09255',2)}
 for(let x=24;x<W;x+=260){line(x,371,x,914,'#243d49',6);line(x,386,x+180,414,'#4f7678',2)}
 line(0,908,1920,908,'#9ca583',3);
 if(lights){rect(878,235,90,28,'#b8aa71',4,black,2);path([[879,263],[651,918],[1207,918],[966,263]],'#e3ba4e12',null);ellipse(923,256,39,14,'#f4d17e22',null)}
}
function van(x,y,s=1){g.save();g.translate(x,y);g.scale(s,s);path([[0,107],[67,0],[700,0],[891,112],[951,337],[951,483],[0,483]],'#466d7b',black,4);rect(79,27,595,186,'#86a5a7',8,black,3);path([[703,29],[864,128],[905,215],[703,215]],'#8aa7a5',black,3);line(686,19,686,471,black,3);line(719,267,774,267,'#c5c29f',7);for(const xx of [167,781]){ellipse(xx,478,72,72,black,black,3);ellipse(xx,478,39,39,'#82978c',black,2)}g.restore()}
function busSet(t){fenceSet(t,false);line(381,335,381,916,'#172f42',9);rect(302,218,160,129,'#a9bbac',4,black,3);rect(326,244,112,49,'#547e85',4,black,2);ellipse(349,313,7,7,black,null);ellipse(411,313,7,7,black,null);}
function gateSet(t){
 g.fillStyle='#2b4758';g.fillRect(-500,-500,W+1000,H+1000);rect(-500,893,W+1000,500,'#4c705e',0,null);
 for(let i=0;i<13;i++){rect(-15+i*157,220,149,713,'#8b774e',2,black,2);line(12+i*157,248,12+i*157,907,'#aa946366',2)}
 rect(704,213,536,727,'#28463e',0,black,4);line(0,941,W,941,'#1c3d3966',6);
}
function gatePanel(q=0,lift=0){
 const width=500*Math.cos(q*1.1);g.save();g.translate(720,250-lift);
 rect(0,0,width,690,'#98774b',1,black,3);for(let i=1;i<6;i++)line(width*i/6,3,width*i/6,686,'#5e573b',2);
 line(13,56,width-13,620,'#6d603d',16);rect(Math.max(4,width-105),323,92,50,'#415d59',3,black,2);g.restore();return 720+440*Math.cos(q*1.1);
}
function bolt(q,t,lift=0){
 rect(1111,586-lift,143,47,'#3b5556',4,black,2);rect(1126,600-lift,107,20,'#91a59a',4,black,2);
 const xx=1138+q*45;rect(xx,592-lift,21,35,'#bac2a4',5,black,1.5);return[xx+10.5,610-lift];
}
function shedSet(t){
 nightFloor('#345564','#3b645f','#8e825e');rect(220,154,1460,762,'#89714b',2,black,3);for(let i=0;i<14;i++)line(237+i*105,160,237+i*105,911,'#4b533b',2);
 smallDoor(339,316,373,600,0,'#705b40');rect(822,490,690,38,'#ac8a56',3,black,3);rect(855,527,22,380,'#5a5138',1,black,2);rect(1453,527,22,380,'#5a5138',1,black,2);rect(1025,341,306,146,'#526d62',7,black,3);line(1114,339,1235,339,'#b5a572',8);
}
function spareSet(t){
 nightFloor(t>C2.dawn?'#8b9c98':'#657e83','#3c626c','#a18a60');smallDoor(155,244,283,676,.6,'#a68a5c');
 rect(823,669,958,181,'#705c68',11,black,3);line(860,850,860,920,'#594d46',13);line(1742,850,1742,920,'#594d46',13);rect(845,625,913,101,'#ab9b8b',15,black,3);rect(1309,641,370,67,'#d6cdb4',14,black,2);
 path([[844,669],[1376,669],[1376,803],[849,803]],'#597f87',black,2);windowPane(716,145,442,335,t<C2.dawn,.8);
 rect(506,683,226,25,'#957445',2,black,3);rect(521,708,18,215,'#6d593c',1,black,2);rect(695,708,18,215,'#6d593c',1,black,2);
}
function utilitySet(t){
 nightFloor('#839789','#446f6a','#a88b5b');rect(145,235,431,686,'#c3bda0',4,black,3);line(147,503,575,503,black,2);rect(184,288,341,157,'#819d91',9,black,2);
 rect(662,640,1110,35,'#9e794c',2,black,3);for(let i=0;i<3;i++){rect(689+i*354,675,325,246,'#5d887b',2,black,2);line(827+i*354,704,895+i*354,704,black,3)}
 rect(711,233,990,186,'#a2aa82',3,black,2);for(let i=0;i<5;i++){line(780+i*204,279,780+i*204,330,'#4c6c57',7)}
}
function hallHomeSet(t){
 nightFloor(t>C2.dawn?'#899b97':'#617d83','#335c6b','#977b52');rect(1080,128,650,793,'#c4b592',1,black,4);rect(1105,154,600,767,'#8e9e8a',0,black,2);
 rect(1192,615,464,156,'#5b7581',7,black,2);line(1221,771,1221,917,'#594d46',8);line(1627,771,1627,917,'#594d46',8);rect(1205,579,442,66,'#b7b19a',9,black,2);rect(1489,590,133,46,'#d7c9ae',8,black,1);
 // The open doorway gives the sister a direct line of sight to her brother.
 path([[1105,154],[1193,179],[1193,944],[1105,921]],'#9d8054',black,3);ellipse(1176,548,6,6,black,black,1);
 rect(274,406,351,511,'#526e69',4,black,3);rect(291,424,317,147,'#7b9980',2,black,1.5);line(423,458,473,458,black,4);
}
const c2BG=new Map(),c2Back=document.createElement('canvas');c2Back.width=W;c2Back.height=H;const c2bc=c2Back.getContext('2d');
function background2(loc,t){
 const key=loc+(t>=C2.dawn?'D':'N'),old=c2BG.get(key);
 if(old)g.drawImage(old,0,0);else{
  if(loc==='home')homeSet(15);
  else if(loc==='garden'||loc==='gardenroute')gardenSet(t);
  else if(loc==='sisterroom')sisterSet(t);
  else if(loc==='hall')hallSet(t);
  else if(loc==='parents')kitchen(710,true);
  else if(loc==='alley'||loc==='carhide')fenceSet(t);
  else if(loc==='busstop')busSet(t);
  else if(loc==='gate')gateSet(t);
  else if(loc==='shed')shedSet(t);
  else if(loc==='spare')spareSet(t);
  else if(loc==='utility')utilitySet(t);
  else if(loc==='hallhome')hallHomeSet(t);
  else if(loc==='backdoor'){homeDoor(710,false);rect(780,247,297,568,'#6b7766',1,black,3);rect(1074,276,360,537,'#31515c',0,black,2)}
  else if(loc==='homestreet'||loc==='crashstreet'){exterior(710,false);g.fillStyle='#193a4b39';g.fillRect(0,0,W,H)}
  else throw Error('Unknown chapter 2 set '+loc);
  const c=document.createElement('canvas');c.width=W;c.height=H;c.getContext('2d').drawImage(C,0,0);c2BG.set(key,c);
 }
 shakeHatch(25,30,1870,785,125,'#183b3b25');dust(t);c2bc.clearRect(0,0,W,H);c2bc.drawImage(C,0,0);
}
function c2Camera(s,t){
 const u=phase(t,s.start,s.end-s.start),zMove=.045*Math.sin(t*.043);
 if(s.frame==='window')return{x:1070,y:310,z:1.65+zMove};
 if(['latchcut','palminjury','takehand'].includes(s.action)&&s.frame==='insert')return{x:1065,y:298,z:2.2+zMove};
 if(['keymiss','keysteady','keyturn'].includes(s.action))return{x:1020,y:640,z:2.1+zMove};
 if(['boltstuck','boltlock'].includes(s.action))return{x:1144,y:617,z:2.2+zMove};
 if(['handslook','dressing','dresshand','bandagelift','cuffstain','fingercut','wristcheck','volume','mirrorcatch','mirrorfold','toolbox','housekey','leavekeys','safety','route','screen','typing','oldmessages','incoming','callstatic','typingdots','finaltyping','feetbare'].includes(s.action))return{x:960,y:540,z:1.02+.025*Math.sin(t*.04)};
 if(s.frame==='close')return{x:s.location==='sisterroom'?1065:980,y:s.location==='sisterroom'?695:670,z:1.48+zMove};
 return{x:s.location==='garden'?1000:960,y:['garden','gate','alley','busstop','carhide','gardenroute'].includes(s.location)?610:580,z:1.035+.04*Math.sin(t*.035)**2};
}
function c2Backpack(x,y,s=1){bag(x,y,s);g.save();g.translate(x,y);g.scale(s,s);line(18,35,80,35,'#c6ac70',2);g.restore()}
function packTable(s,t){
 const u=t-s.start;tableBase({...s,title:s.title||'TAKE WHAT YOU CAN CARRY'},t);
 c2Backpack(1125,558,2.3);rect(1146,563,173,94,'#263f3d',4,black,2);
 const items=[['water',480,465],['torch',683,502],['firstaid',865,488],['mask',997,489]];
 for(let i=0;i<items.length;i++){
  const [kind,xx,yy]=items[i],q=done(t,s.start+.5+i*1.22,.95),X=lerp(xx,1243,q),Y=lerp(yy,714,q);
  if(q<1){g.save();g.translate(X,Y);g.rotate(-q*.14);if(kind==='water')water(-32,-31,1.05);if(kind==='torch')torch(-45,0,1.2);if(kind==='firstaid')firstAid(0,0,1);if(kind==='mask')mask(0,0,1.15);g.restore();
   if(q>0){path([[X+160,1130],[X+54,Y+64],[X+18,Y],[X-10,Y+12],[X+12,Y+85],[X+80,1130]],P.orange,black,3);ellipse(X,Y+8,15,15,black,null)}
  }
 }
 c2Backpack(1125,670,2.3);
}
function keysTable(s,t){
 tableBase({...s,title:s.action==='leavekeys'?'LEAVE THE CAR KEYS':'PARENTS’ HOUSE KEY'},t);keys(655,518,3);rect(621,562,159,57,'#c39d4b',6,black,2);inkText('CAR',700,601,30,black,'center');
 const u=t-s.start,q=s.action==='housekey'?done(t,s.start+.2,.9):0,x=lerp(1110,1235,q),y=lerp(520,399,q);
 keys(x,y,3);rect(x-32,y+43,180,57,'#52918b',6,black,2);inkText('HOUSE',x+60,y+83,29,P.cream,'center');
 if(q){path([[1390,1130],[1266,817],[x+18,y+32],[x-15,y+37],[1214,851],[1298,1130]],P.orange,black,3);ellipse(x+3,y+8,22,22,black,null);keys(x,y,3)}
}
function routeTable(s,t){
 tableBase({...s,title:s.title||'ROUTE'},t);rect(318,350,1265,481,P.paper,2,black,2);
 for(let i=0;i<5;i++)for(let j=0;j<3;j++)rect(357+i*239,390+j*132,143,77,'#b8c29b',2,'#73967d',1.5);
 const alt=s.title.includes('ALTERNATE'),pts=alt?[[425,731],[650,731],[650,440],[1230,440],[1230,731],[1480,731]]:[[425,731],[650,731],[650,570],[1210,570],[1210,440],[1462,440]];
 drawRoute(pts,out((t-s.start)/2),'#bc8740',10);inkText('HOME',390,805,27,'#355f57');inkText('PARENTS',1310,805,27,'#355f57');
 if(!alt)inkText('LESS THAN 1 MILE',944,408,34,'#966c37','center');
}
function closeHand(s,t){
 const a=s.action,u=t-s.start;tableBase({...s,title:a==='fingercut'?'SMALL CUT / NO BITE':a==='wristcheck'?'WRIST':a==='cuffstain'?'CUFF':'RIGHT HAND'},t);
 let x=920,y=521,sc=1.65;
 if(a==='bloodsleeve'){coat(910,503,2.2,'#bda24a',true);return}
 if(a==='wristcheck'||a==='fingercut'){
  palm(982,512,1.35,{cuff:P.yellow,fingerCut:a==='fingercut'});palm(664,714,.95,{cuff:P.orange});return;
 }
 palm(x,y,sc,{cut:['palminjury','latchcut'].includes(a),bandage:['handslook','dressing','dresshand','bandagelift'].includes(a),stain:a==='cuffstain'});
 if(a==='dresshand'){
  const q=out(u/.9);g.save();g.translate(lerp(1229,953,q),lerp(402,553,q));g.rotate(-.3);rect(-68,-34,136,68,'#ded0ad',6,black,2);g.restore();
 }
 if(a==='bandagelift'){
  const q=done(t,s.start+.2,1);g.save();g.translate(975+q*89,566-q*75);g.rotate(-.38-q*.75);rect(-40,-18,82,42,'#d8cba9',4,black,2);g.restore();line(881,553,945,531,'#a3503b',5);
  path([[1400,1130],[1127,795],[1015+q*89,577-q*75],[993+q*89,590-q*75],[1073,824],[1307,1130]],P.orange,black,3);ellipse(1007+q*89,576-q*75,21,19,black,null);
 }
}
function c2Phone(s,t){
 if(s.action==='oldmessages'){screen({...s,action:'screen'},t);return}
 if(s.action==='typingdots'||s.action==='finaltyping'){
  screen({...s,action:'typing',detail:''},t);
  if(s.action==='typingdots')for(let i=0;i<3;i++)ellipse(884+i*36,557-Math.max(0,Math.sin((t-s.start)*5-i*.6))*7,7,7,'#5d927c',null);
  else{line(804,451,804,490,Math.floor(t*2)%2?'#345d58':'#345d5800',3)}
  return;
 }
 if(s.action==='callstatic'||s.action==='volume'){
  tableBase({...s,title:'DAD / CALL CONNECTED'},t);rect(665,354,574,470,'#274d61',33,black,4);inkText('DAD',952,465,55,P.cream,'center');
  const u=t-s.start;for(let i=0;i<25;i++){const q=(Math.sin(t*3.6+i*1.7)+Math.sin(t*5.2+i*.6))*.5;line(740+i*18,608-q*13,740+i*18,608+q*13,'#97b7a3',3)}
  rect(764,718,378,12,'#adc6ae',6,null);const q=s.action==='volume'?1-.7*done(t,s.start,.8):.30;rect(764,718,378*q,12,'#d3ab4a',6,null);ellipse(764+378*q,724,15,15,P.cream,black,2);
  if(s.action==='volume'){ellipse(764+378*q,724,21,21,black,null)}return;
 }
 screen(s,t);
}
function c2Figure(t,x,y,s=.75,o={}){
 c2Actor('driver',x,y,s,t,{top:'#658270',skin:'#a8b995',headY:o.headY||12,head:o.head||.09,look:o.look||[0,8],hands:[[-68,-226],[64,-227]],...o});
}
function c2Pair(t,x=800,dir=1,start=t,o={}){
 const speed=66.666,dt=Math.max(0,t-start),xx=x+dir*dt*speed*.76;
 c2Actor('girl',xx-dir*98,966,.49,t,{walk:o.walk?1:0,wt:dt,dir,bloodSleeve:t>=at('bloodsleeve'),...o.girl});
 c2Actor('hero',xx,960,.76,t,{walk:o.walk?1:0,wt:dt,dir,...o.hero});return xx;
}
function drawGardenRescue(s,t){
 const a=s.action,u=t-s.start,flash=s.flashback;
 let q=t>=at('windowopen')?done(t,at('windowopen'),.7):0;
 const leanQ=a==='ladderlean'?done(t,s.start,Math.min(1.8,s.end-s.start)):1;
 const angle=a==='ladderlean'?lerp(-1.72,LAD.angle,leanQ):LAD.angle;
 if(a==='laddercarry'){
  const root=600+u*66.666*.72;c2Actor('hero',root,960,.72,t,{walk:1,wt:u,dir:1,hands:[[-42,-245],[50,-245]],held:(L,R)=>ladder(-460,-245,920,0,44)});return;
 }
 if(a==='ladderlean'){
  ladder(LAD.x,LAD.y,LAD.length,angle);const h=270,p=[LAD.x+Math.cos(angle)*h,LAD.y+Math.sin(angle)*h],root=p[0]-30;
  c2Actor('hero',root,960,.72,t,{hands:worldHands(root,960,.72,[[p[0]-12,p[1]],[p[0]+12,p[1]]])});return;
 }
 if(t>=at('ladderlean')||flash)ladder(LAD.x,LAD.y);
 if(['windowgirl','windowhandle','windowpush','windowopen','windowfreeze'].includes(a)){
  if(a==='windowhandle')windowActors(t,{hands:[[-65,-220],[(1085-1065)/.454,(270-370)/.454]]});
  else if(a==='windowpush'){
   const q=done(t,s.start,.7),b=142*q,R=worldHands(1065,370,.454,[null,[1075,334]],0,b)[1];windowActors(t,{hands:[[-65,-225],mixp([65,-225],R,q*q*q)],kneel:b});
  }else windowActors(t);
  windowPaneC2(t,q);return;
 }
 if(a==='climbup'){
  const h=lerp(24,335,ease(phase(t,s.start,s.end-s.start)));windowActors(t);windowPaneC2(t,1);climber('hero',h,t);return;
 }
 if(['windowjacket','girlsit','reachwindow','takehand','girlcry','feetbare','latchcut','palminjury','laddertransfer'].includes(a)||flash){
  if(['latchcut','palminjury'].includes(a)){
   if(a==='palminjury'){closeHand({...s,title:'A SHARP STING'},t);return}
   const q=done(t,s.start,.55);palm(989,464,1.4,{cut:true});rect(1084,304,32,165,'#bdc5a4',3,black,2);rect(1059,403,92,19,'#45645f',3,black,2);line(1058,415,1008,468,'#bca776',5);return;
  }
  if(a==='feetbare'){
   rect(565,110,790,620,'#a69c74',4,black,3);rect(581,125,758,533,'#6c7e70',0,black,2);line(566,658,1354,658,'#d2c39b',20);c2Actor('girl',965,800,.8,t,{mask:true,hands:[[-65,-230],[65,-230]]});return;
  }
  const seated=t>=at('girlsit')||flash;
  if(a==='laddertransfer'){
   const q=phase(t,s.start,s.end-s.start);climber('hero',lerp(365,400,q),t);climber('girl',lerp(515,432,q),t);windowPaneC2(t,1);return;
  }
  const h=['reachwindow','takehand'].includes(a)||flash?365:335;
  windowActors(t,{seated,cry:a==='girlcry'});windowPaneC2(t,1);
  const wh=a==='reachwindow'?[null,[1085,270]]:a==='takehand'||a==='girlcry'||flash?[null,[1028,348]]:null;
  climber('hero',h,t,{worldHands:wh});return;
 }
 if(['descend','descentstop'].includes(a)){
  const h=descentH(t);windowPaneC2(t,1);climber('hero',h,t);climber('girl',h+32,t);return;
 }
 if(a==='ladderoff'){
  const q=ease(phase(t,s.start,s.end-s.start));climber('hero',0,t);
  const gx=lerp(lp(32)[0]+18,1065,q),gy=lerp(lp(32)[1],960,q);c2Actor('girl',gx,gy,.454,t,{bloodSleeve:true,hands:[[-55,-268],[56,-223]]});windowPaneC2(t,1);return;
 }
 windowPaneC2(t,1);
}
function chapterAction(s,t){
 const a=s.action,u=t-s.start,d=s.end-s.start;
 if(['screen','typing','incoming','oldmessages','callstatic','volume','typingdots','finaltyping'].includes(a)){c2Phone(s,t);return}
 if(a==='route'){routeTable(s,t);return}
 if(a==='pack'){packTable(s,t);return}
 if(a==='leavekeys'||a==='housekey'){keysTable(s,t);return}
 if(['handslook','dressing','dresshand','bandagelift','cuffstain','fingercut','wristcheck'].includes(a)){closeHand(s,t);return}
 if(['laddercarry','ladderlean','windowgirl','windowhandle','windowpush','windowopen','windowfreeze','climbup','windowjacket','feetbare','girlsit','reachwindow','latchcut','palminjury','takehand','girlcry','laddertransfer','descend','descentstop','ladderoff'].includes(a)&&s.location==='garden'){drawGardenRescue(s,t);return}
 if(['shutter','shadowrun','shutterclose'].includes(a)){
  const q=a==='shutter'?.5:a==='shadowrun'?.58:lerp(.58,1,ease(phase(t,s.start,d)));
  if(a==='shadowrun'){
   g.save();g.beginPath();g.rect(195,204,393,319);g.clip();rect(194,204,393,319,'#203746',0,null);for(let k=0;k<5;k++)line(210+k*85,390,210+k*85,540,'#789380',3);c2Actor('driver',220+u*86.666,530,.65,t,{walk:1,wt:u,period:.65,top:'#274a50',skin:'#7b9181',dir:1});g.restore();
  }
  shutter(q,a==='shadowrun');c2Actor('hero',924,910,.95,t,{phone:true,raise:1,look:[-5,5]});return;
 }
 if(a==='callhero'){
  const inGarden=s.location==='garden';if(inGarden&&t>245&&t<264){ladder(LAD.x,LAD.y);climber('hero',descentH(t),t);climber('girl',descentH(t)+32,t);windowPaneC2(t,1);return}
  phoneEar('hero',inGarden?773:970,inGarden?960:915,inGarden?.72:.95,t);return;
 }
 if(a==='sistercall'||a==='roomlock'||a==='hearbreak'||a==='lookdoor'){
  phoneEar('girl',1065,915,.65,t,{head:a==='lookdoor'?.15:a==='hearbreak'?-.06:0,look:a==='lookdoor'?[-7,0]:[-3,4]});
  if(a==='roomlock'){rect(205,550,127,29,'#7b8e76',4,black,2);rect(225+28*done(t,s.start,.8),551,37,28,'#b4b995',4,black,2)}return;
 }
 if(a==='neighborenter'){
  smallDoor(185,229,426,692,done(t,s.start,1.0),'#8c6b49');goActor('driver',343,923,.84,t,s.start,1,false,{top:'#496f80',bloodSleeve:true});c2Actor('mum',710,925,.86,t,{hands:[[-112,-316],[62,-222]]});return;
 }
 if(a==='woundsleeve'){
  tableBase({...s,title:'MR. HARRIS'},t);coat(968,486,2.4,'#496f80',true);return;
 }
 if(a==='firstaid'){
  const q=done(t,s.start,.9);c2Actor('mum',920,916,.86,t,{hands:[[-42,-260],[50,-260]],held:(L,R)=>firstAid(3,-252,.82,true)});return;
 }
 if(a==='inventory'){
  c2Actor('hero',835,914,.95,t,{phone:true,raise:1,head:.025});water(1100,836,.85);water(1195,836,.85);return;
 }
 if(a==='reaction'){
  c2Actor('hero',960,s.location==='garden'?960:915,.95,t,{phone:true,raise:1,head:.035,look:[1,5]});return;
 }
 if(a==='crash'||a==='headlights'||a==='exitstreet'){
  g.save();g.translate(0,45);car(443,650,1.8);g.save();g.translate(1770,793);g.rotate(.19);g.scale(-1.7,1.7);car(0,0,1);g.restore();
  path([[775,795],[1920,570],[1920,916],[775,828]],'#f1d99420',null);path([[1390,810],[400,678],[180,938],[1390,841]],'#f1d99418',null);
  for(let i=0;i<3;i++)c2Figure(t,950+i*155,925,.65,{walk:a==='headlights'?1:0,wt:u,period:1.3,dir:1});g.restore();
  if(a==='exitstreet')goActor('hero',450,960,.76,t,s.start,1);return;
 }
 if(a==='maskfit'){
  const q=done(t,s.start,.9);c2Actor('hero',960,915,1,t,{mask:true,hands:[[-35,-400+8*(1-q)],[42,-400+8*(1-q)]]});return;
 }
 if(a==='safety'){
  tableBase({...s,title:'RESPIRATOR / LIMITATIONS'},t);mask(640,506,2.35);for(let i=0;i<9;i++){const x=370+((t-s.start)*50+i*29)%250;ellipse(x,468+i%3*35,4,4,'#88bca0',null)}
  rect(1060,428,299,188,'#c4c7a0',10,black,2);line(1085,479,1315,568,'#8e5140',20);line(1089,568,1315,479,'#8e5140',20);
  inkText('PARTICLES',640,763,36,'#426957','center');inkText('NOT BITES',1210,763,36,'#9d583c','center');return;
 }
 if(a==='phoneaway'){
  const q=done(t,s.start,.9);c2Actor('hero',970,915,.95,t,{phone:u<1.1,raise:1-q,walk:u>1.25?1:0,wt:Math.max(0,u-1.25),mask:true});return;
 }
 if(a==='walkalone'||a==='fastwalk'){
  goActor('hero',730,960,.76,t,s.start,1,a==='fastwalk');return;
 }
 if(['busman','vanhide','alertturn','zombiewalk','threefigures','figureturn','figuredistant'].includes(a)){
  if(a==='threefigures'){for(let i=0;i<3;i++)c2Figure(t,360+i*195,919,.75,{head:.08-i*.04});return}
  const q=a==='alertturn'?done(t,s.start,.8):a==='figureturn'?done(t,s.start,.7):0;
  const x=a==='zombiewalk'?418+u*66.666*.76:418;
  c2Figure(t,x,916,.76,{head:lerp(.11,-.025,q),headY:lerp(15,-1,q),look:[q*6,8*(1-q)],walk:a==='zombiewalk'?1:0,wt:u,dir:1});
  if(a==='vanhide'||a==='alertturn'){c2Actor('hero',810,960,.76,t,{head:-.025,look:[-7,2]});van(850,385,1)}return;
 }
 if(a==='gardenarrive'){
  goActor('hero',360,960,.72,t,s.start,1);return;
 }
 if(a==='wreckage'||a==='hallshadowglass'){
  // A close look through the kitchen window retains its frame and dirty glass.
  rect(228,130,1460,719,'#d0c39d',4,black,4);g.save();g.beginPath();g.rect(247,149,1422,680);g.clip();g.translate(247,149);g.scale(.74,.63);kitchen(710,true);
  g.save();g.translate(1120,914);g.rotate(-1.25);rect(-22,-106,44,190,'#7d7252',3,black,3);line(-92,-29,91,-29,'#8b7853',20);line(-74,-29,-90,123,'#675b43',9);line(75,-29,96,121,'#675b43',9);g.restore();firstAid(1020,882,.9,true);
  if(a==='hallshadowglass'){const x=1600-u*74;c2Figure(t,x,920,.8,{top:'#334945',skin:'#637e6d',walk:1,wt:u,dir:-1});}
  g.restore();line(958,146,958,829,'#a9ad91',10);line(248,544,1667,544,'#b4b293',8);return;
 }
 if(['dadcall','dadwound','barricade','hallshadow','doorimpact'].includes(a)){
  if(a==='hallshadow'){g.save();g.beginPath();g.rect(816,208,548,372);g.clip();c2Figure(t,1110,785,.9,{top:'#496f80',head:.07});if(s.anchor.includes('mother'))c2Actor('mum',913,792,.78,t,{skin:'#c7baa6'});g.restore();return}
  phoneEar('dad',592,922,.91,t,{bloodSleeve:true,head:.055,hands:[[-83,-430],[-56,-310]],heldFront:(L,R)=>{line(-59,-321,-49,-310,'#8c4439',6)}});
  if(a==='barricade'){
   const q=done(t,s.start,1.2);g.save();g.translate(-27*(1-q),0);rect(737,580,713,337,'#866c48',4,black,4);for(let i=0;i<3;i++)rect(760+i*225,610,208,277,'#9c8051',2,black,2);g.restore();
  }
  if(a==='doorimpact'){
   const q=Math.max(0,1-(u%1.35)/.23);g.save();g.translate(q*4,0);rect(737,580,713,337,'#866c48',4,black,4);for(let i=0;i<3;i++)rect(760+i*225,610,208,277,'#9c8051',2,black,2);g.restore();
  }return;
 }
 if(a==='dadprotect'||a==='dadgo'){
  c2Actor('dad',688,916,.91,t,{bloodSleeve:t>150,hands:[[-65,-222],[135,-317]],head:.04});c2Actor('girl',1065,915,.65,t,{mask:true,look:[-5,2]});return;
 }
 if(a==='shedkey'||a==='toolbox'||a==='shedopen'){
  if(a==='toolbox'||a==='shedkey'){
   tableBase({...s,title:'SPARE KEY / OLD TOOLBOX'},t);const q=done(t,s.start+.3,.9);rect(620,442-103*q,597,220,'#526c61',10,black,3);line(809,430-103*q,1028,430-103*q,'#b7a773',11);keys(922,678,2.4);
   if(q>0){path([[1420,1110],[1259,722],[1201,481-103*q],[1169,482-103*q],[1194,746],[1329,1110]],P.orange,black,3);ellipse(1188,470-103*q,22,22,black,null)}
  }else{smallDoor(339,316,373,600,done(t,s.start,.9),'#705b40');c2Actor('hero',760,950,.9,t,{hands:[[-146,-330],[63,-224]]});}return;
 }
 if(['underwindow','towardkitchen','sleevehold','leadtogate'].includes(a)){
  ladder(LAD.x,LAD.y);windowPaneC2(t,1);
  const hx=a==='towardkitchen'?948-u*48:948, gx=a==='leadtogate'?1065-u*33.3:1065;
  c2Actor('hero',hx,960,.72,t,{walk:a==='towardkitchen'?1:0,dir:-1,wt:u});
  const hold=a==='sleevehold'||a==='leadtogate',target=[hx+43,960-180];
  c2Actor('girl',gx,960,.454,t,{bloodSleeve:true,walk:a==='leadtogate'?1:0,wt:u,dir:-1,hands:hold?worldHands(gx,960,.454,[target,null]):null});return;
 }
 if(['pairwalk','pairturn','pairfreeze','girlturn','catcharm','wristtalk','sleevedown','girlcall','phonehandoff','sisterask','girlflinch','girlcry','pairarrive'].includes(a)){
  if(a==='girlcall'){phoneEar('girl',1090,966,.49,t,{bloodSleeve:true});c2Actor('hero',880,960,.76,t,{look:[5,5]});return}
  if(a==='girlcry'){c2Actor('girl',1065,966,.58,t,{bloodSleeve:true,cry:true,head:.075});c2Actor('hero',830,960,.76,t);return}
  if(a==='pairwalk'||a==='pairturn'||a==='pairarrive'){c2Pair(t,810,a==='pairturn'?-1:1,s.start,{walk:true});return}
  if(a==='sisterask'&&s.location==='spare'){c2Actor('girl',1358,830,.60,t,{mask:false});c2Actor('hero',530,930,.9,t);return}
  if(a==='sisterask'&&s.location==='utility'){c2Actor('girl',1100,940,.58,t,{mask:true});c2Actor('hero',830,935,.88,t);return}
  if(a==='phonehandoff'){
   const q=done(t,s.start,.8),px=lerp(1032,944,q),py=lerp(737,710,q);
   phoneBack(px-21,py-34,43,68);
   c2Actor('hero',884,960,.76,t,{hands:worldHands(884,960,.76,[null,[px-21,py]])});
   const L=worldHands(1100,966,.49,[[px+21,py],null])[0],release=clamp((q-.12)/.28);
   c2Actor('girl',1100,966,.49,t,{bloodSleeve:true,hands:[mixp(L,[-65,-218],release),null]});return;
  }
  if(a==='catcharm'){
   const hx=Math.min(1000,884+u*50.666),R=worldHands(hx,960,.76,[null,[1076,790]])[1],q=done(t,s.start+1,1.4);
   c2Actor('hero',hx,960,.76,t,{walk:hx<1000?1:0,wt:u,hands:[null,mixp([65,-218],R,q)]});
   c2Actor('girl',1100,966,.49,t,{bloodSleeve:true});return;
  }
  const heroX=(a==='pairfreeze'&&t>at('catcharm')&&t<at('pullbehindcar'))?1000:884,girlX=1100;
  c2Actor('hero',heroX,960,.76,t,{hands:a==='wristtalk'?[[1,-287],[80,-290]]:a==='catcharm'?worldHands(heroX,960,.76,[null,[1037,792]]):null,look:[6,4]});
  c2Actor('girl',girlX,966,.49,t,{bloodSleeve:t>=at('bloodsleeve'),head:a==='girlturn'?.14:0,hands:a==='wristtalk'?[[-111,-320],[54,-220]]:null});
  if(a==='phonehandoff'){const q=done(t,s.start,.8);phoneBack(lerp(1032,944,q),lerp(737,710,q),43,68)}return;
 }
 if(a==='bloodsleeve'){
  if(s.frame==='insert'){closeHand(s,t);return}
  c2Actor('girl',1090,966,.58,t,{bloodSleeve:true,hands:[[-113,-299],[65,-220]]});c2Actor('hero',822,960,.76,t,{look:[5,5]});return;
 }
 if(a==='pullbehindcar'){
  const q=done(t,s.start,1.0);c2Actor('girl',lerp(1300,1110,q),966,.49,t,{walk:1,wt:u,dir:-1,bloodSleeve:true});c2Actor('hero',lerp(1190,980,q),960,.76,t,{walk:1,wt:u,dir:-1});car(903,638,2);return;
 }
 if(a==='mirrorcatch'||a==='mirrorfold'){
  tableBase({...s,title:'WING MIRROR'},t);rect(520,329,862,481,'#416b7a',24,black,4);line(788,447,1087,599,'#2a4450',27);
  const q=a==='mirrorfold'?done(t,s.start,.35):0;g.save();g.translate(1045,550);g.rotate(q*1.0);rect(-113,-63,226,126,'#345660',26,black,4);rect(-92,-46,184,89,'#9bb8b5',17,black,2);g.restore();
  const x=lerp(807,1040,done(t,s.start,.7));c2Backpack(x,490,1.8);line(x+149,591,1114,552,'#2e4f46',11);return;
 }
 if(['pointgate','gateopen','gateenter','gateclose','boltstuck','gatefeet','gatelift','boltlock','gatehit'].includes(a)){
  let q=a==='gateopen'?done(t,s.start,d):a==='gateenter'?1:a==='gateclose'?1-done(t,s.start,d):0;
  const lift=a==='gatelift'?6*done(t,s.start,.8):0;
  gatePanel(q,lift);
  if(a==='pointgate'){goActor('hero',865,940,.8,t,s.start,1,false,{hands:[[-65,-220],[130,-320]]});c2Actor('girl',771,947,.5,t,{walk:1,wt:u});return}
  if(a==='gateopen'){
   const handle=[720+440*Math.cos(q*1.1),610],hx=handle[0]-85;c2Actor('hero',hx,940,.8,t,{walk:1,wt:(1075-hx)/53.333333,dir:-1,hands:worldHands(hx,940,.8,[null,handle])});return;
  }
  if(a==='gateenter'){goActor('girl',1070,948,.5,t,s.start,1,false,{bloodSleeve:true});c2Actor('hero',970,940,.8,t,{hands:[[-65,-220],[95,-225]]});return}
  const bq=a==='boltlock'?done(t,s.start,.4):a==='gatelift'?lerp(.45,1,done(t,s.start,.9)):.45;
  const knob=bolt(bq,t,lift);
  c2Actor('hero',1065,940,.8,t,{hands:worldHands(1065,940,.8,[[1040,675-lift],knob]),head:.04});c2Actor('girl',1410,950,.5,t,{bloodSleeve:true,head:a==='gatehit'?-.07:0});
  if(a==='gatehit'){const r=22*(1-clamp(u/.35));ellipse(1154,494,17+r,19+r,null,'#cfbb80',2)}return;
 }
 if(a==='homeview'){
  for(const x of [248,521]){rect(x,318,131,164,'#516b63',1,black,3);for(let i=0;i<9;i++)line(x+3,325+i*18,x+128,325+i*18,'#294d56',2)}return;
 }
 if(['keymiss','keysteady','keyturn','homebolt','homeenter'].includes(a)){
  if(a==='homeenter'){smallDoor(782,247,295,568,done(t,s.start,.6),'#887654');goActor('girl',1080,915,.58,t,s.start,-1);c2Actor('hero',885,915,.9,t);return}
  if(a==='homebolt'){g.save();g.translate(-115,0);const p=bolt(done(t,s.start,.45),t);g.restore();p[0]-=115;c2Actor('hero',950,940,.8,t,{hands:worldHands(950,940,.8,[null,p])});return}
  const miss=a==='keymiss'?Math.sin(u*12)*5*(1-done(t,s.start,d)):0,pt=[996+miss,640+miss*.7];
  c2Actor('hero',900,950,.85,t,{hands:worldHands(900,950,.85,[null,pt]),held:(L,R)=>{g.save();g.translate(...R);g.rotate(a==='keyturn'?done(t,s.start,.7)*1.2:0);keys(0,0,.85);g.restore()}});
  rect(1008,622,29,41,'#4c6557',3,black,2);ellipse(1020,640,4,7,black,null);return;
 }
 if(a==='jackets'){
  coat(879,556,1.45,P.orange,true);coat(1242,584,1.1,'#bda34c',true);c2Actor('hero',450,935,.9,t);c2Actor('girl',1450,940,.58,t,{mask:true});return;
 }
 if(a==='armcheck'){
  c2Actor('hero',840,935,.88,t,{hands:[[-38,-275],[90,-285]],head:.03});c2Actor('girl',1100,940,.58,t,{hands:[[-123,-320],[63,-222]],mask:true});return;
 }
 if(a==='foodtray'){
  const q=done(t,s.start,.9);c2Actor('hero',670,935,.88,t,{hands:[[-42,-260],[50,-260]],held:(L,R)=>{rect(-56,-251,121,13,'#c9c19c',3,black,2);bottle(-43,-310,.65);can(15,-301,.55)}});c2Actor('girl',1090,920,.60,t,{mask:false});return;
 }
 if(['distance','girlbed','girlsleep','sleepturn'].includes(a)){
  const asleep=a==='girlsleep'||a==='sleepturn';
  if(asleep){g.save();g.translate(1378,674);g.rotate(Math.PI/2+(a==='sleepturn'?Math.sin(u*.8)*.035:0));c2Actor('girl',0,0,.60,t,{mask:false,still:true,head:.02});g.restore();rect(899,681,630,111,'#597f87',3,black,2)}
  else c2Actor('girl',1358,830,.60,t,{mask:false,hands:[[-55,-230],[58,-230]]});
  if(a==='distance')c2Actor('hero',486,930,.9,t,{mask:true});return;
 }
 if(a==='doorajar'||a==='hallseat'){
  const q=a==='doorajar'?done(t,s.start,.7):1;path([[1105,154],[1105+88*q,179],[1105+88*q,944],[1105,921]],'#9d8054',black,3);
  c2Actor('girl',1450,711,.38,t,{mask:false});
  // Seated against the wall, feet remain on the hallway floor.
  c2Actor('hero',845,930,.9,t,{kneel:130,mask:true,hands:[[-52,-265],[56,-265]],head:.03});return;
 }
 throw Error('Unimplemented chapter 2 action '+a);
}
window.renderErrors=[];
function render(t){
 if(stateDepth!==0)throw Error('Unbalanced frame start '+stateDepth);t=Math.min(D-.00001,Math.max(0,t));window.T=t;
 g.save();g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,W,H);
 try{
  window.poseFrames=[];const s=activeAt(SHOTS,t);if(!s)throw Error('No chapter 2 shot');CURRENT_SHOT=s;
  background2(s.location,t);const cam=c2Camera(s,t);
  camera(cam.x,cam.y,cam.z,()=>{g.fillStyle='#365a66';g.fillRect(-400,-400,W+800,H+800);g.drawImage(c2Back,0,0);chapterAction(s,t)});
  if(s.flashback){g.fillStyle='#c5993c0d';g.fillRect(0,0,W,H)}
  if(stateDepth!==1)throw Error('Unbalanced chapter scene '+stateDepth);finish(t);
 }catch(e){window.renderErrors.push({t,id:CURRENT_SHOT?.id,error:String(e)});throw e}finally{g.restore()}
}
function c2DadAvatar(t){ellipse(960,359,75,75,'#3d6e89',black,2);g.save();g.translate(960,364);g.scale(.86,.86);face(t,{hat:false,hair:'#929b96',mood:'neutral',look:[0,0]});g.restore()}
