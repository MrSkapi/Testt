/* Authored action continuity. Dialogue never drives hands: contacts and deliberate
   reach/hold/release beats own the arms; speech only changes the mouth/eyes. */
const legacyChapterAction=chapterAction;
const legacyGardenRescue=drawGardenRescue;
const legacyPhoneEar=phoneEar;
const REST=[[-65,-208],[65,-208]];
const seqShot=(id)=>SHOTS.find(s=>s.id===id);
const when=id=>seqShot(id).start;
const qAt=(t,a,d=.8)=>ease(phase(t,a,d));
function moveC2(id,x0,x1,y,sc,t,a,b,o={}){
 const q=qAt(t,a,b-a),x=lerp(x0,x1,q),dist=Math.abs(x-x0),dir=Math.sign(x1-x0)||1;
 c2Actor(id,x,y,sc,t,{walk:t>a&&t<b?1:0,wt:dist/(66.6666666667*sc),dir,...o});return x;
}
function callC2(id,x,y,sc,t,o={}){
 const right=!!o.right,hand=right?[82,-429]:[-83,-429],hands=right?[REST[0],hand]:[hand,REST[1]];
 c2Actor(id,x,y,sc,t,{hands,look:[right?3:-3,1],held:(L,R)=>{
  const H=right?R:L;phoneBack(H[0]+(right?0:-28),H[1]-32,28,64);
 },...o});
}
phoneEar=callC2;
function pocketPhone(id,x,y,sc,t,a,d=.9,right=true){
 const q=qAt(t,a,d),A=right?[82,-429]:[-83,-429],B=right?[52,-227]:[-52,-227],P=right?[165,-340]:[-165,-340],H=mixp(mixp(A,P,q),mixp(P,B,q),q);
 c2Actor(id,x,y,sc,t,{hands:right?[REST[0],H]:[H,REST[1]],held:q<.95?(L,R)=>{const p=right?R:L;phoneBack(p[0]+(right?0:-28),p[1]-32,28,64)}:null});
}
function lockedWindowGirl(t,o={}){
 const push=at('windowpush'),opened=at('windowopen'),sit=at('girlsit');
 const crouch=t>=push&&t<opened+1?142*qAt(t,push,.75)*(1-qAt(t,opened+.45,.55)):0;
 const seat=t>=sit?qAt(t,sit,.8):0,gy=lerp(370,450,seat);
 let hands=REST.map(p=>p.slice());
 if(t>=at('windowhandle')&&t<push){
  const q=qAt(t,at('windowhandle'),.48);hands[1]=mixp(REST[1],worldHands(1065,370,.454,[null,[1072,269]])[1],q);
 }
 if(t>=push&&t<opened+1){
  const reach=qAt(t,push,.75),opening=qAt(t,opened,.7),release=qAt(t,opened+.18,.6);
  const target=[1070-34*Math.min(1,opening/.6),328],L=worldHands(1065,gy,.454,[target,null],0,crouch)[0];
  hands[0]=mixp(REST[0],L,reach**3*(1-release));const ax=hands[0][0]+48,ay=hands[0][1]+359,ad=Math.hypot(ax,ay);if(ad>153.5)hands[0]=[-48+ax*153.5/ad,-359+ay*153.5/ad];
 }
 if(seat>0)hands=[mixp(REST[0],[-80,-224],seat),mixp(REST[1],[38,-319],seat)];
 const turn=t>=when('c2-073')&&t<when('c2-074')?.10*qAt(t,when('c2-073'),.5):0;
 windowActors(t,{seated:seat>0,hands,kneel:crouch,head:turn,cry:o.cry,...o,bodyGround:gy});
}
// Window pose uses the same interpolation on either side of cuts.
const baseWindowActors=windowActors;
windowActors=(t,o={})=>{
 const seat=t>=at('girlsit')?qAt(t,at('girlsit'),.8):0,gy=o.bodyGround??lerp(370,450,seat);
 g.save();g.beginPath();g.rect(936,44,311,326);if(seat>0)g.rect(935,350,320,165);g.clip();
 c2Actor('girl',1065,gy,.454,t,{hands:o.hands||(seat>0?[[-80,-224],[38,-319]]:REST),mask:true,mood:o.cry?'concerned':'neutral',bloodSleeve:t>=at('takehand'),...o});g.restore();
};
drawGardenRescue=(s,t)=>{
 const a=s.action;
 if(a==='laddercarry'){
  const x=825+(t-s.start)*48;c2Actor('hero',x,960,.72,t,{walk:1,wt:t-s.start,hands:[[-42,-245],[50,-245]],held:()=>ladder(-460,-245,920,0,44)});return;
 }
 if(['windowgirl','windowhandle','windowpush','windowopen','windowfreeze','lookdoor'].includes(a)){
  ladder(LAD.x,LAD.y);lockedWindowGirl(t);windowPaneC2(t,t>=at('windowopen')?qAt(t,at('windowopen'),.7):0);return;
 }
 if(a==='climbup'){
  ladder(LAD.x,LAD.y);lockedWindowGirl(t);windowPaneC2(t,1);
  climber('hero',lerp(130,335,phase(t,s.start,s.end-s.start)),t);return;
 }
 legacyGardenRescue(s,t);
};
function pairedIdle(t,o={}){
 const hx=o.hx??884,gx=o.gx??1100;
 c2Actor('hero',hx,960,.76,t,{look:[5,2],...o.hero});
 c2Actor('girl',gx,966,.49,t,{bloodSleeve:t>=at('bloodsleeve'),look:[-5,0],...o.girl});
}
function jacketGrip(t,x,dir,dt=0){
 const gx=x-dir*98;
 c2Actor('hero',x,960,.76,t,{walk:1,wt:dt,dir});
 const target=[x-dir*47,960-202*.76],h=worldHands(gx,966,.49,dir>0?[null,target]:[target,null]);
 c2Actor('girl',gx,966,.49,t,{walk:1,wt:dt,period:1.3*.49/.76,dir,hands:h,bloodSleeve:true});
}
// Same world velocity, separate cadence for the shorter character; no skating.
c2Pair=(t,x=810,dir=1,start=t,o={})=>{
 const dt=Math.max(0,t-start),xx=x+dir*dt*66.6666666667*.76;
 jacketGrip(t,xx,dir,dt);return xx;
};
function showWrist(s,t){
 const start=at('bloodsleeve'),end=at('sleevedown'),lift=qAt(t,start+.4,.7)*(1-qAt(t,end,.7));
 const L=mixp(REST[0],[-112,-310],lift);
 pairedIdle(t,{girl:{hands:[L,REST[1]],bloodSleeve:true}});
}
function keyAction(t){
 const begin=at('keymiss'),miss=when('c2-147'),steady=at('keysteady'),turn=at('keyturn');
 let angle=t>=turn?qAt(t,turn,.85)*1.10:0;
 const vx=37*.7225,vy=25*.7225,correct=[1020-(vx*Math.cos(angle)-vy*Math.sin(angle)),640-(vx*Math.sin(angle)+vy*Math.cos(angle))];
 let H=correct.slice();
 if(t<miss)H=mixp([946,760],[correct[0]-10,correct[1]+14],qAt(t,begin,miss-begin));
 else if(t<steady){const q=qAt(t,miss,.45);H=[correct[0]-10+q*10,correct[1]+14*(1-.35*q)];}
 else if(t<turn)H=mixp([correct[0],correct[1]+9.1],correct,qAt(t,steady,.8));
 c2Actor('hero',900,950,.85,t,{hands:worldHands(900,950,.85,[null,H]),held:(L,R)=>{
  g.save();g.translate(...R);g.rotate(angle);keys(0,0,.85);g.restore();
 }});
 rect(1008,622,29,41,'#4c6557',3,black,2);ellipse(1020,640,4,7,black,null);
 c2Actor('girl',1170,955,.55,t,{bloodSleeve:true,look:[-5,0]});
}
function gateAction(s,t){
 const a=s.action,open=at('gateopen'),enter=at('gateenter'),close=at('gateclose'),stuck=at('boltstuck'),liftAt=at('gatelift'),locked=at('boltlock');
 let swing=t<enter?qAt(t,open,enter-open):t<close?1:1-qAt(t,close,stuck-close);
 const lift=6*qAt(t,liftAt,.8)*(1-qAt(t,locked,.6));gatePanel(swing,lift);
 const handle=[720+440*Math.cos(swing*1.1),610-lift];
 if(t<close){
  const hx=t<enter?handle[0]-85:835;
  c2Actor('hero',hx,940,.8,t,{hands:worldHands(hx,940,.8,[null,handle]),walk:t<enter?1:0,wt:Math.abs(hx-1075)/(66.6666666667*.8),dir:-1});
  if(t<enter)c2Actor('girl',960,948,.5,t,{bloodSleeve:true});
  else moveC2('girl',960,1200,948,.5,t,enter,at('gatefeet'),{bloodSleeve:true});return;
 }
 if(t<stuck){
  // Follow the closing handle, then keep the next shot's contact pose.
  const hx=handle[0]-85;
  c2Actor('hero',hx,940,.8,t,{hands:worldHands(hx,940,.8,[null,handle]),walk:1,wt:Math.abs(hx-835)/(66.6666666667*.8),dir:1});
  moveC2('girl',960,1200,948,.5,t,enter,at('gatefeet'),{bloodSleeve:true});return;
 }
 const failed=.45*qAt(t,stuck,.42),lockedQ=qAt(t,locked,.42),boltQ=lerp(failed,1,lockedQ),p=bolt(boltQ,t,lift),settle=qAt(t,stuck,.48);
 const target=worldHands(1065,940,.8,[[1040,675-lift],p]);
 const hands=[mixp(REST[0],target[0],settle),target[1]];
 if(t>=at('gatehit')){
  const release=qAt(t,at('gatehit'),.85);hands[0]=mixp(hands[0],REST[0],release);hands[1]=mixp(hands[1],REST[1],release);
  const hit=qAt(t,at('gatehit'),.16)*(1-qAt(t,at('gatehit')+.16,.25));
  line(1161,486,1171+8*hit,475,'#c9ad71',2);line(1135,477,1126-8*hit,463,'#c9ad71',2);
 }
 c2Actor('hero',1065,940,.8,t,{hands,head:0});
 const flinch=t>=at('gatehit')?.03*Math.sin(Math.PI*phase(t,at('gatehit'),.6)):0;
 if(t<at('gatefeet'))moveC2('girl',960,1200,948,.5,t,enter,at('gatefeet'),{bloodSleeve:true});else c2Actor('girl',1200,948,.5,t,{bloodSleeve:true,head:flinch});
}
chapterAction=(s,t)=>{
 const a=s.action,u=t-s.start;
 if(a==='callhero'){
  if(s.location==='garden'&&t>245&&t<264){legacyChapterAction(s,t);return;}
  if(s.location==='alley'){
   const q=qAt(t,when('c2-120'),.7),H=mixp([82,-337],[82,-429],q);
   callC2('hero',970,960,.76,t,{right:true,hands:[REST[0],H]});c2Actor('girl',1100,966,.49,t,{bloodSleeve:true});return;
  }
  callC2('hero',s.location==='garden'?773:960,s.location==='garden'?960:915,s.location==='garden'?.72:.95,t);return;
 }
 if(['sistercall','roomlock','hearbreak'].includes(a)){
  callC2('girl',1065,915,.65,t,{look:a==='hearbreak'?[-6,0]:[-3,2]});
  if(a==='roomlock'){rect(205,550,127,29,'#7b8e76',4,black,2);rect(253,551,37,28,'#b4b995',4,black,2)}return;
 }
 if(a==='lookdoor'&&s.location==='garden'){drawGardenRescue(s,t);return;}
 if(['dadcall','dadwound','barricade','doorimpact'].includes(a)){
  // Injured arm rests across the body; the phone arm never passes through the face.
  callC2('dad',592,922,.91,t,{bloodSleeve:true,hands:[[-83,-429],[-31,-286]],heldFront:()=>line(-33,-295,-23,-286,'#8c4439',6)});
  if(a==='doorimpact'){
   const pulse=Math.sin(Math.PI*phase(t,s.start+.1,.30))*Math.exp(-Math.max(0,u-.1)*2);
   g.save();g.translate(pulse*3,0);rect(737,580,713,337,'#866c48',4,black,4);for(let i=0;i<3;i++)rect(760+i*225,610,208,277,'#9c8051',2,black,2);g.restore();
  }return;
 }
 if(a==='dadgo'){
  const q=qAt(t,s.start+.12,.45)*(1-qAt(t,s.end-.5,.5));
  callC2('dad',688,916,.91,t,{bloodSleeve:true,hands:[[-83,-429],mixp([-31,-286],[126,-310],q*.65)],look:[5,0]});return;
 }
 if(a==='dadprotect'){
  const begin=s.start,end=s.end;
  moveC2('girl',890,1020,915,.65,t,begin,end,{mask:true});
  c2Actor('dad',688,916,.91,t,{hands:[REST[0],mixp(REST[1],[121,-289],qAt(t,begin,.6)*(1-qAt(t,end-.6,.6)))],bloodSleeve:true});return;
 }
 if(a==='inventory'&&s.location==='home'){callC2('hero',960,915,.95,t);return;}
 if(a==='reaction'){
  if(s.location==='alley'){pocketPhone('hero',970,960,.76,t,s.start,1.25,true);c2Actor('girl',1100,966,.49,t,{bloodSleeve:true});return;}
  if(s.location==='home'){callC2('hero',960,915,.95,t);return;}
  const home=s.location==='home',utility=s.location==='utility',x=home?960:utility?840:948,y=home?915:utility?935:960,sc=home?.95:utility?.88:.72;
  c2Actor('hero',x,y,sc,t,{hands:REST,look:[1,4]});return;
 }
 if(a==='phoneaway'){
  const q=qAt(t,s.start,.9),H=mixp([20,-315],[51,-226],q);
  c2Actor('hero',970,915,.95,t,{hands:[REST[0],H],held:q<.96?(L,R)=>phoneBack(R[0],R[1]-32,28,64):null});return;
 }
 if(a==='headlights'){
  // Infected figures sway and look toward the horn; they do not moonwalk in place.
  const old=c2Figure;c2Figure=(tt,x,y,sc,o)=>old(tt,x,y,sc,{...o,walk:0,head:.12+Math.sin((tt-s.start)*.7)*.025});
  try{legacyChapterAction(s,t);}finally{c2Figure=old;}return;
 }
 if(a==='pairturn'||(a==='pairwalk'&&t>315&&t<321)){
  const begin=at('pairturn'),x=1000-(t-begin)*66.6666666667*.76;
  jacketGrip(t,x,-1,t-begin);return;
 }
 if(a==='bloodsleeve'&&s.location==='alley'&&s.frame!=='insert'){showWrist(s,t);return;}
 if(a==='wristtalk'||a==='sleevedown'){showWrist(s,t);return;}
 if(a==='girlcall'){
  const hx=t>=when('c2-118')?lerp(884,970,qAt(t,when('c2-118'),when('c2-119')-when('c2-118'))):884;
  if(t>=when('c2-118'))moveC2('hero',884,970,960,.76,t,when('c2-118'),when('c2-119'));
  else c2Actor('hero',hx,960,.76,t);
  callC2('girl',1100,966,.49,t,{bloodSleeve:true});return;
 }
 if(a==='phonehandoff'){
  const q=qAt(t,s.start,.8),px=lerp(1045,1046,q),py=lerp(755,704,q);
  phoneBack(px-14,py-32,28,64);
  c2Actor('hero',970,960,.76,t,{hands:worldHands(970,960,.76,[null,[px-14,py]])});
  const release=qAt(t,s.start+.18,1.05),holdQ=qAt(Math.min(t,s.start+.18),s.start,.8),hold=[lerp(1045,1046,holdQ)+14,lerp(755,704,holdQ)],L=worldHands(1100,966,.49,[hold,null])[0],P=[-160,-340],hand=mixp(mixp(L,P,release),mixp(P,REST[0],release),release);
  c2Actor('girl',1100,966,.49,t,{bloodSleeve:true,hands:[hand,REST[1]]});return;
 }
 if(a==='girlturn'){pairedIdle(t,{hx:970,girl:{look:[-6,1],head:0}});return;}
 if(a==='catcharm'){
  const q=qAt(t,s.start,.9),hx=lerp(970,1000,q),target=[1076,790],R=worldHands(hx,960,.76,[null,target])[1];
  c2Actor('hero',hx,960,.76,t,{hands:[REST[0],mixp(REST[1],R,q)]});c2Actor('girl',1100,966,.49,t,{bloodSleeve:true});return;
 }
 if(a==='pairfreeze'){
  if(t>at('catcharm')){const R=worldHands(1000,960,.76,[null,[1076,790]])[1];pairedIdle(t,{hx:1000,hero:{hands:[REST[0],R]}});}
  else pairedIdle(t);return;
 }
 if(a==='pullbehindcar'){
  moveC2('girl',1250,1120,966,.49,t,s.start,s.end,{bloodSleeve:true});moveC2('hero',1130,980,960,.76,t,s.start,s.end);car(903,638,2);return;
 }
 if(a==='mirrorfold'){
  tableBase({...s,title:'WING MIRROR'},t);rect(520,329,862,481,'#416b7a',24,black,4);line(788,447,1087,599,'#2a4450',27);
  const q=qAt(t,s.start,.35);g.save();g.translate(1045,550);g.rotate(q);rect(-113,-63,226,126,'#345660',26,black,4);rect(-92,-46,184,89,'#9bb8b5',17,black,2);g.restore();
  c2Backpack(1040,490,1.8);const hook=[1045+69*Math.cos(q)-2*Math.sin(q),550+69*Math.sin(q)+2*Math.cos(q)];line(1189,591,...hook,'#2e4f46',11);return;
 }
 if(a==='pointgate'){
  gatePanel(0);const q=qAt(t,s.start+.15,.5)*(1-qAt(t,s.end-.55,.55));
  c2Actor('hero',1075,940,.8,t,{hands:[REST[0],mixp(REST[1],[130,-320],q)],look:[6,1]});c2Actor('girl',960,948,.5,t,{bloodSleeve:true});return;
 }
 if(['gateopen','gateenter','gateclose','boltstuck','gatefeet','gatelift','boltlock','gatehit'].includes(a)){gateAction(s,t);return;}
 if(a==='girlflinch'){
  gatePanel(0);bolt(1,t);c2Actor('hero',1065,940,.8,t);c2Actor('girl',1200,948,.5,t,{bloodSleeve:true});return;
 }
 if(['underwindow','towardkitchen','sleevehold','leadtogate'].includes(a)){
  ladder(LAD.x,LAD.y);windowPaneC2(t,1);
  const begin=at('towardkitchen'),hold=at('sleevehold'),leave=at('leadtogate');let hx=t<begin?948:t<hold?948-(t-begin)*48:871.2;
  const leaving=t>=leave;if(leaving)hx=871.2-(t-leave)*48;
  const gx=leaving?hx+98.8:t>=hold?970:t>=begin?lerp(1065,970,qAt(t,begin,hold-begin)):1065,q=t>=hold?qAt(t,hold,.75):0,point=[hx+43,960-202*.72];
  c2Actor('hero',hx,960,.72,t,{walk:(t>=begin&&t<hold)||leaving?1:0,dir:-1,wt:Math.abs(948-hx)/48});
  const L=worldHands(gx,960,.454,[point,null])[0];
  c2Actor('girl',gx,960,.454,t,{bloodSleeve:true,walk:leaving||t>=begin&&t<hold?1:0,dir:-1,period:1.3*.454/.72,wt:leaving?t-leave:Math.abs(1065-gx)/48,hands:[mixp(REST[0],L,q),REST[1]]});return;
 }
 if(['keymiss','keysteady','keyturn'].includes(a)||(a==='sisterask'&&s.location==='backdoor')){keyAction(t);return;}
 if(a==='armcheck'){
  c2Actor('hero',840,935,.88,t,{hands:REST,look:[6,7]});c2Actor('girl',1100,940,.58,t,{hands:[mixp(REST[0],[-115,-294],qAt(t,s.start,.7)),REST[1]],mask:true});return;
 }
 if(a==='foodtray'){
  moveC2('hero',510,660,935,.88,t,s.start,s.end,{hands:[[-50,-250],[55,-250]],held:()=>{rect(-56,-258,121,13,'#c9c19c',3,black,2);bottle(-43,-314,.65);can(15,-290,.55)}});
  c2Actor('girl',1358,830,.60,t,{mask:false});return;
 }
 if(a==='distance'||a==='girlbed'||(a==='sisterask'&&s.location==='spare')){
  const q=1;c2Actor('girl',1358,830,.60,t,{mask:false,hands:REST});
  if(a==='distance'||a==='sisterask')c2Actor('hero',486,930,.9,t,{mask:true});return;
 }
 if(a==='doorajar'||a==='hallseat'){
  const q=qAt(t,at('doorajar'),.75);path([[1105,154],[1105+88*q,179],[1105+88*q,944],[1105,921]],'#9d8054',black,3);
  if(t<at('girlsleep'))c2Actor('girl',1450,711,.38,t,{mask:false});
  else{g.save();g.translate(1425,613);g.rotate(Math.PI/2);c2Actor('girl',0,0,.38,t,{mask:false,noShadow:true});g.restore();rect(1210,616,350,110,'#597f87',3,black,2);}
  c2Actor('hero',845,930,.9,t,{kneel:130*qAt(t,at('hallseat'),1.05),mask:true,hands:[[-52,-265],[56,-265]],look:[3,4]});return;
 }
 legacyChapterAction(s,t);
};
