from pathlib import Path
import json,hashlib,re
P=Path(__file__).resolve().parent;data=json.loads((P/'timeline.json').read_text());words=json.loads((P/'words.json').read_text());D=data['duration']
for i,w in enumerate(words):
 w['end']=min(D,w['end'],words[i+1]['start'] if i+1<len(words) else D)
 if w['end']<=w['start']:w['end']=w['start']+.01
captions=[];buf=[]
def flush():
 global buf
 if buf:captions.append(dict(start=buf[0]['start'],end=min(D,buf[-1]['end']+.08),words=buf));buf=[]
for w in words:
 if buf and (len(buf)>=5 or len(' '.join(x['text'] for x in buf)+' '+w['text'])>37 or w['start']-buf[-1]['end']>.32):flush()
 buf.append(w)
 if w['text'].endswith(('.',',','?','!',':',';')):flush()
flush()
for a,b in zip(captions,captions[1:]):a['end']=min(a['end'],b['start'])
assert sum(len(c['words']) for c in captions)==len(words)
(P/'captions.json').write_text(json.dumps(captions,ensure_ascii=False,indent=2))
(P/'aligned-words.json').write_text(json.dumps(words,ensure_ascii=False,indent=2))
js='const DATA='+json.dumps(data,ensure_ascii=False)+';\nconst WORDS='+json.dumps(words,ensure_ascii=False)+';\nconst CAPTIONS='+json.dumps(captions,ensure_ascii=False)+';\n'
for name in ['drawing.js','opening.js','assets.js','engine.js','chapter2.js','acting.js']:js+=(P/name).read_text()+'\n'
player='''
const audio=document.getElementById('voice'),seek=document.getElementById('seek'),clock=document.getElementById('clock');seek.max=D;
const stamp=x=>Math.floor(x/60)+':'+String(Math.floor(x%60)).padStart(2,'0');
document.getElementById('play').onclick=()=>{if(audio.currentTime>=D-.02)audio.currentTime=0;audio.paused?audio.play():audio.pause()};
seek.oninput=()=>{audio.currentTime=+seek.value;render(+seek.value)};
const fixed=new URLSearchParams(location.search).get('t');
function tick(){render(Math.min(D-.00001,audio.currentTime));seek.value=audio.currentTime;clock.textContent=stamp(audio.currentTime)+' / '+stamp(D);requestAnimationFrame(tick)}
document.fonts.ready.then(()=>fixed!==null?render(+fixed||0):requestAnimationFrame(tick));
'''
html='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Five Days — Chapter 2</title><style>@font-face{font-family:Fredoka;src:url(fonts/fredoka-700.woff2);font-weight:700}*{box-sizing:border-box}body{margin:0;background:#172c34;color:#eee7da;font:14px sans-serif}main{max-width:1440px;padding:16px;margin:auto}canvas{display:block;width:100%;height:auto}footer{display:flex;gap:14px;padding:16px 0;align-items:center}input{flex:1}button{background:#b65d36;color:white;padding:10px 25px;border:0;cursor:pointer}</style><main><canvas id="scene" width="1920" height="1080"></canvas><audio id="voice" src="mix.m4a" preload="metadata"></audio><footer><button id="play">Play / Pause</button><input id="seek" type="range" min="0" value="0" step="0.01"><span id="clock"></span></footer></main><script>'''+js+player+'</script></html>'
(P/'chapter2.html').write_text(html)
def stamp(t):
 n=round(t*1000);return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02},{n%1000:03}'
(P/'zombtlou-chapter2.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(c["start"])} --> {stamp(c["end"])}\n'+ ' '.join(w['text'] for w in c['words']) for i,c in enumerate(captions))+'\n')
digest=hashlib.sha256(js.encode()).hexdigest();(P/'build-hash.txt').write_text(digest)
print('Built',len(data['shots']),'shots,',len(captions),'caption groups,',len(words),'words;',D,'seconds;',digest[:12])
