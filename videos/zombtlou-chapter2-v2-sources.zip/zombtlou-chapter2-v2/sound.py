"""Chapter 2 Foley, evaluated on the unchanged source narration clock."""
from pathlib import Path
import json,sys,subprocess,math,gc
import numpy as np
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P/'audio'))
from sfx import make as library_make
from dsp import SR,place,write_wav

def make(name,dur=.2,pitch=1,seed=1):
 if name not in ['horn','alarm']:return library_make(name,dur=dur,pitch=pitch,seed=seed)
 t=np.arange(round(dur*SR))/SR
 if name=='horn':x=.55*np.sin(2*np.pi*310*t)+.35*np.sin(2*np.pi*392*t)+.1*np.sin(2*np.pi*620*t)
 else:x=np.sin(2*np.pi*(1000*t+130*np.sin(2*np.pi*1.6*t)/(2*np.pi*1.6))) * (.6+.4*np.sin(2*np.pi*2.4*t)**2)
 envelope=np.minimum(1,t/.09)*np.minimum(1,(dur-t)/.25)
 return np.repeat((x*envelope)[:,None],2,axis=1).astype(np.float32)

data=json.loads((P/'timeline.json').read_text());D=data['duration'];cues=[]
def cue(at,name,gain=-32,dur=.14,pitch=1):
 if 0<=at<D:cues.append(dict(at=round(at,5),name=name,gainDb=gain,duration=dur,pitch=pitch))
walking={'walkalone','fastwalk','exitstreet','gardenarrive','towardkitchen','leadtogate','pairwalk','pairturn','pairarrive','neighborenter','zombiewalk','pointgate','gateopen','gateenter','homeenter'}
for s in data['shots']:
 a,b,act=s['start'],s['end'],s['action'];span=b-a
 if act in ['screen','oldmessages']:
  cue(a+.12,'pop',-36,.12)
 if act in ['typing','finaltyping']:
  for k in range(min(10,int(span/.31))):cue(a+.16+k*.31,'tick',-40,.05,1.2)
 if act in ['pack','toolbox','housekey','leavekeys','shedkey','foodtray']:
  cue(a+.35,'tick',-34,.1,.7)
 if act in ['climbup','descend']:
  for k in range(int(span/.8)):cue(a+.25+k*.8,'tick',-37,.09,.7)
 if act in ['sleevedown','jackets','bandagelift','dressing','dresshand','keysteady']:cue(a+.25,'swish',-40,.21)
 if act=='incoming':
  for k in range(min(2,int(span/1.5))):cue(a+.1+k*1.5,'phonering',-32,.7)
for a in [3.4,125.6,469.9,489.1]:cue(a,'phonebuzz',-34,.4)
for a in [.25,8.9]:cue(a,'swish',-34,.7)
for a in [12.1,17.6,31.4,173.8,231.2,248.1,259.4,383.5,389.9]:cue(a,'hit',-31 if a>100 else -36,.18)
cue(57.9,'horn',-35,3.4);cue(102.9,'horn',-32,2.8)
cue(116.15,'alarm',-35,3.7);cue(310.4,'alarm',-39,3.2)
for a in [185.99,190.8,202.4,362.98,375.6,379.3,382.05,403.35,411.4,416.0]:cue(a,'tick',-30,.12,.75)
# Heel contacts were sampled from the final 24 FPS character motion.
for plant in json.loads((P/'qc/foot-plants.json').read_text()):
 cue(plant['t'],'footstep',-32 if plant['id']=='hero' else -38,.14)
# These footsteps belong to the unseen pursuer outside the gate.
for t in [377.08,377.46,377.84,378.22]:cue(t,'footstep',-38,.14)
cues.sort(key=lambda x:x['at'])
(P/'sound-cues.json').write_text(json.dumps(cues,indent=2))
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(P/'narration.mp3'),'-ar',str(SR),'-ac','2','-f','f32le','-'])
voice=np.frombuffer(raw,dtype=np.float32).reshape(-1,2).copy();del raw
fx=np.zeros_like(voice);cache={}
for i,c in enumerate(cues):
 key=(c['name'],c['duration'],c['pitch'],i%3)
 if key not in cache:cache[key]=make(c['name'],dur=c['duration'],pitch=c['pitch'],seed=231+i%3)
 sample=cache[key];place(fx,sample,round(c['at']*SR),10**(c['gainDb']/20))
mix=voice+fx
if float(np.abs(mix).max())>.99:
 fx*=.6;mix=voice+fx
write_wav(str(P/'mix.wav'),mix)
write_wav(str(P/'sfx.wav'),fx)
stats={'sourceSamples':len(voice),'sourceDuration':len(voice)/SR,'voiceGain':1,'timeStretch':1,'sfxCues':len(cues),'peak':float(np.abs(mix).max()),'music':False}
(P/'audio-check.json').write_text(json.dumps(stats,indent=2));print(json.dumps(stats),flush=True)
del voice,fx,mix,cache;gc.collect()
subprocess.run(['ffmpeg','-y','-v','error','-i',str(P/'mix.wav'),'-c:a','aac','-b:a','160k',str(P/'mix.m4a')],check=True)
