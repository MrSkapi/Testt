from pathlib import Path
import zipfile
P=Path(__file__).resolve().parent
files=['README.md','requirements.txt','manifest.json','final-probe.json','drawing.js','opening.js','assets.js','engine.js','chapter2.js','acting.js','audit-motion.mjs','plan.py','build_timeline.py','timeline.json','words.json','aligned-words.json','captions.json','sound.py','sound-cues.json','audio-check.json','narration.mp3','mix.m4a','chapter2.html','build.py','build-hash.txt','render-compatibility.json','qc/final-fix-log.txt','qc/acting-audit.json','qc/foot-plants.json','render-worker.mjs','cdp.mjs','review.mjs','motion-check.mjs','assemble.py','verify-final.py','package.py','transcript.txt','storyboard.txt','zombtlou-chapter2.srt','zombtlou-chapter2-v2-contact.jpg','audio/dsp.py','audio/sfx.py','fonts/fredoka-700.woff2','fonts/LICENSE','final-qc/audio-alignment.json','final-qc/render-audit.json','qc/all-scenes-audit.json','qc/motion-check.json']
files += ['final-qc/'+n+'-motion.jpg' for n in ['walk','climb','descent','phone','gate','key','mirror','dialogue']]
out=P/'zombtlou-chapter2-v2-sources.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name in files:z.write(P/name,arcname='zombtlou-chapter2-v2/'+name)
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print('SOURCE ZIP VERIFIED',out.stat().st_size,flush=True)
