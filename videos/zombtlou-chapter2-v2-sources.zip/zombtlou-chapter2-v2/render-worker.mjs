import fs from 'node:fs';import {spawn} from 'node:child_process';import {connect} from './cdp.mjs';
const opt={};for(let i=2;i<process.argv.length;i+=2)opt[process.argv[i].replace(/^--/,'')]=process.argv[i+1];
const port=+(opt.port||9260),worker=+(opt.worker||0),workers=+(opt.workers||1),fps=24;
fs.mkdirSync('parts',{recursive:true});fs.mkdirSync('qc',{recursive:true});
const data=JSON.parse(fs.readFileSync('timeline.json','utf8')),hash=fs.readFileSync('build-hash.txt','utf8').trim();
const total=Math.ceil(data.duration*fps),per=30*fps,parts=Math.ceil(total/per),{cmd,ws}=await connect(port);
const compat=fs.existsSync('render-compatibility.json')?JSON.parse(fs.readFileSync('render-compatibility.json','utf8')):{};
const reusable=(oldHash,part)=>oldHash===hash||(compat.currentHash===hash&&compat.compatible?.some(q=>q.hash===oldHash&&!q.excludeParts.includes(part)));
for(let part=worker;part<parts;part+=workers){
 if(opt.parts&&!opt.parts.split(',').map(Number).includes(part))continue;
 const a=part*per,b=Math.min(total,a+per),out=`parts/part-${String(part).padStart(3,'0')}.mp4`,ok=out+'.ok';
 if(!opt.force&&fs.existsSync(out)&&fs.existsSync(ok)&&reusable(JSON.parse(fs.readFileSync(ok,'utf8')).hash,part)){console.log('REUSE',part);continue}
 const ff=spawn('ffmpeg',['-y','-v','error','-f','image2pipe','-framerate',String(fps),'-i','-','-an','-c:v','libx264','-threads','1','-preset','fast','-tune','animation','-crf','19','-g','48','-pix_fmt','yuv420p','-r','24','-movflags','+faststart',out],{stdio:['pipe','inherit','inherit']});
 const done=new Promise((r,j)=>ff.on('close',c=>c?j(Error('FFmpeg '+c)):r()));const began=Date.now();
 for(let f=a;f<b;f++){
  const t=f/fps,r=await cmd('Runtime.evaluate',{expression:`render(${t});C.toDataURL('image/jpeg',.96)`,returnByValue:true});
  if(r.exceptionDetails){ff.stdin.destroy();ff.kill();throw Error(JSON.stringify(r.exceptionDetails))}
  const buf=Buffer.from(r.result.value.split(',')[1],'base64');if(!ff.stdin.write(buf))await new Promise(r=>ff.stdin.once('drain',r));
  if((f-a)%120===0)console.log(`W${worker} PART ${part+1}/${parts} FRAME ${f-a}/${b-a} t=${t.toFixed(2)} fps=${((f-a+1)/((Date.now()-began)/1000)).toFixed(2)}`);
 }
 ff.stdin.end();await done;
 const audit=await cmd('Runtime.evaluate',{expression:'JSON.stringify({audit,errors:window.renderErrors,stateDepth})',returnByValue:true});
 fs.writeFileSync(ok,JSON.stringify({hash,frames:b-a,start:a/fps,end:b/fps,seconds:(Date.now()-began)/1000,audit:JSON.parse(audit.result.value)},null,2));
 console.log(`DONE W${worker} PART ${part+1}/${parts} in ${((Date.now()-began)/1000).toFixed(1)}s`);
}
ws.close();console.log('WORKER COMPLETE',worker);
