from pathlib import Path
import json,subprocess,math,hashlib
P=Path(__file__).resolve().parent;data=json.loads((P/'timeline.json').read_text());frames=math.ceil(data['duration']*24);parts=[];build=(P/'build-hash.txt').read_text().strip()
compat=json.loads((P/'render-compatibility.json').read_text()) if (P/'render-compatibility.json').exists() else {}
for k in range(math.ceil(frames/720)):
 p=P/'parts'/f'part-{k:03}.mp4';m=json.loads(p.with_suffix('.mp4.ok').read_text())
 allowed=m['hash']==build or compat.get('currentHash')==build and any(q['hash']==m['hash'] and k not in q['excludeParts'] for q in compat.get('compatible',[]))
 assert allowed,(k,'stale source')
 probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=width,height,r_frame_rate,nb_frames','-of','json',str(p)]))['streams'][0]
 assert probe['width']==1920 and probe['height']==1080 and probe['r_frame_rate']=='24/1'
 assert int(probe['nb_frames'])==m['frames'];assert not m['audit']['errors'];assert m['audit']['stateDepth']==0
 assert m['audit']['audit'].get('legMaxFlex',0)<=32
 parts.append(p)
(P/'parts.txt').write_text('\n'.join("file '"+str(p)+"'" for p in parts)+'\n')
out=P/'zombtlou-animated-chapter2-v2.mp4'
subprocess.run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(P/'parts.txt'),'-i',str(P/'mix.m4a'),'-map','0:v:0','-map','1:a:0','-c','copy','-movflags','+faststart',str(out)],check=True)
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_type,codec_name,width,height,r_frame_rate,nb_frames,duration:format=duration,size','-of','json',str(out)]))
v=next(s for s in probe['streams'] if s['codec_type']=='video');a=next(s for s in probe['streams'] if s['codec_type']=='audio')
assert int(v['nb_frames'])==frames;assert abs(float(a['duration'])-data['duration'])<.03
(P/'final-probe.json').write_text(json.dumps(probe,indent=2))
print(json.dumps(probe,indent=2));print('SHA256',hashlib.sha256(out.read_bytes()).hexdigest())
