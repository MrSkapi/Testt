import fs from 'node:fs';import {connect} from './cdp.mjs';
const {cmd,ws}=await connect(9261),data=JSON.parse(fs.readFileSync('timeline.json','utf8'));let n=0;const errors=[],pops=[],plants=[];
for(const s of data.shots){
 const r=await cmd('Runtime.evaluate',{expression:`(()=>{const out=[];let prev=null;for(let t=${s.start+.001};t<${s.end-.001};t+=1/24){try{render(t);let poses=window.poseFrames||[];if(prev)for(let i=0;i<poses.length;i++){const a=poses[i],b=prev[i];if(!b||a.id!==b.id)continue;if(a.walk&&b.walk&&a.gait>b.gait)for(let foot=0;foot<2;foot++){if(Math.floor(a.gait+foot*.5)>Math.floor(b.gait+foot*.5))out.push({t,id:a.id,foot,plant:true});}for(let arm=0;arm<2;arm++){const jump=Math.hypot(a.elbows[arm][0]-b.elbows[arm][0],a.elbows[arm][1]-b.elbows[arm][1]);if(jump>25)out.push({t,id:a.id,arm,jump});}}prev=poses;}catch(e){out.push({t,error:String(e)});while(stateDepth>0)g.restore();prev=null;}}return out;})()`,returnByValue:true});
 for(const p of r.result?.value||[]){if(p.plant)plants.push({...p,shot:s.id});else if(p.error)errors.push({...p,shot:s.id});else pops.push({...p,shot:s.id,action:s.action});}
 if(r.exceptionDetails)errors.push({shot:s.id,error:r.exceptionDetails.text});
 if(++n%20===0)console.log('AUDITED',n,'/',data.shots.length,'errors',errors.length,'elbow jumps',pops.length);
}
fs.writeFileSync('qc/foot-plants.json',JSON.stringify(plants,null,2));const q={shots:n,errors,elbowJumps:pops};fs.writeFileSync('qc/acting-audit.json',JSON.stringify(q,null,2));console.log(JSON.stringify(q));ws.close();
