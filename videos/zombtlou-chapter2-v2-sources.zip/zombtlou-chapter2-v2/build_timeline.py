from pathlib import Path
import json,re,difflib,wave
from plan import PLAN
P=Path(__file__).resolve().parent;words=json.loads((P/'words.json').read_text())
if (P/'narration.wav').exists():
 with wave.open(str(P/'narration.wav')) as w:D=w.getnframes()/w.getframerate()
else:D=json.loads((P/'timeline.json').read_text())['duration']
norm=lambda t:re.sub('[^a-z0-9]','',t.lower().replace('’',"'"))
for w in words:
 if w['text'].lower()=='shudders':w['text']='shutters'
 if w['text'].lower() in ['daniel','harris']:w['text']=w['text'].capitalize()
N=[norm(w['text']) for w in words];cursor=0;shots=[];issues=[]
for item in PLAN:
 anchor=item['anchor']
 for a,b in [("Don t","Don't"),("don t","don't"),("won t","won't"),("can t","can't"),("Where s","Where's"),("you re","you're"),("Who s","Who's"),("Dad s","Dad's"),("I m","I'm"),("she s","she's")]:anchor=anchor.replace(a,b)
 q=[norm(x) for x in anchor.split()];best=(-1,None,None)
 for i in range(cursor,min(len(N),cursor+150)):
  for n in range(max(1,len(q)-2),len(q)+3):
   score=difflib.SequenceMatcher(None,q,N[i:i+n],autojunk=False).ratio()-.00013*(i-cursor)
   if score>best[0]:best=(score,i,n)
 score,i,n=best
 if score<.72:issues.append([item['anchor'],round(score,3),words[i]['start'],' '.join(x['text'] for x in words[i:i+n])])
 shots.append(dict(item,id=f'c2-{len(shots)+1:03}',start=max(0,words[i]['start']-.055)))
 cursor=i+1
shots[0]['start']=0
for i,s in enumerate(shots):s['end']=shots[i+1]['start'] if i+1<len(shots) else D
assert all(s['end']>s['start'] for s in shots)
(P/'words.json').write_text(json.dumps(words,ensure_ascii=False,indent=2))
(P/'timeline.json').write_text(json.dumps(dict(duration=D,shots=shots),ensure_ascii=False,indent=2))
(P/'storyboard.txt').write_text('\n'.join(f"{s['id']} {s['start']:7.2f}–{s['end']:7.2f} {s['location']:12} {s['action']:17} {s['anchor']}" for s in shots))
print('Duration',D,'shots',len(shots),'words',len(words));print('Low-confidence anchors',json.dumps(issues))
print('Longest shots',[(s['id'],round(s['end']-s['start'],1),s['anchor']) for s in shots if s['end']-s['start']>9])
