// render.mjs — deterministic frame renderer (headless Chromium -> ffmpeg), parallel workers.
//   node render.mjs --project projects/my-video                      full video  -> build/video_silent.mp4
//   node render.mjs --project P --from 30 --to 45 --scale 0.5         preview a range
//   node render.mjs --project P --sheet                               one still per shot -> build/sheets/*.png
//   node render.mjs --project P --stills 3.5,12,40                    stills at times -> build/stills
//   node render.mjs --project P --styles dusk,midnight,golden,neon --at 3.5,12,40   style comparison grid
// Options: --workers N  --scale K  --style ID  --debug  --format png|jpeg  --crf 18  --gl auto|gpu|swiftshader  --out FILE
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const args = {}; { const a = process.argv.slice(2); for (let i = 0; i < a.length; i++) { if (a[i].startsWith('--')) { const k = a[i].slice(2); const v = a[i + 1] && !a[i + 1].startsWith('--') ? a[++i] : true; args[k] = v; } } }
if (!args.project) { console.error('usage: node render.mjs --project projects/<name> [options]'); process.exit(1); }
const PROJECT = path.resolve(args.project);
const BUILD = path.join(PROJECT, 'build'); fs.mkdirSync(BUILD, { recursive: true });
const TYPES = { '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.json': 'application/json', '.woff2': 'font/woff2', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml' };

function listScenes(dir, base) { let out = []; if (!fs.existsSync(dir)) return out; for (const f of fs.readdirSync(dir).sort()) { const p = path.join(dir, f); if (fs.statSync(p).isDirectory()) out = out.concat(listScenes(p, `${base}/${f}`)); else if (f.endsWith('.js') && !f.startsWith('_')) out.push(`${base}/${f}`); } return out; }
const server = http.createServer((req, res) => {
  const url = decodeURIComponent(req.url.split('?')[0]);
  if (url === '/__manifest') { res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); return res.end(JSON.stringify(listScenes(path.join(PROJECT, 'scenes'), '/project/scenes'))); }
  const p = url.startsWith('/project/') ? path.join(PROJECT, url.slice(9)) : path.join(ROOT, url);
  if (!(p.startsWith(ROOT) || p.startsWith(PROJECT)) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': TYPES[path.extname(p)] || 'application/octet-stream', 'Cache-Control': 'no-store' }); fs.createReadStream(p).pipe(res);
}).listen(0);
const PORT = server.address().port;
const gl = args.gl || (process.platform === 'linux' ? 'swiftshader' : 'auto');
const LAUNCH = { args: ['--ignore-gpu-blocklist', '--enable-unsafe-swiftshader', '--disable-dev-shm-usage', ...(gl === 'swiftshader' ? ['--use-angle=swiftshader'] : []), ...(gl === 'gpu' ? ['--enable-gpu', '--use-angle=default'] : [])] };
const FORMAT = args.format === 'jpeg' ? 'jpeg' : 'png';
const CFG = JSON.parse(fs.readFileSync(path.join(PROJECT, 'config.json'), 'utf8'));
const FPS = CFG.fps || 24;

async function openPlayer(browser, style) {
  const qs = new URLSearchParams(); if (args.scale) qs.set('scale', args.scale); if (style || args.style) qs.set('style', style || args.style); if (args.debug) qs.set('debug', '1');
  const page = await browser.newPage({ viewport: { width: 640, height: 360 } });
  page.on('pageerror', e => console.log('[pageerror]', e.message));
  page.on('console', m => { const t = m.text(); if (/ERROR|missing/i.test(t)) console.log('[page]', t); });
  await page.goto(`http://localhost:${PORT}/player.html?${qs}`);
  await page.waitForFunction('window.READY === true || !!window.BOOT_ERROR', null, { timeout: 120000 });
  const boot = await page.evaluate('window.BOOT_ERROR'); if (boot) throw new Error('Player failed to boot: ' + boot);
  const [w, h] = await page.evaluate('window.OUT'); await page.setViewportSize({ width: w, height: h });
  return page;
}
const shot = (page, f) => page.evaluate(i => { window.renderFrame(i); return document.getElementById('main').toDataURL('image/jpeg', .94).split(',')[1]; }, f).then(s => Buffer.from(s, 'base64'));
const fmtT = s => `${Math.floor(s / 60)}m${String(Math.round(s % 60)).padStart(2, '0')}s`;

async function renderVideo() {
 const initial=await chromium.launch(LAUNCH),check=await openPlayer(initial);
 const total=await check.evaluate('window.TOTAL_FRAMES');const missing=(await check.evaluate('window.SHOT_LIST')).filter(s=>!s.ok);if(missing.length)throw Error('Missing shots: '+missing.map(x=>x.id));await initial.close();
 const f0=Math.max(0,Math.round((+args.from||0)*FPS)),f1=Math.min(total,args.to?Math.round(+args.to*FPS):total),workers=+(args.workers||3),chunk=Math.ceil((f1-f0)/workers),dir=path.join(BUILD,'native-parts');fs.mkdirSync(dir,{recursive:true});
 let done=0;const begun=Date.now();const errors=new Set();
 console.log(`Native encoder: ${f1-f0} frames, ${workers} workers, ${CFG.resolution}, ${FPS} fps`);
 const job=async k=>{const first=f0+k*chunk,last=Math.min(f1,first+chunk);if(first>=last)return null;const browser=await chromium.launch(LAUNCH),page=await openPlayer(browser);const file=path.join(dir,`part_${k}.h264`),fd=fs.openSync(file,'w');
 await page.evaluate(({fps,first})=>{window.NATIVE={chunks:[],errors:[],first};const encoder=new VideoEncoder({output(c){const a=new Uint8Array(c.byteLength);c.copyTo(a);NATIVE.chunks.push(a)},error(e){NATIVE.errors.push(String(e))}});encoder.configure({codec:'avc1.420028',width:OUT[0],height:OUT[1],bitrate:12000000,framerate:fps,bitrateMode:'variable',avc:{format:'annexb'},latencyMode:'realtime'});NATIVE.encoder=encoder;},{fps:FPS,first});
 try{for(let a=first;a<last;a+=24){const b=Math.min(a+24,last);const encoded=await page.evaluate(async({a,b,fps})=>{const en=NATIVE.encoder;for(let f=a;f<b;f++){renderFrame(f);const vf=new VideoFrame(document.getElementById('main'),{timestamp:Math.round((f-NATIVE.first)*1e6/fps)});en.encode(vf,{keyFrame:(f-NATIVE.first)%48===0});vf.close();if(en.encodeQueueSize>4)await new Promise(r=>{en.ondequeue=r});}await en.flush();if(NATIVE.errors.length)throw Error(NATIVE.errors.join('; '));const result=NATIVE.chunks.splice(0).map(bytes=>{let s='';for(let i=0;i<bytes.length;i+=32768)s+=String.fromCharCode(...bytes.subarray(i,i+32768));return btoa(s)});return result;},{a,b,fps:FPS});for(const part of encoded)fs.writeSync(fd,Buffer.from(part,'base64'));done+=b-a;if(done%240<24){const elapsed=(Date.now()-begun)/1000;console.log(`${done}/${f1-f0} frames (${Math.round(done/(f1-f0)*100)}%) | ${(done/elapsed).toFixed(1)} fps | ETA ${Math.ceil((f1-f0-done)/(done/elapsed))}s`);}}
 (await page.evaluate('window.ERRORS')).forEach(e=>errors.add(e));await page.evaluate('NATIVE.encoder.close()');}finally{fs.closeSync(fd);await browser.close();}return file;};
 const parts=(await Promise.all(Array.from({length:workers},(_,k)=>job(k)))).filter(Boolean);if(errors.size)throw Error([...errors].join('\n'));
 const raw=path.join(BUILD,'native-full.h264');fs.writeFileSync(raw,'');for(const file of parts)fs.appendFileSync(raw,fs.readFileSync(file));
 const out=path.resolve(args.out||path.join(BUILD,'full-silent.mp4'));
 await new Promise((resolve,reject)=>spawn('ffmpeg',['-hide_banner','-loglevel','warning','-y','-r',String(FPS),'-i',raw,'-an','-c:v','libx264','-preset','fast','-crf',String(args.crf||19),'-threads','3','-pix_fmt','yuv420p','-movflags','+faststart',out],{stdio:'inherit'}).on('close',code=>code?reject(Error('Final encoder '+code)):resolve()));
 console.log(`DONE ${out} | ${((Date.now()-begun)/1000).toFixed(1)} seconds`);
}
// grid of labelled images, laid out by the browser (works on every OS)
async function contactSheet(browser, items, outFile, cols = 4, cellW = 480) {
  const page = await browser.newPage({ viewport: { width: cols * (cellW + 12) + 12, height: 400 } });
  const html = `<html><body style="margin:0;background:#111;font:600 15px sans-serif;color:#eee"><div style="display:grid;grid-template-columns:repeat(${cols},${cellW}px);gap:12px;padding:12px">${items.map(it => `<div><img src="data:image/${FORMAT};base64,${it.img.toString('base64')}" style="width:${cellW}px;display:block;border-radius:4px"><div style="padding:5px 2px">${it.label.replace(/</g, '&lt;')}</div></div>`).join('')}</div></body></html>`;
  await page.setContent(html); await page.screenshot({ path: outFile, fullPage: true }); await page.close();
}
async function renderStills() {
  const browser = await chromium.launch(LAUNCH); const styles = args.styles ? String(args.styles).split(',') : [args.style || null];
  const dir = path.join(BUILD, args.styles ? 'styles' : args.sheet ? 'sheets' : 'stills'); fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir, { recursive: true });
  const all = [];
  for (const st of styles) {
    const page = await openPlayer(browser, st); const fps = FPS;
    let targets;
    if (args.sheet) targets = (await page.evaluate('window.SHOT_LIST')).map(s => ({ t: s.start + (s.end - s.start) * 0.45, label: `${s.id}  ${s.start.toFixed(1)}s${s.ok ? '' : '  (MISSING)'}` }));
    else targets = String(args.stills || args.at || '1').split(',').map(Number).map(t => ({ t, label: `${t}s` }));
    for (const tg of targets) { const img = await shot(page, Math.round(tg.t * fps)); const name = `${st ? st + '_' : ''}${tg.label.split(' ')[0].replace(/[^\w.]/g, '')}_${tg.t.toFixed(2)}.${FORMAT}`; fs.writeFileSync(path.join(dir, name), img); all.push({ img, label: `${st ? `[${st}] ` : ''}${tg.label}`, st }); }
    (await page.evaluate('window.ERRORS')).forEach(e => console.log('  shot error:', e)); await page.close();
  }
  if (args.styles) { const n = all.length / styles.length; await contactSheet(browser, all, path.join(dir, 'style_grid.png'), n, 420); }
  else { const per = 24; for (let i = 0; i < all.length; i += per) await contactSheet(browser, all.slice(i, i + per), path.join(dir, `sheet_${String(i / per + 1).padStart(2, '0')}.png`), 4, 440); }
  await browser.close(); console.log(`Wrote ${all.length} stills + contact sheet(s) to ${dir}`);
}
try { if (args.sheet || args.stills || args.styles) await renderStills(); else await renderVideo(); }
catch (e) { console.error('RENDER FAILED:', e.message); process.exitCode = 1; }
finally { server.close(); }
