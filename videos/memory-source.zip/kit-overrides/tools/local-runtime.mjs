// Reuse the system Chromium provided by this workspace; leave the bundled renderer intact.
import {chromium} from 'playwright';
const launch=chromium.launch.bind(chromium);
chromium.launch=(options={})=>launch({...options,executablePath:'/usr/bin/chromium',args:['--no-sandbox',...(options.args||[])]});
