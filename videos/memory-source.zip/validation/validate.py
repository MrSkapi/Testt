from pathlib import Path
import json,hashlib,statistics,subprocess
p=Path(__file__).resolve().parent.parent
s=json.loads((p/'story/shots.json').read_text());a=s['shots'];assert a[0]['start']==0 and a[-1]['end']==486
for j,x in enumerate(a):
 assert x['end']>x['start']
 assert abs(x['start']*24-round(x['start']*24))<1e-7
 assert abs(x['end']*24-round(x['end']*24))<1e-7
 if j:assert a[j-1]['end']==x['start']
 assert not x['captions'] and not x['sfx']
for f in (p/'scenes').rglob('*.js'):subprocess.run(['node','--check',str(f)],check=True)
r=dict(shots=len(a),duration=486,frames=11664,fps=24,contiguous=True,frame_aligned=True,median_shot=statistics.median(x['end']-x['start'] for x in a),max_shot=max(x['end']-x['start'] for x in a),source_audio_sha256=hashlib.sha256((p/'input/voiceover.mp3').read_bytes()).hexdigest(),scene_source_sha256={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [p/'config.json',p/'story/shots.json',*sorted((p/'scenes').rglob('*.js'))]})
(p/'build/timeline-validation.json').write_text(json.dumps(r,indent=2));print(json.dumps({k:v for k,v in r.items() if k!='scene_source_sha256'},indent=2))
