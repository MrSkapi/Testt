from pathlib import Path
import subprocess,json,hashlib,zipfile
import numpy as np
root=Path('/workspace/2d-video');p=root/'projects/memory';b=p/'build';prefix='memory';out=Path('/workspace')/(prefix+'.mp4');duration=486;frames=11664

def run(a):subprocess.run(a,check=True)
def probe(f,count=False):return json.loads(subprocess.check_output(['ffprobe','-v','error',*(['-count_frames'] if count else []),'-show_streams','-show_format','-of','json',str(f)]))
def compare(f,t0,t1,seconds=4):
 s=[]
 for file,t in [(p/'input/voiceover.mp3',t0),(f,t1)]:
  x=subprocess.check_output(['ffmpeg','-v','error','-ss',str(t),'-i',str(file),'-t',str(seconds),'-ac','1','-ar','16000','-f','f32le','-']);s.append(np.frombuffer(x,dtype='<f4'))
 n=min(map(len,s));c=float(np.corrcoef(s[0][:n],s[1][:n])[0,1]);assert c>.97,(t0,c);return c
vld=json.loads((b/'timeline-validation.json').read_text())
assert 'DONE ' in (b/'full-render.log').read_text() and 'ERROR' not in (b/'full-render.log').read_text()
for f,h in vld['scene_source_sha256'].items():assert hashlib.sha256((p/f).read_bytes()).hexdigest()==h,('Source changed during render',f)
assert hashlib.sha256((p/'input/voiceover.mp3').read_bytes()).hexdigest()==vld['source_audio_sha256']
run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(b/'full-silent.mp4'),'-i',str(p/'input/voiceover.mp3'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-af','apad','-t',str(duration),'-movflags','+faststart',str(out)])
q=probe(out,True);(b/'final-probe.json').write_text(json.dumps(q,indent=2));v=next(s for s in q['streams'] if s['codec_type']=='video');a=next(s for s in q['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'],v['avg_frame_rate'],int(v['nb_read_frames']))==(1920,1080,'24/1',frames)
assert abs(float(v['duration'])-duration)<.001 and abs(float(a['duration'])-duration)<.05 and a['channels']==1
with (b/'decode-check.log').open('w') as log:subprocess.run(['ffmpeg','-v','error','-err_detect','explode','-threads','2','-i',str(out),'-map','0:v','-map','0:a','-f','null','-'],check=True,stderr=log)
assert not (b/'decode-check.log').stat().st_size
checks=[dict(start=t,seconds=4,correlation=round(compare(out,t,t),6)) for t in [2,100,210,350,480]]
r=dict(file=out.name,bytes=out.stat().st_size,duration=duration,video_frames=frames,resolution=[1920,1080],fps=24,full_decode='Passed, zero errors',original_audio='Original English mono recording, AAC 192k, no retiming or added tracks',audio_excerpt_checks=checks,source_sha256=hashlib.sha256((p/'input/voiceover.mp3').read_bytes()).hexdigest(),scene_source_unchanged_during_render=True,continuity_notes=['Same living-room geometry and props in recordings and investigation','Eva recorder POV distinct from orange-clad Ben','Blurred memory faces; photos reveal Nina and silver glasses repair','Chipped original mug / intact kitchen replacement','Headset remains held through opening cut','One continuous wardrobe slide; three-apartment service route','Coast walk ends at following positions','New jacket and yellow coat match the final market preview','Final price appears at the narration price line','No subtitles or live poll publication'])
(b/'final-qc.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2),flush=True)
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';vf="select='not(mod(n,480))',scale=384:-1,drawtext=fontfile="+font+":text='%{pts\\:hms}':x=8:y=8:fontsize=16:fontcolor=white:box=1:boxcolor=black@0.6,tile=5x5:padding=8:margin=8:color=0x151723"
contact=Path('/workspace')/(prefix+'-contact-sheet.jpg')
run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(out),'-vf',vf,'-frames:v','1',str(contact)])
opening=Path('/workspace')/(prefix+'-preview-00-30.mp4')
run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(out),'-t','30','-c:v','libx264','-preset','veryfast','-crf','21','-threads','2','-c:a','copy','-movflags','+faststart',str(opening)])
preview=Path('/workspace')/(prefix+'-passage-preview.mp4');start=9067/24;length=431/24
run(['ffmpeg','-hide_banner','-loglevel','error','-y','-ss',str(start),'-i',str(out),'-t',str(length),'-vf','scale=960:540','-c:v','libx264','-preset','veryfast','-crf','21','-threads','2','-c:a','aac','-b:a','192k','-movflags','+faststart',str(preview)])
pv=next(x for x in probe(preview,True)['streams'] if x['codec_type']=='video');ov=next(x for x in probe(opening,True)['streams'] if x['codec_type']=='video');assert int(pv['nb_read_frames'])==431 and int(ov['nb_read_frames'])==720
pr=dict(file=preview.name,source_range=[start,start+length],duration=length,frames=431,resolution=[960,540],fps=24,extracted_from_final_master=True,audio_correlation=compare(preview,start,0),opening=dict(file=opening.name,frames=720,duration=30,audio_correlation=compare(opening,2,2)));(b/'preview-qc.json').write_text(json.dumps(pr,indent=2));print('PREVIEW',pr,flush=True)
run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(preview),'-vf','fps=1,scale=480:-1,tile=6x3:padding=6:margin=6','-frames:v','1',str(b/'passage-final-motion-sheet.jpg')])
poster=Path('/workspace')/(prefix+'-poster.png')
run(['ffmpeg','-hide_banner','-loglevel','error','-y','-ss','27','-i',str(out),'-frames:v','1',str(poster)])
archive=Path('/workspace')/(prefix+'-source.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for folder in ['input','timeline','story','scenes']:
  for f in sorted((p/folder).rglob('*')):
   if f.is_file() and '__pycache__' not in str(f) and not f.name.endswith('.log'):z.write(f,Path(prefix)/f.relative_to(p))
 for name in ['config.json','README.md']:z.write(p/name,prefix+'/'+name)
 for name in ['timeline-validation.json','final-qc.json','final-probe.json','decode-check.log','preview-qc.json','passage-final-motion-sheet.jpg','validate.py','finish.py']:z.write(b/name,'validation/'+name)
 z.write(preview,'validation/passage-preview.mp4');z.write(contact,'validation/final-contact-sheet.jpg');z.write(poster,'validation/poster.png')
 for f in (root/'engine').glob('*.js'):z.write(f,'kit-overrides/engine/'+f.name)
 for name in ['render-native.mjs','player.html','package.json']:z.write(root/name,'kit-overrides/'+name)
 z.write(root/'tools/local-runtime.mjs','kit-overrides/tools/local-runtime.mjs')
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print('SOURCE ZIP',archive.stat().st_size,flush=True)
