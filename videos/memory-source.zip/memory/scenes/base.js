import {person,HERO,MOM,POSES} from './cast.js';
import {motion} from './animation.js';
import {box} from './sets/props.js';
export const hero=(g,x,y,s,i,o={})=>person(g,{x,y,s,cast:HERO,expr:'neutral',blink:(i.globalT%3.6)>3.48,...o,pose:motion(o.pose||POSES.stand,i.globalT)});
export const mom=(g,x,y,s,i,o={})=>person(g,{x,y,s,cast:MOM,bun:true,old:true,expr:'sad',blink:((i.globalT+.8)%3.9)>3.78,...o,pose:motion(o.pose||POSES.stand,i.globalT,3)});
export function panel(g,x,y,w,h){box(g,x+8,y+13,w,h,'#0d183344',15);box(g,x,y,w,h,'#23364d',15);box(g,x+12,y+12,w-24,h-24,'#d5e1d9',9);}
