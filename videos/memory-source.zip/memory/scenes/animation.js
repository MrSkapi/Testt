import {clamp,lerp,ease,seg,circle} from '/engine/core.js';
import {POSES,breathe} from './cast.js';
export const P=(t,a,b)=>ease.inOut(clamp((t-a)/(b-a)));
export const env=(t,a,b,c,d)=>P(t,a,b)*(1-P(t,c,d));
export function blend(a,b,k){const p={};for(const n in a)p[n]=[lerp(a[n][0],b[n][0],k),lerp(a[n][1],b[n][1],k)];return p;}
export function arm(base,target,side='F'){
 const p={...base},f=side==='F',root=[base.sh[0]+(f?12:-12),base.sh[1]+2],dx=target[0]-root[0],dy=target[1]-root[1],d=clamp(Math.hypot(dx,dy),.01,73.9),ang=Math.atan2(dy,dx)+(f?1:-1)*Math.acos(d/74);
 const hand=[root[0]+dx/Math.max(.01,Math.hypot(dx,dy))*d,root[1]+dy/Math.max(.01,Math.hypot(dx,dy))*d];
 p['e'+side]=[root[0]+Math.cos(ang)*37-(f?12:-12),root[1]+Math.sin(ang)*37];p['h'+side]=[hand[0]-(f?13:-13),hand[1]];return p;
}
export const seat={...POSES.sit,fF:[46,-9],fB:[38,-9]};
export function gesture(base,name,t,dur){let q=POSES[name]||POSES.stand,k=env(t,.12,.65,Math.max(.85,dur-.85),Math.max(1.2,dur-.12)),p={...base};for(let n of['eF','hF','eB','hB'])p[n]=[lerp(base[n][0],q[n][0],k),lerp(base[n][1],q[n][1]+base.sh[1]-q.sh[1],k)];return p;}
export function motion(base,T,seed=1){return breathe(base,T,.35,seed);}
// Finite, planted footsteps: each supporting foot stays fixed in world space.
export function travel(t,A,B,y,s=1.8,duration=3,steps=4){
 const dir=Math.sign(B-A)||1,span=Math.abs(B-A)/s,step=span/(steps-.5),dt=duration/steps;
 let feet=[[3,0],[-11,0]],root=0,phase=clamp(t/duration);
 for(let n=0;n<steps;n++){
  const k=P(t,n*dt,(n+1)*dt),idx=n%2,old=feet[idx][0],target=n===steps-1?span-7:step*(n+1);feet[idx]=[lerp(old,target,k),-Math.sin(Math.PI*k)*12];
  if(t<(n+1)*dt)break;
 }
 root=(feet[0][0]+feet[1][0])*.5;const p={...POSES.stand,hip:[0,-100],sh:[1,-174],head:[5,-208],fF:[feet[0][0]-root,feet[0][1]],fB:[feet[1][0]-root,feet[1][1]]};
 function knee(f){let dx=f[0],dy=f[1]+100,d=Math.min(106.9,Math.hypot(dx,dy)),ang=Math.atan2(dy,dx)-Math.acos(d/107);return[Math.cos(ang)*53.5,-100+Math.sin(ang)*53.5];}
 p.kF=knee(p.fF);p.kB=knee(p.fB);let sw=Math.sin(phase*steps*Math.PI)*10;p.eF=[10+sw,-132];p.hF=[13+sw,-100];p.eB=[-8-sw,-132];p.hB=[-10-sw,-100];
 return{x:A+dir*root*s,y,pose:p,facing:dir};
}
