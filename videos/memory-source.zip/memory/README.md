# AFTER THE BEACH — Someone Else’s Memories

Complete illustrated film for memory.mp3: 486 seconds (8:06), 1920×1080, 24fps, 16:9, 211 contiguous shots and 11,664 frames. Original narration is 484.597500 seconds, kept without retiming. English graphics, no captions or added audio tracks. Established black/orange hero without hat; the final coast trip introduces the blue jacket explicitly mentioned in the story.

Use kit-overrides/ as a minimal studio root, or apply it over the installed 2d-video toolkit. Put memory/ in projects/memory/ under that studio root. Install npm dependencies, ffmpeg and Chromium. tools/local-runtime.mjs selects /usr/bin/chromium here; adjust the executable path for another system.

Render from the studio root:

    node --import ./tools/local-runtime.mjs render-native.mjs --project projects/memory --workers 3 --gl auto --crf 21 --out projects/memory/build/full-silent.mp4

Mux the unchanged narration:

    ffmpeg -i projects/memory/build/full-silent.mp4 -i projects/memory/input/voiceover.mp3 -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -af apad -t 486 -movflags +faststart memory.mp4

story/shots.json owns timing. story/beats.tsv plus build_story.py reproduce the edit from timeline/words.json. story/bible.md records cast, visual clues, continuity and staging. The original recording is authoritative; transcription is an editorial aid.

Use --from A --to B --scale .5 for a partial preview. Never run concurrent native video renders into the same project's build directory, since encoder intermediates are shared. No external generated images or videos are required.

validation/ in the source archive contains timeline/source hashes, full media/voiceover checks, preview validation and master contact sheet. A separate narrated hidden-passage preview is extracted directly from the finished master, not assembled at a different speed.
