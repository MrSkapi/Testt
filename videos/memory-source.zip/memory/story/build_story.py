from pathlib import Path
import json,csv,statistics
p=Path(__file__).resolve().parent.parent
w=json.loads((p/'timeline/words.json').read_text());w=w.get('words',[]) if isinstance(w,dict) else w
beats=[x.split('|') for x in (p/'story/beats.tsv').read_text().strip().splitlines()]
groups=[0,7.1,19.65,25.2,38.85,50.7,61.2,73,90.35,100.1,108.6,121.15,135.3,152,161,179.85,187.05,204.55,228.7,244.4,259.5,275.35,288.85,303.6,330.25,345.85,358.05,377.8,395.75,414.6,429.55,435.6,451.1,475.05,486]
shots=[]
for j,(t,v,m,loc) in enumerate(beats):
 t=float(t);st=round(t*24)/24;en=round(float(beats[j+1][0])*24)/24 if j+1<len(beats) else 486
 k=next(k for k in range(len(groups)-1) if groups[k]<=t<groups[k+1]);params=dict(view=v,mode=m,place=loc,groupStart=groups[k],groupEnd=groups[k+1],night=not(7<=t<19.65 or 113.45<=t<119.3 or 267.3<=t<271.6 or 307<=t<358 or 439<=t<451.1))
 if v in ['police','staged','cafe','coast','forget','originals','testimony'] and j%4==1:params.update(frame='medium',focusX=1110 if v in ['staged','originals'] else 960,focusY=640)
 tr='flash' if t in [7.1,19.65] else 'dip' if t in [73,135.3,152,204.55,307.15,377.8,401.95,435.6,451.1] else 'fade' if t in [25.2,259.5,439.05] else 'cut'
 shots.append(dict(id=f'me{j+1:03}',start=st,end=en,line=' '.join(x['word'] for x in w if st<=x['start']<en),scene=f'{v}: {m}; literal story action in {loc}, grounded 2D acting and layered depth.',set=loc,bars='wide',captions=False,params=params,**{'in':dict(type=tr,dur=.16)},sfx=[]))
assert shots[0]['start']==0 and all(s['end']>s['start'] for s in shots)
(p/'story/shots.json').write_text(json.dumps(dict(title='AFTER THE BEACH — Someone Else’s Memories',duration=486,shots=shots,music=[],sfx=[]),indent=2))
with (p/'story/scene-markers.csv').open('w') as f:
 z=csv.writer(f);z.writerow(['id','start','end','view','mode','location']);z.writerows([s['id'],s['start'],s['end'],s['params']['view'],s['params']['mode'],s['set']] for s in shots)
print(len(shots),'shots;',statistics.median(s['end']-s['start'] for s in shots),'median; 486 seconds')
