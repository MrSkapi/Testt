# AFTER THE BEACH — Someone Else’s Memories

Ben, 32, discovers that a damaged holiday memory contains a killing in his own living room. He and Eva expose the abuse behind a memory marketplace and its room-sharing discount. Later, his first genuine visit to the coast becomes a product without his knowledge.

## Cast and continuity
Ben uses the established black round head and orange hoodie, without headwear, facial hair or anatomy changes. At the real coast trip he deliberately changes to the new blue jacket mentioned by the narration; this jacket remains through the ending. His sister wears a yellow coat. Eva wears muted rose, with a dark bun and small recorder implant. Nina wears teal/green with a patterned cardigan, bun, square glasses and one silver temple repair. Nina and Eva are different people. The supervisor wears dark navy, the police blue, the regular performer olive. Quoted speech alone moves mouths; narration is not lip-synced.

The opening is Eva's implanted recording seen through Ben's headset. Its POV forearm has Eva's rose sleeve. Ben does not attack Nina. Nina backs away and falls beside the couch without a weapon or graphic impact being invented. Her identifying features are blurred in purchased memories; photographs reveal her face later. The silver glasses repair remains a visual clue.

## Sets, light and actions
Sunlit Greece: turquoise sea, white coastal buildings, blue doors, warm stone, slow waves and POV hands. Night living room: blue-green couch, city window on left, radiator beneath it, little table burn at its right edge, hallway/bedroom door on right, practical lamp, books and plants. All repeats preserve this geometry. The record framing excludes the left couch seat where Ben was connected; the later room-sharing and studio scenes show him there. The real 2:16 PM sessions use daylight.

Kitchen: coral/mauve walls, teal cabinets, pale wood counters and the blue mug. The original has a chipped handle. The unnoticed replacement in the kitchen has an intact handle. Trolley evidence and the final comparison make the difference explicit.

Workroom: blue daylight, monitor, files, coffee and weekend work. Temporary hotel: violet room, pink bedding, night window and desk. Eva's remote call room has a separate green-grey wall, window and bookcase; she is not standing in Ben's hotel. Bedroom: blue bedding, wardrobe on the right, visible narrow rails. The wardrobe slides right to reveal the service door. Police/manager stand clear of its path. The service passage and a clear three-apartment plan establish the exit route. Investigation and arrest use a police office, notes and source media. Nina's death is conveyed by evidence and remembrance without depicting a corpse.

Later: cafe conversation, moving cartons and a boxed unused headset. Real coast: grey sky, cool water, blue railing, warm wood walkway, Ben's blue jacket and his sister's yellow coat. These colors and railing recur exactly in the final marketplace preview; faces in that product are blurred. Final evening uses Ben's new green/ochre home, not the earlier hotel.

## Editing and animation
211 contiguous shots, 24fps, 486 seconds. Fixed composition scales, shared absolute group camera clocks, slow parallax and foreground depth; no resetting push-in loops. Inserts, POV, two-shots, large reaction faces, diagrams and varied warm/cool environments. Hand poses use two-segment IK. Supporting feet use planted finite walks. Headset removal follows one continuous action. Coast walking ends at the following shot's planted positions. Repeated traumatic memory holds the falling instant instead of manufacturing a new assault. The three notes are visualized; no new audio is added.

Prices/dates reveal in step with the narration: $9, 2:15 PM, 2:16 PM, another hour, 30% discount, 43 service accesses, then $4 only at the final price line. No exact case number or unknown full surname is fabricated. Onscreen Nina notes use the known name, leaving the surname unfilled.

The channel Posts invitation uses an animated Posts/poll graphic without inventing new story choices, voting totals, selections or a live published poll. No captions or text over characters' heads. Authored interface text is English.

## Audio
Original memory.mp3, 484.597500 seconds, used from sample zero without edits, retiming, replacement speech, music, wind or extra SFX. Encode AAC 192kbps and pad the last visual hold to 486 seconds. All narration remains intact.
