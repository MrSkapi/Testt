# Five Days — Chapter 2

Complete animated chapter, 9:05, 1920 × 1080, 24 FPS. Original TLOUV2.mp3 narration is included unchanged. The mix adds sparse procedural Foley, with no music and no changes to narration timing or gain.

The drawing treatment continues Chapter 1: teal cap, dark orange hoodie, pale round face, black round hands, thin black legs and short stick feet; colored night interiors and exteriors; moving pencil hatching, continuous camera movement, animated object and message entrances. Walking knee deflection stays below 29 degrees from straight. Climbing uses separate fixed-length joint targets attached to ladder rungs and window edges.

195 narrative shots cover the phone call, blocked street, approach to the parents’ house, window rescue, ladder descent, return through the gate, and the uncertain exposure at dawn. Short English captions use white bold rounded letters with dark outlines; only the currently spoken word turns yellow.

## Edit

- `chapter2.html`: ready browser player. Serve this folder over HTTP.
- `chapter2.js`: new sets, actions, ladder, gate and hand contacts.
- `drawing.js`, `opening.js`, `assets.js`, `engine.js`: shared drawing helpers, actor rig, reusable props and captions. Chapter 2 overrides legacy narrative staging.
- `plan.py`, `build_timeline.py`, `timeline.json`, `storyboard.txt`: editable narrative plan and shot timing.
- `words.json`, `aligned-words.json`, `captions.json`, `zombtlou-chapter2.srt`: speech timing and captions. The MP4 contains highlighted captions; SRT is a plain-text fallback.
- `sound.py`, `audio/`, `sound-cues.json`: editable Foley and the unchanged narration mix.
- `narration.mp3`: the complete original user upload.
- `mix.m4a`: full video soundtrack.
- `manifest.json`, `final-probe.json`, `final-qc/`: rendered-video checks.

## Rebuild

Requires Python 3, NumPy, SciPy, Pillow, Node 22+ with native WebSocket, Chromium and FFmpeg. The font and sound generator are included; video rendering does not require a model download or an API key. To edit scene timing, change plan.py and run build_timeline.py before build.py. Word timestamps are already provided; retranscription is unnecessary.

```sh
python -m pip install -r requirements.txt
python build.py
python sound.py
python -m http.server 8768 --bind 127.0.0.1
```

Open http://127.0.0.1:8768/chapter2.html to play or scrub the full editable scene.

For video export, start Chromium in another terminal. In a container use its usual sandbox configuration; this environment runs it with --no-sandbox.

```sh
chromium --headless --disable-dev-shm-usage --disable-gpu --remote-debugging-port=9250 --user-data-dir=/tmp/chapter2-render about:blank
node review.mjs
node render-worker.mjs --port 9250 --worker 0 --workers 1
python assemble.py
python verify-final.py
python package.py
```

The render script resumes from source-hash-verified 30-second parts. The final H.264/AAC MP4 has native 24 FPS animation. GitHub repository .bin chunks transport the exact master to a Release; the workflow verifies each chunk and the concatenated MP4 without re-encoding.
