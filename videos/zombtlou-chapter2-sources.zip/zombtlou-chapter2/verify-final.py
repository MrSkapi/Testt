from pathlib import Path
from PIL import Image,ImageDraw
import subprocess,json,hashlib,numpy as np,math,sys
P=Path(__file__).resolve().parent;Q=P/'final-qc';Q.mkdir(exist_ok=True)
video=P/'zombtlou-animated-chapter2-full.mp4';data=json.loads((P/'timeline.json').read_text());D=data['duration']
times=[0.8, 4.6, 7.7, 10, 14.5, 21, 29, 36, 45, 52, 56.5, 65, 73, 80, 87, 97, 104, 107, 112, 117, 122, 126, 134, 140, 151, 156, 163, 174, 183, 189.4, 191.8, 194, 198.1, 203, 210.7, 214, 217.8, 223.2, 224.5, 230.1, 238, 244.7, 246.5, 249, 253.8, 260, 264.3, 271.8, 276, 285, 294, 304, 311, 324, 330, 340.4, 352.9, 359, 361.5, 363, 371.6, 373, 376, 379.5, 382.2, 384, 394, 402, 405, 411.6, 418.5, 423, 426, 438.5, 446, 450, 453, 467.8, 474, 484, 500, 506, 514, 519.7, 527, 530, 536.8, 541.4, 544.5]
# A localized front-layer correction can reuse the already verified, unchanged
# images/audio, while decoding every frame of the changed 30-second range.
localized='--localized-fitting' in sys.argv
# Decode the whole file once and collect the requested native frames.
frames=[min(math.ceil(D*24)-1,round(t*24)) for t in times]
selection='+'.join(f'eq(n\\,{f})' for f in frames)
if localized:
 subprocess.run(['ffmpeg','-v','error','-i',str(P/'parts'/'part-009.mp4'),'-f','null','-'],check=True)
 i=times.index(285.9)
 subprocess.run(['ffmpeg','-y','-v','error','-ss',str(frames[i]/24),'-i',str(video),'-frames:v','1',str(Q/f'frame-{i+1:03d}.png')],check=True)
else:
 subprocess.run(['ffmpeg','-y','-v','error','-i',str(video),'-vf','select='+selection,'-fps_mode','vfr',str(Q/'frame-%03d.png')],check=True)
paths=sorted(Q.glob('frame-*.png'));assert len(paths)==len(frames),(len(paths),len(frames))
out=Image.new('RGB',(1920,math.ceil(len(paths)/4)*294),'#172c34');draw=ImageDraw.Draw(out)
for i,(f,t) in enumerate(zip(paths,times)):
 im=Image.open(f).convert('RGB');assert im.size==(1920,1080)
 # A simple coverage check catches accidental blank/transparent-camera edges.
 arr=np.asarray(im);assert arr.mean()>15 and arr.std()>10,(f,'unexpected dark/blank frame')
 im=im.resize((480,270));x=i%4*480;y=i//4*294;out.paste(im,(x,y));draw.text((x+10,y+274),f'{int(t)//60:02}:{t%60:05.2f}',fill='#fff0c3')
# A compact release contact sheet; detailed encoded samples remain below.
chosen=[0,1,8,12,15,19,24,28,30,33,36,41,44,48,52,55,60,62,65,70,74,78,83,87]
poster=Image.new('RGB',(1920,1764),'#172c34');pd=ImageDraw.Draw(poster)
for j,i in enumerate(chosen):
 im=Image.open(paths[i]).resize((480,270));x=j%4*480;y=j//4*294;poster.paste(im,(x,y));pd.text((x+8,y+274),f'{times[i]:.2f}s',fill='white')
poster.save(P/'zombtlou-chapter2-contact.jpg',quality=92)
# Keep two manageable sheets for close visual review.
for k in range(0,len(paths),12):
 out=Image.new('RGB',(1440,math.ceil(min(12,len(paths)-k)/3)*294),'#172c34');draw=ImageDraw.Draw(out)
 for j,f in enumerate(paths[k:k+12]):
  im=Image.open(f).resize((480,270));x=j%3*480;y=j//3*294;out.paste(im,(x,y));draw.text((x+8,y+274),f'{times[k+j]:.2f}s',fill='#fff0c3')
 out.save(Q/f'encoded-sheet-{k//12:02}.jpg',quality=91)
# Native 24-fps movement samples, taken from the final muxed file.
sequences={'walk':[106.0+i*.18 for i in range(8)],
 'climb':[209.5+i*.28 for i in range(8)],
 'descent':[252.9+i*.30 for i in range(8)],
 'phone':[339.93+i*.10 for i in range(8)],
 'gate':[370.98+i*.16 for i in range(8)],
 'key':[410.96+i*.09 for i in range(8)]}
for name,ts in ([] if localized else sequences.items()):
 out=Image.new('RGB',(1600,484),'#172c34');draw=ImageDraw.Draw(out)
 for i,t in enumerate(ts):
  f=Q/f'{name}-{i}.jpg';subprocess.run(['ffmpeg','-y','-v','error','-ss',str(t),'-i',str(video),'-frames:v','1','-vf','scale=400:225',str(f)],check=True)
  im=Image.open(f);x=i%4*400;y=i//4*242;out.paste(im,(x,y));draw.text((x+6,y+226),f'{t:.2f}s',fill='white')
 out.save(Q/f'{name}-motion.jpg',quality=91)
def decoded(path):
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-vn','-ar','16000','-ac','1','-f','f32le','-'])
 return np.frombuffer(raw,dtype=np.float32)
if localized:
 def audio_hash(path):return subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-map','0:a:0','-c','copy','-f','hash','-hash','sha256','-']).strip()
 assert audio_hash(video)==audio_hash(P/'mix.m4a'),'Audio payload changed'
 checks=json.loads((Q/'audio-alignment.json').read_text())
else:
 source=decoded(P/'narration.mp3');output=decoded(video);checks=[]
 for t in [4.3,59.5,119.5,210.4,299.5,391.4,479.1,539.3]:
  k=round(t*16000);n=4800;a=source[k:k+n];window=output[k-100:k+n+100]
  lag=int(np.argmax(np.correlate(window,a,'valid')))-100
  corr=float(np.corrcoef(a,output[k+lag:k+lag+n])[0,1]);checks.append(dict(at=t,lagSamples=lag,correlation=corr))
assert all(abs(c['lagSamples'])<=1 for c in checks),checks
(Q/'audio-alignment.json').write_text(json.dumps(checks,indent=2))
audits=[]
for f in sorted((P/'parts').glob('*.ok')):
 q=json.loads(f.read_text());assert not q['audit']['errors'] and q['audit']['stateDepth']==0
 audits.append(dict(part=f.stem,hash=q['hash'],frames=q['frames'],audit=q['audit']['audit']))
meta={'title':'Five Days — Chapter 2','duration':D,'width':1920,'height':1080,'fps':24,'nativeFrames':math.ceil(D*24),'sourceHash':(P/'build-hash.txt').read_text().strip(),'sha256':hashlib.sha256(video.read_bytes()).hexdigest(),'bytes':video.stat().st_size,'walkingMaxKneeFlex':max(x['audit'].get('legMaxFlex',0) for x in audits),'audioAlignment':checks,'parts':audits}
(P/'manifest.json').write_text(json.dumps(meta,indent=2));(Q/'render-audit.json').write_text(json.dumps(audits,indent=2))
print('FINAL VERIFIED:',video.stat().st_size,'bytes;',len(paths),'native sample frames; max knee flex',meta['walkingMaxKneeFlex'],'; audio lags',[q['lagSamples'] for q in checks],flush=True)
