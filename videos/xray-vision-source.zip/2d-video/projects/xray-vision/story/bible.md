# X-Ray Vision — choose where to stop

Original English V3.1.mp3 narration, 462.184490 seconds, preserved in full. Film length463.5 seconds. No subtitles or added sound beds. Local PocketSphinx recognition supplies rough timing anchors and is not a verified transcript.

## Visual continuity
Reuse the approved 2D drawing language: black round heads, white understated facial features, turquoise knitted beanie, ochre hoodie, warm plum/olive/amber environments, fine rim light, soft grain, contact and projected shadows. No plastic 3D character models. Depth comes from layered sets, close views, selective focus and cutaway panels. Keep clothes visible and consistent: X-ray panels are a distinct stylized view of pocket contents and schematic bones, not wardrobe changes or nudity. No graphic injuries. The narrator is not lip-synced.

## Story and picture plan
1. Street discovery: a neighbor and dog, winter coat, six people at a bus stop, a phone in a pocket and delivery packages visible through a van. Hero averts his eyes. Establish the power with graphic scan windows.
2. Training focus: cereal-box cover, contents, kitchen wall, neighbor and toaster. Parallax planes and a focus dial explain selective depth.
3. Everyday advantages and rules: couch earbud/coins/fork, avocado cutaways, friend's bag, coin in sleeve, privacy rules, socks, cable drawer, broken package, screw behind washer and leaking pipe. Dedicated object inserts carry the jokes.
4. Limits: a menu reveals a kitchen and alley; a transparent moving car is a hazard; normal vision comes first. Nighttime layers, sleep mask, medical-training comparison and the guilty dog with the dinosaur.
5. Collapse: a new renovation site, stable damaged landing above a cavity under concrete. Daniel lies head-left/feet-right. X-ray depth briefly overshoots to a room beyond before the hero finds the correct layer. Workers see opaque rubble; one steps back from the loose support. Rescue crew checks equipment, confirms position and works while hero waits. A passage opens, the casualty is brought out and reunited with his brother. No miraculous lifting or moving through concrete.
6. Cafe resolution: the hero stops scanning a paper bag, accepts a surprise dinosaur in sunglasses, and waves to the neighbor using normal vision. End question and couch/fork callback.

## Graphics, sound and checks
English labels only on separate explanatory boards or physical signs, never dialogue over heads. Red SUBSCRIBE and blue LIKE. Hard cuts dominate with a few short dips, depth zooms and energetic montage whips. Original voice only, no replacement speech, music or wind loop. All timing lives in shots.json. Inspect every contact sheet, representative motion and the final encoded film. Deliver MP4 and editable source via the user's GitHub repository.
