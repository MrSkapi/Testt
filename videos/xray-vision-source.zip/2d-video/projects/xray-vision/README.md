# What If You Had X-Ray Vision?

Animated film built for the supplied English `V3.1.mp3` narration. The voiceover is 462.184490 seconds; the final film is 463.5 seconds (11,124 frames at 24 fps), including a short tail. Canvas 2D at 1920×1080, warm illustrated sets, layered depth, selective focus and schematic X-ray reveals. The hero retains the turquoise knitted beanie and ochre hoodie from the approved design.

No burned subtitles, replacement voice, music or ambience are added. Explanatory text is in English on separate graphics. The red SUBSCRIBE and blue LIKE buttons retain the established colours.

The X-ray effect preserves the clothing silhouette and renders schematic bones within it. It is a fictional visual device, not medical imaging. The story's training and diagnostic limits remain in the supplied narration. The rescue sequence uses a consistent cavity and casualty position; the cavity is empty after the casualty moves onto the stretcher.

## Timing and source

`story/shots.json` owns 158 contiguous shots. `story/bible.md` records visual continuity and the picture plan. `timeline/rough-asr.json` and `transcript-rough.txt` are independent PocketSphinx recognition used only as editing anchors. They contain recognition errors and are not a verified verbatim script or captions. The original MP3 is authoritative and included unchanged.

## Rebuild

The source archive includes the engine, project, original voiceover, renderers and pinned npm manifests. Install Node.js and ffmpeg, then run commands from the archive's `2d-video` directory.

```sh
npm ci
npx playwright install chromium
node render.mjs --project projects/xray-vision --sheet --scale 0.4 --gl auto
node render-native.mjs --project projects/xray-vision --workers 3 --gl auto --crf 23 --out projects/xray-vision/build/full-silent.mp4
ffmpeg -y -i projects/xray-vision/build/full-silent.mp4 -i projects/xray-vision/input/voiceover.mp3 -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -af apad -t 463.5 -movflags +faststart xray-vision-complete.mp4
```

In this cloud workspace, add `--import ./tools/local-runtime.mjs` directly after `node` to use `/usr/bin/chromium`. Keep `--gl auto`: forcing SwiftShader slows the pure 2D render considerably here.

All storyboard sheets and representative encoded motion are inspected before the full render. Final delivery is checked for frame count, audio/video timing and complete decoding without errors.
