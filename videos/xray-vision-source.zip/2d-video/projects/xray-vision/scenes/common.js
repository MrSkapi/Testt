import {layer,blurLayer,veil,alpha,text,FONTS,lerp,ease} from '/engine/core.js';
import {C,box,shadow} from './sets/props.js';
import {street,apartment,cafe,market,office,atmosphere} from './sets/world.js';
import {closeFace,HERO,FRIEND} from './cast.js';
export const camera=(t,i,o={})=>{const p=ease.inOut(t/i.dur),c={z:1,x:0,y:0,...(i.camera||{}),...o};return{...c,z:c.z+.045*p,x:c.x+lerp(-14,14,p)};};
export function setting(g,t,i,where='street',opts={}){const cam=camera(t,i);({street,apartment,cafe,market,office}[where]||street)(g,i.globalT,cam,opts);return cam;}
export function portrait(g,t,i){blurLayer(g,11,g=>setting(g,0,i,i.where||'street',{kind:i.kind,night:i.night}));veil(g,C.ink,.23);closeFace(g,i.friend||i.neighbor||i.plumber?1110:845,601,238*(1+.04*ease.inOut(i.p)),{cast:i.neighbor?{color:"#8c8973"}:i.plumber?{color:"#6c8882"}:i.friend?FRIEND:HERO,expr:i.expr||'sad',look:[.35,-.1],blink:(t%4.1)>3.96});atmosphere(g,t);}
export function chair(g,x,y,side=1){shadow(g,x,y+120,53,8);box(g,x-44,y-8,91,17,'#464d45',5);for(let dx of[-34,38]){g.strokeStyle='#354239';g.lineWidth=8;g.beginPath();g.moveTo(x+dx,y+6);g.lineTo(x+dx*1.13,y+120);g.stroke();}box(g,x+side*36,y-134,8,133,'#455244',3);box(g,x-24,y-135,67,9,'#455244',3);}
