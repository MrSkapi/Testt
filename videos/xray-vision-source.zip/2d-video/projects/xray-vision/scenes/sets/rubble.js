import {layer,backdrop,seg,poly,circle,alpha,shade,glow,rng,text,FONTS,ease,prog,lerp} from '/engine/core.js';
import * as FX from '/engine/fx2d.js';
import {person,POSES} from '../cast.js';
import {C,box,ellipse,shadow,car,arrow} from './props.js';
import {XR,reveal} from './xray.js';
import {floor,atmosphere} from './world.js';
export const WORKER={color:'#b28a55'},CREW={color:'#96764f'},DANIEL={color:'#a46e63'},BROTHER={color:'#727f75'};
export function worker(g,o){person(g,{...o,cast:o.cast||WORKER});const p=o.pose||POSES.stand,s=o.s||1;g.save();g.translate(o.x,o.y);g.scale((o.facing??1)*s,s);const hx=p.head[0],hy=p.head[1];g.fillStyle=C.paper;g.beginPath();g.arc(hx,hy-5,29,Math.PI,Math.PI*2);g.fill();box(g,hx-33,hy-9,66,9,'#c7b993',3);seg(g,[[hx-17,hy-27],[hx-17,hy-11]],3,'#e9d9b1');seg(g,[[p.sh[0]-11,p.sh[1]+13],[p.hip[0]-9,p.hip[1]-4]],4,'#d7cf9b');seg(g,[[p.sh[0]+11,p.sh[1]+13],[p.hip[0]+11,p.hip[1]-4]],4,'#d7cf9b');g.restore();}
export function block(g,x,y,w,h,a=0,c='#a89d89'){g.save();g.translate(x,y);g.rotate(a);poly(g,[[-w*.5,-h*.5],[w*.5,-h*.5],[w*.5-12,h*.5],[-w*.5+4,h*.5]],c);poly(g,[[w*.5,-h*.5],[w*.5+12,-h*.5+10],[w*.5,h*.5+11],[w*.5-12,h*.5]],shade(c,-.23));seg(g,[[-w*.4,-h*.5+5],[w*.4,-h*.5+5]],2,alpha(C.cream,.29));seg(g,[[-w*.19,-h*.31],[-w*.07,-h*.05],[-w*.12,h*.35]],1,shade(c,-.26));g.restore();}
export function casualty(g,t,o={}){const p={...POSES.stand,sh:[Math.sin(t*1.6)*.8,-174],eF:[24,-142],hF:[26,-109],eB:[-7,-139],hB:[-5,-108],kF:[19,-51],fF:[5,0],kB:[-7,-48],fB:[-15,0]};person(g,{x:o.x||1330,y:o.y||754,s:o.s||.72,rot:-Math.PI/2,pose:p,cast:DANIEL,expr:'tired',shadow:false});}
export function cavity(g,t,{light=false,empty=false}={}){box(g,994,625,440,173,light?'#3a3932':XR.dark,12);poly(g,[[1005,630],[1414,654],[1425,701],[1006,669]],'#777c6c');for(let j=0;j<4;j++)seg(g,[[1050+j*90,641],[1069+j*90,674]],2,'#b2b49b55');if(!empty)casualty(g,t);if(light){poly(g,[[1423,702],[1138,718],[1138,781],[1423,775]],'#f4dda11c');glow(g,1399,738,96,C.gold,.15);}}
export function rubble(g,t,cam={},o={}){
 layer(g,cam,.12,g=>{backdrop(g,['#77777c','#b49c88','#e0c39a']);FX.sun(g,1510,161,38,C.cream,C.gold,4);for(let j=-1;j<6;j++)box(g,j*394,310-(j*31%130),352,395,'#85807866');});
 layer(g,cam,.35,g=>{box(g,740,-220,1190,902,'#948773');for(let row=0;row<3;row++)for(let j=0;j<5;j++){let x=791+j*231,y=40+row*181;box(g,x,y,160,129,'#576661',5);box(g,x+13,y+13,132,102,'#8b9b8b',3);box(g,x+77,y+10,8,110,'#53665f');}for(let j=0;j<6;j++)seg(g,[[760+j*190,-100],[760+j*190,639]],8,'#5c6660');for(let y of[15,214,417,624])seg(g,[[730,y],[1960,y]],10,'#b5aa91');box(g,877,356,891,344,'#3b4744');for(let j=0;j<5;j++)seg(g,[[917+j*180,401],[917+j*180,676]],12,'#717b6c');floor(g,686,'#877f70');car(g,313,766,.55,'#8d8d7c');});
 layer(g,cam,.68,g=>{box(g,897,577,625,112,'#6c7060');for(let j=0;j<7;j++)block(g,915+j*77,605-j*13,88,38,-.05,'#9b947e');
 block(g,1218,612,521,64,.16,'#b9ad96');seg(g,[[963,574],[1007,800]],14,'#565c52');seg(g,[[1450,638],[1482,809]],14,'#565c52');seg(g,[[958,583],[966,608],[951,619]],5,'#d1cab1');
 if(o.cleared)cavity(g,t,{light:true,empty:o.emptyCavity});
 const R=rng(344);for(let j=0;j<45;j++){let x=835+R()*835,y=723+R()*156,w=42+R()*121,h=21+R()*55;if(o.cleared&&x>1014&&x<1430&&y<792)continue;block(g,x,y,w,h,(R()-.5)*.8,['#a39b86','#8e8b79','#b1a48e'][j%3]);}
 seg(g,[[1040,540],[1015,508],[1030,467],[1017,432]],7,'#6b7368');seg(g,[[1337,580],[1360,546],[1352,505]],6,'#747a6e');
 for(let j=0;j<12;j++){let x=800+j*95;circle(g,x,882+(j%3)*9,4,'#5f655b');}box(g,1666,611,150,130,'#a58250',7);seg(g,[[1691,642],[1790,642]],3,'#c2a46d');});
 if(o.scan)layer(g,cam,.72,g=>{reveal(g,1008,630,420,178,o.scan,g=>cavity(g,t));});
 if(o.dust){FX.fog(g,420,480,'#c1b39a',.19);for(let j=0;j<7;j++)ellipse(g,770+j*145,678,70+j*14,47+j*8,'#cbb89916');}
 atmosphere(g,t,false);
}
export function rescueVan(g,x=250,y=861,s=.72){g.save();g.translate(x,y);g.scale(s,s);box(g,-220,-237,466,205,'#c2c1a9',19);box(g,-216,-106,454,34,'#a76c4e');for(let xx of[-139,149]){circle(g,xx,-16,41,C.ink);circle(g,xx,-16,22,'#7e8d80');}box(g,-176,-215,106,70,'#607b79',7);box(g,171,-215,55,70,'#607b79',7);box(g,-9,-266,103,22,'#6d9993',4);seg(g,[[28,-203],[28,-141]],13,'#9f6e55');seg(g,[[0,-172],[57,-172]],13,'#9f6e55');g.restore();}
export function toolCase(g,x,y,s=1){g.save();g.translate(x,y);g.scale(s,s);box(g,-80,-67,160,67,'#a07f52',9);box(g,-24,-81,48,16,'#4b5145',4);for(let xx of[-48,48])box(g,xx,-41,12,25,'#d0bf8e',3);g.restore();}
export function instrument(g,x,y,s=1){g.save();g.translate(x,y);g.scale(s,s);seg(g,[[-28,0],[0,-112],[40,0]],6,'#7b9286');box(g,-48,-157,99,62,'#425f5f',8);box(g,-38,-148,78,43,'#779e8b',4);seg(g,[[-29,-125],[-17,-125],[-10,-138],[-3,-113],[7,-126],[31,-126]],2,XR.bright);seg(g,[[0,-97],[112,-45],[115,-2]],4,'#2f4545');g.restore();}
export function stretcher(g,x,y,s=1){g.save();g.translate(x,y);g.scale(s,s);shadow(g,0,1,215,15);for(let xx of[-139,143])circle(g,xx,-8,17,'#323a39');seg(g,[[-165,-32],[150,-107],[-145,-107],[167,-32]],7,'#91a294');box(g,-182,-116,367,22,'#8c9f83',11);seg(g,[[-207,-116],[208,-116]],8,'#c9c6a7');person(g,{x:100,y:-133,s:.88,rot:-Math.PI/2,cast:DANIEL,pose:POSES.stand,expr:'tired',shadow:false});box(g,-49,-172,141,52,'#9aab8a',12);g.restore();}
