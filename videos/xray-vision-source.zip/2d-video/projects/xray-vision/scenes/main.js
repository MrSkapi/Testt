import {registerShot} from '/engine/core.js';
import {life} from './shots/life.js';
import {graphics} from './shots/graphics.js';
import {rescue} from './shots/rescue.js';
const views={...life,...graphics,...rescue};
for(let n=1;n<=240;n++)registerShot('x'+String(n).padStart(3,'0'),{draw(g,t,info){const fn=views[info.view];if(!fn)throw Error('Unknown view '+info.view);fn(g,t,info);}});
