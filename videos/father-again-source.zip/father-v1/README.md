# AGAIN — Which One Is Your Father?

Complete animated film for the supplied fatherV1.1.mp3. 1920×1080, 24fps, 16:9 with fixed 60px letterbox bars. Timeline: 489 seconds (8:09), 172 contiguous shots, 11,736 frames. The original recording is 488.176327 seconds; the final visual hold lasts less than a second. Original narration is preserved without retiming. No subtitles, music or added SFX.

Hero: the previous black drawn character in an orange hoodie, without a hat. Story-specific Father has crooked glasses and a patterned teal shirt; Mother's separate account wears mauve. The project is built from original Canvas drawings; no generated image/video assets are required.

The authoritative timeline is story/shots.json. story/beats.tsv and build_story.py document the editorial starting point. timeline/rough-asr.json contains imperfect local ASR for timing assistance, not verified captions. Scene-marker CSV is generated from the final timeline.

Install the supplied project folder as projects/father-v1/ inside the installed 2d-video toolkit. Copy kit-overrides/ into the toolkit root. Install its npm dependencies, ffmpeg, and a Chromium browser. The included local-runtime.mjs selects /usr/bin/chromium; adjust that path on another machine.

Render:

    node --import ./tools/local-runtime.mjs render-native.mjs --project projects/father-v1 --workers 3 --gl auto --crf 21 --out projects/father-v1/build/full-silent.mp4

Mux without changing narration speed:

    ffmpeg -i projects/father-v1/build/full-silent.mp4 -i projects/father-v1/input/voiceover.mp3 -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -af apad -t 489 -movflags +faststart father-again-complete.mp4

For previews use --from A --to B --scale .5. Do not run two native video renders into the same project's build directory simultaneously.

The camera uses a constant scale and an absolute sequence clock for lateral movement. Deliberate framing cuts are separate from camera animation. Walking has planted world-space feet; a shared global clock preserves the hallway position across shots. Individual hand/prop actions and physical screen placement are authored in scenes/main.js, animation.js and objects.js.

validation/ includes final timeline/media checks and representative motion previews. See story/bible.md for character, location, continuity and visual-design choices.
