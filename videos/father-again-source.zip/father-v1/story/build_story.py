import json,csv
from pathlib import Path
p=Path(__file__).resolve().parent.parent
w=json.loads((p/'timeline/rough-asr.json').read_text())['words']
beats=[]
for row in (p/'story/beats.tsv').read_text().strip().splitlines():
 a=row.split('|');beats.append({'start':float(a[0]),'view':a[1],'mode':a[2], 'mother':len(a)>3})
shots=[]
places={'garage':'garage','engine':'garage','ignition':'garage','lake':'river','carOffer':'garage','reject':'garage','friend':'kitchen','kitchen':'kitchen','motherCall':'kitchen','showBody':'showroom','price':'showroom','server':'servers','mechanism':'servers','arrive':'hallway','momTable':'kitchen','closedLid':'kitchen','devices':'kitchen','duel':'kitchen','final':'kitchen'}
descriptions={'absence':'Framed family photograph, untouched car keys and calendar in the actual room.','home':'Evan listens and reacts across a physical desk from the laptop copy of Dad.','screen':'Insert: Dad inside his video-call window, crooked glasses and patterned shirt.','face':'Reaction close-up, with blurred physical location and motivated eye line.','memoryCall':'Insert: the last phone message beside a family photograph.','advert':'An online advertisement shows a woman introducing a baby to a reconstruction.','uploads':'Family photographs, home video, messages and email are uploaded through a real monitor.','mechanism':'Digital history flows through the server to a reconstructed face; an explanatory insert.','rules':'Concrete account settings, permissions and independent-account notice on a screen.','motherCall':'Mother in her warm kitchen declines the suggestion.','kitchen':'Evan stirs a pot while Dad watches from a laptop on the kitchen counter.','friend':'Two-shot: a friend challenges Evan; a ringing phone interrupts the conversation.','handheld':'Macro: a hand holds Dad’s video call on a physical phone.','garage':'Wide garage with the old blue car, tool wall, repair props and phone against toolbox.','engine':'Macro: Evan’s hand guides a wrench onto a loose engine connection.','ignition':'Macro: key turns in ignition, instruments respond to the narration.','server':'Brief comic cutaway to an expensive server rack.','messages':'Physical phone screen: the repaired car video and Mother’s responses.','routine':'Evan and Dad establish a routine in a furnished room.','lake':'Warm childhood memory at the river: keys fall, ripples expand, a fish passes.','memoryCards':'Yesterday/today photo evidence visualises the reconstruction adopting Evan’s correction.','coat':'Evan gets ready to leave while the laptop copy asks him to stay.','windowStill':'Insert: the permanently closed window behind the reconstructed father.','decline':'Evan declines Mother’s call and sends a message.','support':'Support question and evasive answer on a readable browser screen.','showBody':'Product announcement and a physical-body demonstration in a violet showroom.','price':'Physical monitor shows $18,000 plus the monthly plan.','savings':'Savings paperwork, the car photo and keys become a single composition.','carOffer':'The buyer inspects the same blue car; Evan holds the camera or reacts.','keyClose':'Insert: Evan tightens his grip around the unchanged car keys.','paperwork':'Vehicle documents on the desk; the buyer is visible through the window.','quoteMemory':'Family photo and archived conversation become evidence of emotional pressure.','reject':'Evan refuses the sale and the disappointed buyer walks away; Dad’s car stays.','turnPhone':'Evan turns the ringing phone face down on the desk.','arrive':'Evan uses his own key, enters Mother’s hallway and stops at the kitchen door.','momTable':'Mother, her laptop and Evan share a stable kitchen layout.','closedLid':'A closed laptop on the kitchen table; a new incoming call interrupts.','devices':'Both physical devices are opened and turned so their cameras can see each other.','duel':'Final confrontation: two versions of Dad on the phone and laptop, never floating avatars.','final':'Two copies remain visible; restrained English viewer question and red Subscribe/blue Like.'}
# One absolute clock per continuous sequence; neighboring shots never restart a zoom.
groups=[(0,20.1),(20.1,32.2),(32.2,47.7),(47.7,66.4),(66.4,81.6),(81.6,101),(101,118),(118,129.7),(129.7,169.1),(169.1,175.1),(175.1,190.1),(190.1,198.6),(198.6,225.4),(225.4,250.7),(250.7,263),(263,283.4),(283.4,315.3),(315.3,324.6),(324.6,360.8),(360.8,376.6),(376.6,385.4),(385.4,440),(440,475.1),(475.1,489)]
for n,b in enumerate(beats):
 start=round(b['start']*24)/24;end=round(beats[n+1]['start']*24)/24 if n+1<len(beats) else 489
 grp=next(x for x in groups if x[0]<=b['start']<x[1]);v=b['view'];m=b['mode'];place=places.get(v,'room')
 if v=='handheld' and 129<b['start']<170:place='garage'
 if v=='face' and 129<b['start']<170:place='garage'
 if v=='face' and b['start']>=385.4:place='kitchen'
 if v=='screen' and b['mother']:place='kitchen'
 params={k:b[k] for k in ['view','mode','mother']};params.update(groupStart=grp[0],groupEnd=grp[1],place=place,dir=1 if groups.index(grp)%2 else -1)
 if v=='home' and (109<start<112.5 or 295<start<313):params['frame']='ots'
 if v in ['friend','momTable'] and m in ['explain','question','tell','closed']:params.update(frame='medium',focusX=960,focusY=640)
 if v=='motherCall' and start>105:params.update(frame='medium',focusX=1130,focusY=610)
 if v=='garage' and m in ['hood','together']:params.update(frame='medium',focusX=1080,focusY=640)
 if v=='carOffer' and m=='inspect':params.update(frame='medium',focusX=1050,focusY=640)
 if b['mother']:params['variant']=True
 params['night']=not (94<=b['start']<129.7 or b['start']>=315.3)
 line=' '.join(x['word'] for x in w if start<=x['start']<end)
 tr='cut'
 if b['start'] in [20.1,190.1,207.0]:tr='fade'
 if b['start'] in [129.7,263,376.6]:tr='dip'
 if b['start'] in [161.1,315.3]:tr='whip'
 shots.append(dict(id=f'fa{n+1:03}',start=start,end=end,line=line,scene=descriptions[v]+' Beat: '+m,set=place,bars='wide',captions=False,**{'in':{'type':tr,'dur':.22}},params=params,sfx=[],notes='Editorial cue from rough ASR; audio is authoritative. No subtitles.'))
story={'title':'AGAIN — Which One Is Your Father?','duration':489,'shots':shots,'music':[],'sfx':[]}
(p/'story/shots.json').write_text(json.dumps(story,indent=2))
(p/'timeline/words.json').write_text(json.dumps(w,indent=2))
with (p/'story/scene-markers.csv').open('w') as f:
 out=csv.writer(f);out.writerow(['id','start','end','view','mode','scene']);out.writerows([s['id'],s['start'],s['end'],s['params']['view'],s['params']['mode'],s['scene']] for s in shots)
print(len(shots),'shots', 'duration',shots[-1]['end'])
