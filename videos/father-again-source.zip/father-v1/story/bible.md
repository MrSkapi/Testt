# AGAIN — Which One Is Your Father?

A suspense story told by the supplied English narration. Evan, 22, uses a digital reconstruction of the father he lost eleven months ago. Repairing their blue car initially reconnects him with his father. A false memory, an evasive support answer, a physical-body offer and pressure to sell the car turn comfort into manipulation. At Mother's table, two independent accounts tell conflicting stories.

## Cast

- Evan: recurring black round head, cream eyes and minimal mouth, ochre/orange hoodie (#ed9437), black stick limbs, no headwear. Left side of conversations, facing right.
- Father / Evan's account: same black drawn construction, slightly crooked pale rectangular glasses, teal patterned shirt (#459b91). Outside flashbacks, he exists only inside an actual phone/laptop screen.
- Father / Mother's account: identical head and glasses; mauve version of the patterned shirt (#a26a98), as explicitly narrated. Never swap the two device positions in the final scene.
- Mother: purple garment (#ac7bc6), grey hair/bun, minimal face. Right side at the kitchen table, facing left. The advertisement's grandmother is also an older female figure, not an unlabelled copy of Father.
- Friend: muted blue (#608fc8). Buyer: grey-lilac (#8e8da5), first appears when the narration introduces him.

## Locations and light

- Evan's room: purple/blue evening, amber floor lamp, cyan city window, turquoise sofa, books, photos, keys. Sunrise is peach/amber.
- Kitchens: peach walls, turquoise cabinetry at Evan's home, lilac cabinetry at Mother's home; spice jars, towel, tile joints, cups, framed art. One stable screen direction.
- Garage: blue masonry and shutter, warm overhead strip, red tool drawers, wrenches, tyres, blue car, phone propped against a toolbox. Floor/contact shadows establish depth.
- River memory: cyan water, layered green hills, gold sky, reeds, ripples and fish. Childhood Evan is smaller; Father wears his recognisable shirt/glasses.
- Server racks: navy/cyan, restrained animated status lights; a brief comic cutaway, not a change to realistic 3D.
- Presence advertisement: violet showroom, flat illustrated physical-body demonstrator.
- Hallway: mauve walls, warm open kitchen doorway, floor perspective, family art, plant and a single continuous walking clock across the cut.

## Editing and motion

172 contiguous authored shots on a 24fps grid. Rough speech recognition is an editorial aid, not a verified transcript; it is never rendered as subtitles. The uploaded MP3 is authoritative and is neither retimed nor replaced.

Use actual actions: hands tighten an engine connection, keys turn, instruments respond, a cup is stirred, a baby is lifted, switches are granted, files move into an upload, Mother closes and pushes the laptop, a phone turns face down, and a planted-foot walk continues across the hallway cut. Conversations include meaningful one-off gestures, eye-line changes, blinks and held reactions. Facial speaking motion is limited to approximate quoted-dialogue windows.

The set camera has constant scale 1.025 and one slow lateral movement per continuous sequence using absolute global time. Medium and over-the-shoulder compositions are explicit cuts. There are no automatic restarting zoom tweens or zoom transitions. Parallax, foreground blur, grounded shadows, restrained dust and visible practical lights preserve the illustrated 2.5D look.

The blue car is not sold and stays in the garage after the buyer leaves. The second account is a laptop, never a floating avatar or a desktop monitor. The final call uses a phone on the left and laptop on the right.

All authored text is English and attached to a document, device or end-screen interface. No subtitles or dialogue above heads. Red SUBSCRIBE and blue LIKE appear only during the narrated closing call to action.

Audio: original narration only, with no new music, artificial wind, replacement voices or added effects. Visual effects do not imply added sound effects.
