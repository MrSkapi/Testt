import {registerShot,layer,blurLayer,backdrop,veil,seg,poly,circle,alpha,shade,ease,prog,lerp,clamp} from '/engine/core.js';
import * as FX from '/engine/fx2d.js';
import {hero,aide,face} from './cast.js';
import {C,box,ellipse,shadow,plate,cup} from './sets/props.js';
const P=t=>ease.inOut(Math.max(0,Math.min(1,t)));
function cam(t,i){return {z:1+.035*P(t/i.dur),x:lerp(-9,9,P(t/i.dur)),y:0};}
function room(g,t,c={}){
 layer(g,c,.1,g=>backdrop(g,['#3b3335','#87705a','#b69b77']));
 layer(g,c,.35,g=>{
  for(let j=0;j<3;j++){
   let x=165+j*577;box(g,x,99,369,584,'#292d30',6);box(g,x+15,114,338,552,'#a9b19a',2);
   for(let k=0;k<5;k++)box(g,x+28+k*65,399-(k*17%82),48,260,'#65757277');
   box(g,x+176,111,13,559,'#4f5149');box(g,x+12,319,343,12,'#52534a');box(g,x-8,674,386,20,'#b8a080');
   for(let side of[-1,1]){
    const dx=side<0?x-44:x+330;
    poly(g,[[dx,81],[dx+83,81],[dx+61,461],[dx+91,683],[dx-8,683],[dx+21,456]],'#623c36');
    seg(g,[[dx+28,88],[dx+38,402],[dx+20,624]],5,'#89604b');
    seg(g,[[dx+11,454],[dx+71,457]],9,'#b39055');
   }
   box(g,x-52,75,478,18,'#a68b62',4);
  }
  // Paneled walls and quiet, warm architectural depth.
  box(g,-100,695,2200,195,'#554c42');seg(g,[[-100,703],[2100,703]],9,'#a99067');
  for(let j=0;j<10;j++){box(g,j*219+9,728,189,133,'#6a5847',3);box(g,j*219+20,740,166,110,'#554b41',2);}
  box(g,-200,886,2400,500,'#5b5752');
  for(let k=0;k<9;k++)seg(g,[[-500,903+k*k*5],[2500,903+k*k*5]],1,'#bbb09b20');
  for(let k=0;k<11;k++)seg(g,[[k*220-260,890],[k*400-1000,1600]],1,'#c2af8d15');
  poly(g,[[216,679],[511,679],[1430,1240],[820,1240]],'#e8c99212');
 });
 layer(g,c,.68,g=>{
  // Two framed portraits are deliberately indistinct until the final glance.
  for(let j=0;j<2;j++){
   const x=564+j*578;box(g,x,186,142,190,'#a88750',4);box(g,x+7,193,128,176,'#453d36');
   ellipse(g,x+70,263,33,43,'#8f8066');poly(g,[[x+26,353],[x+39,302],[x+99,302],[x+116,353]],'#686954');
   seg(g,[[x+17,202],[x+127,202]],2,'#dfc18b55');
  }
 });
 FX.dust(g,t,{count:26,color:C.gold,a:.15,size:1.3,speed:6});
}
function chair(g,x,y,s=1){
 box(g,x-108*s,y-353*s,216*s,342*s,'#3c3030',18*s);box(g,x-92*s,y-338*s,184*s,286*s,'#705043',13*s);
 seg(g,[[x-105*s,y-344*s],[x-108*s,y-28*s]],5*s,'#b09461');seg(g,[[x+105*s,y-344*s],[x+108*s,y-28*s]],5*s,'#b09461');
}
function diningTable(g,x=996,y=778,s=1){
 g.save();g.translate(x,y);g.scale(s,s);
 shadow(g,0,197,650,51);
 for(let a of[-461,461])box(g,a-15,29,31,230,'#392b26',4);
 poly(g,[[-633,-24],[541,-24],[652,78],[-732,78]],'#9a7a57');
 poly(g,[[-632,-20],[540,-20],[625,54],[-709,54]],'#d0bea0');
 poly(g,[[-709,54],[625,54],[628,149],[-715,149]],'#aa9b82');
 for(let j=0;j<11;j++){let x=-676+j*122;seg(g,[[x,61],[x-10,139]],1.5,'#e7d6b35c');}
 seg(g,[[-704,57],[624,57]],4,'#ecdec2');
 plate(g,-132,4,.82);cup(g,36,-4,.58);
 ellipse(g,258,7,116,27,'#d9cbae');ellipse(g,258,2,100,21,'#a89b7d');
 for(let j=0;j<4;j++)ellipse(g,213+j*27,0-(j%2)*10,20,11,['#bcb38b','#bca174','#c9b58d'][j%3]);
 box(g,-375,-6,76,23,'#ddd1b4',3);seg(g,[[-370,-3],[-305,-3]],1,'#8b7f6680');
 // Water glass, always anchored to the table plane.
 poly(g,[[109,-100],[155,-100],[150,-5],[116,-5]],'#b1c0af44');ellipse(g,132,-100,23,7,'#d0dcc288');ellipse(g,132,-35,18,5,'#c8d7c088');
 seg(g,[[113,-93],[120,-13]],2,'#e6e6cd88');g.restore();
}
function spoon(g,x,y,s=1,r=0){g.save();g.translate(x,y);g.rotate(r);g.scale(s,s);seg(g,[[0,0],[0,-81]],9,'#a1aaa4');seg(g,[[-2,-7],[-2,-79]],2,'#ece9cc');ellipse(g,0,-104,16,27,'#b7c0b5',.02);ellipse(g,0,-109,11,19,'#7d8c88');seg(g,[[-9,-117],[-6,-124],[3,-128]],2,'#e7ead2');g.restore();}
function wide(g,t,i,o={}){
 const c=cam(t,i);room(g,i.globalT,c);
 layer(g,c,.88,g=>{
  chair(g,866,990,.95);
  const fl=P((i.globalT-3.11)/.17)*(1-P((i.globalT-3.62)/.35));
  aide(g,424,990,1.9,{flinch:fl>.2,bend:-.055*fl});
  if(o.rush){const x=lerp(1633,1334,P((i.globalT-4.25)/1.12));aide(g,x,990,1.9,{bend:-.12,walk:i.globalT<5.37,phase:i.globalT*13});}
  else aide(g,1334,990,1.9,{bend:o.apology?-.19*P((i.globalT-6.04)/.6):0});
  if(o.third)aide(g,1668,995,1.76,{bend:-.28*P((i.globalT-6.01)/.65)});
  hero(g,866,1010,1.04,{turn:.28,look:[o.look??.4,0],blink:i.globalT>10.6&&i.globalT<10.75});
 });layer(g,c,1,g=>diningTable(g));
 blurLayer(g,5,g=>layer(g,c,1.45,g=>{box(g,-30,-20,120,1300,'#28292c');box(g,1840,-20,110,1300,'#29282a');}));
}
function spoonShot(g,t,i){
 // The opening action is a literal insert: the spoon leaves the dark cuff.
 room(g,t,{z:1.02,x:0});veil(g,C.ink,.23);
 layer(g,cam(t,i),1,g=>{
  box(g,-100,179,2230,188,'#cfb99a');box(g,-100,354,2230,89,'#9d8d75');
  for(let j=0;j<13;j++)seg(g,[[j*172,367],[j*172+31,435]],2,'#c5b29444');
  seg(g,[[1193,-56],[1128,145],[1024,228]],104,'#414044');seg(g,[[1166,10],[1111,135]],3,'#a48a69');
  ellipse(g,1021,233,47,33,'#131317',-.21);
  const u=clamp((t-.17)/.69),fall=ease.in(u),sx=lerp(1034,961,u),sy=lerp(312,872,fall);
  spoon(g,sx,sy+((t>.86&&t<1.12)?-Math.sin((t-.86)/.26*Math.PI)*27:0),1.16,lerp(.1,1.59,u));
  shadow(g,974,898,54+u*21,7);
  // No added impact sound: retain the original narration track.
 });
}
function closeHero(g,t,i){
 blurLayer(g,10,g=>room(g,i.globalT,{z:1.04,x:0}));veil(g,C.ink,.14);
 layer(g,cam(t,i),1,g=>{
  hero(g,965,1530,2.2,{turn:lerp(-.5,.5,P(t/1.05)),look:[lerp(-1,1,P(t/1.05)),0],tilt:-.018,blink:t>.98&&t<1.12});
  // Foreground table edge; jacket and collar remain visible.
  box(g,-100,1020,2200,200,'#b9a88b');
 });
}
function flinch(g,t,i){
 if(t<.9){wide(g,t,i);return;}
 blurLayer(g,9,g=>room(g,i.globalT,{z:1.02,x:0}));veil(g,C.ink,.12);
 layer(g,cam(t,i),1,g=>{
  const k=P((i.globalT-3.11)/.18),release=1-P((i.globalT-3.62)/.35);
  aide(g,1230-14*k*release,1550,3.5,{flinch:k*release>.3,bend:-.04*k*release});
  blurLayer(g,4,g=>hero(g,219,1510,1.8,{look:[1,0],turn:.5}));
 });
}
function apology(g,t,i){
 blurLayer(g,8,g=>room(g,i.globalT,{z:1.03,x:0}));
 layer(g,cam(t,i),1,g=>{
  aide(g,1208,1200,3.0,{bend:-.25*P(t/.55),blink:t>1.35&&t<1.48});
  hero(g,364,1280,1.85,{turn:.45,look:[1,0]});
 });layer(g,cam(t,i),1.1,g=>diningTable(g,400,993,.85));
}
function breakfast(g,t,i){
 // A held, untouched setting seen from above, cut back to all frozen hands.
 if(t>1.04){wide(g,t,i,{third:true});return;}
 blurLayer(g,9,g=>room(g,i.globalT,{}));
 layer(g,cam(t,i),1,g=>{
  box(g,-100,-100,2200,1400,'#bdae91');
  for(let j=0;j<18;j++)seg(g,[[j*127,-50],[j*127,1200]],.7,'#ede0c344');
  ellipse(g,944,579,291,247,'#e2d3b3');ellipse(g,944,579,246,207,'#c6b797');
  for(let j=0;j<4;j++)ellipse(g,910+j*31,568-(j%2)*18,68,29,['#b78a4d','#d4b477'][j%2],-.2);
  cup(g,1377,415,1.45);box(g,487,370,139,254,'#ded2b6',7);seg(g,[[504,392],[610,392]],2,'#a1987d');
  seg(g,[[775,1220],[777,1007],[733,825]],75,'#454246');ellipse(g,729,806,36,49,'#141417',-.2);
  seg(g,[[1214,1220],[1190,1004],[1237,826]],75,'#454246');ellipse(g,1244,804,36,49,'#141417',.2);
 });
}
function silence(g,t,i){
 const c=cam(t,i);room(g,i.globalT,c);
 layer(g,c,1,g=>{
  aide(g,627,1125,2.7,{bend:-.035,blink:t>.77&&t<.9});aide(g,1195,1125,2.7,{bend:-.08});
  box(g,-100,963,2200,300,'#b29f80');
  blurLayer(g,4,g=>hero(g,102,1548,2.12,{turn:.6,look:[1,0]}));
 });
}
function notice(g,t,i){
 closeHero(g,t,i);
 // The glance starts here; the portrait reveal belongs to the next segment.
}
const views={spoon:spoonShot,flinch,rush:(g,t,i)=>wide(g,t,i,{rush:true}),apology,breakfast,hero:closeHero,silence,notice};
for(let n=1;n<=8;n++)registerShot('nk'+String(n).padStart(2,'0'),{draw(g,t,i){views[i.view](g,t,i);}});
