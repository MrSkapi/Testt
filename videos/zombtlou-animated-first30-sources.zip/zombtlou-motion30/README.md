# Five days — animated 30-second revision

1920 × 1080, 24 unique rendered frames per second. This is a new motion test of the first 30.000 seconds, not a replacement of the complete chapter yet.

## Requested changes

- Continuous action: walk / stop / phone lift / tap / laugh / game controller / dish pickup / lid lift / typing.
- Fixed-length two-bone arm and leg IK. Standing legs are straight; hands and carried props use the same transforms.
- Animated message entrances, word-timed warning items, typed reply, three individual reaction pops.
- Continuous camera moves within related inserts and visible close-up pushes.
- Teal, burnt orange, amber and green color separation, with darker cool shadows.
- Drawing hatching changes at 8 Hz; character and camera motion render at 24 Hz.
- Rounded bold white all-caps captions with a dark outline. Only the currently spoken word turns yellow. No caption rectangles.
- Sparse procedural Foley: footfalls, phone buzz, typing, message and reaction clicks. No music.
- The first 30 seconds of supplied narration remain at their original timing and gain, without time stretching or word edits.

## Editable files

- `motion.js`: actors, IK, actions, camera, messages, laboratory, specimen, captions.
- `drawing.js`: base vector drawing primitives, workroom and cap; colors can be edited here.
- `words.json`, `captions.json`: editable word timing and short phrase groups.
- `shots.json`: action and cut timing plan.
- `sound-cues.json`, `sound.py`: source-aligned Foley, unity-gain narration mix.
- `narration.mp3`: original uploaded audio; only 00:00–00:30 is used.
- `narration-first30.wav`, `sfx.wav`, `mix.wav`: separate audio stems and mix.
- `preview.html`: browser player with sound and seeking. Serve the directory with Python to preview.
- `build.py`: rebuilds the player and caption groups from editable source files.
- `render.mjs`, `cdp.mjs`: deterministic frame rendering through Chromium and FFmpeg.

## Build

Requires Python with NumPy and SciPy, Node 22+ with native WebSocket, Chromium, FFmpeg. No model or API key is required.

```sh
python build.py
python sound.py
python3 -m http.server 8766 --bind 127.0.0.1 --directory .
```

In another terminal, run Chromium with a dedicated writable profile and debugging port 9230. In a managed container, add `--no-sandbox` only if required by that container.

```sh
chromium --headless --disable-dev-shm-usage --disable-gpu --remote-debugging-port=9230 --user-data-dir=/tmp/zombtlou-motion-preview about:blank
node qc.mjs
node render.mjs 0 30 silent.mp4
ffmpeg -y -i silent.mp4 -i mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -t 30 -movflags +faststart zombtlou-animated-first30.mp4
```

The renderer draws every frame independently, so any range can be rebuilt using `node render.mjs START END output.mp4`.

## Asset provenance

All illustrated artwork is editable vector/Canvas code; reference-video frames are not used. The included `audio/dsp.py` and `audio/sfx.py` come from the user's attached 2d-video.plugin, author Андрей Зенин, version 0.1.1. Fredoka Bold is from @fontsource/fredoka (SIL Open Font License); its license is included in fonts/LICENSE. Narration is the user's uploaded ZombTLOU.mp3.
