"""Original supplied narration + sparse procedural Foley, no music.
All event times are in the untouched source recording's timebase.
Procedural effects from the user-supplied 2d-video plugin.
"""
from pathlib import Path
import sys,json,subprocess
import numpy as np
from scipy.io import wavfile
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P/'audio'))
from sfx import make
from dsp import SR,place,write_wav
src=P/'narration.mp3'
if not src.exists():
 import shutil
 shutil.copyfile('/workspace/zombtlou-full/narration.mp3',src)
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(src),'-t','30','-ar',str(SR),'-ac','2','-f','f32le','-'])
voice=np.frombuffer(raw,dtype=np.float32).reshape(-1,2).copy()
assert len(voice)==30*SR
sfx=np.zeros_like(voice)
cues=[
 (.34,'footstep',-28,.16),(.92,'footstep',-29,.16),(1.50,'footstep',-28,.16),
 (1.89,'phonebuzz',-27,.45),
 (3.13,'pop',-32,.13),(3.73,'pop',-33,.13),
 (5.24,'ding',-29,.48),(6.49,'tick',-34,.09),(7.45,'tick',-34,.09),
 (8.1,'swish',-34,.22),(9.60,'tick',-33,.08),
 (10.73,'pop',-30,.13),
 (10.98,'tick',-36,.065),(11.20,'tick',-36,.065),(11.48,'tick',-36,.065),
 (11.79,'tick',-36,.065),(12.04,'tick',-36,.065),(12.40,'tick',-36,.065),
 (12.84,'blip',-31,.14),
 (13.29,'pop',-32,.12),(13.55,'pop',-33,.12),(13.84,'pop',-34,.12),
 (18.06,'swish',-32,.3),(19.4,'blip',-34,.16),
 (22.18,'tick',-32,.09),(25.48,'tick',-30,.12),(25.65,'swish',-36,.35),
 (28.13,'phonebuzz',-31,.4),
 (28.78,'tick',-35,.06),(29.08,'tick',-35,.06),(29.46,'tick',-35,.06)
]
for i,(at,name,db,dur) in enumerate(cues):
 fx=make(name,dur=dur,seed=100+i)
 # Gentle stereo placement follows the phone / desk rather than broad swooshes.
 fx[:,0]*=.94;place(sfx,fx,round(at*SR),10**(db/20))
write_wav(str(P/'sfx.wav'),sfx)
mix=voice+sfx
# Keep narration gain at unity and only tame effects if source leaves little headroom.
peak=float(np.abs(mix).max())
if peak>.99:
 for _ in range(8):
  sfx*=.7;mix=voice+sfx
  if np.abs(mix).max()<=.99:break
write_wav(str(P/'mix.wav'),mix)
wavfile.write(P/'narration-first30.wav',SR,voice)
(P/'sound-cues.json').write_text(json.dumps([{'at':a,'name':n,'gainDb':g,'duration':d} for a,n,g,d in cues],indent=2))
print('Audio:',len(voice)/SR,'seconds; peak',float(np.abs(mix).max()),'voice gain unchanged; no music')
