import fs from 'node:fs';import {connect} from './cdp.mjs';
const {cmd,ws}=await connect();
const times=process.argv.slice(2).map(Number);if(!times.length)times.push(.5,1.2,2.3,3.2,4.6,5.8,7.6,8.8,9.8,11.7,13.9,15.5,17.5,18.8,20.2,21.8,23.1,24.5,25.2,26.7,27.5,29.5);
for(const t of times){const r=await cmd('Runtime.evaluate',{expression:`render(${t});C.toDataURL('image/jpeg',.93)`,returnByValue:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));fs.writeFileSync(`qc/t${t.toFixed(3)}.jpg`,Buffer.from(r.result.value.split(',')[1],'base64'))}
const q=await cmd('Runtime.evaluate',{expression:'JSON.stringify({audit,errors:window.renderErrors})',returnByValue:true});console.log(q.result.value);fs.writeFileSync('qc/audit.json',q.result.value);ws.close();
