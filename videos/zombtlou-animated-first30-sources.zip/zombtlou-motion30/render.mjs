import fs from 'node:fs';import {spawn} from 'node:child_process';import {connect} from './cdp.mjs';
const rate=24,start=Number(process.argv[2]||0),end=Number(process.argv[3]||30),out=process.argv[4]||'silent.mp4';
const {cmd,ws}=await connect();
const ff=spawn('ffmpeg',['-y','-v','error','-f','image2pipe','-framerate',String(rate),'-i','-','-an','-c:v','libx264','-threads','2','-preset','medium','-crf','18','-pix_fmt','yuv420p','-r','24','-movflags','+faststart',out],{stdio:['pipe','inherit','inherit']});
const done=new Promise((r,j)=>ff.on('close',c=>c?j(Error('FFmpeg '+c)):r()));let count=0,begin=Date.now();
for(let f=Math.round(start*rate);f<Math.round(end*rate);f++){
 const t=f/rate,r=await cmd('Runtime.evaluate',{expression:`render(${t});C.toDataURL('image/jpeg',.97)`,returnByValue:true});
 if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));const b=Buffer.from(r.result.value.split(',')[1],'base64');if(!ff.stdin.write(b))await new Promise(r=>ff.stdin.once('drain',r));
 count++;if(count%48===0)console.log(`Frame ${count}/${(end-start)*rate} t=${t.toFixed(2)} fps=${(count/((Date.now()-begin)/1000)).toFixed(2)}`);
}
ff.stdin.end();await done;const r=await cmd('Runtime.evaluate',{expression:'JSON.stringify({audit,errors:window.renderErrors})',returnByValue:true});fs.writeFileSync('qc/render-audit.json',r.result.value);console.log('DONE',out,r.result.value);ws.close();
