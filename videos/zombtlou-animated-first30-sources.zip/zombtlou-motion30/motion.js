/* 30-second animation test. All animation is deterministic at full 24 fps.
   World positions and IK targets share a coordinate space. T is global time. */
const C=canvas;
const lerp=(a,b,u)=>a+(b-a)*u;
const mixp=(a,b,u)=>[lerp(a[0],b[0],u),lerp(a[1],b[1],u)];
const out=x=>1-Math.pow(1-clamp(x),3);
const back=x=>{x=clamp(x)-1;return 1+2.5*x*x*x+1.5*x*x};
const beat=(t,a,d=.35)=>Math.sin(Math.PI*clamp((t-a)/d));
const P={orange:'#b65d36',orangeLight:'#d78248',orangeDark:'#87412e',teal:'#218e94',cream:'#eee7da',ink:'#24272c',blue:'#315b73',yellow:'#f4cf50',green:'#65ad99',paper:'#e8dec6'};
let audit={armMaxError:0,legMaxError:0,unreachable:[]};
// Detect unbalanced save/restore calls before they can change another actor's scale.
let stateDepth=0;
const nativeSave=g.save.bind(g),nativeRestore=g.restore.bind(g);
g.save=()=>{stateDepth++;nativeSave()};
g.restore=()=>{if(stateDepth<=0)throw Error('Canvas state underflow');stateDepth--;nativeRestore()};
function IK(a,b,A,B,side=1){
 const d=Math.hypot(b[0]-a[0],b[1]-a[1]);
 if(d>A+B+.01||d<Math.abs(A-B)+.01){audit.unreachable.push({t:window.T,a,b,d,A,B});throw Error('Unreachable IK target '+d.toFixed(1))}
 const k=knee(a,b,A,B,side);
 const e=Math.max(Math.abs(Math.hypot(k[0]-a[0],k[1]-a[1])-A),Math.abs(Math.hypot(k[0]-b[0],k[1]-b[1])-B));
 audit.armMaxError=Math.max(audit.armMaxError,e);return k;
}
function skCurve(points,c=P.ink,w=3){
 g.beginPath();g.moveTo(...points[0]);for(let i=1;i<points.length;i+=3)g.bezierCurveTo(...points[i],...points[i+1],...points[i+2]);g.strokeStyle=c;g.lineWidth=w;g.lineCap='round';g.lineJoin='round';g.stroke();
}
function inkText(s,x,y,size=40,c=P.cream,align='left',stroke=0){
 g.save();g.font=`700 ${size}px Fredoka,"DejaVu Sans",sans-serif`;g.textAlign=align;g.lineJoin='round';
 if(stroke){g.strokeStyle=P.ink;g.lineWidth=stroke;g.strokeText(s,x,y)}g.fillStyle=c;g.fillText(s,x,y);g.restore();
}
function shakeHatch(x,y,w,h,n,c='#182d3235'){
 const f=Math.floor(window.T*8);g.save();g.beginPath();g.rect(x,y,w,h);g.clip();
 for(let i=0;i<n;i++){const xx=x+(i*29.23)%w+Math.sin(f*2+i*11)*1.7,yy=y+(i*13.31)%h+Math.cos(f*1.8+i)*1.4;line(xx,yy,xx+10+(i%7),yy-15,c,.9+(i%3)*.25)}g.restore();
}
function dust(t,lab=false){for(let i=0;i<28;i++){
 const x=(i*79.67+Math.sin(t*.27+i)*19)%1920,y=90+(i*137.17+t*(3+i%5))%760;
 ellipse(x,y,1.3+(i%3)*.35,1.3+(i%3)*.35,lab?'#e7fff037':'#fbdc8940',null);
}}
function room(t){
 g.fillStyle='#7e9da1';g.fillRect(-600,-500,W+1200,H+1000);
 rect(-600,535,W+1200,270,'#396b70',0,null);rect(-600,803,W+1200,15,'#d0cbb8',0,null);rect(-600,818,W+1200,900,'#b28255',0,null);
 workroom(t);
 // Restrained warm practical light; blue window fill preserves the drawing.
 path([[230,525],[355,768],[742,768],[255,525]],'#edb54c17',null);
 ellipse(410,785,240,22,'#e6ae4c12',null);
 shakeHatch(15,25,1860,480,160,'#20384020');shakeHatch(10,825,1890,230,100,'#46332325');
 shakeHatch(1308,207,305,600,62,'#1d392d35');
 // In-world lobby activity, not a floating overlay.
 for(let i=0;i<3;i++){const f=clamp((t-(.3+i*.22))/.6);rect(365,525+i*24,70*f,5,['#65b9ac','#deaa55','#ca765d'][i],1,null)}
 if(t>1.85){const f=out((t-1.85)/.3);rect(327,562,226*f,30,'#b3883b',3,null);if(f>.9)text('NEW SQUAD MESSAGE',335,582,13,'#f3e6c1',true)}
 dust(t);
}
function limb(a,b,A,B,side,color,width=26){
 const k=IK(a,b,A,B,side);line(...a,...k,P.ink,width+5);line(...k,...b,P.ink,width+5);
 line(...a,...k,color,width);line(...k,...b,color,width);
 line(a[0]-4,a[1]+1,k[0]-4,k[1]+1,'#eab17655',2);return k;
}
function phoneRig(cx,cy,angle=0,sc=1){
 g.save();g.translate(cx,cy);g.rotate(angle);g.scale(sc,sc);
 phoneBack(-29,-45,58,91);line(-21,-35,-21,34,'#697981',1);g.restore();
 const pt=(x,y)=>[cx+sc*(x*Math.cos(angle)-y*Math.sin(angle)),cy+sc*(x*Math.sin(angle)+y*Math.cos(angle))];
 return {left:pt(-30,21),right:pt(30,24),tap:pt(24,-10)};
}
function face(t,o={}){
 const mood=o.mood||'neutral',look=o.look||[0,0],head=o.head||0,daniel=o.daniel;
 g.save();g.rotate(head);
 ellipse(0,0,65,65,P.cream,P.ink,3.4);
 // Hair fringe tucked beneath the same cap in every room shot.
 if(!daniel)path([[-63,-25],[-61,1],[-52,-17],[-48,-31],[-29,-31],[-19,-23],[-8,-36],[7,-27],[25,-36],[54,-31],[60,-2],[63,-25],[54,-48]],'#23272b',null);
 else{path([[-64,-5],[-58,-39],[-34,-62],[1,-67],[38,-59],[60,-32],[63,-1],[45,-20],[15,-35],[-15,-25]],o.female?'#644d3e':'#36302e',P.ink,2);if(o.female)ellipse(64,-17,15,29,'#644d3e',P.ink,2)}
 let blink=1;
 for(const a of [3.85,8.7,14.05,20.4,23.2,28.4]){if(t>a&&t<a+.17)blink=Math.min(blink,Math.abs(t-a-.085)/.085)}
 const smile=mood==='amused'||mood==='laugh',worry=mood==='concerned';
 for(const xx of [-17,17]){
  if(mood==='laugh')skCurve([[xx-6,1],[xx-1,-7],[xx+3,-7],[xx+8,0]],P.ink,3);
  else{g.save();g.translate(xx+look[0],look[1]);g.scale(1,Math.max(.08,blink));rect(-5,-8,10,worry?25:23,P.ink,4,null);g.restore()}
 }
 if(worry){line(-26,-19,-11,-21,P.ink,2);line(12,-21,26,-18,P.ink,2);skCurve([[-10,34],[-3,31],[3,31],[11,34]],P.ink,2.6)}
 else if(smile){skCurve([[-12,29],[-5,38],[8,37],[16,26]],P.ink,2.7);if(mood==='laugh'){g.beginPath();g.ellipse(2,31,10,8,0,0,Math.PI);g.fillStyle=P.ink;g.fill()}}
 else skCurve([[-10,31],[-2,32],[6,32],[11,30]],P.ink,2.3);
 if(!daniel)cap();
 shakeHatch(-50,40,100,17,12,'#79675122');g.restore();
}
function actor(x,ground,s,t,o={}){
 // Actor height is 520 units in all world shots; no independent scale changes.
 const daniel=!!o.daniel,col=daniel?'#c4cdb7':P.orange;
 const walk=o.walk||0,dir=o.dir||1,wt=o.wt??t;
 const breathe=Math.sin(t*2.2)*.9;
 let gait=wt/1.16,hipY=lerp(-174,-164+2.7*Math.cos(gait*Math.PI*4),walk);
 g.save();g.translate(x,ground);g.scale(s,s);
 ellipse(4,5,58,7,'#1a2b3938',null);
 const feet=[];
 for(let i=0;i<2;i++){
  const hx=i?28:-24,q=(gait+i*.5)%1,stance=q<.6,v=stance?q/.6:(q-.6)/.4;
  const animated=[hx+dir*(stance?43-86*v:-43+86*ease(v)),stance?0:-31*Math.sin(Math.PI*v)];
  const f=mixp([hx,0],animated,walk),h=[hx,hipY];feet.push(f);
  if(walk>.001){const k=IK(h,f,90,90,dir);line(...h,...k,i?P.ink:'#30333b',10);line(...k,...f,i?P.ink:'#30333b',10)}else line(...h,...f,P.ink,10);
  line(...f,f[0]+23*dir,f[1],P.ink,10);
 }
 const by=hipY+174+breathe+(o.bounce||0);
 g.save();g.translate(0,by);
 // Slight torso lean uses a local transform shared by shoulders/head/phone.
 g.rotate(o.lean||0);
 rect(-61,-377,123,205,col,5,P.ink,3.2);
 rect(-57,-190,115,16,daniel?'#9baea1':P.orangeDark,2,null);
 path([[-38,-376],[-20,-384],[17,-384],[39,-376],[28,-347],[3,-359],[-20,-348]],daniel?'#a8bdb4':P.orangeDark,P.ink,2);
 path([[-19,-374],[3,-359],[26,-374],[16,-348],[-11,-348]],'#2f3438',P.ink,2);
 if(!daniel){line(-22,-351,-22,-312,'#e0bd85',2);line(25,-351,24,-312,'#e0bd85',2);path([[-31,-240],[30,-240],[43,-201],[-40,-201]],'#af552f',P.ink,2)}
 else{line(3,-347,3,-179,'#829e99',2);rect(23,-315,28,37,'#e3dac0',2,P.ink,1.5);text('ID',28,-292,12,'#3d676a',true)}
 line(-56,-362,-56,-199,'#ec9e5a70',2);
 let lh=[-65,-218],rh=[65,-218],prop=null;
 if(walk){const swing=Math.sin(gait*Math.PI*2)*31*walk;lh=[-63+swing,-220];rh=[63-swing,-220]}
 if(o.phone){
  const u=o.raise??1,center=mixp([4,-238],[17,-315],u),rot=lerp(.12,-.09,u)+(o.phoneAngle||0);
  // Drawing of phone is delayed until both sleeves are drawn.
  const dx=(xx,yy)=>[center[0]+xx*Math.cos(rot)-yy*Math.sin(rot),center[1]+xx*Math.sin(rot)+yy*Math.cos(rot)];
  lh=dx(-30,21);rh=dx(30,24);prop={center,rot};
  if(o.tap){rh=mixp(rh,dx(27,-9),o.tap)}
 }
 if(o.hands){lh=o.hands[0]||lh;rh=o.hands[1]||rh}
 limb([-48,-359],lh,78,76,-1,col,19);
 limb([44,-359],rh,78,76,1,col,19);
 if(prop)phoneRig(...prop.center,prop.rot);
 if(o.dish){g.save();g.translate(o.dish[0],o.dish[1]);g.rotate(o.dish[2]||0);petri(0,0,.26,t);g.restore()}
 ellipse(...lh,11,11,P.ink,P.ink,1);ellipse(...rh,11,11,P.ink,P.ink,1);
 shakeHatch(-53,-358,107,180,38,daniel?'#284b392b':'#522e242c');
 g.save();g.translate(o.headX||0,-440+(o.headY||0));face(t,{...o,look:o.look||[2,5]});g.restore();
 g.restore();g.restore();
 return {feet};
}
function camera(cx,cy,z,fn){g.save();g.translate(960,540);g.scale(z,z);g.translate(-cx,-cy);fn();g.restore()}
function opening(t){
 // A single continuous camera move across the whole workroom action.
 const u=clamp(t/5.2),z=lerp(1.02,1.52,ease(u)),cx=lerp(1020,1090,ease(u)),cy=lerp(540,566,ease(u));
 camera(cx,cy,z,()=>{
  room(t);
  const walk=1-ease((t-1.35)/.4),xx=1315-Math.min(t,1.55)*(86/(1.16*.6));
  const raise=ease((t-2.12)/.9),notice=beat(t,1.88,.58);
  actor(xx,904,1,t,{walk,wt:t,dir:-1,phone:t>1.9,raise,mood:t>3.45?'amused':'neutral',look:t<2?[0,0]:[5,7],head:-.04*notice+.035*ease((t-2.15)/.7),tap:t>3.65?beat(t,3.65,.45):0});
  if(t>1.87&&t<2.43){const a=(t-1.87)/.56;for(let k=0;k<2;k++){g.globalAlpha=(1-a)*.7;g.beginPath();g.arc(xx+32,680,30+a*22+k*9,-1.1,1.1);g.strokeStyle=P.yellow;g.lineWidth=2.2;g.stroke()}g.globalAlpha=1}
  // Foreground is anchored to the floor; only camera parallax changes its offset.
  g.save();g.translate(-u*17,0);g.filter='blur(2px)';rect(-75,915,322,185,'#385850',3,P.ink,3);path([[-30,927],[30,927],[48,856],[11,828]],'#476d58',P.ink,2);g.restore();
 });
}
function avatar(x,y,r,kind='daniel'){
 ellipse(x,y,r,r,kind==='hero'?'#bc6c40':kind==='daniel'?'#56847f':'#d09e4a',P.ink,2);
 if(kind==='daniel'){line(x-r*.45,y+r*.22,x+r*.45,y+r*.22,'#e3dec9',3);line(x-r*.4,y-r*.25,x+r*.4,y-r*.25,'#262e36',7);rect(x-r*.2,y-r*.5,r*.4,r*.25,'#76ab93',2,null)}
 else if(kind==='hero'){g.save();g.translate(x,y+4);g.scale(r/81,r/81);ellipse(0,0,61,61,P.cream,P.ink,3);cap();rect(-23,-5,10,23,P.ink,4,null);rect(10,-5,10,23,P.ink,4,null);g.restore()}
 else{ellipse(x-6,y-4,3,3,P.ink,null);ellipse(x+6,y-4,3,3,P.ink,null);skCurve([[x-7,y+5],[x-2,y+12],[x+4,y+12],[x+8,y+4]],P.ink,2)}
}
function emoji(x,y,r=26,t=0){
 g.save();g.translate(x,y);g.rotate(Math.sin(t*5)*.05);ellipse(0,0,r,r,'#edb83e',P.ink,2);
 for(const xx of [-r*.36,r*.36])skCurve([[xx-r*.16,-2],[xx-r*.02,-r*.2],[xx+r*.1,-r*.2],[xx+r*.22,-2]],P.ink,2.4);
 g.beginPath();g.ellipse(1,r*.18,r*.48,r*.38,0,0,Math.PI);g.fillStyle='#433231';g.fill();g.strokeStyle=P.ink;g.lineWidth=2;g.stroke();
 path([[-r*.84,-1],[-r*.98,r*.25],[-r*.62,r*.25]],'#70bfcb',P.ink,1);path([[r*.84,-1],[r*.98,r*.25],[r*.62,r*.25]],'#70bfcb',P.ink,1);g.restore();
}
function pizza(x,y,s=1){g.save();g.translate(x,y);g.scale(s,s);path([[-40,-28],[44,-28],[13,44]],'#e3b64d',P.ink,2);line(-38,-28,43,-28,'#b4733c',11);for(const [xx,yy]of [[-12,-10],[21,-8],[12,14]])ellipse(xx,yy,7,7,'#b14c3b',P.ink,1);g.restore()}
function smallGear(kind,x,y,s=1,t=0){
 g.save();g.translate(x,y);g.scale(s,s);
 if(kind==='mask'){path([[-45,-10],[-24,-35],[24,-35],[45,-10],[28,33],[-28,33]],'#618d87',P.ink,3);ellipse(-36,6,20,18,'#c5c8a8',P.ink,2);ellipse(36,6,20,18,'#c5c8a8',P.ink,2);rect(-15,-10,30,30,'#8cb3a1',5,P.ink,2);line(-22,-30,-50,-50,'#7a9a84',4);line(22,-30,50,-50,'#7a9a84',4)}
 if(kind==='filter'){rect(-28,-34,56,66,'#caba86',6,P.ink,2.5);ellipse(0,-4,21,20,'#5d7775',P.ink,2);for(let i=0;i<4;i++)line(-13+i*8,-15,-13+i*8,8,'#9eb69d',2);rect(-19,24,38,5,'#8c7858',1,null)}
 if(kind==='water'){rect(-29,-35,58,74,'#73adc0',7,P.ink,2.5);rect(-10,-45,22,13,'#4c7c91',2,P.ink,2);rect(-26,-10,52,27,'#dfdbb3',1,P.ink,1);line(-20,26,20,26,'#427b93',2);text('WATER',-23,9,12,'#32617c',true)}
 g.restore();
}
function cardEnter(at,t,fn){const q=clamp((t-at)/.42);if(q<=0)return;g.save();g.globalAlpha=clamp(q*2);g.translate(0,30*(1-out(q)));fn();g.restore()}
let phoneBackground=null;
function chatBase(t,mode){
 // Phone insert is in front of the actual desk. The screen faces the character.
 if(!phoneBackground){
  g.save();camera(1030,570,1.22,()=>room(3.1));g.restore();
  phoneBackground=document.createElement('canvas');phoneBackground.width=W;phoneBackground.height=H;phoneBackground.getContext('2d').drawImage(C,0,0);
 }
 g.save();g.filter='blur(7px)';g.drawImage(phoneBackground,-8,-5,W+16,H+10);g.restore();
 g.fillStyle='#14263168';g.fillRect(0,0,W,H);
 const uu=['early','warning'].includes(mode)?(t-3.12)/6.18:mode==='reply'?(t-10.72)/3.63:mode==='profile'?(t-14.35)/3.7:(t-27)/3;
 const z=1.0+uu*(mode==='profile'?.18:.13);
 g.save();g.translate(960,480);g.scale(z,z);g.rotate(-.023+uu*.008);g.translate(-960,-480);
 // Short crop of hoodie cuffs, hands and phone. All phone content is clipped.
 path([[540,1080],[584,733],[657,674],[715,723],[685,1080]],P.orange,P.ink,4);
 path([[1398,1080],[1358,735],[1295,699],[1244,740],[1271,1080]],P.orange,P.ink,4);
 rect(622,51,682,912,'#1d2f3b',42,P.ink,5);rect(641,72,644,869,'#e4dcca',27,P.ink,2);
 g.save();g.beginPath();g.roundRect(641,72,644,869,27);g.clip();
 rect(641,72,644,124,'#294f63',0,null);text('SQUAD / GENERAL',691,146,29,'#f4e7cb',true);
 ellipse(1234,137,7,7,'#7cc4ad',null);text('4 online',1098,177,18,'#b7cfc1');
 rect(838,78,248,17,'#1d2f3b',9,null);
 shakeHatch(657,203,609,645,70,'#6d60471a');
 if(mode==='warning'||mode==='early')warningChat(t);
 if(mode==='reply')replyChat(t);
 if(mode==='profile')profileChat(t);
 if(mode==='typing')typingChat(t);
 rect(665,859,597,58,'#f2ead9',22,'#a8ada0',1.5);text(mode==='typing'?'SporeLoser is typing…':'Message the squad…',693,896,22,'#77867c');
 line(889,929,1034,929,'#60777d',5);
 g.restore();
 // Grip hands are attached to the bezel, never to independently moving UI.
 ellipse(635,707,36,43,P.ink,P.ink,2);ellipse(1286,740,35,43,P.ink,P.ink,2);
 if(mode==='reply'){
  const tap=beat(t,12.82,.32)+beat(t,10.95,.28)*.5;
  g.save();g.translate(-tap*22,-tap*72);ellipse(1246,770,22,28,'#2a3035',P.ink,2);g.restore();
 }
 g.restore();
}
function warningChat(t){
 // Earlier jokes already exist above the warning, keeping story chronology.
 cardEnter(3.13,t,()=>{avatar(693,243,22,'other');text('NIKA',731,233,18,'#8a603b',true);text('your aim is the real crime',731,263,23,'#424b4c');emoji(1193,247,23,t)});
 cardEnter(3.73,t,()=>{avatar(693,323,22,'other');text('MILO',731,310,18,'#8a603b',true);text('pineapple is a crime.',731,342,23,'#424b4c');pizza(1193,328,.47)});
 cardEnter(5.22,t,()=>{
  rect(667,380,593,427,'#cbdcc9',16,'#5d897d',2);avatar(708,424,25);text('SPORELOSER',748,418,24,'#245c59',true);text('Today · 17:42',748,448,17,'#67877a');
  const rows=[['Buy respirators.',5.3,'mask'],['Spare filters.',6.49,'filter'],['Water.',7.45,'water']];
  rows.forEach(([s,at,kind],i)=>cardEnter(at,t,()=>{
   const yy=505+i*74;smallGear(kind,719,yy-9,.49,t);text(s,766,yy,29,'#304b49',true);
  }));
  cardEnter(8.1,t,()=>{rect(691,716,545,65,'#bf7650',7,null);text('Don’t wait for an announcement.',706,757,24,'#fff0d0',true)});
 });
}
function replyChat(t){
 rect(669,214,588,217,'#cbdcc9',12,'#6a8b78',1.5);avatar(706,251,24);text('SPORELOSER',745,250,21,'#2c5c59',true);
 text('Buy respirators. Spare filters. Water.',693,301,25,'#36584e');text('Don’t wait for an announcement.',693,341,24,'#36584e');
 cardEnter(10.72,t,()=>{rect(1046,460,210,102,'#cad9e1',16,'#718f9f',1.5);text('YOU',1071,491,18,'#37667e',true);emoji(1170,519,28,t)});
 const msg='Do the filters improve my aim?';
 cardEnter(10.94,t,()=>{
  rect(749,586,505,126,'#cad9e1',14,'#718f9f',1.5);text('YOU',773,618,18,'#37667e',true);
  const n=Math.floor(msg.length*clamp((t-10.94)/1.91));text(msg.slice(0,n),773,661,25,'#344d60');
  if(t<12.85&&Math.floor(t*5)%2)line(774+g.measureText(msg.slice(0,n)).width,640,774+g.measureText(msg.slice(0,n)).width,664,'#344d60',2);
 });
 [13.29,13.55,13.84].forEach((at,i)=>{
  const q=clamp((t-at)/.3);if(!q)return;g.save();g.translate(798+i*134,746);g.scale(back(q),back(q));rect(-51,-24,105,47,'#edc471',23,'#9e7e47',1.5);emoji(-17,0,14,t);text('1',13,8,23,'#654e36',true);g.restore();
 });
}
function profileChat(t){
 // The three reactions stay on YOUR message; Daniel's own message stays quiet.
 rect(697,217,552,113,'#cad9e1',14,'#718f9f',1.5);text('YOU',722,249,18,'#37667e',true);text('Do the filters improve my aim?',722,290,25,'#344d60');
 for(let i=0;i<3;i++){rect(772+i*131,342,101,40,'#e2bd6b',19,'#9e7e47',1);emoji(797+i*131,361,13,t);text('1',825+i*131,369,22,'#654e36',true)}
 cardEnter(14.36,t,()=>{
  rect(668,417,590,385,'#cbdcc9',17,'#5b8d7f',2);
  avatar(746,499,50);inkText('SPORELOSER',819,505,37,'#2b605c');
  text('Buy respirators. Spare filters. Water.',695,580,25,'#38574b');text('Don’t wait for an announcement.',695,622,24,'#38574b');
  const q=clamp((t-17.13)/.52);if(q)line(819,519,819+327*q,519,'#c48e35',5);
  text('SQUAD MEMBER',819,544,16,'#6d8f7c',true);
  cardEnter(15.57,t,()=>{rect(697,704,209,47,'#b8cbb5',23,'#9bae98',1.5);text('No reactions',716,735,23,'#6c8272')});
 });
 // No response animation is intentional in this beat; camera and paper still move.
}
function typingChat(t){
 rect(668,219,590,117,'#cbdcc9',15,'#5b8d7f',1.5);avatar(713,265,27);text('SPORELOSER',760,259,25,'#245c59',true);text('Daniel',760,296,23,'#657f71');
 rect(670,368,588,384,'#cbdcc9',15,'#5b8d7f',1.5);
 const s='We were studying a modified fungus.';
 const n=Math.min(s.length,Math.floor(s.length*clamp((t-28.64)/1.86)));
 text(s.slice(0,Math.min(n,25)),698,435,28,'#36584e');if(n>25)text(s.slice(25,n),698,479,28,'#36584e');
 for(let i=0;i<3;i++){const phase=(t*2.6-i*.25)%(Math.PI*2);ellipse(723+i*27,668-Math.max(0,Math.sin(phase))*5,6,6,'#528d79',null)}
}
function reaction(t){
 const u=(t-9.3)/1.42;
 camera(1090,561,lerp(2.04,2.2,out(u)),()=>{
  room(t);
  const laughter=Math.sin((t-9.3)*19)*2.5*ease((t-9.35)/.16);
  actor(1123,904,1,t,{phone:true,raise:1,mood:t>9.64?'laugh':'amused',head:-.05+Math.sin(t*10)*.025,bounce:laughter,look:[4,6],tap:beat(t,9.53,.5)});
 });
}
function identity(t){
 const u=t-18.05;
 // Daniel is introduced as a person, not a huge floating head beside a tiny actor.
 g.fillStyle='#41656d';g.fillRect(0,0,W,H);shakeHatch(0,0,W,H,300,'#172c3d24');
 const z=1.05+.035*u;
 camera(960,524,z,()=>{
  path([[0,771],[1920,771],[1920,1080],[0,1080]],'#806c52',P.ink,2);
  rect(173,333,450,280,'#273f50',12,P.ink,4);rect(194,350,408,244,'#587c7d',3,P.ink,2);
  rect(389,614,25,65,'#273f50',2,P.ink,2);rect(360,677,84,9,'#273f50',3,P.ink,2);
  g.save();g.beginPath();g.rect(194,350,408,244);g.clip();
  inkText('SPORELOSER',406,377,24,'#e6d6ad','center');
  // In-world gaming avatar walks across cover while Daniel operates his controller.
  rect(210,518,391,104,'#3d5a5a',0,null);rect(230,462,141,58,'#9d744e',3,P.ink,2);
  const px=456+Math.min(u,.95)*49;
  actor(px,587,.40,t,{daniel:true,walk:u<.95?1:0,wt:u,dir:1,hands:[[-35,-272],[49,-272]]});
  actor(px-108,587,.40,t,{walk:u<.95?1:0,wt:u+.58,dir:1,hands:[[-35,-272],[49,-272]],head:-.025});
  g.restore();
  rect(312,683,951,30,'#925d3c',3,P.ink,3);rect(346,713,21,190,'#75492f',1,P.ink,2);rect(1220,713,21,190,'#75492f',1,P.ink,2);
  const press=Math.max(0,Math.sin(u*8));
  actor(1051,912,1.04,t,{daniel:true,mood:'neutral',look:[-6,1],hands:[[-24+press*2,-258-press*5],[43-press*2,-258-press*5]],head:-.025*Math.sin(u*4),bounce:Math.sin(t*4)*1.5});
  g.save();g.translate(1061,639);g.rotate(Math.sin(t*5)*.015);rect(-40,-15,81,37,'#324a57',13,P.ink,3);line(-21,0,-5,0,'#c2d0be',3);line(-13,-8,-13,8,'#c2d0be',3);ellipse(22,-2,4,4,'#d59a4e',null);g.restore();
  // Small printed ID sits on the desk and reveals his real name with narration.
  const v=out((t-18.5)/.5);g.save();g.translate(1400,443+35*(1-v));g.globalAlpha=v;
  rect(-138,-84,282,187,P.paper,4,P.ink,3);avatar(-82,-28,27);text('DANIEL',-29,-18,32,'#345c64',true);text('RESEARCH STAFF',-114,39,19,'#6a7c69',true);line(-114,67,115,67,'#a6a389',2);ellipse(0,-76,5,5,'#ad6946',P.ink,1);g.restore();
  if(t>19.38){const v=back((t-19.38)/.5);g.save();g.translate(421,274);g.scale(v,v);rect(-145,-35,290,70,'#d2a346',9,P.ink,2);inkText('2 YEARS / CO-OP',0,13,30,'#303f43','center');g.restore()}
 });dust(t);
}
function labSet(t){
 g.fillStyle='#80aaa6';g.fillRect(-600,-500,W+1200,H+1000);rect(-600,585,W+1200,239,'#477c7e',0,null);
 rect(-600,820,W+1200,900,'#648d83',0,null);for(let i=0;i<7;i++)line(i*320-150,820,i*320-260,1080,'#325a6045',2);for(let i=0;i<4;i++)line(-600,835+i*73,W+600,835+i*73,'#325a6045',2);
 rect(139,170,608,362,'#d0d7bc',2,P.ink,3);rect(155,187,575,329,'#9bd4d0',0,P.ink,2);
 // Stable building silhouettes through a fixed window; no flying houses.
 for(let i=0;i<5;i++)rect(171+i*115,363+(i%2)*44,93,145,'#74a09e',1,'#476e76',1);
 line(441,189,441,514,'#ccd9bc',10);line(159,365,728,365,'#ccd9bc',8);
 rect(1060,197,303,267,'#38656b',3,P.ink,3);rect(1075,212,272,236,'#b7d5bf',1,P.ink,2);
 inkText('CULTURE / B-04',1210,258,23,'#315d61','center');
 for(let i=0;i<4;i++){line(1097,298+i*33,1305-i*23,298+i*33,'#5a8f83',4)}
 rect(1550,212,205,608,'#416e71',5,P.ink,3);rect(1569,238,168,250,'#6da49e',3,P.ink,2);rect(1569,510,168,282,'#87b3a0',3,P.ink,2);
 for(let i=0;i<5;i++){line(1586,536+i*44,1721,536+i*44,'#426c6c',3)}
 // Rotating ventilation fan, with blades contained in the housing.
 ellipse(893,241,64,64,'#5d898b',P.ink,3);g.save();g.translate(893,241);g.rotate(t*2.1);for(let i=0;i<4;i++){g.rotate(Math.PI/2);path([[0,0],[15,-43],[40,-25],[24,0]],'#bdd1b8',P.ink,2)}g.restore();ellipse(893,241,9,9,'#365d68',P.ink,2);
 rect(250,689,1125,31,'#c5d0ad',3,P.ink,3);rect(276,720,20,169,'#3f686c',1,P.ink,2);rect(1323,720,20,169,'#3f686c',1,P.ink,2);
 rect(296,727,590,101,'#4d7b76',3,P.ink,2);for(let i=0;i<3;i++){rect(307+i*190,740,171,74,'#7d9f89',2,P.ink,1.5);line(370+i*190,754,419+i*190,754,P.ink,3)}
 // Microscope occupies the counter plane, not the floor plane.
 ellipse(527,680,70,11,'#365966',P.ink,2);path([[476,675],[479,640],[521,602],[537,547],[555,551],[551,619],[514,654],[518,675]],'#b7c6aa',P.ink,3);
 g.save();g.translate(544,548);g.rotate(.47);rect(-15,-60,31,85,'#315c67',5,P.ink,3);rect(-20,-62,41,17,'#6e9c96',2,P.ink,2);g.restore();
 line(489,632,581,632,'#315c67',7);ellipse(526,649,12,9,'#e0c167',P.ink,1.5);
 for(let i=0;i<3;i++){rect(776+i*38,617,22,64,'#7db8ae',4,P.ink,2);rect(779+i*38,647,16,29,['#c9b859','#83bb8f','#c38755'][i],2,null);rect(773+i*38,611,27,9,'#d1c99f',2,P.ink,1.5)}
 shakeHatch(10,20,1880,560,140,'#1b434323');shakeHatch(300,740,580,60,43,'#1c484635');dust(t,true);
}
function labAction(t){
 const u=t-21.25,z=lerp(1.02,1.37,ease(u/3.55));
 camera(1000-65*ease(u/3.55),550,z,()=>{
  labSet(t);
  const reach=ease((u-.25)/.65),lift=ease((u-1.0)/.8);
  const hand=mixp([61,-222],[108,-245],reach);const hand2=mixp(hand,[42,-300],lift);
  const left=mixp([-66,-220],[-36,-286],lift);
  const pc=[hand2[0]-28,hand2[1]+12];
  // Dish is on bench at first, then constrained to the hand throughout lift.
  if(u<.9)petri(1130,679,.26,t);
  actor(1050,912,1,t,{daniel:true,hands:[left,hand2],mood:'neutral',look:[5,6],head:.035*reach,dish:u>=.9?[pc[0],pc[1],-.06*lift]:null});
  // Second researcher has the same full-size rig; farther depth reduces size 8%.
  actor(1466,860,.9,t,{daniel:true,female:true,hands:[[-69,-238],[67,-252]],head:-.03,look:[-5,4]});
  rect(1412,618,111,80,'#b8c4a9',3,P.ink,2);text('B-04',1433,652,19,'#315b60',true);line(1427,669,1508,669,'#729084',2);
 });
}
function petri(x,y,s,t){
 g.save();g.translate(x,y);g.scale(s,s);
 ellipse(0,4,213,104,'#739c88',P.ink,4);ellipse(0,-3,213,104,'#c9d4abcc',P.ink,3);
 g.save();g.beginPath();g.ellipse(0,-3,196,91,0,0,Math.PI*2);g.clip();
 for(let i=0;i<18;i++){
  const a=i*2.399,rr=48+(i%5)*20,xx=Math.cos(a)*rr,yy=Math.sin(a)*rr*.45;
  ellipse(xx,yy,13+(i%4)*5,9+(i%3)*4,['#7c9f66','#a4b567','#638b70'][i%3],null);
  for(let k=0;k<3;k++){
   const ang=a+k*2.1,amount=.35+.65*ease((t-24.85-i*.055)/1.6),tx=xx+Math.cos(ang)*55*amount,ty=yy+Math.sin(ang)*34*amount;
   skCurve([[xx,yy],[xx+Math.cos(ang+.6)*16,yy+Math.sin(ang+.6)*12],[tx-9,ty+5],[tx,ty]],'#345f43',1.8);
   if(amount>.6){line(tx,ty,tx+Math.cos(ang+.7)*16*amount,ty+Math.sin(ang+.7)*10*amount,'#345f43',1.3)}
  }
 }
 shakeHatch(-177,-74,355,151,70,'#45694730');g.restore();
 g.beginPath();g.ellipse(0,-10,195,90,0,Math.PI*1.08,Math.PI*1.82);g.strokeStyle='#edf4d488';g.lineWidth=3;g.stroke();
 g.restore();
}
function macro(t){
 const u=t-24.8;
 g.fillStyle='#426a65';g.fillRect(0,0,W,H);shakeHatch(0,0,W,H,200,'#14383c20');
 camera(963-16*u,510,1.02+.038*u,()=>{
  rect(236,169,1437,660,'#7b9a83',7,P.ink,3);shakeHatch(254,181,1400,635,260,'#34574230');
  // Sleeve and black hand physically lower the dish into frame.
  const q=ease(u/.75),yy=lerp(271,491,q),lid=out((u-.75)/.65);
  path([[1523,851],[1390,670],[1198,yy+39],[1166,yy-4],[1214,yy-45],[1421,565],[1646,815]],'#c4cdb7',P.ink,4);
  petri(910,yy,1.47,t);
  ellipse(1185,yy,30,24,P.ink,P.ink,2);
  if(lid>0){
   const lx=910+lid*254,ly=yy-lid*160;
   path([[1800,50],[1659,150],[lx+272,ly-22],[lx+245,ly+12],[lx+280,ly+45],[1739,266],[1920,103]],'#c4cdb7',P.ink,4);
   ellipse(lx+270,ly+9,31,25,P.ink,P.ink,2);
   g.save();g.globalAlpha=1-lid*.3;ellipse(lx,ly,313,151,'#c4e1ce27','#c4ddc4aa',3);g.restore();
  }
  rect(523,733,426,61,P.paper,3,P.ink,2);inkText('B-04 / MODIFIED CULTURE',737,775,25,'#315b56','center');
  path([[1274,714],[1239,774],[1309,774]],'#d6af48',P.ink,2);inkText('!',1274,761,30,P.ink,'center');
 });dust(t,true);
}
function returnRoom(t){
 // The same camera trajectory continues from the earlier reaction angle.
 const u=t-27;
 if(t<28.1){camera(1090,555,2.12+u*.075,()=>{
  room(t);actor(1123,904,1,t,{phone:true,raise:1,mood:t<27.35?'amused':'concerned',head:lerp(-.035,.018,ease(u/.8)),look:[4,6],phoneAngle:.035*ease(u/.65),tap:beat(t,27.65,.3)});
 });}
 else chatBase(t,'typing');
}
function karaoke(t){
 const c=CAPTIONS.find(x=>t>=x.start&&t<x.end);if(!c)return;
 // Short groups, a single baseline, rounded heavy font and charcoal outline.
 const sizes=c.words.length>5?67:73;
 g.save();g.font=`700 ${sizes}px Fredoka,"DejaVu Sans",sans-serif`;
 const widths=c.words.map(w=>g.measureText(w.text.toUpperCase()).width),space=g.measureText(' ').width;
 const total=widths.reduce((a,b)=>a+b,0)+(widths.length-1)*space;
 let x=(W-total)/2;const active=c.words.findIndex(w=>t>=w.start&&t<w.end);
 const rise=7*(1-out((t-c.start)/.13));
 // No black rectangles: the reference uses a thick text outline and tiny shadow.
 g.lineJoin='round';g.lineWidth=11;g.strokeStyle='#20242a';g.shadowColor='#111c2560';g.shadowBlur=0;g.shadowOffsetY=4;
 for(let i=0;i<c.words.length;i++){
  const w=c.words[i],s=w.text.toUpperCase();
  g.strokeText(s,x,987+rise);g.fillStyle=i===active?'#f3ca4e':'#f4f1e9';g.fillText(s,x,987+rise);x+=widths[i]+space;
 }
 g.restore();
}
function finish(t){
 g.save();g.drawImage(paper,0,0);
 // Very light vignette; colors stay richer than the rejected grey grade.
 const v=g.createRadialGradient(960,500,480,960,500,1200);v.addColorStop(0,'#102b3500');v.addColorStop(1,'#10233535');g.fillStyle=v;g.fillRect(0,0,W,H);g.restore();
 karaoke(t);
}
window.renderErrors=[];
function render(t){
 if(stateDepth!==0)throw Error('Unbalanced frame start '+stateDepth);
 window.T=t;g.save();g.clearRect(0,0,W,H);
 try{
  if(t<3.12)opening(t);
  else if(t<5.2)chatBase(t,'early');
  else if(t<9.3)chatBase(t,'warning');
  else if(t<10.72)reaction(t);
  else if(t<14.35)chatBase(t,'reply');
  else if(t<18.05)chatBase(t,'profile');
  else if(t<21.25)identity(t);
  else if(t<24.8)labAction(t);
  else if(t<27)macro(t);
  else returnRoom(t);
  if(stateDepth!==1)throw Error('Unbalanced scene state '+stateDepth);
  finish(t);
 }catch(e){window.renderErrors.push({t,error:String(e)});throw e}finally{g.restore()}
}
