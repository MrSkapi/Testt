from pathlib import Path
import json,subprocess
P=Path(__file__).resolve().parent
words=json.loads((P/'words.json').read_text())
# Short phrase groups track all spoken words, one word in yellow at a time.
groups=[5,3,3,5,2,2,1,5,5,5,4,3,7,4,5,8,5,3,5,6]
# Explicit phrase boundaries keep captions readable and never combine clauses.
phrases=[
 'Five days before the outbreak,','the warning arrives','between a meme',
 'and an argument about pizza.','Buy respirators,','spare filters,','water.',
 "Don't wait for an announcement.",'You send a laughing emoji.',
 'Then you ask whether','the filters improve your aim.','Three people react.',
 "The man who sent the warning", "doesn't.",'His username is SporeLoser.',
 'His real name is Daniel.','You have played together','for two years.',
 'He works at a research facility','and describes his job as',
 "growing things you wouldn't eat.",'Tonight, he explains,',
 'we were studying a modified'
]
idx=0;captions=[]
for phrase in phrases:
 n=len(phrase.split());ws=words[idx:idx+n]
 assert len(ws)==n,(phrase,idx)
 captions.append({'start':ws[0]['start'],'end':min(30,ws[-1]['end']+.10),'words':ws})
 idx+=n
assert idx==len(words),(idx,len(words))
for i in range(len(captions)-1):captions[i]['end']=min(captions[i]['end'],captions[i+1]['start'])
(P/'captions.json').write_text(json.dumps(captions,indent=2))
js='const CAPTIONS='+json.dumps(captions)+';\n'+(P/'drawing.js').read_text()+'\n'+(P/'motion.js').read_text()
player='''
const audio=document.getElementById('voice'),seek=document.getElementById('seek');
document.getElementById('play').onclick=()=>audio.paused?audio.play():audio.pause();
seek.oninput=()=>{audio.currentTime=+seek.value;render(+seek.value)};
const fixed=new URLSearchParams(location.search).get('t');
function animate(){render(Math.min(29.999,audio.currentTime));seek.value=audio.currentTime;requestAnimationFrame(animate)}
document.fonts.ready.then(()=>{if(fixed!==null)render(+fixed||0);else animate()});
'''
html='''<!DOCTYPE html><html lang="en"><meta charset="utf-8"><title>Five Days — motion test 30 seconds</title>
<style>@font-face{font-family:Fredoka;src:url(fonts/fredoka-700.woff2);font-weight:700}*{box-sizing:border-box}body{background:#172c34;color:#eee7da;margin:0;font:16px sans-serif}main{max-width:1440px;margin:auto;padding:16px}canvas{width:100%;height:auto;display:block}footer{display:flex;gap:16px;padding:16px}input{flex:1}button{background:#b65d36;color:#fff;border:0;padding:10px 24px;cursor:pointer}</style>
<main><canvas id="scene" width="1920" height="1080"></canvas><audio id="voice" src="mix.wav" preload="auto"></audio><footer><button id="play">Play / Pause</button><input id="seek" type="range" min="0" max="29.999" value="0" step="0.01"></footer></main><script>'''+js+player+'</script></html>'
(P/'preview.html').write_text(html)
print('Built',len(captions),'phrases;',len(words),'words')
