export async function connect(port=9270){
 const pages=await(await fetch(`http://127.0.0.1:${port}/json/list`)).json(),p=pages.find(p=>p.type==='page');
 const ws=new WebSocket(p.webSocketDebuggerUrl);await new Promise(r=>ws.onopen=r);let seq=0;const pending=new Map();
 ws.onmessage=e=>{const r=JSON.parse(e.data);if(r.id){const q=pending.get(r.id);if(!q)return;pending.delete(r.id);r.error?q.reject(Error(JSON.stringify(r.error))):q.resolve(r.result)}};
 const cmd=(method,params={})=>new Promise((resolve,reject)=>{const id=++seq;pending.set(id,{resolve,reject});ws.send(JSON.stringify({id,method,params}));setTimeout(()=>{if(pending.delete(id))reject(Error('Timeout '+method))},60000).unref()});
 await cmd('Page.enable');await cmd('Page.navigate',{url:'http://127.0.0.1:8772/index.html?t=0'});
 for(let i=0;i<60;i++){const r=await cmd('Runtime.evaluate',{expression:'typeof render',returnByValue:true});if(r.result.value==='function')break;await new Promise(r=>setTimeout(r,100))}
 await cmd('Runtime.evaluate',{expression:`document.fonts.load('700 96px "Patrick Hand"')`,awaitPromise:true});await cmd('Runtime.evaluate',{expression:'document.fonts.ready',awaitPromise:true});return{cmd,ws};
}
