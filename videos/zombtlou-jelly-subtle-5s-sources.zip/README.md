# Five-second hand-drawn motion study

1920×1080, 24 FPS, 120 frames. Original first five seconds of TLOUV2 voiceover, no music or added sound. Original protagonist identity blended with elongated reference proportions: round cream head, teal cap, orange hoodie sleeves, black ball hands, straight stick legs.

All world artwork passes through an animated low-amplitude two-dimensional displacement shader. Screen HUD and captions are rendered afterwards and never displaced. Fixed camera helps judge this effect.

Build: `python build.py`; serve at port8772, start headless Chromium remote-debugging at9270, then `node render.mjs`. The offline HTML preview uses mix.m4a and the included font. No external artwork or network dependencies.

Revision: spatial displacement reduced to under 0.9px horizontally and 0.7px vertically at 1080p; wave speed reduced by about three times, contour boil reduced four times. Screen overlays unchanged.
