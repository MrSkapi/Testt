"""Source-aligned, sparse Foley. Original voice keeps unity gain and timing."""
from pathlib import Path
import json,sys,subprocess,math,gc
import numpy as np
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P/'audio'))
from sfx import make
from dsp import SR,place,write_wav
data=json.loads((P/'timeline.json').read_text());D=data['duration'];cues=[]
def cue(at,name,gain=-32,dur=.14,pitch=1):
 if 0<=at<D:cues.append(dict(at=round(at,5),name=name,gainDb=gain,duration=dur,pitch=pitch))
early=json.loads((P/'opening-sound-cues.json').read_text())
for c in early:
 if c['name']!='footstep':cue(c['at'],c['name'],c['gainDb'],c['duration'])
for t in [.35,.70,1.05,1.40]:cue(t,'footstep',-29,.15)
for s in data['shots']:
 if s['start']<34:continue
 a,b,action=s['start'],s['end'],s['action'];span=b-a
 if action=='screen':
  rows=(s['detail'] or '').split('\n')
  for i,row in enumerate(rows):
   at=a+.13+i*min(1.35,max(.42,span/(len(rows)+1)));cue(at,'pop',-33,.12)
  if 'UPLOAD' in s['title']:cue(b-.16,'blip',-30,.13)
 if action=='typing':
  for k in range(min(9,int(span/.3))):cue(a+.22+k*.30,'tick',-37,.055,1.2)
  if action=='typing' and s['id'] not in ['s108','s114']:cue(b-.17,'blip',-32,.12)
 if action in ['carry','clear','arrival','delivery','watercarry','neighborhelp','sisterpeek','chaseidea']:
  for k in range(int(span/.65)+1):cue(a+.01+k*.65,'footstep',-29,.14)
 if action in ['water','food','mask','pack','counter','inventory','tablegear','parentwater']:
  for k in range(min(6,int(span/.63)+1)):cue(a+.55+k*.63,'tick',-31,.09,.7)
 if action in ['map','split','exitplan','distance','exposuremap','calendar','privacy']:
  cue(a+.21,'swish',-35,.26)
  if span>1.6:cue(a+1.15,'tick',-34,.08)
 if action in ['notebook','motherlist','receipt','evidence']:
  for k in range(min(6,int(span/.75))):cue(a+.37+k*.75,'tick',-37,.06,.7)
 if action in ['lock','door','gate','arrival']:
  cue(a+.65,'tick',-29,.1,.75)
 if action=='repair':
  for k in range(int(span/1.256)+1):cue(a+.94+k*1.256,'hit',-34,.14)
 if action=='tap':
  for k in range(int(span/.43)):cue(a+.15+k*.43,'tick',-40,.05,2.2)
 if action=='fitting' and s['id']=='s063':cue(a+.9,'swish',-38,.21)
 if action=='blind':cue(a+.45,'swish',-37,.55)
 if action=='flashlight':cue(a+.18,'tick',-28,.10)
 if action=='takekeys':cue(a+.48,'tick',-27,.13,1.8)
 if action=='incoming':
  for k in range(int(span/1.9)):cue(a+.1+k*1.9,'phonering',-29,.65)
 if action=='phone' and s['id'] in ['s064','s094']:cue(a+.1,'phonebuzz',-31,.48)
 if action=='bagtable':cue(a+.9,'footstep',-29,.13)
 if action in ['labvideo','busvideo'] and s['id'] in ['s036','s065']:cue(a+.13,'tick',-32,.10)
# Window-contact cues use exactly the same time origin as the animated strike.
for k in range(8):cue(173.89+.3125+k*1.25,'hit',-28,.20)
cue(181.93,'hit',-27,.25)
cues.sort(key=lambda x:x['at'])
(P/'sound-cues.json').write_text(json.dumps(cues,indent=2))
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(P/'narration.mp3'),'-ar',str(SR),'-ac','2','-f','f32le','-'])
voice=np.frombuffer(raw,dtype=np.float32).reshape(-1,2).copy();del raw
fx=np.zeros_like(voice);cache={}
for i,c in enumerate(cues):
 key=(c['name'],c['duration'],c['pitch'],i%3)
 if key not in cache:cache[key]=make(c['name'],dur=c['duration'],pitch=c['pitch'],seed=231+i%3)
 sample=cache[key];place(fx,sample,round(c['at']*SR),10**(c['gainDb']/20))
mix=voice+fx
if float(np.abs(mix).max())>.99:
 fx*=.6;mix=voice+fx
write_wav(str(P/'mix.wav'),mix)
write_wav(str(P/'sfx.wav'),fx)
stats={'sourceSamples':len(voice),'sourceDuration':len(voice)/SR,'voiceGain':1,'timeStretch':1,'sfxCues':len(cues),'peak':float(np.abs(mix).max()),'music':False}
(P/'audio-check.json').write_text(json.dumps(stats,indent=2));print(json.dumps(stats),flush=True)
del voice,fx,mix,cache;gc.collect()
subprocess.run(['ffmpeg','-y','-v','error','-i',str(P/'mix.wav'),'-c:a','aac','-b:a','160k',str(P/'mix.m4a')],check=True)
