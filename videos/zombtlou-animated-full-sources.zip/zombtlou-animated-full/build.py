from pathlib import Path
import json,re,difflib,hashlib
P=Path(__file__).resolve().parent
data=json.loads((P/'timeline.json').read_text());words=json.loads((P/'words.json').read_text())
# Carry the earlier editorial corrections into the aligned words, including times.
editorial=' '.join(c['text'].replace('\n',' ') for c in data['captions']).split()
norm=lambda s:re.sub('[^a-z0-9]','',s.lower())
m=difflib.SequenceMatcher(None,[norm(w['text']) for w in words],[norm(w) for w in editorial],autojunk=False)
for tag,a,b,c,d in m.get_opcodes():
 if tag=='equal' or tag=='replace' and b-a==d-c:
  for i,j in zip(range(a,b),range(c,d)):words[i]['text']=editorial[j]
for i,w in enumerate(words):
 w['start']=max(0,w['start']);w['end']=min(data['duration'],w['end'],words[i+1]['start'] if i+1<len(words) else data['duration'])
 assert w['end']>w['start'],(i,w)
prefix=json.loads((P/'opening-captions.json').read_text())
captions=prefix.copy();rest=[w for w in words if w['start']>=30]
group=[]
def flush():
 global group
 if group:
  captions.append(dict(start=group[0]['start'],end=min(data['duration'],group[-1]['end']+.09),words=group));group=[]
for i,w in enumerate(rest):
 if group and (len(group)>=5 or len(' '.join(x['text'] for x in group)+' '+w['text'])>37 or w['start']-group[-1]['end']>.35):flush()
 group.append(w)
 if w['text'].endswith(('.',',','?','!',':',';')) and len(group)>=2:flush()
flush()
for i in range(len(captions)-1):captions[i]['end']=min(captions[i]['end'],captions[i+1]['start'])
assert sum(len(c['words']) for c in captions)==len(words)
(P/'captions.json').write_text(json.dumps(captions,ensure_ascii=False,indent=2))
(P/'aligned-words.json').write_text(json.dumps(words,ensure_ascii=False,indent=2))
js='const DATA='+json.dumps(data,ensure_ascii=False)+';\nconst WORDS='+json.dumps(words,ensure_ascii=False)+';\nconst CAPTIONS='+json.dumps(captions,ensure_ascii=False)+';\n'
for f in ['drawing.js','opening.js','assets.js','engine.js']:js+=(P/f).read_text()+'\n'
player='''
const audio=document.getElementById('voice'),seek=document.getElementById('seek'),play=document.getElementById('play'),clock=document.getElementById('clock');
seek.max=D;function stamp(x){return Math.floor(x/60)+':'+String(Math.floor(x%60)).padStart(2,'0')}
play.onclick=()=>{if(audio.currentTime>=D-.05)audio.currentTime=0;audio.paused?audio.play():audio.pause()};
document.getElementById('replay').onclick=()=>{audio.currentTime=0;audio.play()};seek.oninput=()=>{audio.currentTime=+seek.value;render(+seek.value)};
const fixed=new URLSearchParams(location.search).get('t');
function frame(){render(Math.min(D-.00001,audio.currentTime));seek.value=audio.currentTime;clock.textContent=stamp(audio.currentTime)+' / '+stamp(D);play.textContent=audio.paused?'Play':'Pause';requestAnimationFrame(frame)}
document.fonts.ready.then(()=>{if(fixed!==null)render(+fixed||0);else requestAnimationFrame(frame)});
'''
html='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Five Days — full animated chapter</title><style>@font-face{font-family:Fredoka;src:url(fonts/fredoka-700.woff2);font-weight:700}*{box-sizing:border-box}body{margin:0;background:#172c34;color:#eee7da;font:14px sans-serif}main{max-width:1440px;margin:auto;padding:16px}canvas{display:block;width:100%;height:auto}footer{display:flex;gap:12px;align-items:center;padding:16px 0}input{flex:1}button{padding:10px 22px;background:#b65d36;color:white;border:0;cursor:pointer}</style></head><body><main><canvas id="scene" width="1920" height="1080"></canvas><audio id="voice" src="mix.m4a" preload="metadata"></audio><footer><button id="play">Play</button><button id="replay">Replay</button><input id="seek" type="range" min="0" step="0.01" value="0"><span id="clock"></span></footer></main><script>'''+js+player+'</script></body></html>'
(P/'chapter1.html').write_text(html)
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(P/'zombtlou-animated-full.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(c["start"])} --> {stamp(c["end"])}\n'+ ' '.join(w['text'] for w in c['words']) for i,c in enumerate(captions))+'\n')
digest=hashlib.sha256(js.encode()).hexdigest();(P/'build-hash.txt').write_text(digest)
print('Built',len(data['shots']),'shots,',len(captions),'phrases,',len(words),'words;',data['duration'],'seconds;',digest[:12])
