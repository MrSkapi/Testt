from pathlib import Path
import zipfile
P=Path(__file__).resolve().parent
files=['README.md','requirements.txt','manifest.json','final-probe.json','drawing.js','opening.js','assets.js','engine.js','timeline.json','words.json','aligned-words.json','captions.json','opening-captions.json','opening-sound-cues.json','sound.py','sound-cues.json','audio-check.json','narration.mp3','mix.m4a','chapter1.html','build.py','build-hash.txt','render-compatibility.json','render-worker.mjs','cdp.mjs','review.mjs','assemble.py','transcript.txt','storyboard.txt','zombtlou-animated-full.srt','zombtlou-animated-full-contact.jpg','audio/dsp.py','audio/sfx.py','fonts/fredoka-700.woff2','fonts/LICENSE','final-qc/audio-alignment.json','final-qc/render-audit.json']
files += ['verify-final.py','package.py']
files += ['final-qc/'+n+'-motion.jpg' for n in ['walk','glass','carry','arrival','family']]
out=P/'zombtlou-animated-full-sources.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name in files:z.write(P/name,arcname='zombtlou-animated-full/'+name)
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print('SOURCE ZIP VERIFIED:',out.stat().st_size,'bytes',flush=True)
