# Five Days — complete animated chapter

The complete 12:10 chapter uses the animation treatment approved in the 30-second preview. The supplied narration remains in its original order and timebase, at unity voice gain. No music has been added.

## Video and animation

- 1920 × 1080, horizontal, 24 unique rendered frames per second.
- Hand-drawn Canvas/vector illustration, teal/amber/rust/green palette, charcoal outlines and animated pencil hatching.
- Original hoodie/cap character, black round hands, thin black legs and short stick feet.
- Walking uses short, low steps. Joint checks limit the walking knee deflection to 32 degrees from straight; the sampled chapter stays below 29 degrees. Standing legs are straight.
- Consistent character rigs and fixed-length arm/leg IK. Props held by actors share the actor's hand transform.
- Phone lifts/taps, walking/carrying, laughter, typing, message and reaction entrances, dish handling, door/gate interactions, mask fitting, family gestures and reaching actions.
- Shot-specific camera framing and continuous moves across neighboring shots. Recorded videos have independent, clipped camera moves and glass-contact effects.
- Near houses, vehicles and people use compatible proportions and ground planes. Far buildings use a separate, clearly established ground plane.
- Rounded bold white English captions with charcoal outlines. Only the currently spoken word is yellow; no caption boxes.
- Sparse original procedural Foley: steps, taps, phone notifications, message/reaction pops, lab-glass impacts, keys and object contacts. No source-reference audio or footage is reused.

## Editable project

`chapter1.html` is the complete browser player with audio and seeking. Serve this folder over HTTP and open it in a modern desktop browser.

| File | Purpose |
| --- | --- |
| `drawing.js` | Primitive drawing helpers, paper texture, workroom and cap |
| `opening.js` | Approved opening sequence, character rig, faces and 30-second action staging |
| `assets.js` | Reusable drawn sets, props and legacy staging helpers |
| `engine.js` | Complete chapter actions, updated staging, corrected exterior scale, camera, captions and frame checks |
| `timeline.json` | Narrative beats and source-aligned shot timing |
| `words.json`, `aligned-words.json` | Word timestamps and editorially corrected words |
| `captions.json` | Short subtitle phrase groups with per-word timing |
| `opening-captions.json` | Approved opening subtitle groups |
| `sound.py`, `sound-cues.json` | Procedural Foley generation, placement and narration mix |
| `opening-sound-cues.json` | Opening Foley timings |
| `narration.mp3` | User's original, complete narration |
| `mix.m4a` | Complete narration plus Foley soundtrack |
| `build.py` | Rebuild the HTML player, caption groups and SRT |
| `render-worker.mjs`, `cdp.mjs` | Render every frame through Chromium and FFmpeg |
| `assemble.py` | Verify rendered parts and assemble the full MP4 |
| `review.mjs` | Sample every scene and save review images and joint/state audits |

The final MP4 is a high-quality H.264/AAC master. GitHub Releases supplies a single MP4 download. Repository chunks exist only to transport the exact master into the release; their assembly is byte-for-byte verified and does not transcode the video.

## Rebuild

Requirements: Python 3 with NumPy and SciPy, Node 22+ with native WebSocket, Chromium and FFmpeg. Fonts and procedural sound code are included; no API key or model download is required.

```sh
python build.py
python sound.py
python3 -m http.server 8767 --bind 127.0.0.1 --directory .
```

In another terminal start Chromium with a dedicated writable profile and debugging port 9240. A managed container may require its normal `--no-sandbox` flag.

```sh
chromium --headless --disable-dev-shm-usage --disable-gpu --remote-debugging-port=9240 --user-data-dir=/tmp/zombtlou-render0 about:blank
node review.mjs
node render-worker.mjs --port 9240 --worker 0 --workers 1
python assemble.py
```

For two rendering workers, start a second Chromium on port 9241 with a different user-data directory. Run workers 0 and 1 with `--workers 2`. Each worker renders alternating 30-second parts. Completed parts are reused only when their generated scene hash matches the current build, or an explicit compatibility record proves that a localized correction does not affect that range. The compatibility record documents the final walking and glass-contact corrections. `--parts 3,4 --force true` can rebuild a selected range after a correction.

## Review and provenance

Every rendered frame checks IK reachability, maximum walking knee bend and balanced drawing state. The project also includes contact sheets, movement samples, render audits, technical probes and final audio alignment checks. These checks supplement visual inspection; they do not replace it.

All illustrated art is editable drawing code. The sound synthesis modules `audio/dsp.py` and `audio/sfx.py` come from the user-supplied **2d-video.plugin**, author Андрей Зенин, version 0.1.1. Fredoka Bold is from `@fontsource/fredoka` and is distributed under the SIL Open Font License, included in `fonts/LICENSE`. The voice recording belongs to the user. Reference video pixels and audio are not included.
