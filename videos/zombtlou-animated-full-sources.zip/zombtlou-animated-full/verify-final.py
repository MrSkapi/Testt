from pathlib import Path
from PIL import Image,ImageDraw
import subprocess,json,hashlib,numpy as np,math,sys
P=Path(__file__).resolve().parent;Q=P/'final-qc';Q.mkdir(exist_ok=True)
video=P/'zombtlou-animated-chapter1-full.mp4';data=json.loads((P/'timeline.json').read_text());D=data['duration']
times=[.5,2.6,6.8,9.8,13.9,20.2,23.1,26.7,31.4,40.9,53.1,72.2,86.5,106.1,133.7,160.1,174.2,177.9,203.7,228.7,264.2,285.9,300.4,331.1,358.8,365.3,384.6,418.1,427.1,439.1,449.2,476.1,486.1,512.5,528.1,547.1,568.5,578.2,606.2,621.2,642.7,673.1,687.9,708.1,724.1,729.9]
# A localized front-layer correction can reuse the already verified, unchanged
# images/audio, while decoding every frame of the changed 30-second range.
localized='--localized-fitting' in sys.argv
# Decode the whole file once and collect the requested native frames.
frames=[min(math.ceil(D*24)-1,round(t*24)) for t in times]
selection='+'.join(f'eq(n\\,{f})' for f in frames)
if localized:
 subprocess.run(['ffmpeg','-v','error','-i',str(P/'parts'/'part-009.mp4'),'-f','null','-'],check=True)
 i=times.index(285.9)
 subprocess.run(['ffmpeg','-y','-v','error','-ss',str(frames[i]/24),'-i',str(video),'-frames:v','1',str(Q/f'frame-{i+1:03d}.png')],check=True)
else:
 subprocess.run(['ffmpeg','-y','-v','error','-i',str(video),'-vf','select='+selection,'-fps_mode','vfr',str(Q/'frame-%03d.png')],check=True)
paths=sorted(Q.glob('frame-*.png'));assert len(paths)==len(frames),(len(paths),len(frames))
out=Image.new('RGB',(1920,math.ceil(len(paths)/4)*294),'#172c34');draw=ImageDraw.Draw(out)
for i,(f,t) in enumerate(zip(paths,times)):
 im=Image.open(f).convert('RGB');assert im.size==(1920,1080)
 # A simple coverage check catches accidental blank/transparent-camera edges.
 arr=np.asarray(im);assert arr.mean()>15 and arr.std()>10,(f,'unexpected dark/blank frame')
 im=im.resize((480,270));x=i%4*480;y=i//4*294;out.paste(im,(x,y));draw.text((x+10,y+274),f'{int(t)//60:02}:{t%60:05.2f}',fill='#fff0c3')
out.save(P/'zombtlou-animated-full-contact.jpg',quality=91)
# Keep two manageable sheets for close visual review.
for k in range(0,len(paths),12):
 out=Image.new('RGB',(1440,math.ceil(min(12,len(paths)-k)/3)*294),'#172c34');draw=ImageDraw.Draw(out)
 for j,f in enumerate(paths[k:k+12]):
  im=Image.open(f).resize((480,270));x=j%3*480;y=j//3*294;out.paste(im,(x,y));draw.text((x+8,y+274),f'{times[k+j]:.2f}s',fill='#fff0c3')
 out.save(Q/f'encoded-sheet-{k//12:02}.jpg',quality=91)
# Native 24-fps movement samples, taken from the final muxed file.
sequences={'walk':[.08,.32,.58,.88,1.16,1.43,1.65,1.90],
 'glass':[174.10,174.22,174.35,174.47,174.60,174.73,174.85,174.98],
 'carry':[357.7,358,358.3,358.6,358.9,359.2,359.5,359.8],
 'arrival':[510.6,511,511.4,511.8,512.2,512.6,513,513.4],
 'family':[618.95,619.15,619.4,619.7,620.1,620.5,621,621.7]}
for name,ts in ([] if localized else sequences.items()):
 out=Image.new('RGB',(1600,484),'#172c34');draw=ImageDraw.Draw(out)
 for i,t in enumerate(ts):
  f=Q/f'{name}-{i}.jpg';subprocess.run(['ffmpeg','-y','-v','error','-ss',str(t),'-i',str(video),'-frames:v','1','-vf','scale=400:225',str(f)],check=True)
  im=Image.open(f);x=i%4*400;y=i//4*242;out.paste(im,(x,y));draw.text((x+6,y+226),f'{t:.2f}s',fill='white')
 out.save(Q/f'{name}-motion.jpg',quality=91)
def decoded(path):
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-vn','-ar','16000','-ac','1','-f','f32le','-'])
 return np.frombuffer(raw,dtype=np.float32)
if localized:
 def audio_hash(path):return subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-map','0:a:0','-c','copy','-f','hash','-hash','sha256','-']).strip()
 assert audio_hash(video)==audio_hash(P/'mix.m4a'),'Audio payload changed'
 checks=json.loads((Q/'audio-alignment.json').read_text())
else:
 source=decoded(P/'narration.mp3');output=decoded(video);checks=[]
 for t in [4.3,59.5,119.5,239.1,359.5,479.4,599.1,719.3]:
  k=round(t*16000);n=4800;a=source[k:k+n];window=output[k-100:k+n+100]
  lag=int(np.argmax(np.correlate(window,a,'valid')))-100
  corr=float(np.corrcoef(a,output[k+lag:k+lag+n])[0,1]);checks.append(dict(at=t,lagSamples=lag,correlation=corr))
assert all(abs(c['lagSamples'])<=1 for c in checks),checks
(Q/'audio-alignment.json').write_text(json.dumps(checks,indent=2))
audits=[]
for f in sorted((P/'parts').glob('*.ok')):
 q=json.loads(f.read_text());assert not q['audit']['errors'] and q['audit']['stateDepth']==0
 audits.append(dict(part=f.stem,hash=q['hash'],frames=q['frames'],audit=q['audit']['audit']))
meta={'title':'Five Days — complete animated chapter','duration':D,'width':1920,'height':1080,'fps':24,'nativeFrames':math.ceil(D*24),'sourceHash':(P/'build-hash.txt').read_text().strip(),'sha256':hashlib.sha256(video.read_bytes()).hexdigest(),'bytes':video.stat().st_size,'walkingMaxKneeFlex':max(x['audit'].get('legMaxFlex',0) for x in audits),'audioAlignment':checks,'parts':audits}
(P/'manifest.json').write_text(json.dumps(meta,indent=2));(Q/'render-audit.json').write_text(json.dumps(audits,indent=2))
print('FINAL VERIFIED:',video.stat().st_size,'bytes;',len(paths),'native sample frames; max knee flex',meta['walkingMaxKneeFlex'],'; audio lags',[q['lagSamples'] for q in checks],flush=True)
