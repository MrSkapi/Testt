# TOMORROW — If AI Could Predict Your Death

A fictional suspense explainer built to the supplied English narration. A 23-year-old hero trusts TOMORROW after useful warnings prevent harm. A smoke-inhalation forecast follows him through changed hotel/friend plans to a protection shelter. Mara receives the same booking and deadline. The two subscribers discover that the system optimises for each customer separately and treats the other as an obstacle. They inspect an unverified route, cooperate to escape, bypass a one-person refuge and survive together. Afterwards they retain useful warnings but decline delegated control.

## Cast and style

Hero: established black round head, cream minimal face, orange hoodie #ed9437, black limbs, no hat. Mara: the same drawn construction, muted pink #b77696, dark hair/bun; she stays on the right in shelter conversations. Mother: purple and grey bun. Mechanic/cyclist/friend: muted blue. Doctor: pale coat and black round head. All characters stay flat drawn 2D with rim light; depth comes from layered staging, foreground blur, light and shadows.

No subtitles or dialogue over heads. All authored device, diagram and closing-question text is English. Phone screens carry actual story information; editorial phone/wide split-screen explains the threshold test. Forecast bars are illustrative and never claim invented numerical percentages.

## Atmosphere and sets

- Cold open: concrete teal shelter, warm bed/pillow, locked right-hand door, sealed left-hand window, fan/service panel and ceiling hatch. Establish the same geometry used later.
- Three weeks earlier: peach/turquoise breakfast and detailed everyday city, lift lobby, stairwell, medical check, train platform and tyre maintenance. These warnings have real benefits.
- Work and booking: blue daylight office, changing reservations, conditional forecasts. The hero remains a passenger in the autonomous car.
- Evening city: warm windows, blue shadows, wet reflections, smoke above the river/warehouse and route changes. No arbitrary camera shaking.
- Shelter escalation: teal safety initially, then warmer grey/plum heat and smoke. The security door is a real opening when Mara crosses it; phone confidence changes with that movement. Confirmation disables protection and releases the lock.
- Shaft: a narrow metal cutaway with heat below, constrained bodies, alternating anchored hand/foot movements and clear vertical order. Hero above, Mara below. The tool falls out of frame with no landing impact added.
- Roof: navy/violet/gold skyline, small white one-person refuge with green lock, hatch, adjacent-building maintenance connection, ladder and water tank. Both people survive the deadline.
- Resolution: daylight incident review, evidence, refund and medical/tyre benefits, then a warm cafe and a direct ordinary message to Mara. The final message uses MESSAGES, not the TOMORROW interface.

## Acting and continuity

158 contiguous shots on a 24fps grid, median 3 seconds. The uploaded narration is authoritative; rough local ASR is only an editorial timing aid. No words are retimed, replaced or reordered.

Specific actions: warnings checked at breakfast; descending a stair; cycle rider attached to bars/pedals; a mechanic's tool aligned to a wheel; sequential permissions; autonomous routing; trying a sealed window; comparing phones; Mara crossing and re-crossing an open threshold; emergency hold and rejected car; confirmation and lock release; fan slowing; failed battery inspection; screen hesitation and sharing; pulling a ceiling hatch down while standing on the bed; flashlight inspection; phone pocketing; braced climbing; tool handoff, fasteners, dropped screwdriver and two-hand grille bending; one continuous rescue that shares a hand target; bypassing the refuge; ladder grips; Mara retaining contact with the hero's sleeve; evidence read before a single final submit; direct human messaging.

The camera scale is fixed per composition; lateral movement uses one absolute clock per sequence. No restarting zoom tween. Repeated shots of the hatch and rescue use shared clocks so actions do not replay. The two characters do not exchange positions during the shelter test. A still final question is allowed to hold with subtle atmosphere, as a deliberate ending.

Audio: preserve AiPredDeath.mp3, with no added music, wind, replacement voices or SFX. Silence of the falling tool is meaningful. The final film has a short visual hold after the source audio ends.
