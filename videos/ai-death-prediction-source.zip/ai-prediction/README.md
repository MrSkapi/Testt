# TOMORROW — If AI Could Predict Your Death

Complete illustrated video for AiPredDeath.mp3. 1920×1080, 24fps, 16:9, 60px letterbox bars. 473 seconds (7:53), 158 shots, 11,352 frames. Original recording duration: 471.719125 seconds. Original English narration, unchanged speed/order, no subtitles, added music or SFX.

The hero keeps the previous black/orange design without headwear. Mara and all environments are drawn by code. No image/video generation assets are required. See story/bible.md for locations, acting, visual language and continuity.

Install ai-prediction/ as projects/ai-prediction/ within the 2d-video toolkit. Apply kit-overrides/ to the toolkit root. Install npm dependencies, ffmpeg and Chromium. tools/local-runtime.mjs selects /usr/bin/chromium in this workspace; adjust its path on another system.

Render:

    node --import ./tools/local-runtime.mjs render-native.mjs --project projects/ai-prediction --workers 3 --gl auto --crf 21 --out projects/ai-prediction/build/full-silent.mp4

Mux without retiming the supplied narration:

    ffmpeg -i projects/ai-prediction/build/full-silent.mp4 -i projects/ai-prediction/input/voiceover.mp3 -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -af apad -t 473 -movflags +faststart ai-death-prediction.mp4

story/shots.json is the authoritative timeline. story/beats.tsv and build_story.py reproduce the editorial shot plan. timeline/rough-asr.json and words.json are imperfect local ASR for timing only; they are not verified captions.

scenes/main.js contains the authored scenes and interactions. animation.js supplies pose blending and shoulder-attached arm IK. objects.js supplies the device/app/prop drawings. sets/world.js supplies the new shelter, shaft, rooftops, rooms and city atmosphere; legacy-world.js contains reusable physical set primitives.

Use --from A --to B --scale .5 for partial previews. Do not run two native video renders into the same project's build directory concurrently because the intermediate encoder files are shared.

The delivered master includes a final correction to the report workflow and direct-message header, rendered from this final source and spliced on exact frame boundaries. Rendering this source afresh produces those corrections directly. validation/ contains timeline/media/audio reports and representative motion proof.
