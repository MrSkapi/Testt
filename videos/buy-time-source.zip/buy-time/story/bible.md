# What if youth became a subscription?

Follow the original English buytime.mp3 narration. A fictional age-repair service genuinely helps people; a son saves to restore his mother's health, then sees the cost turning recovery into more work. This is an imagined social scenario, not a claim that the treatment exists.

Cast: the approved everyday hero in ochre hoodie and turquoise knitted beanie, black round face and minimal white features. Mom wears muted lilac with a bun: grey hair at age 64, dark hair after biological rejuvenation to about 49. The younger aunt wears a salmon cardigan. Friends wear grey teal; company managers wear richer teal. Signature clothes remain consistent.

Locations: home and kitchen, stairwell, mountain path, clinic and treatment room, learning centre, cafe, office after dark, waiting room, yacht, seaside terrace, beach and bus stop. Explanatory information lives on a laptop, clinic monitor, brochure, desk papers, photo album, physical wall calendar, cork pinboard, or street advertisement. The 40-minute clock sits on a nightstand beside a bed and books. A project-local warm grade adds 20 percent saturation with modest contrast.

Camera rule: no zoom animation and no zoom/whip transitions. All camera scales stay exactly 1. Most shots are locked; two slow linear establishing pans use absolute group time across cuts. Max pan speed is about 1.28 pixels per second. Character idle motion and blinks use continuous global time. At the final bus stop, incoming character poses settle from the previous walking pose without a location jump.

156 contiguous shots, 480 seconds, 1920x1080 at 24fps. Preserve the complete 478.955102-second source audio and add only a brief final visual hold. No subtitles, dialogue text over heads, synthesized speech, added music or wind/SFX beds.

Numbers from narration: 5 years = $2,000 + $399/month; 10 years = $3,500 + $699/month; 15 years = $5,000 + $999/month; 20 years = $8,000 + $1,499/month. Mom chooses 15 years: 64 to 49; first course plus prepaid year is $16,988. Later $1,200/month maintenance applies to new packages, while existing prepayments are honoured. Do not invent a later upfront price. Savings milestones are $3,000, $6,000 and $9,000. Age 90/looks 50 and a later hundredth birthday are deliberate contrasts with working life.
