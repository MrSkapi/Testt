# Buy Time — complete film

The complete buytime.mp3 recording, with the approved ochre hoodie/turquoise beanie hero. 1920x1080, 24 fps, English, 156 shots, 480 seconds. Original narration is unchanged in timing and wording. No subtitles, added music, wind loop, sound effects or replacement speech.

Requested changes: calm camera with no zoom/reset loop; moderately richer colours; varied physical settings for explanatory visuals. See scenes/common.js for the locked camera and absolute-clock pans, scenes/sets/surfaces.js for the objects carrying the information, and scenes/sets/places.js for new locations. Style buytime uses a modest saturation/contrast filter; other projects are unaffected.

Put buy-time/ in projects/buy-time in the installed 2d-video toolkit. Copy kit-overrides/ over the toolkit root to retain the custom renderer, style and engine. Install npm dependencies if necessary. The included local-runtime.mjs selects /usr/bin/chromium; adjust that path for another machine.

Render:

    node --import ./tools/local-runtime.mjs render-native.mjs --project projects/buy-time --workers 3 --gl auto --crf 23 --out projects/buy-time/build/full-silent.mp4

Mux:

    ffmpeg -i projects/buy-time/build/full-silent.mp4 -i projects/buy-time/input/voiceover.mp3 -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -af apad -t 480 -movflags +faststart buy-time-complete.mp4

story/shots.json owns all timing. timeline/rough-asr.json is rough local recognition for editorial timing, not a verified caption transcript. The supplied audio is authoritative. Validation includes a rendered 20-second pricing sequence, boundary stills at the final walk/stand cut, a camera trace across all 11,520 frames, and final media checks.
