import {layer,backdrop,blurLayer,seg,poly,circle,ring,alpha,text,FONTS,lerp} from '/engine/core.js';
import * as FX from '/engine/fx2d.js';
import {C,box,ellipse,shadow,clock,cup,plant,book,car} from './props.js';
export const GY=900;
export function dust(g,t){FX.dust(g,t,{count:17,color:C.gold,a:.10,size:1.2,speed:3});}
function floor(g,y=811,col='#827765'){box(g,-2000,y,6000,1800,col);for(let j=0;j<12;j++)seg(g,[[-2000,y+15+j*j*4],[4000,y+15+j*j*4]],1,'#d9c9a51a');}
export function clinic(g,t,c={},o={}){
 layer(g,c,.2,g=>{backdrop(g,['#687e73','#c4c2a4']);box(g,173,102,570,529,'#41625a',8);box(g,192,121,530,489,'#bdcdb5',4);for(let j=0;j<4;j++)box(g,210+j*132,380-(j%3)*55,104,230,'#879e8b66');box(g,451,120,12,489,'#5b7767');box(g,192,370,529,12,'#5b7767');floor(g,812,'#8c8f79');});
 layer(g,c,.58,g=>{
  box(g,903,217,686,450,'#567369',14);box(g,924,239,644,406,'#d0d4b6',10);
  text(g,'RENEW',1246,316,{size:44,font:FONTS.ui,color:'#4e7160',spacing:7});
  for(let j=0;j<3;j++){let x=1048+j*197;circle(g,x,470,44,'#8ea487');seg(g,[[x-17,470],[x+17,470]],6,'#dbe1c4');seg(g,[[x,453],[x,487]],6,'#dbe1c4');}
  box(g,834,699,858,32,'#b0a486',7);box(g,855,731,819,129,'#6d8975',8);plant(g,1768,845,1.4);
  if(o.waiting){for(let j=0;j<4;j++){let x=337+j*329;box(g,x-93,665,186,33,'#58776a',8);box(g,x-84,553,168,104,'#78957e',13);for(let dx of[-69,69])box(g,x+dx,698,12,151,'#425e53');}}
 });dust(g,t);
}
export function treatment(g,t,c={}){
 layer(g,c,.2,g=>{backdrop(g,['#697f75','#b4bea4']);floor(g,809,'#81917c');for(let j=0;j<5;j++){box(g,106+j*374,145,290,408,'#4d6f60',10);box(g,119+j*374,159,264,379,'#c1d0b2',7);}});
 layer(g,c,.65,g=>{
  box(g,669,694,636,192,'#547365',30);box(g,708,626,561,93,'#c7cbb0',29);box(g,707,618,161,65,'#e3dcc1',20);
  for(let xx of[719,1212])box(g,xx,863,27,82,'#476456',5);
  box(g,1367,467,265,298,'#526f60',18);box(g,1387,486,226,133,'#284c45',9);for(let j=0;j<3;j++)seg(g,[[1410,522+j*28],[1587-j*21,522+j*28]],3,'#b1d0ae');
  seg(g,[[1369,659],[1275,659],[1241,709]],14,'#89a68a');
 });dust(g,t);
}
export function stairs(g,t,c={}){
 layer(g,c,.2,g=>{backdrop(g,['#6d7068','#b8a98d']);box(g,138,92,419,559,'#455d57');box(g,157,110,382,520,'#a9baa3');box(g,347,109,10,520,'#607a69');});
 layer(g,c,.55,g=>{
  floor(g,920,'#71675c');for(let j=0;j<8;j++){let x=469+j*157,y=907-j*57;box(g,x,y,1700,800,'#8a8572');box(g,x,y,1700,15,'#c7b99a');seg(g,[[x+11,y+40],[2100,y+40]],1,'#635f5333');}
  seg(g,[[498,615],[1744,163]],13,'#4b6158');for(let j=0;j<8;j++){let x=514+j*168,y=611-j*61;seg(g,[[x,y],[x,y+284]],7,'#5e7362');}
 });dust(g,t);
}
export function classroom(g,t,c={},o={}){
 layer(g,c,.2,g=>{backdrop(g,['#6e7c68','#b9b48e']);box(g,214,124,403,489,'#4c6855',6);box(g,232,142,368,453,'#bbcbb0');box(g,414,142,11,453,'#6a826b');floor(g,786,'#83765e');});
 layer(g,c,.58,g=>{
  box(g,781,150,918,441,'#385b49',10);text(g,'LEARNING CENTRE',1240,249,{size:37,font:FONTS.ui,color:'#d0d5b4',spacing:2});
  for(let j=0;j<3;j++)seg(g,[[883,351+j*67],[1546-j*75,351+j*67]],3,'#a9bc9366');
  for(let j=0;j<4;j++){let x=181+j*465;box(g,x,776,291,26,'#a68b5f',7);for(let d of[22,254])box(g,x+d,799,14,157,'#665d45');book(g,x+73,766,87,15,C.paper);}
 });dust(g,t);
}
export function office(g,t,c={},o={}){
 layer(g,c,.25,g=>{backdrop(g,o.night?['#38434a','#746c60']:['#63756d','#b9b298']);floor(g,791,'#7e725f');for(let j=0;j<3;j++){let x=116+j*590;box(g,x,107,459,504,'#3e5c53',8);box(g,x+17,122,425,471,o.night?'#667c82':'#bbccb4');for(let k=0;k<5;k++)box(g,x+28+k*84,371-k*21,69,222,'#718f7e77');box(g,x+224,120,12,474,'#4c6a5b');}});
 layer(g,c,.66,g=>{
  box(g,739,650,986,38,'#9e8159',8);box(g,766,688,935,127,'#6e6d56',6);for(let x of[777,1654])box(g,x,794,22,148,'#4f5546');
  box(g,1033,447,257,179,'#2d4640',11);box(g,1048,460,227,148,'#789c85',5);seg(g,[[1038,630],[1294,630]],12,'#505d4b');
  box(g,1374,591,150,52,'#b7aa86',5);clock(g,1678,227,66,o.night?'22:40':'09:00',true);plant(g,1857,840,1.25);
 });dust(g,t);
}
export function waiting(g,t,c={}){clinic(g,t,c,{waiting:true});layer(g,c,.74,g=>{box(g,1557,365,202,134,'#4b6c5d',11);text(g,'PLEASE WAIT',1658,425,{size:24,font:FONTS.ui,color:C.cream});});}
export function beach(g,t,c={},o={}){
 layer(g,c,.12,g=>{backdrop(g,['#7c7e83','#d1ad8b','#edc99b']);FX.sun(g,1242,295,49,'#f1d6a4',C.gold,4);});
 layer(g,c,.38,g=>{box(g,-1500,548,5100,498,'#708e89');for(let j=0;j<14;j++){let y=570+j*22,x=-600+((t*11+j*79)%300);seg(g,[[x,y],[x+2600,y]],j%3===0?3:1,'#d2c4a64c');}poly(g,[[-1500,873],[460,745],[1166,774],[2600,667],[2800,1600],[-1600,1600]],'#bda882');});
 layer(g,c,.7,g=>{if(o.hotel){box(g,1337,146,900,417,'#b1a287');box(g,1354,166,842,303,'#536e64');for(let j=0;j<5;j++){box(g,1380+j*176,187,14,282,'#d1bda0');circle(g,1458+j*176,213,9,'#edce94');}box(g,1314,469,970,32,'#dcc7a2');for(let j=0;j<12;j++)box(g,1329+j*81,503,8,143,'#8d9a80');seg(g,[[1314,499],[2280,499]],9,'#b8bca0');}
  ellipse(g,628,976,214,24,'#81796244');
 });dust(g,t);
}
export function yacht(g,t,c={}){
 layer(g,c,.1,g=>backdrop(g,['#6f8d90','#c2c8ab']));layer(g,c,.32,g=>{box(g,-2000,555,6000,900,'#719591');for(let j=0;j<15;j++)seg(g,[[-1600+(j%3)*40,593+j*28],[2800,593+j*28]],2,'#c6d0b233');});
 layer(g,c,.65,g=>{poly(g,[[289,667],[1676,667],[1550,839],[543,839]],'#e0d1b0');box(g,608,408,760,258,'#c5bea2',17);box(g,679,303,562,109,'#dcd5b5',13);for(let j=0;j<5;j++)box(g,647+j*140,469,108,91,'#527773',7);box(g,563,643,872,33,'#eee0c0',6);seg(g,[[1036,310],[1036,129]],7,'#879f8a');poly(g,[[1041,135],[1150,165],[1041,190]],'#bb7960');});dust(g,t);
}
export function terrace(g,t,c={}){
 beach(g,t,c,{hotel:false});layer(g,c,.5,g=>{box(g,-2000,726,6000,1300,'#96896c');seg(g,[[-1500,622],[3300,622]],12,'#b9b99a');for(let x=-500;x<2400;x+=147)seg(g,[[x,623],[x,797]],7,'#6b8d7c');
 for(let j=0;j<9;j++){let x=246+j*180;seg(g,[[x,-100],[x,139+(j%2)*26]],2,'#6d7460');circle(g,x,147+(j%2)*26,12,'#e3c58e');}
 });dust(g,t);
}
export function busStop(g,t,c={}){beach(g,t,c,{hotel:true});layer(g,c,.71,g=>{
 box(g,119,240,660,29,'#4c6c5d',5);box(g,150,269,17,588,'#567660');box(g,726,269,17,588,'#567660');box(g,172,280,552,389,'#88a48a55');box(g,244,743,434,25,'#536c59',6);for(let x of[280,628])box(g,x,766,13,101,'#4c6151');
 box(g,199,318,150,85,'#557e6d',7);text(g,'BUS',274,360,{size:35,font:FONTS.ui,color:C.cream});
 });}
