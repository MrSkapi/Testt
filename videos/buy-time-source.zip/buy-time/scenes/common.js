import {layer,blurLayer,veil,clamp} from '/engine/core.js';
import * as W from './sets/world.js';
// Locked camera by default. Any authored pan uses ONE absolute group clock,
// never a shot-local p/t/duration, never a zoom tween, never an oscillation.
export function camera(t,i){const p=i.pan;if(!p)return {z:1,x:0,y:0};const u=clamp((i.globalT-p.start)/(p.end-p.start));return {z:1,x:p.from+(p.to-p.from)*u,y:0};}
export function setting(g,t,i,where='apartment',o={}){const c=camera(t,i);W[where](g,i.globalT,c,o);return c;}
