from pathlib import Path
import subprocess,json,zipfile,hashlib
import numpy as np
from PIL import Image,ImageDraw
P=Path(__file__).parent;V=P/'zombtlou-jelly-style-5s.mp4'
meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_type,width,height,r_frame_rate,nb_frames,duration:format=duration,size','-of','json',str(V)]))
s=next(x for x in meta['streams'] if x['codec_type']=='video');assert (s['width'],s['height'],s['r_frame_rate'],s['nb_frames'])==(1920,1080,'24/1','120');assert float(meta['format']['duration'])==5
# Fully decode all native frames and inspect movement in the exported file.
b=subprocess.check_output(['ffmpeg','-v','error','-i',str(V),'-an','-vf','scale=480:270','-f','rawvideo','-pix_fmt','rgb24','-'])
a=np.frombuffer(b,dtype=np.uint8).reshape(120,270,480,3)
delta=np.abs(np.diff(a[:,45:210,:250].astype(float),axis=0)).mean((1,2,3));assert min(delta)>.05
sheet=Image.new('RGB',(1440,588),'#242b29');d=ImageDraw.Draw(sheet)
for i,f in enumerate([0,12,24,48,84,119]):
 x=i%3*480;y=i//3*294;sheet.paste(Image.fromarray(a[f]),(x,y));d.text((x+8,y+275),f'{f/24:.2f} s',fill='white')
sheet.save(P/'motion-review.jpg',quality=92)
# Source HUD equality is pixel-perfect: encoding itself may add small block noise.
x=np.array(Image.open(P/'preview-0.png'));y=np.array(Image.open(P/'preview-4.png'));assert np.array_equal(x[52:131,60:530],y[52:131,60:530])
def dec(p):return np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-t','5','-vn','-ar','16000','-ac','1','-f','f32le','-']),dtype=np.float32)
x=dec('/workspace/supermarket-style30/narration.mp3');y=dec(V);lags=[]
for t in [.5,2,3.5,4.5]:
 k=round(t*16000);n=3200;lag=int(np.argmax(np.correlate(y[k-80:k+n+80],x[k:k+n],'valid')))-80;lags.append(lag)
assert max(abs(v) for v in lags)<=1,lags
report=dict(video=meta,audioLagSamples=lags,HUD='exactly equal source pixels across sample frames',worldFrameDeltaRange=[float(min(delta)),float(max(delta))],sha256=hashlib.sha256(V.read_bytes()).hexdigest())
(P/'verification.json').write_text(json.dumps(report,indent=2))
with zipfile.ZipFile(P/'zombtlou-jelly-style-5s-sources.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['README.md','index.html','scene.js','words.json','mix.m4a','build.py','build-hash.txt','cdp.mjs','render.mjs','render-audit.json','verification.json','verify.py','fonts/PatrickHand-Regular.ttf','fonts/OFL.txt']:
  z.write(P/name,name)
with zipfile.ZipFile(P/'zombtlou-jelly-style-5s-sources.zip') as z:assert z.testzip() is None
print(json.dumps(report,indent=2))
