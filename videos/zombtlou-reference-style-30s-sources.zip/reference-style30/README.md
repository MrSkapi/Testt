# Five Days — 30-second drawn style study

1920×1080, 24 FPS, exactly 30 seconds. This is a new animation of the first 30 seconds of the supplied TLOUV2 narration.

The visual treatment follows the supplied supermarket reference: long rectangular coats, thin segmented black limbs, round pale faces, thick hand-drawn outlines, paper grain, gently moving pencil marks, muted warm/cool lighting, close reaction shots, and a paper day/time/temperature card. The main character keeps his teal cap and orange clothing. English captions appear one word at a time in black with a white halo.

The reference recording is used only for style study. Its footage, narrator, music, channel branding and watermark are not included in the animation. The story's clock/temperature card is an illustrative fictional setting, with the one-hour flashback shown by a change in clock time.

The shutter chain, phone, door handle and first-aid case use authored hand contacts. Hands stay calm during dialogue. The original first 30 seconds of narration keep their timing and unity gain; sparse procedural Foley is added, with no music.

## Edit or play

`index.html` is the self-contained browser player. Serve this folder over HTTP:

```sh
python -m http.server 8770 --bind 127.0.0.1
```

Open http://127.0.0.1:8770/index.html in a desktop browser. The player includes audio, pause and seeking.

`scene.js` contains all drawing, rigs, lighting, camera moves, actions and captions. `words.json` contains the original word timings. `narration.mp3` is the complete original uploaded narration, for source integrity; the exported clip uses only its first 30 seconds.

## Rebuild

Requires Python 3, NumPy, SciPy, Pillow, Node 22+, Chromium and FFmpeg. No API key or model is required. The hand-drawn font and its OFL license are included.

```sh
python -m pip install -r requirements.txt
python build.py
python sound.py
```

With the HTTP server running, start a dedicated Chromium browser and export:

```sh
chromium --headless --disable-dev-shm-usage --disable-gpu --remote-debugging-port=9270 --user-data-dir=/tmp/reference-style30 about:blank
node review.mjs
node render.mjs
python verify.py
python package.py
```

Use the normal Chromium sandbox configuration for your machine; this managed container uses `--no-sandbox`.

`qc/audit.json` records pose checks for all 720 frames. The final verification checks the H.264/AAC file, audio alignment, native frame count and encoded motion samples. Sound cues are editable in `sound.py` and `sound-cues.json`.
