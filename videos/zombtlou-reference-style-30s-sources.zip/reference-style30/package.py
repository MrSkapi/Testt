from pathlib import Path
import zipfile,hashlib,tempfile,subprocess
P=Path(__file__).resolve().parent
files=['README.md','requirements.txt','scene.js','words.json','build.py','build-hash.txt','index.html','sound.py','sound-cues.json','audio-check.json','narration.mp3','mix.m4a','cdp.mjs','review.mjs','render.mjs','verify.py','package.py','render-audit.json','manifest.json','final-probe.json','fonts/PatrickHand-Regular.ttf','fonts/OFL.txt','audio/dsp.py','audio/sfx.py','qc/audit.json','final-qc/audio-alignment.json','zombtlou-reference-style-30s-contact.jpg']
files+=['final-qc/'+n+'-motion.jpg' for n in ['chain','call','entry','kit']]
out=P/'zombtlou-reference-style-30s-sources.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in files:z.write(P/f,arcname='reference-style30/'+f)
with tempfile.TemporaryDirectory(dir='/tmp',prefix='reference-style-rebuild-') as t:
 with zipfile.ZipFile(out) as z:assert z.testzip() is None;z.extractall(t)
 root=Path(t)/'reference-style30';digest=(root/'build-hash.txt').read_text();subprocess.run(['python','build.py'],cwd=root,check=True);assert (root/'build-hash.txt').read_text()==digest
print('EDITABLE SOURCE ZIP VERIFIED',out.stat().st_size,'bytes',flush=True)
