/* Original, deterministic 2D animation. 1920x1080, 24 FPS, 30 seconds.
   The supplied recording is a style reference; its artwork/audio are not used. */
const C=document.getElementById('scene'),g=C.getContext('2d'),W=1920,H=1080,D=30;
let T=0,poseFrames=[];const ink='#292720';
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x)),lerp=(a,b,q)=>a+(b-a)*q;
const ease=x=>{x=clamp(x);return x*x*(3-2*x)},phase=(t,a,d)=>clamp((t-a)/d),qAt=(t,a,d)=>ease((t-a)/d);
const mix=(a,b,q)=>[lerp(a[0],b[0],q),lerp(a[1],b[1],q)];
const B={shadow:6.1149998474,close:8.7950000763,call:12.3149998093,girl:13.5549998474,hero:15.7550003052,lock:17.1949999237,flash:19.9149999237,wound:24.5549998474,aid:28.5149996948};
let audit={maxBoneError:0,maxWalkFlex:0,unreachable:[],frames:0};
function path(ps,fill=null,stroke=ink,width=4,close=true){g.beginPath();g.moveTo(...ps[0]);for(let i=1;i<ps.length;i++)g.lineTo(...ps[i]);if(close)g.closePath();if(fill){g.fillStyle=fill;g.fill()}if(stroke){g.strokeStyle=stroke;g.lineWidth=width;g.lineJoin='round';g.lineCap='round';g.stroke()}}
function line(x,y,X,Y,c=ink,w=4){g.beginPath();g.moveTo(x,y);g.lineTo(X,Y);g.strokeStyle=c;g.lineWidth=w;g.lineCap='round';g.stroke()}
function softLine(x,y,X,Y,c=ink,w=3,seed=0){const v=Math.sin(seed*4.27+Math.floor(T*6)*1.71)*1.0;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo((x+X)/2+v,(y+Y)/2-v,X,Y);g.strokeStyle=c;g.lineWidth=w;g.lineCap='round';g.stroke()}
function rect(x,y,w,h,fill,stroke=ink,sw=4,r=0){g.beginPath();g.roundRect(x,y,w,h,r);if(fill){g.fillStyle=fill;g.fill()}if(stroke){g.strokeStyle=stroke;g.lineWidth=sw;g.stroke()}}
function oval(x,y,rx,ry,c,stroke=ink,sw=4){g.beginPath();g.ellipse(x,y,rx,ry,0,0,Math.PI*2);if(c){g.fillStyle=c;g.fill()}if(stroke){g.strokeStyle=stroke;g.lineWidth=sw;g.stroke()}}
function label(s,x,y,size=28,c=ink,align='left',family='Patrick Hand',bold=false){g.font=`${bold?'700':'400'} ${size}px "${family}",sans-serif`;g.fillStyle=c;g.textAlign=align;g.fillText(s,x,y)}
function hatch(x,y,w,h,n=20,c='#332e2330',seed=0){g.save();g.beginPath();g.rect(x,y,w,h);g.clip();const f=Math.floor(T*6);for(let i=0;i<n;i++){const X=x+(i*31.37+seed*17)%w+Math.sin(i*8.1+f)*.7,Y=y+(i*57.93+seed*13)%h;line(X,Y,X+8+i%6,Y-15,c,.8+i%2*.25)}g.restore()}
function cam(x,y,z,fn){g.save();g.translate(960,540);g.scale(z,z);g.translate(-x,-y);fn();g.restore()}
function rand(seed){let n=seed>>>0;return()=>{n=(Math.imul(n,1664525)+1013904223)>>>0;return n/4294967296}}
const grain=document.createElement('canvas');grain.width=640;grain.height=360;{const ctx=grain.getContext('2d'),d=ctx.createImageData(640,360),r=rand(274);for(let i=0;i<d.data.length;i+=4){const v=110+r()*100;d.data[i]=v;d.data[i+1]=v;d.data[i+2]=v;d.data[i+3]=24}ctx.putImageData(d,0,0)}
function finish(){g.save();g.globalCompositeOperation='multiply';g.globalAlpha=.72;g.drawImage(grain,0,0,W,H);g.restore();const v=g.createRadialGradient(1030,490,190,970,540,1190);v.addColorStop(0,'#26262400');v.addColorStop(.56,'#302a2320');v.addColorStop(1,'#161820a0');g.fillStyle=v;g.fillRect(0,0,W,H);for(let i=0;i<19;i++){const x=(i*107.4+Math.sin(T*.18+i)*23)%W,y=70+(i*137.3+T*(1+i%3))%930;oval(x,y,1.2+i%2,1.2+i%2,'#f7efd62b',null)} }
function joint(a,b,A=76,Bb=78,pole=[0,-290]){
 const dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy);if(d>A+Bb+.02||d<Math.abs(A-Bb)+.01){audit.unreachable.push({t:T,a,b,d});throw Error('Unreachable joint '+d)}
 const q=(A*A-Bb*Bb+d*d)/(2*d),h=Math.sqrt(Math.max(0,A*A-q*q)),mid=[a[0]+dx*q/d,a[1]+dy*q/d],perp=[dy/d,-dx/d];
 const c=clamp(((pole[0]-mid[0])*perp[0]+(pole[1]-mid[1])*perp[1])/Math.max(1,h),-1,1)*d*d/(d*d+1600),K=[mid[0]+perp[0]*h*c,mid[1]+perp[1]*h*c],z=h*Math.sqrt(1-c*c);
 const err=Math.max(Math.abs(Math.hypot(K[0]-a[0],K[1]-a[1],z)-A),Math.abs(Math.hypot(K[0]-b[0],K[1]-b[1],z)-Bb));audit.maxBoneError=Math.max(audit.maxBoneError,err);return K;
}
function legK(a,b,side){const dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy),A=88;if(d>176+.01)throw Error('Unreachable leg '+d);const h=Math.sqrt(Math.max(0,A*A-d*d/4));return[(a[0]+b[0])/2+side*dy*h/d,(a[1]+b[1])/2-side*dx*h/d]}
function cap(){g.beginPath();g.moveTo(-49,-21);g.bezierCurveTo(-58,-52,-28,-78,3,-75);g.bezierCurveTo(34,-73,53,-48,49,-19);g.closePath();g.fillStyle='#337b7c';g.fill();g.strokeStyle=ink;g.lineWidth=6;g.stroke();g.beginPath();g.moveTo(-49,-27);g.bezierCurveTo(-70,-32,-92,-25,-96,-16);g.bezierCurveTo(-94,-4,-57,-2,-31,-13);g.fillStyle='#397e7b';g.fill();g.strokeStyle=ink;g.lineWidth=6;g.stroke();softLine(-3,-72,-9,-23,'#285a5b',2,12);line(-46,-27,44,-21,'#275052',3);oval(2,-73,4,4,'#286364',ink,2)}
function head(t,o={}){g.save();g.rotate(o.head||0);oval(0,0,49,49,o.skin||'#e5e1d5',ink,5.5);
 if(o.hat){path([[-48,-14],[-43,2],[-37,-15],[-27,-22],[-17,-15],[0,-24],[21,-16],[39,-25],[48,-11],[42,-40]],'#242824',null)}
 else{g.beginPath();g.moveTo(-48,-8);g.bezierCurveTo(-53,-35,-29,-56,0,-53);g.bezierCurveTo(30,-55,50,-31,47,-5);g.lineTo(28,-22);g.quadraticCurveTo(10,-32,-10,-17);g.quadraticCurveTo(-30,-25,-48,-8);g.fillStyle=o.hair||'#4a4034';g.fill();g.strokeStyle=ink;g.lineWidth=4;g.stroke();if(o.female){g.beginPath();g.moveTo(35,-31);g.bezierCurveTo(61,-40,62,-20,62,-4);g.quadraticCurveTo(64,11,62,24);g.quadraticCurveTo(44,17,40,-2);g.fill();g.stroke()}}
 g.save();g.beginPath();g.ellipse(0,0,47,47,0,0,Math.PI*2);g.clip();path([[-55,-19],[53,-5],[53,5],[-53,-6]],'#676b6230',null);g.restore();
 const bl=(t+(o.phase||0))%4.3,blink=bl>4.12?Math.max(.08,Math.abs(bl-4.21)/.09):1,look=o.look||[0,2];
 for(const x of [-16,7]){if(o.infected){oval(x+look[0]*.5,1,9,10,'#464c42',null);oval(x+1,1,2.1,2.1,'#ced0b7',null)}else oval(x+look[0],look[1],3.8,7.1*blink,ink,null)}
 if(o.worry){softLine(-24,-13,-12,-16,ink,2,1);softLine(6,-16,18,-12,ink,2,2)}
 if(o.surprise)oval(-4,25,5,7,ink,null);else if(o.talk)oval(-4,25,5,2+5*o.talk,ink,null);else softLine(-12,25,3,24,ink,2.4,3);
 if(o.mask){path([[-33,14],[-22,6],[18,7],[31,17],[24,38],[-24,38]],'#8c9181',ink,2.5);for(const x of [-22,20])oval(x,26,10,10,'#b4b69f',ink,2.3);rect(-9,16,17,18,'#9ba28b',ink,2,3)}
 if(o.hat)cap();hatch(-38,29,70,10,5,'#66614d28');g.restore();}
const REST=[[-52,-218],[52,-218]];
function actor(id,x,y,s,t,o={}){
 const sc=s,col=o.col||'#b96d3e',walk=o.walk||0,dir=o.dir||1,gait=o.gait||0,breath=o.still?0:Math.sin(t*1.5+(o.phase||0))*.55;
 g.save();g.translate(x,y);g.scale(s,s);oval(0,3,48,6,'#211e192c',null);
 const feet=[];
 for(let i=0;i<2;i++){const hx=i?21:-20,q=(gait+i*.5)%1,stance=q<.62,v=stance?q/.62:(q-.62)/.38;
  const f=[hx+dir*(stance?30-60*v:-30+60*ease(v))*walk,stance?0:-(o.limp&&i?1.2:2.8)*Math.sin(Math.PI*v)*walk],hip=[hx,lerp(-176,-172.8,walk)];feet.push(f);
  if(walk){const k=legK(hip,f,dir),flex=2*Math.acos(Math.min(1,Math.hypot(f[0]-hip[0],f[1]-hip[1])/176))*180/Math.PI;audit.maxWalkFlex=Math.max(audit.maxWalkFlex,flex);if(flex>33)throw Error('Excessive walk flex');softLine(...hip,...k,ink,8.5,i);softLine(...k,...f,ink,8.5,i+2)}else softLine(...hip,...f,ink,8.5,i);
  softLine(...f,f[0]+18*dir,f[1],ink,9,i+3);
 }
 g.save();g.translate(0,breath);g.rotate(o.lean||0);
 path([[-42,-389],[36,-379],[45,-175],[-42,-175]],col,ink,5.5);
 path([[-27,-386],[-8,-373],[14,-382],[12,-352],[-3,-344],[-18,-365]],o.trim||'#4d554e',ink,3.2);
 rect(2,-226,29,30,null,ink,3);softLine(-32,-368,-31,-192,'#e9dec244',1.4,91);hatch(-36,-355,68,160,17,'#352d231f',5);
 let hands=(o.hands||REST).map(p=>p.slice()),elbows=[];
 if(walk&&!o.hands){const z=Math.sin(gait*2*Math.PI)*3;hands=[[-54-z,-220+z],[54+z,-220-z]]}
 const shoulders=[[-34,-365],[34,-363]];
 for(let i=0;i<2;i++){const K=joint(shoulders[i],hands[i],76,78,[i?100:-100,-288]);elbows.push(K);softLine(...shoulders[i],...K,ink,10,i+10);softLine(...K,...hands[i],ink,10,i+13);
  if(o.sleeve&&i===0){softLine(...shoulders[i],...K,col,12,i+10);softLine(...K,...hands[i],col,12,i+13);line(K[0]-4,K[1],hands[i][0]-3,hands[i][1],o.blood?'#733e35':col,6);if(o.blood){const p=mix(K,hands[i],.64);oval(p[0]+3,p[1]-4,8,10,'#6b3b34',null);line(p[0]-7,p[1]+1,p[0]-9,p[1]+17,'#814239',2)}}
 }
 if(o.held)o.held(hands[0],hands[1]);
 for(const p of hands)oval(...p,9.5,9.5,ink,null);
 g.save();g.translate(0,-440);head(t,o);g.restore();g.restore();g.restore();
 const world=p=>{const a=o.lean||0,c=Math.cos(a),sn=Math.sin(a);return[x+s*(p[0]*c-p[1]*sn),y+s*(p[0]*sn+p[1]*c+breath)]};
 poseFrames.push({id,x,y,s,hands:hands.map(world),elbows:elbows.map(world),feet:feet.map(p=>[x+p[0]*s,y+p[1]*s])});
}
function worldHand(x,y,s,p,t,phase=0){const by=Math.sin(t*1.5+phase)*.55;return[(p[0]-x)/s,(p[1]-y)/s-by]}
function phoneBack(p){rect(p[0]-12,p[1]-35,28,64,'#3c4546',ink,3.5,4);rect(p[0]-7,p[1]-30,12,20,'#252c2d',ink,1,3);oval(p[0]-2,p[1]-25,2,2,'#8b9d9a',null);oval(p[0]-2,p[1]-16,2,2,'#7d8b85',null)}
function aidBox(x,y,s=1){g.save();g.translate(x,y);g.scale(s,s);rect(-53,12,106,80,'#d8d4bd',ink,4,5);path([[-17,12],[-17,-3],[17,-3],[17,12]],null,ink,4,false);line(-18,50,18,50,'#974d40',10);line(0,32,0,68,'#974d40',10);line(-48,31,48,31,'#9e9d82',2);g.restore()}
function floor(y,col='#8e8875'){rect(-500,y,W+1000,650,col,null);softLine(-500,y,2400,y,ink,3.5,45);for(let i=-2;i<10;i++){const x=190+i*260;softLine(x,y,960+(x-960)*2.3,1400,'#4b4c4233',1.4,i)}for(let i=0;i<5;i++){const Y=y+38+i*i*23;softLine(-300,Y,2300,Y+3,'#504c3c1a',1.1,i+10)}}
function wall(col='#aaa18a'){g.fillStyle=col;g.fillRect(-500,-500,3000,1800);for(let y=55;y<960;y+=86){softLine(-200,y,2150,y+2,'#4a4b412f',1.6,y);for(let x=(y/86%2)*160;x<2000;x+=320)softLine(x,y,x+2,y+83,'#5c594e20',1.2,x+y)}hatch(0,0,W,900,95,'#524e3820',17)}
function lamp(x,y){line(x,-40,x,y-30,ink,3);path([[x-39,y],[x-16,y-30],[x+18,y-30],[x+44,y]],'#646756',ink,3.5);oval(x+3,y+3,13,4,'#e8ce8e',null);const light=g.createRadialGradient(x,y,20,x,y+200,570);light.addColorStop(0,'#edcc8050');light.addColorStop(.65,'#dfb9680d');light.addColorStop(1,'#f3dc8800');g.fillStyle=light;g.fillRect(x-600,y-50,1200,1100)}
function outside(t){g.save();g.beginPath();g.rect(190,200,1018,638);g.clip();rect(190,200,1018,638,'#707a85',null);const sky=g.createLinearGradient(0,200,0,850);sky.addColorStop(0,'#4f5c70');sky.addColorStop(1,'#a9a18c');g.fillStyle=sky;g.fillRect(190,200,1018,638);
 for(let i=0;i<7;i++){const x=150+i*184,h=150+i%3*36;rect(x,575-h,160,h,'#5b6266',ink,2);for(let j=0;j<2;j++)for(let k=0;k<3;k++)rect(x+22+k*42,460-h+j*68,17,28,j%2?'#d4bb7580':'#9aabac55',null)}
 if(t>=6.25&&t<8.7){const x=315+(t-6.25)*650;actor('runner',x,822,.51,t,{col:'#74877a',skin:'#9aab94',infected:true,walk:1,gait:(x-315)/(.51*(60/.62)),dir:1,lean:.06,hands:[[-46,-255],[70,-284]],head:.08,still:true})}
 for(let i=0;i<13;i++){const x=188+i*81;path([[x,705],[x+37,690],[x+74,705],[x+74,841],[x,841]],'#8f927c',ink,2.8);softLine(x+15,716,x+15,836,'#596c6160',1,i)}line(194,769,1205,769,'#5d706b',8);
 g.fillStyle='#a6bec714';g.fillRect(190,200,1018,638);for(let i=0;i<7;i++)softLine(210+i*150,235,265+i*150,633,'#eff1d00d',3,i);g.restore();
}
function shutter(q){const yy=190,hh=648*q;g.save();g.beginPath();g.rect(180,183,1035,664);g.clip();rect(180,yy,1035,hh,'#90958e',null);for(let y=yy+11;y<yy+hh-3;y+=24){softLine(185,y,1211,y-2,'#414d497d',2.0,y);softLine(190,y+4,1210,y+3,'#dddcc53b',1.1,y+11)}hatch(185,190,1024,hh,90,'#444b3c20',11);g.restore();line(180,yy+hh,1215,yy+hh,'#424e48',10);line(185,yy+hh-4,1210,yy+hh-4,'#c5c8b6',3)}
function chain(q){line(1234,183,1245,885,'#3b4d48',2);line(1264,183,1260,885,'#3b4d48',2);g.beginPath();g.ellipse(1252,882,13,16,0,0,Math.PI);g.strokeStyle='#3b4d48';g.lineWidth=2;g.stroke();const offset=58*qAt(T,0,3.31)+58*qAt(T,B.close,2.95);for(let side=0;side<2;side++)for(let y=200+(((side?offset:-offset)%14)+14)%14;y<884;y+=14)oval(side?1264-(y-200)*.006:1240+(y-200)*.007,y,2.6,3.2,'#a9b6a9',ink,1.2)}

function homeSet(t,q){wall('#aaa48f');floor(948,'#92917d');outside(t);shutter(q);rect(166,171,1067,681,null,'#384844',8);rect(161,150,1077,39,'#626f63',ink,4,4);line(161,160,1237,160,'#c5c7ad',3);chain(q);
 rect(1701,350,166,595,'#969d88',ink,4,4);line(1704,607,1866,607,ink,3);line(1720,464,1720,553,ink,4);line(1720,656,1720,733,ink,4);rect(1739,393,99,111,'#d5d1b4',ink,1.5);label('NO',1788,430,26,'#5b5c4e','center');label('VISITORS',1788,461,21,'#5b5c4e','center');
 for(let i=0;i<2;i++){rect(1408,670+i*135,249,20,'#6f6850',ink,3);line(1420,690+i*135,1420,938,ink,3);line(1645,690+i*135,1645,938,ink,3)}
 for(let i=0;i<3;i++){rect(1434+i*69,574,42,94,'#899d92',ink,3,5);rect(1445+i*69,564,21,13,'#b3b7a0',ink,2,2);rect(1438+i*69,605,34,31,'#c6c4a4',ink,1);label('H₂O',1455+i*69,626,16,'#4a655e','center')}
 for(let i=0;i<2;i++){rect(1450+i*95,739,61,64,'#a29a74',ink,3);oval(1480+i*95,740,30,5,'#cac0a2',ink,2);label(i?'FILTERS':'FOOD',1480+i*95,781,15,'#4c5c4a','center')}
 lamp(1530,202);line(1550,282,1663,308,'#6a6b5550',1);path([[231,942],[925,942],[750,1080],[64,1080]],'#182d3220',null);
}
function heroPose(t,q){
 const x=1340,y=955,s=1.05,rest=REST.map(p=>p.slice());let R=[69,-315],pull=t<B.close?qAt(t,0,3.31):qAt(t,B.close,2.95),point=[1260,lerp(650,708,pull)];if(t>=8.2&&t<B.close){const r=qAt(t,8.2,B.close-8.2);point=[1260+24*Math.sin(Math.PI*r),lerp(708,650,r)];}let L=worldHand(x,y,s,point,t,.3);
 if(t>=B.call){R=mix([69,-315],[62,-430],qAt(t,B.call,.75));const release=qAt(t,B.call,.75);L=mix(worldHand(x,y,s,[1260,708],t,.3),REST[0],release)}
 const alarm=t>=B.shadow&&t<B.call;actor('hero',x,y,s,t,{hat:true,col:'#b46b3c',trim:'#3e5c58',hands:[L,R],look:alarm?[-9,1]:t<B.call?[6,7]:[1,2],worry:t>=6.3,surprise:alarm&&t<8,talk:t>=B.hero&&t<B.lock?.35+.3*Math.sin(t*15):0,phase:.3,held:(l,r)=>phoneBack(r)});
}
function heroScene(t){let q=t<B.shadow?lerp(.43,.55,qAt(t,0,3.31)):t<B.close?.55:lerp(.55,1,qAt(t,B.close,2.95));
 let z,cx,cy;
 if(t<3.31){z=2.36+.075*t/3.31;cx=1100;cy=493;}
 else if(t<B.close){z=1.16+.025*phase(t,B.shadow,B.close-B.shadow);cx=1050;cy=580;}
 else if(t<B.call){z=1.80+.10*phase(t,B.close,B.call-B.close);cx=960;cy=583;}
 else{z=1.82+.05*phase(t,B.call,5);cx=1265;cy=600;}

 cam(cx,cy,z,()=>{homeSet(t,q);heroPose(t,q);g.save();g.filter='blur(1px)';path([[-80,1036],[463,1000],[523,1120],[-100,1150]],'#405448',ink,5);g.restore()});
}
function phoneInsert(t){cam(1080,590,1.10,()=>homeSet(t,.55));g.fillStyle='#242b223d';g.fillRect(0,0,W,H);g.save();g.translate(970,526);g.rotate(-.035);const sc=1+.024*qAt(t,3.31,2.8);g.scale(sc,sc);
 softLine(199,196,279,389,ink,40,15);softLine(279,389,354,672,ink,40,16);oval(196,190,43,48,ink,null);
 rect(-196,-288,392,640,'#354345',ink,8,23);rect(-177,-246,354,552,'#d6d8c3',ink,4,11);rect(-53,-272,106,9,'#14292b',null,4);oval(0,328,11,11,'#5e6f6c',ink,2);
 rect(-177,-246,354,63,'#678680',null,0,9);label('SISTER',-149,-204,29,'#efecd9');
 const rise=10*(1-qAt(t,3.31,.35));g.save();g.translate(0,rise);rect(-155,-150,305,212,'#eeeed8','#8f9d89',2,13);label('Did you tell Mom',-137,-103,32);label('not to let',-137,-60,32);label('anyone in?',-137,-17,32);label('now',132,43,19,'#7b8c7a','right');g.restore();
 rect(-151,242,304,42,'#ebead9','#aeb9a2',1,10);label('Message...',-132,269,21,'#889b8c');oval(177,198,17,24,ink,null);g.restore();}
function bedroomSet(){wall('#93918a');rect(-500,603,2900,340,'#6c8178',null);floor(942,'#737c72');
 rect(154,386,344,553,'#716d5e',ink,5,3);rect(172,404,309,517,'#8a8270',ink,3);line(183,648,345,648,'#b7bcaa',9);rect(246,627,104,34,'#465e5b',ink,3,3);rect(270,632,77,25,'#bcc2a9',ink,2,3);oval(439,705,8,10,'#b6ad82',ink,3);
 rect(939,681,788,157,'#695f6d',ink,4,9);rect(955,638,758,100,'#b6afa0',ink,4,14);rect(1448,652,220,57,'#d7cfb5',ink,3,13);path([[950,664],[1359,665],[1382,796],[951,796]],'#638884',ink,3);for(const x of [976,1685])line(x,838,x,943,'#4b4b42',11);
 rect(1275,160,433,359,'#3a4f64',ink,5);for(const x of [1289,1490,1693])line(x,168,x,510,'#9caa9b',8);line(1285,338,1695,338,'#9caa9b',8);line(1696,166,1696,508,'#5b7069',3);path([[1306,334],[1335,306],[1371,319],[1384,302]],null,'#8d9d9080',1.6,false);
 rect(625,205,378,237,'#c2bea0',ink,3,2);label('CO-OP NIGHT',811,253,35,'#475e59','center');for(let i=0;i<4;i++)softLine(668,296+i*25,939-i*31,296+i*25,'#738d8060',2,i);
 lamp(786,130);hatch(110,394,370,540,30,'#2a3e3d25',9);}
function sisterScene(t){const close=t<B.lock,p=(t-B.girl)/(B.flash-B.girl),z=close?1.63+.025*clamp(p):1.13+.04*phase(t,B.lock,B.flash-B.lock),cx=close?1020:900;cam(cx,close?650:590,z,()=>{bedroomSet();actor('sister',1148,942,.82,t,{col:'#b99b4d',trim:'#5b654c',hair:'#5a4538',female:true,mask:true,hands:[[-62,-430],REST[1]],phase:1.6,worry:true,look:[-5,1],held:(L,R)=>{rect(L[0]-16,L[1]-35,28,64,'#354345',ink,3.5,4);oval(L[0]-10,L[1]-26,2,2,'#86988f',null)}})});}
function hallSet(){wall('#b1a38b');rect(-500,675,3000,260,'#7c8573',null);floor(935,'#928675');rect(246,381,309,553,'#394d58',ink,5);rect(266,400,270,533,'#4b6265',null);rect(1297,620,451,313,'#7b745b',ink,4,4);rect(1310,632,426,96,'#a39a7a',ink,3);for(let i=0;i<2;i++){rect(1320+i*206,749,190,163,'#8d8669',ink,3);oval(1488+i*206,823,4,4,'#3d5147',null)}
 rect(700,829,124,19,'#857853',ink,3);line(716,847,703,934,ink,7);line(807,847,820,934,ink,7);
 rect(984,265,362,218,'#a4ad94',ink,3);label('FAMILY NOTES',1165,306,30,'#3f5e56','center');softLine(1017,343,1296,343,'#4e6a6055',2,3);label('Return the water containers',1014,380,23,'#546b5e');label('Call before you visit',1014,417,23,'#546b5e');
 line(1690,366,1793,366,ink,5);for(const x of [1720,1761]){oval(x,375,5,5,'#b2b6a0',ink,1);path([[x-15,394],[x+10,391],[x+25,505],[x-30,503]],'#777c71',ink,2)}lamp(1020,169);
}
function door(q){const w=300*Math.cos(q*1.31);path([[250,385],[250+w,385+q*20],[250+w,935],[250,935]],'#9b8b6c',ink,5);rect(268,409,Math.max(10,w-37),143,'#69776c',ink,3);const handle=[250+270*Math.cos(q*1.31),687+q*8];oval(...handle,7,7,'#c5b58b',ink,3);return handle;}
function hallActorStates(t){const start=B.flash,elapsed=t-start,q=qAt(t,start,1.2),hx=lerp(350,960,qAt(t,start+.7,3.55));
 actor('harris',hx,935,.9,t,{col:'#8c896e',skin:'#c4c6b2',hair:'#646353',worry:true,surprise:elapsed<2,sleeve:true,blood:true,walk:elapsed>.7&&elapsed<4.25?1:0,gait:(hx-350)/(.9*(60/.62)),limp:true,look:[4,2],hands:[[-73,-248],[-55,-245]],phase:2.5});
 const handle=door(q),mx=lerp(630,740,qAt(t,start+.45,1.25)),release=start+.33;
 let L;if(t<release)L=worldHand(mx,965,.92,handle,t,.8);else{const handle0=[250+270*Math.cos(qAt(release,start,1.2)*1.31),687+qAt(release,start,1.2)*8],x0=lerp(630,740,qAt(release,start+.45,1.25)),A=worldHand(x0,965,.92,handle0,release,.8);L=mix(A,REST[0],qAt(t,release,.75))}
 actor('mother',mx,965,.92,t,{col:'#936a72',trim:'#635462',hair:'#544237',female:true,look:[5,1],worry:true,phase:.8,hands:[L,REST[1]],walk:t>start+.45&&t<start+1.7?1:0,gait:(mx-630)/(.92*(60/.62))});
 actor('father',1480,930,.88,t,{col:'#557281',hair:'#96998b',look:[-5,1],worry:true,phase:3.3});aidBox(760,744,.92);}
function flashback(t){
 if(t<B.wound){cam(951,608,1.055+.028*qAt(t,B.flash,4.65),()=>{hallSet();hallActorStates(t)});return;}
 if(t<B.aid){const z=4.15+.23*qAt(t,B.wound,4);cam(891,697,z,()=>{hallSet();actor('harris',960,935,.9,t,{col:'#8c896e',skin:'#c4c6b2',hair:'#646353',sleeve:true,blood:true,hands:[[-73,-248],[-55,-245]],worry:true,look:[2,3],phase:2.5});});return;}
 const u=t-B.aid,reach=qAt(t,B.aid,.28),lift=qAt(t,B.aid+.28,.55),mx=740+55*qAt(t,B.aid+.6,.9),R=mix(REST[1],[22,-240-35*lift],reach);
 cam(1030,615,1.26+.045*qAt(t,B.aid,1.5),()=>{hallSet();actor('harris',960,935,.9,t,{col:'#8c896e',skin:'#c4c6b2',hair:'#646353',sleeve:true,blood:true,hands:[[-73,-248],[-55,-245]],worry:true,phase:2.5});actor('father',1480,930,.88,t,{col:'#557281',hair:'#96998b',look:[-5,0],phase:3.3,worry:true});if(reach<.99)aidBox(760,744,.92);actor('mother',mx,965,.92,t,{col:'#936a72',trim:'#635462',hair:'#544237',female:true,worry:true,look:[5,2],phase:.8,hands:[REST[0],R],walk:u>.6?1:0,gait:(mx-740)/(.92*(60/.62)),held:reach>=.99?(L,R)=>aidBox(R[0],R[1],1):null});});
}
function hud(t){g.save();g.translate(41,37);g.rotate(-.018);rect(0,0,513,115,'#f1efdc',ink,4.5,5);rect(0,0,513,23,'#e7cd55',ink,3,4);label('FIVE DAYS · AFTER THE WARNING',15,18,17,ink,'left','DejaVu Sans',true);label('DAY 1',17,94,64);rect(228,33,187,66,null,'#9d3e35',3.5,6);label(t>=B.flash?'8:12 PM':'9:12 PM',322,78,31,'#a3453d','center','DejaVu Sans',true);
 rect(443,41,17,47,'#e9efdf',ink,2.5,9);rect(447,52,9,38,'#6f9ba8',null,0,5);oval(451,92,12,12,'#72a0b5',ink,2.5);label('16°',482,82,26,'#425e77','center','DejaVu Sans',true);g.restore();}
function subtitle(t){let lo=0,hi=WORDS.length-1,i=-1;while(lo<=hi){let m=(lo+hi)>>1;if(WORDS[m].start<=t){i=m;lo=m+1}else hi=m-1}if(i<0)return;const w=WORDS[i],next=WORDS[i+1]?.start??30;if(t>Math.min(next,w.end+.24))return;const u=t-w.start,sc=lerp(.94,1,qAt(t,w.start,.09)),text=w.text.replace(/[.,?!:;]+$/,'').toUpperCase();g.save();g.translate(960,923);g.scale(sc,sc);g.font='700 96px "Patrick Hand",sans-serif';g.textAlign='center';g.lineJoin='round';g.lineWidth=8;g.strokeStyle='#fffef4';g.shadowColor='#fffef4';g.shadowBlur=21;g.strokeText(text,0,0);g.strokeText(text,0,0);g.shadowBlur=0;g.fillStyle='#111713';g.fillText(text,0,0);g.restore();}
function render(t){T=clamp(t,0,30-1/24000);poseFrames=[];g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,W,H);g.lineCap='round';g.lineJoin='round';if(T>=B.flash)flashback(T);else if(T>=B.girl&&T<B.hero||T>=B.lock)sisterScene(T);else if(T>=3.31&&T<B.shadow)phoneInsert(T);else heroScene(T);finish();hud(T);subtitle(T);audit.frames++;return poseFrames;}
window.render=render;
