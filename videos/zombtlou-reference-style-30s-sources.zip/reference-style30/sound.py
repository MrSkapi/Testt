from pathlib import Path
import subprocess,json,sys,numpy as np
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P/'audio'))
from sfx import make
from dsp import SR,place,write_wav
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(P/'narration.mp3'),'-t','30','-ar','48000','-ac','2','-f','f32le','-'])
voice=np.frombuffer(raw,dtype=np.float32).reshape(-1,2).copy();assert len(voice)==30*48000
fx=np.zeros_like(voice);cues=[]
def add(t,name,gain,dur,pitch=1):
 cues.append(dict(at=t,name=name,gainDb=gain,duration=dur,pitch=pitch));place(fx,make(name,dur=dur,pitch=pitch,seed=240+len(cues)),round(t*SR),10**(gain/20))
add(3.30,'phonebuzz',-32,.36);add(3.45,'tick',-36,.08)
add(.55,'swish',-40,.46);add(9.05,'swish',-36,.65);add(11.70,'tick',-31,.13,.7)
add(20.03,'tick',-33,.09,.7);add(20.35,'swish',-39,.6)
for t in [21.3,21.84,22.37,22.91,23.44,23.97]:add(t,'footstep',-38,.14)
add(29.04,'tick',-36,.1,.7)
mix=voice+fx;assert np.abs(mix).max()<.99
write_wav(str(P/'mix.wav'),mix)
(P/'audio-check.json').write_text(json.dumps(dict(duration=30,samples=len(voice),voiceGain=1,timeStretch=1,music=False,peak=float(np.abs(mix).max())),indent=2));(P/'sound-cues.json').write_text(json.dumps(cues,indent=2))
subprocess.run(['ffmpeg','-y','-v','error','-i',str(P/'mix.wav'),'-c:a','aac','-b:a','192k',str(P/'mix.m4a')],check=True)
print('Original first 30 seconds, unity voice gain; sparse Foley, no music.')
