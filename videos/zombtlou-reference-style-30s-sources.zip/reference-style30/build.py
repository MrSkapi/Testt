from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent
js='const WORDS='+json.dumps(json.loads((P/'words.json').read_text()))+';\n'+(P/'scene.js').read_text()
player='''
const audio=document.getElementById('voice'),seek=document.getElementById('seek'),clock=document.getElementById('clock');
document.getElementById('play').onclick=()=>audio.paused?audio.play():audio.pause();seek.oninput=()=>{audio.currentTime=+seek.value;render(+seek.value)};
const fixed=new URLSearchParams(location.search).get('t');function tick(){const t=Math.min(29.999,audio.currentTime);render(t);seek.value=t;clock.textContent=t.toFixed(1)+' / 30.0';requestAnimationFrame(tick)}
document.fonts.ready.then(()=>fixed!==null?render(+fixed||0):requestAnimationFrame(tick));
'''
html='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Five Days — reference style study</title><style>@font-face{font-family:'Patrick Hand';src:url('fonts/PatrickHand-Regular.ttf')}*{box-sizing:border-box}body{background:#242b29;color:#ede9d7;font:14px sans-serif;margin:0}main{max-width:1440px;margin:auto;padding:16px}canvas{display:block;width:100%;height:auto}footer{display:flex;gap:16px;align-items:center;padding:16px 0}input{flex:1}button{background:#a66b3b;color:white;border:0;padding:10px 24px}</style><main><canvas id="scene" width="1920" height="1080"></canvas><audio id="voice" src="mix.m4a" preload="metadata"></audio><footer><button id="play">Play / Pause</button><input id="seek" type="range" min="0" max="30" step="0.01" value="0"><span id="clock"></span></footer></main><script>'''+js+player+'</script></html>'
(P/'index.html').write_text(html);(P/'build-hash.txt').write_text(hashlib.sha256(js.encode()).hexdigest());print('Built 30 seconds,',len(json.loads((P/'words.json').read_text())),'timed words')
