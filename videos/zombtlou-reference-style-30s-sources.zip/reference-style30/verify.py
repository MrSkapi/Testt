from pathlib import Path
import subprocess,json,math,hashlib,zipfile,numpy as np
from PIL import Image,ImageDraw
P=Path(__file__).resolve().parent;V=P/'zombtlou-reference-style-30s.mp4';Q=P/'final-qc';Q.mkdir(exist_ok=True)
meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_type,width,height,r_frame_rate,nb_frames,duration:format=duration,size','-of','json',str(V)]))
v=next(s for s in meta['streams'] if s['codec_type']=='video');a=next(s for s in meta['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'],int(v['nb_frames']))==(1920,1080,'24/1',720)
assert abs(float(meta['format']['duration'])-30)<.03 and abs(float(a['duration'])-30)<.03
# Decode the complete movie while extracting native sample frames.
ts=[.5,2.2,4.4,6.9,10.2,12.9,14.5,18.2,20.7,23.2,25.8,29.5];ids=[round(t*24) for t in ts];sel='+'.join(f'eq(n\\,{f})' for f in ids)
subprocess.run(['ffmpeg','-y','-v','error','-i',str(V),'-vf','select='+sel,'-fps_mode','vfr',str(Q/'frame-%02d.png')],check=True)
files=sorted(Q.glob('frame-*.png'));assert len(files)==len(ts)
out=Image.new('RGB',(1920,3*294),'#252d29');draw=ImageDraw.Draw(out)
for i,(p,t) in enumerate(zip(files,ts)):
 im=Image.open(p).convert('RGB');arr=np.asarray(im);assert im.size==(1920,1080) and arr.std()>12
 x=i%4*480;y=i//4*294;out.paste(im.resize((480,270)),(x,y));draw.text((x+6,y+274),f'{t:.2f}s',fill='white')
out.save(P/'zombtlou-reference-style-30s-contact.jpg',quality=93)
seq={'chain':[8.18+i*.15 for i in range(8)],'call':[12.32+i*.11 for i in range(8)],'entry':[20.05+i*.32 for i in range(8)],'kit':[28.56+i*.18 for i in range(8)]}
for name,times in seq.items():
 out=Image.new('RGB',(1600,484),'#252d29');d=ImageDraw.Draw(out)
 for i,t in enumerate(times):
  f=Q/f'{name}-{i}.jpg';subprocess.run(['ffmpeg','-y','-v','error','-ss',str(t),'-i',str(V),'-frames:v','1','-vf','scale=400:225',str(f)],check=True)
  x=i%4*400;y=i//4*242;out.paste(Image.open(f),(x,y));d.text((x+5,y+228),f'{t:.2f}s',fill='white')
 out.save(Q/f'{name}-motion.jpg',quality=92)
def decode(p):return np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-t','30','-vn','-ar','16000','-ac','1','-f','f32le','-']),dtype=np.float32)
source=decode(P/'narration.mp3');actual=decode(V);checks=[]
for t in [2.1,4.4,9.1,14.4,18.1,21.6,26.4,29.2]:
 k=round(t*16000);n=3200;A=source[k:k+n];win=actual[k-80:k+n+80];lag=int(np.argmax(np.correlate(win,A,'valid')))-80;corr=float(np.corrcoef(A,actual[k+lag:k+lag+n])[0,1]);checks.append(dict(at=t,lagSamples=lag,correlation=corr))
assert all(abs(x['lagSamples'])<=1 for x in checks),checks
(Q/'audio-alignment.json').write_text(json.dumps(checks,indent=2));(P/'final-probe.json').write_text(json.dumps(meta,indent=2))
audit=json.loads((P/'render-audit.json').read_text());assert not audit['audit']['unreachable'];assert audit['audit']['maxBoneError']<1e-6
manifest=dict(duration=30,width=1920,height=1080,fps=24,frames=720,bytes=V.stat().st_size,sha256=hashlib.sha256(V.read_bytes()).hexdigest(),sourceHash=(P/'build-hash.txt').read_text().strip(),voiceGain=1,audioChecks=checks,renderAudit=audit)
(P/'manifest.json').write_text(json.dumps(manifest,indent=2));print('VERIFIED',V.stat().st_size,'bytes;',720,'native frames; audio lags',[x['lagSamples'] for x in checks],flush=True)
