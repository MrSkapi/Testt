# Buy Time v2 — brighter environments, visible action, no beanie

Complete 8-minute film at 1920x1080, 24fps. This revision preserves the prior film's exact narration and all 156 shot boundaries. The final MP4 remuxes the existing AAC track without re-encoding it.

User-requested revisions: no hero headwear; different brighter colour families for the locations; actual body/hand/prop actions rather than relying on a static picture or camera movement. See scenes/motion.js, cast.js, main.js and sets/. The shared head function never draws the old hat asset. Character clothes and silhouettes are otherwise retained.

Animation proof: build/opening-motion.mp4 (source distribution: validation/opening-motion.mp4). Short action sequences and all storyboard sheets were inspected before full rendering. Camera scale is always 1, with no zoom transitions. Slow lateral tracking is limited to authored action scenes and uses an absolute group clock.

Install: copy buy-time-v2/ to projects/buy-time-v2/ inside the installed 2d-video toolkit. Apply kit-overrides/ to its root to retain the renderer, current engine and vivid custom style. Install npm dependencies if necessary. local-runtime.mjs uses /usr/bin/chromium in this workspace; adjust that path for a different machine.

Render:

    node --import ./tools/local-runtime.mjs render-native.mjs --project projects/buy-time-v2 --workers 3 --gl auto --crf 23 --out projects/buy-time-v2/build/full-silent.mp4

Mux the original voice without retiming:

    ffmpeg -i projects/buy-time-v2/build/full-silent.mp4 -i projects/buy-time-v2/input/voiceover.mp3 -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -af apad -t 480 -movflags +faststart buy-time-complete-v2.mp4

The delivered v2 instead copies the v1 AAC audio packets directly; that original film is available separately in the repository. No subtitles, replacement speech, music or added SFX. Original recording length is 478.955102 seconds; the remainder is the final visual hold.

Final action QC widened the sprite drawing area for extended wrists and uses a two-bone arm solution for writing on the board. The teacher stands close enough to write without stretching the arm.
