import {layer,backdrop,blurLayer,seg,poly,circle,ring,alpha,text,FONTS,lerp} from '/engine/core.js';
import * as FX from '/engine/fx2d.js';
import {C,box,ellipse,shadow,clock,cup,plant,book,car} from './props.js';
export const GY=900;
export function dust(g,t){FX.dust(g,t,{count:17,color:C.gold,a:.10,size:1.2,speed:3});}
function floor(g,y=811,col='#827765'){box(g,-2000,y,6000,1800,col);for(let j=0;j<12;j++)seg(g,[[-2000,y+15+j*j*4],[4000,y+15+j*j*4]],1,'#d9c9a51a');}
export function clinic(g,t,c={},o={}){
 layer(g,c,.2,g=>{backdrop(g,['#5eabca','#d9f2f5']);box(g,173,102,570,529,'#427da7',8);box(g,192,121,530,489,'#d2f2fa',4);for(let j=0;j<4;j++)box(g,210+j*132,380-(j%3)*55,104,230,'#879e8b66');box(g,451,120,12,489,'#5b7767');box(g,192,370,529,12,'#5b7767');floor(g,812,'#c5dce2');});
 layer(g,c,.58,g=>{
  box(g,903,217,686,450,'#568db9',14);box(g,924,239,644,406,'#eff8f2',10);
  text(g,'RENEW',1246,316,{size:44,font:FONTS.ui,color:'#317eac',spacing:7});
  for(let j=0;j<3;j++){let x=1048+j*197;circle(g,x,470,44,'#7cc8e2');seg(g,[[x-17,470],[x+17,470]],6,'#dbe1c4');seg(g,[[x,453],[x,487]],6,'#dbe1c4');}
  box(g,834,699,858,32,'#dfb886',7);box(g,855,731,819,129,'#579ac2',8);plant(g,1768,845,1.4);
  if(o.waiting){for(let j=0;j<4;j++){let x=337+j*329;box(g,x-93,745,186,33,'#58776a',8);box(g,x-84,633,168,104,'#78957e',13);for(let dx of[-69,69])box(g,x+dx,778,12,71,'#425e53');}}
 });dust(g,t);
}
export function treatment(g,t,c={}){
 layer(g,c,.2,g=>{backdrop(g,['#67a5c3','#d6f2f1']);floor(g,809,'#bddadd');for(let j=0;j<5;j++){box(g,106+j*374,145,290,408,'#4b8fb3',10);box(g,119+j*374,159,264,379,'#e2f4f2',7);}});
 layer(g,c,.65,g=>{
  box(g,669,694,636,192,'#6c95c8',30);box(g,708,626,561,93,'#c7cbb0',29);box(g,707,618,161,65,'#e3dcc1',20);
  for(let xx of[719,1212])box(g,xx,863,27,82,'#476456',5);
  box(g,1367,467,265,298,'#526f60',18);box(g,1387,486,226,133,'#284c45',9);for(let j=0;j<3;j++)seg(g,[[1410,522+j*28],[1587-j*21,522+j*28]],3,'#b1d0ae');
  seg(g,[[1369,659],[1275,659],[1241,709]],14,'#72c6df');
 });dust(g,t);
}
export function stairs(g,t,c={}){
 layer(g,c,.2,g=>{backdrop(g,['#9a94b5','#e1d8ed']);box(g,138,92,419,559,'#455d57');box(g,157,110,382,520,'#b9dfe9');box(g,347,109,10,520,'#607a69');});
 layer(g,c,.55,g=>{
  floor(g,920,'#b2917c');for(let j=0;j<8;j++){let x=469+j*157,y=907-j*57;box(g,x,y,1700,800,'#bcabb7');box(g,x,y,1700,15,'#f1dcc3');seg(g,[[x+11,y+40],[2100,y+40]],1,'#635f5333');}
  seg(g,[[498,615],[1744,163]],13,'#4b6158');for(let j=0;j<8;j++){let x=514+j*168,y=611-j*61;seg(g,[[x,y],[x,y+284]],7,'#5e7362');}
 });dust(g,t);
}
export function classroom(g,t,c={},o={}){
 layer(g,c,.2,g=>{backdrop(g,['#a38bc0','#f0dfb0']);box(g,214,124,403,489,'#596896',6);box(g,232,142,368,453,'#c5e8ee');box(g,414,142,11,453,'#6a826b');floor(g,786,'#c5a27c');});
 layer(g,c,.58,g=>{
  box(g,781,150,918,441,'#64538d',10);text(g,'LEARNING CENTRE',1240,249,{size:37,font:FONTS.ui,color:'#f5e8c5',spacing:2});
  for(let j=0;j<3;j++)seg(g,[[883,351+j*67],[1546-j*75,351+j*67]],3,'#a9bc9366');
  for(let j=0;j<4;j++){let x=181+j*465;box(g,x,776,291,26,'#d5a95f',7);for(let d of[22,254])box(g,x+d,799,14,157,'#665d45');book(g,x+73,766,87,15,C.paper);}
 });dust(g,t);
}
export function office(g,t,c={},o={}){
 layer(g,c,.25,g=>{backdrop(g,o.night?['#424875','#8f85ab']:['#597aad','#c5dded']);floor(g,791,'#9b99b1');for(let j=0;j<3;j++){let x=116+j*590;box(g,x,107,459,504,'#456894',8);box(g,x+17,122,425,471,o.night?'#6e79ad':'#d0e9fb');for(let k=0;k<5;k++)box(g,x+28+k*84,371-k*21,69,222,'#577ab699');box(g,x+224,120,12,474,'#4e69a1');}});
 layer(g,c,.66,g=>{
  box(g,739,650,986,38,'#9e8159',8);box(g,766,688,935,127,'#667eac',6);for(let x of[777,1654])box(g,x,794,22,148,'#4f5546');
  box(g,1033,447,257,179,'#2d4640',11);box(g,1048,460,227,148,'#789c85',5);seg(g,[[1038,630],[1294,630]],12,'#505d4b');
  box(g,1374,591,150,52,'#b7aa86',5);clock(g,1678,227,66,o.night?'22:40':'09:00',true);plant(g,1857,840,1.25);
 });dust(g,t);
}
export function waiting(g,t,c={}){clinic(g,t,c,{waiting:true});layer(g,c,.74,g=>{box(g,1557,365,202,134,'#427fba',11);text(g,'PLEASE WAIT',1658,425,{size:24,font:FONTS.ui,color:C.cream});});}
export function beach(g,t,c={},o={}){
 layer(g,c,.12,g=>{backdrop(g,['#da9da9','#f4bc96','#ffe4ad']);FX.sun(g,1242,295,49,'#f1d6a4',C.gold,4);});
 layer(g,c,.38,g=>{box(g,-1500,548,5100,498,'#32aebb');for(let j=0;j<14;j++){let y=570+j*22,x=-600+((t*11+j*79)%300);seg(g,[[x,y],[x+2600,y]],j%3===0?3:1,'#d2c4a64c');}poly(g,[[-1500,873],[460,745],[1166,774],[2600,667],[2800,1600],[-1600,1600]],'#edc57f');});
 layer(g,c,.7,g=>{if(o.hotel){box(g,1337,146,900,417,'#e4b389');box(g,1354,166,842,303,'#6761a7');for(let j=0;j<5;j++){box(g,1380+j*176,187,14,282,'#d1bda0');circle(g,1458+j*176,213,9,'#edce94');}box(g,1314,469,970,32,'#dcc7a2');for(let j=0;j<12;j++)box(g,1329+j*81,503,8,143,'#8d9a80');seg(g,[[1314,499],[2280,499]],9,'#b8bca0');}
  ellipse(g,628,976,214,24,'#a9846544');
 });dust(g,t);
}
export function yacht(g,t,c={}){
 layer(g,c,.1,g=>backdrop(g,['#579fc7','#d4eff6']));layer(g,c,.32,g=>{box(g,-2000,555,6000,900,'#2eaccc');for(let j=0;j<15;j++)seg(g,[[-1600+(j%3)*40,593+j*28],[2800,593+j*28]],2,'#c6d0b233');});
 layer(g,c,.65,g=>{g.save();g.translate(-Math.max(0,Math.min(t-240.8,4))*24,0);poly(g,[[289,667],[1676,667],[1550,839],[543,839]],'#fff0cf');box(g,608,408,760,258,'#e8edf2',17);box(g,679,303,562,109,'#f7efd8',13);for(let j=0;j<5;j++)box(g,647+j*140,469,108,91,'#427bb0',7);box(g,563,643,872,33,'#eee0c0',6);seg(g,[[1036,310],[1036,129]],7,'#879f8a');poly(g,[[1041,135],[1150,165],[1041,190]],'#bb7960');g.restore();});dust(g,t);
}
export function terrace(g,t,c={}){
 beach(g,t,c,{hotel:false});layer(g,c,.5,g=>{box(g,-2000,726,6000,1300,'#cf9c75');seg(g,[[-1500,622],[3300,622]],12,'#efdcad');for(let x=-500;x<2400;x+=147)seg(g,[[x,623],[x,797]],7,'#659bb2');
 for(let j=0;j<9;j++){let x=246+j*180;seg(g,[[x,-100],[x,139+(j%2)*26]],2,'#6d7460');circle(g,x,147+(j%2)*26,12,'#e3c58e');}
 });dust(g,t);
}
export function busStop(g,t,c={}){beach(g,t,c,{hotel:true});layer(g,c,.71,g=>{
 box(g,119,240,660,29,'#6c70ae',5);box(g,150,269,17,588,'#6f78ab');box(g,726,269,17,588,'#6f78ab');box(g,172,280,552,389,'#82b9d666');box(g,244,743,434,25,'#6c78a5',6);for(let x of[280,628])box(g,x,766,13,101,'#4c6151');
 box(g,199,318,150,85,'#4d82b5',7);text(g,'BUS',274,360,{size:35,font:FONTS.ui,color:C.cream});
 });}
