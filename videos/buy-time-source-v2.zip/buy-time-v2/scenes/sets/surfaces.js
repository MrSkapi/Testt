import {blurLayer,seg,poly,circle,backdrop} from '/engine/core.js';
import {C,box,ellipse,shadow,book,cup,plant,laptop} from './props.js';
import * as W from './world.js';
import * as L from './places.js';
// Information belongs to physical objects in distinct locations, not a void.
export function surface(g,t,kind='screen'){
 const paper=['paper','book','calendar','brochure'].includes(kind);
 if(kind==='billboard'){
  blurLayer(g,5,g=>W.street(g,t,{}, {clean:true}));
  for(let x of[352,1557])box(g,x,856,22,310,'#537365',5);
  shadow(g,960,997,718,29);box(g,137,109,1646,800,'#c7995b',15);box(g,159,131,1602,756,'#3f5592',10);
  for(let x of[277,960,1644]){seg(g,[[x,111],[x,77]],6,'#4d6556');ellipse(g,x,79,49,12,'#c8b78b');}
  return false;
 }
 if(kind==='clinic'){
  blurLayer(g,7,g=>L.treatment(g,t,{}));
  box(g,119,111,1682,829,'#bac4a7',27);box(g,144,137,1632,777,'#245f88',19);
  for(let j=0;j<4;j++)circle(g,1717,972+j*5,5,'#7c9b78');
  return false;
 }
 if(kind==='cork'){
  blurLayer(g,8,g=>W.apartment(g,t,{}, {kind:'kitchen'}));
  box(g,161,96,1598,846,'#b18a58',14);box(g,183,118,1554,802,'#b67a53',8);
  for(let j=0;j<240;j++)circle(g,197+(j*109%1520),136+(j*173%764),j%3?1:2,'#d1a56b28');
  for(let x of[215,1704])for(let y of[152,885])circle(g,x,y,7,'#d7c7a0');
  return false;
 }
 if(kind==='book'){
  blurLayer(g,8,g=>W.apartment(g,t,{},{}));box(g,-300,94,2500,1300,'#916b47');
  for(let j=0;j<22;j++)seg(g,[[-200,126+j*48],[2200,129+j*48]],1,'#d9ac6b25');
  box(g,172,91,1584,895,'#76589c',15);box(g,192,109,1544,857,'#d7b7e0',9);
  poly(g,[[210,125],[920,122],[960,151],[960,943],[920,922],[210,939]],'#fff1d0');
  poly(g,[[960,151],[1001,125],[1715,125],[1715,940],[1001,922],[960,943]],'#fbe5bb');
  seg(g,[[960,153],[960,934]],3,'#a89b7755');
  // Real objects stay at the edges, leaving the explanation unobstructed.
  cup(g,91,858,.9);seg(g,[[1790,898],[1810,270]],12,'#3d655b');seg(g,[[1810,270],[1812,246]],4,'#c6a366');
  return true;
 }
 if(kind==='calendar'){
  blurLayer(g,6,g=>W.apartment(g,t,{}, {kind:'kitchen'}));
  box(g,194,119,1532,840,'#d5c397',11);box(g,218,143,1484,785,'#f0e0b8',5);
  box(g,218,143,1484,72,'#e58b61',4);for(let j=0;j<11;j++)ringBinding(g,359+j*123,148);
  for(let x of[269,1652])circle(g,x,173,7,'#4c7761');
  return true;
 }
 if(kind==='paper'||kind==='brochure'){
  blurLayer(g,7,g=>kind==='brochure'?L.clinic(g,t,{}):W.apartment(g,t,{},{}));
  box(g,-200,936,2400,400,'#9e7248');
  book(g,41,464,117,373,'#57917a');book(g,55,407,99,56,'#e58b61');
  box(g,191,102,1540,853,'#b99f74',9);box(g,207,113,1510,827,'#fff0d4',5);
  // Layered sheet corners, notebook, pen, and cup anchor the board in a desk.
  poly(g,[[1687,113],[1717,113],[1717,143]],'#c4b08a');
  seg(g,[[1794,885],[1801,364]],11,'#4f7f67');cup(g,1823,841,.84);
  return true;
 }
 // A wide laptop screen at home/at work. Its keyboard and room are visible.
 blurLayer(g,8,g=>W.office(g,t,{},{}));box(g,-100,986,2200,400,'#9f754c');
 box(g,110,83,1700,904,'#344d46',26);box(g,133,107,1654,855,'#293f7d',16);
 circle(g,960,95,4,'#9fbd98');poly(g,[[111,987],[1809,987],[1907,1043],[13,1043]],'#6e8d7a');
 seg(g,[[105,1006],[1811,1006]],4,'#a1b497');return false;
}
function ringBinding(g,x,y){seg(g,[[x,y-29],[x-6,y+5],[x+9,y+20]],6,'#716b54');}
