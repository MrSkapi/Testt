import {ease,clamp,lerp} from '/engine/core.js';
import {POSES,posesAt,breathe} from '/engine/rig2d.js';
export const E=(t,a,b)=>ease.inOut(clamp((t-a)/(b-a)));
export function envelope(t,a=.2,b=.7,c=1.8,d=2.5){return E(t,a,b)*(1-E(t,c,d));}
export function armGesture(base,name,k){
 const targets={point:POSES.point,think:POSES.think,explain:POSES.explain,wave:POSES.wave,shrug:POSES.shrug,phone:POSES.phone};
 const target=targets[name]||POSES.stand,dy=base.sh[1]-target.sh[1],q={...base};
 for(const key of['eF','hF','eB','hB'])q[key]=[lerp(base[key][0],target[key][0],k),lerp(base[key][1],target[key][1]+dy,k)];
 return q;
}
export function acting(role,base,i,hasProp=false){
 if(!i||hasProp)return breathe(base,i?.globalT||0,.55,role==='hero'?1:3);
 const t=i.globalT-i.shot.start,v=i.view,m=i.mode;let gesture=null;
 if(role==='hero'){
  if(v==='momMenu'||v==='cafe')gesture=m==='awkward'?'shrug':'explain';
  else if(v==='clinic')gesture=m==='noGuard'?'think':'point';
  else if(v==='office')gesture='think';
  else if(v==='beach')gesture='point';
 }else if(role==='mom'){
  if(v==='momMenu')gesture=m==='close'?'shrug':'point';
  else if(v==='cafe')gesture='explain';
  else if(v==='clinic')gesture='wave';
  else if(v==='beach')gesture='think';
 }else{
  if(v==='office')gesture='explain';
  else if(v==='clinic')gesture='point';
  else if(v==='party'||v==='terrace')gesture='explain';
 }
 const d=i.dur,k=envelope(t,.2,Math.min(.8,d*.28),Math.max(.9,d*.65),Math.max(1.3,d-.08));
 let q=gesture?armGesture(base,gesture,k):base;
 q=breathe(q,i.globalT,.6,role==='hero'?1:role==='mom'?3:5);
 if(gesture)q.head=[q.head[0]+k*2,q.head[1]+Math.sin(k*Math.PI)*1.5];
 return q;
}
function knee(hip,foot,L=57,dir=1){const dx=foot[0]-hip[0],dy=foot[1]-hip[1],d=Math.min(Math.hypot(dx,dy),L*2-.01),a=Math.atan2(dy,dx)-dir*Math.acos(clamp(d/(L*2)));return[hip[0]+Math.cos(a)*L,hip[1]+Math.sin(a)*L];}
export function stairStep(t,{start=2,speed=.9,steps=1,s=1.94}={}){
 const total=steps*speed,u=clamp(t/total),j=Math.min(steps-1,Math.floor(t/speed)),phase=clamp((t-j*speed)/speed);
 const X=k=>469+(start+k)*157+78,Y=k=>907-(start+k)*57;
 const advance=E(phase,.25,.94),x=lerp(X(j),X(j+1),advance),y=lerp(Y(j),Y(j+1),advance);
 const f=E(phase,.03,.48),b=E(phase,.49,.94);
 const fX=lerp(X(j)+18,X(j+1)+18,f),fY=lerp(Y(j),Y(j+1),f)-Math.sin(f*Math.PI)*37;
 const bX=lerp(X(j)-18,X(j+1)-18,b),bY=lerp(Y(j),Y(j+1),b)-Math.sin(b*Math.PI)*30;
 let p={...POSES.stand,hip:[0,-86],sh:[0,-160],head:[7,-194],fF:[(fX-x)/s,(fY-y)/s],fB:[(bX-x)/s,(bY-y)/s]};
 p.kF=knee(p.hip,p.fF);p.kB=knee(p.hip,p.fB);
 const handX=x+84,handY=615-(handX-498)*452/1246;
 p.eF=[18,-163];p.hF=[(handX-x)/s-13,(handY-y)/s];p.eB=[-10,-120];p.hB=[-14,-89];
 if(t>=total){const xx=X(steps),yy=Y(steps);p={...POSES.stand,eF:[18,-166],hF:[84/s-13,(615-(xx+84-498)*452/1246-yy)/s]};return{x:xx,y:yy,pose:p,feet:[[xx+3*s,yy],[xx-11*s,yy]]};}
 return{x,y,pose:p,feet:[[fX,fY],[bX,bY]],ground:[Y(j),Y(j+1)]};
}
