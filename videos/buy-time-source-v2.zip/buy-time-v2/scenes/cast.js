import {E,seg,circle,poly,alpha,shade,lerp,clamp} from '/engine/core.js';
import {POSES,walkPose,breathe,posesAt} from '/engine/rig2d.js';
import {C,box,ellipse,shadow} from './sets/props.js';
export {POSES,walkPose,breathe,posesAt};
export const HERO={color:'#ed9437',hat:false};
export const FRIEND={color:'#608fc8',hat:false};
export const WOMAN={color:'#ab6960',hat:false};
export const CLEANER={color:'#7c947e',hat:false};
export const FATHER={color:'#7c8099',hat:false};
export const CHILD={color:'#d2aa64',hat:false};
// One head-local attachment for wide shots, walking, sleeping and close-ups.
// A fitted knitted beanie: rounded crown and folded cuff, without a brim.
export const BEANIE={crown:'#499a9b',shade:'#347779',cuff:'#61aaa8',stitch:'#a5d4c7'};
export function hat(g,x,y,r){
 g.save();g.translate(x,y);g.scale(r,r);
 g.fillStyle=BEANIE.crown;g.beginPath();g.moveTo(-.98,-.63);
 g.bezierCurveTo(-1.07,-1.10,-.93,-1.66,-.25,-1.70);
 g.bezierCurveTo(.48,-1.78,1.08,-1.42,.99,-.64);
 g.quadraticCurveTo(0,-.44,-.98,-.63);g.fill();
 g.fillStyle=BEANIE.shade;g.beginPath();g.moveTo(-.98,-.63);
 g.bezierCurveTo(-1.07,-1.10,-.93,-1.66,-.25,-1.70);
 g.bezierCurveTo(-.70,-1.37,-.78,-.99,-.66,-.63);g.closePath();g.fill();
 // Restrained knit stitches, clipped inside the crown silhouette.
 g.save();g.beginPath();g.moveTo(-.93,-.91);g.bezierCurveTo(-1,-1.35,-.63,-1.68,-.25,-1.68);g.bezierCurveTo(.42,-1.75,1.02,-1.41,.94,-.91);g.closePath();g.clip();
 for(let row=0;row<7;row++)for(let k=-8;k<=8;k++){
  const xx=k*.13+(row%2)*.065,yy=-1.65+row*.12;
  seg(g,[[xx-.025,yy-.025],[xx,yy],[xx+.025,yy-.025]],.009,alpha(BEANIE.stitch,.36));
 }
 g.restore();
 g.fillStyle=BEANIE.cuff;g.beginPath();g.moveTo(-1.005,-.96);
 g.quadraticCurveTo(0,-.83,1.005,-.96);g.lineTo(1.005,-.62);
 g.quadraticCurveTo(0,-.43,-1.005,-.62);g.closePath();g.fill();
 for(let k=-10;k<=10;k++){const xx=k*.091;seg(g,[[xx,-.915+.055*(1-xx*xx)],[xx,-.60+.075*(1-xx*xx)]],.013,alpha(BEANIE.shade,.53));}
 seg(g,[[-.99,-.95],[-1,-.65],[-.82,-.61]],.018,alpha(C.cream,.6));
 // A small sewn label gives the cap a clear silhouette at full-body scale.
 box(g,.39,-.77,.25,.16,'#756756',.025);seg(g,[[.45,-.69],[.57,-.69]],.012,alpha(C.cream,.7));
 g.restore();
}
export function head(g,x,y,r,o={}){
 const f=o.facing??1;g.save();g.translate(x,y);g.scale(f,1);if(o.tilt)g.rotate(o.tilt);
 if(o.bun){circle(g,-r*.86,-r*.63,r*.32,o.old?'#a8a69a':'#302c32');}
 circle(g,0,0,r,C.ink);
 if(o.bun){g.beginPath();g.moveTo(-r*.97,-r*.20);g.bezierCurveTo(-r*1.04,-r*1.08,r*.64,-r*1.32,r*.95,-r*.29);g.lineTo(r*.77,-r*.55);g.quadraticCurveTo(-r*.10,-r*.92,-r*.97,-r*.20);g.fillStyle=o.old?'#a6a497':'#353038';g.fill();if(o.old)seg(g,[[r*.80,-r*.49],[r*.82,-r*.1]],r*.09,'#a6a497');}
 
 const tired=o.expr==='tired',sad=o.expr==='sad',happy=o.expr==='happy',shock=o.expr==='shock';
 const front=o.front??false,ex=front?0:r*.21,yy=-r*.08,l=o.look||[0,0];
 for(let i=0;i<2;i++){let xx=ex+(i?1:-1)*r*(front?.30:.26),sz=i||front?1:.83;if(o.blink){seg(g,[[xx-r*.10,yy],[xx+r*.10,yy]],r*.05,C.cream);}else if(happy){g.strokeStyle=C.cream;g.lineWidth=r*.06;g.beginPath();g.arc(xx,yy+r*.08,r*.13,Math.PI*1.1,Math.PI*1.9);g.stroke();}else{ellipse(g,xx,yy,r*.13*sz,r*(shock?.21:tired?.10:.17),C.cream);circle(g,xx+l[0]*r*.04,yy+l[1]*r*.04,r*.055,C.ink);}}
 if(shock)ellipse(g,ex+r*.03,r*.39,r*.07,r*.10,C.cream);else if(happy){g.strokeStyle=C.cream;g.lineWidth=r*.045;g.beginPath();g.arc(ex+r*.03,r*.24,r*.16,0,Math.PI);g.stroke();}else seg(g,[[ex-r*.07,r*.35],[ex+r*.09,r*(sad?.38:.35)]],r*.045,C.cream);
 if(sad||shock||tired){for(let i=0;i<2;i++){let xx=ex+(i?1:-1)*r*.28;seg(g,[[xx-r*.10,-r*.40+(i?-1:1)*r*.035],[xx+r*.10,-r*.41]],r*.04,alpha(C.cream,.7));}}
 if(o.beard){for(let i=0;i<19;i++){let xx=((i*37)%83-41)*r/100,yy=(.42+Math.abs(xx/r)*.24+(i%3)*.064)*r;seg(g,[[xx,yy],[xx+r*.013,yy+r*.026]],r*.014,'#8b8376');}}
 // No headwear in this revision, including close-ups and the CTA.
 g.restore();
}
function rawPerson(g,o={}){
 const p=o.pose||POSES.stand,f=o.facing??1,s=o.s??1,c=(o.cast||HERO),cc=c.color;
 if(o.shadow!==false){poly(g,[[o.x-17*s,o.y],[o.x+22*s,o.y+3*s],[o.x-99*s,o.y+39*s],[o.x-138*s,o.y+25*s]],'#090a1124');shadow(g,o.x,o.y+3,36*s,7*s);}
 g.save();g.translate(o.x,o.y);g.scale(f*s,s);if(o.rot)g.rotate(o.rot);if(o.alpha!=null)g.globalAlpha*=o.alpha;
 const sh=p.sh,hip=p.hip,farRoot=[sh[0]-12,sh[1]+2],nearRoot=[sh[0]+12,sh[1]+2];
 // The arms attach to separate shoulders. Neutral hands stay outside the tunic.
 let eb=[p.eB[0]-12,p.eB[1]],hb=[p.hB[0]-13,p.hB[1]],ef=[p.eF[0]+12,p.eF[1]],hf=[p.hF[0]+13,p.hF[1]];
 const leg=(k,foot,col)=>{seg(g,[hip,k,foot,[foot[0]+12,foot[1]]],12,col);seg(g,[[foot[0]-3,foot[1]+3],[foot[0]+13,foot[1]+3]],3,'#4c454244');};
 leg(p.kB,p.fB,'#302b31');
 const arm=(root,e,h,col)=>{seg(g,[root,e,h],12,C.ink);seg(g,[root,e,[lerp(e[0],h[0],.64),lerp(e[1],h[1],.64)]],17,col);circle(g,h[0],h[1],6.5,C.ink);};
 arm(farRoot,eb,hb,shade(cc,-.24));
 poly(g,[[sh[0]-17,sh[1]-4],[sh[0]+16,sh[1]-4],[hip[0]+16,hip[1]+9],[hip[0]-15,hip[1]+9]],cc);
 poly(g,[[sh[0]-17,sh[1]-3],[sh[0]-8,sh[1]+3],[hip[0]-7,hip[1]+8],[hip[0]-15,hip[1]+9]],shade(cc,-.15));
 seg(g,[[sh[0]+6,sh[1]+9],[hip[0]+7,hip[1]+3]],1.3,alpha(C.cream,.2));
 seg(g,[[hip[0]-12,hip[1]+5],[hip[0]+13,hip[1]+5]],4,shade(cc,-.24));
 if(c===HERO){ellipse(g,sh[0]-2,sh[1]-4,20,8,shade(cc,-.23),-.1);seg(g,[[sh[0]+1,sh[1]+4],[sh[0]+1,sh[1]+26]],1.9,C.cream);seg(g,[[sh[0]+8,sh[1]+4],[sh[0]+8,sh[1]+25]],1.9,C.cream);}
 leg(p.kF,p.fF,C.ink);arm(nearRoot,ef,hf,cc);

 head(g,p.head[0],p.head[1],27,{hat:c.hat,expr:o.expr,look:o.look,blink:o.blink,beard:o.beard,bun:o.bun,old:o.old});
 if(o.prop)o.prop(g,hf,hb);g.restore();
}
function rawCloseFace(g,x,y,r,o={}){
 const c=o.cast||HERO;ellipse(g,x,y+r*1.53,r*1.15,r*.57,c.color);
 if(c===HERO){ellipse(g,x,y+r*1.1,r*.65,r*.21,shade(c.color,-.25));seg(g,[[x-r*.1,y+r*1.1],[x-r*.12,y+r*1.57]],r*.023,C.cream);seg(g,[[x+r*.1,y+r*1.1],[x+r*.12,y+r*1.57]],r*.023,C.cream);}
 head(g,x,y,r,{...o,hat:c.hat,front:true});
}

export const MOM={color:'#ac7bc6',hat:false};
export const AUNT={color:'#e78783',hat:false};
export const BOSS={color:'#4168b0',hat:false};
// Rim follows the composited visible edge. No interior orange/blue strokes.
const buffers={};
function rim(g,fn,bounds,scale,key){
 const [x,y,w,h]=bounds,res=Math.max(.5,Math.abs(scale)*(E.PX||1));
 let b=buffers[key];if(!b)b=buffers[key]=[document.createElement('canvas'),document.createElement('canvas')];
 for(const c of b){let W=Math.ceil(w*res),H=Math.ceil(h*res);if(c.width!==W||c.height!==H){c.width=W;c.height=H;}}
 const [base,edge]=b,ctx=base.getContext('2d'),e=edge.getContext('2d');
 ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,base.width,base.height);ctx.setTransform(res,0,0,res,-x*res,-y*res);fn(ctx);
 g.drawImage(base,x,y,w,h);
 const thick=2.3;for(const [dx,color]of[[thick,'#d7a36b'],[-thick,'#668d9b']]){
 e.setTransform(1,0,0,1,0,0);e.globalCompositeOperation='source-over';e.clearRect(0,0,edge.width,edge.height);e.drawImage(base,0,0);e.globalCompositeOperation='destination-out';e.drawImage(base,dx,thick*.2);e.globalCompositeOperation='source-in';e.fillStyle=color;e.fillRect(0,0,edge.width,edge.height);g.drawImage(edge,x,y,w,h);
 }
}
export function person(g,o={}){
 const s=o.s??1;if(o.shadow!==false){const p=o.pose||POSES.stand,Y=Math.max(p.fF[1],p.fB[1]),f=o.facing??1;for(const foot of[p.fF,p.fB])shadow(g,o.x+(foot[0]+5)*s*f,o.y+Y*s+3,14*s,4*s);}
 g.save();g.translate(o.x,o.y);g.scale(s,s);rim(g,q=>rawPerson(q,{...o,x:0,y:0,s:1,shadow:false}),[-170,-279,340,325],s,'body');g.restore();
}
export function closeFace(g,x,y,r,o={}){g.save();g.translate(x,y);g.scale(r,r);rim(g,q=>rawCloseFace(q,0,0,1,o),[-1.6,-1.9,3.2,4.2],r,'face');g.restore();}
