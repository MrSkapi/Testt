import {registerShot,layer,blurLayer,backdrop,veil,seg,poly,circle,ring,alpha,shade,text,FONTS,ease,prog,lerp,clamp} from '/engine/core.js';
import * as FX from '/engine/fx2d.js';
import {person,head,closeFace,HERO,MOM,AUNT,FRIEND,BOSS,POSES,walkPose,breathe,posesAt} from './cast.js';
import {C,box,ellipse,shadow,phone,cup,clock,book,laptop,plate,bicycle,arrow,playIcon} from './sets/props.js';
import * as W from './sets/world.js';
import * as L from './sets/places.js';
import {camera} from './common.js';
import {surface} from './sets/surfaces.js';
import {acting,stairStep,envelope} from './motion.js';
const P=(t,a=0,b=1)=>ease.inOut(prog(t,a,b));
const COST=[['5 YEARS',2000,399],['10 YEARS',3500,699],['15 YEARS',5000,999],['20 YEARS',8000,1499]];
const usd=n=>'$'+n.toLocaleString('en-US');
let paperLabels=false,CURRENT=null;
function label(g,s,x,y,size=30,color=C.cream){if(paperLabels){if(color===C.cream)color='#30446a';else if(color===C.gold)color='#a34f45';}text(g,s,x,y,{size,font:FONTS.ui,color});}
function set(g,t,i,name='apartment',o={}){const c=camera(t,i);(L[name]||W[name])(g,i.globalT,c,o);return c;}
function board(g,t,kind='screen'){paperLabels=surface(g,t,kind);}
function hero(g,x=614,y=912,s=1.8,o={}){const pose=acting('hero',o.pose||POSES.stand,CURRENT,!!o.prop);person(g,{x,y,s,expr:o.expr||'sad',look:o.look||[.4,0],...o,pose,blink:(CURRENT?.globalT||0)%3.8>3.65});}
function mom(g,x=1296,y=912,s=1.8,o={}){const pose=acting('mom',o.pose||POSES.stand,CURRENT,!!o.prop);person(g,{x,y,s,cast:MOM,bun:true,old:!o.young,expr:o.expr||'sad',look:o.look||[-.2,0],...o,pose,blink:((CURRENT?.globalT||0)+.7)%4.0>3.85});}
function others(g,x,y,s=1.8,o={}){const pose=acting('other',o.pose||POSES.stand,CURRENT,!!o.prop);person(g,{x,y,s,cast:o.cast||FRIEND,expr:o.expr||'neutral',...o,pose,blink:((CURRENT?.globalT||0)+x*.001)%4.1>3.96});}
function chair(g,x,y){box(g,x-63,y-119,126,19,'#546b59',6);for(let dx of[-44,44])box(g,x+dx,y-103,9,119,'#44584b');box(g,x+51,y-277,10,171,'#44584b');box(g,x-51,y-279,111,20,'#546b59',6);}
function table(g,x=960,y=789,w=610){W.table(g,x,y,w);}
function motherAge(T){return T>=350.4;}
function pair(g,t,i,where='apartment',o={}){const c=set(g,t,i,where,{bare:true,night:o.night});layer(g,c,1,g=>{
 if(o.seated){chair(g,618,950);chair(g,1317,950);}
 hero(g,621,o.seated?969:915,o.seated?1.92:1.8,{T:i.globalT,pose:o.seated?{...POSES.sit,fF:[46,-10],fB:[38,-10]}:POSES.stand,...o.hero});
 mom(g,1311,o.seated?969:915,o.seated?1.92:1.8,{T:i.globalT,young:motherAge(i.globalT),pose:o.seated?{...POSES.sit,fF:[46,-10],fB:[38,-10]}:POSES.stand,facing:-1,...o.mom});
 if(o.seated){table(g,960,827,560);cup(g,828,809,.6);cup(g,1120,809,.6);}
 });return c;}
function framedPhoto(g,x,y,s=1,o={}){g.save();g.translate(x,y);g.scale(s,s);box(g,-414,-300,828,595,'#e1d1ad',9);box(g,-389,-278,778,509,'#93a38b',3);
 g.save();g.beginPath();g.rect(-387,-276,774,504);g.clip();box(g,-387,-276,774,504,'#99ab8f');for(let j=0;j<6;j++)box(g,-370+j*153,-177-(j%2)*43,100,405,'#6b8b7666');
 const memory=o.memory;mom(g,-163,507,2.34,{young:!!memory,expr:'happy',pose:POSES.stand,T:0});others(g,174,507,2.34,{cast:AUNT,bun:true,old:false,expr:'happy',pose:POSES.stand,T:0});g.restore();label(g,o.family?'FAMILY':o.memory?'SAME MOM':'TODAY',0,266,25,'#69765c');g.restore();}
function phoneScene(g,t,i){const momCall=['classCall','accept'].includes(i.mode);blurLayer(g,10,g=>momCall?L.beach(g,i.globalT,{}, {hotel:true}):W.apartment(g,i.globalT,{},{}));layer(g,camera(t,i),1,g=>{g.save();g.translate(0,65*(1-P(t,0,.55)));
 seg(g,[[539,1300],[704,899],[786,740]],108,momCall?MOM.color:HERO.color);ellipse(g,800,716,43,62,C.ink,.1);phone(g,1005,543,3.9,-.025);
 box(g,859,285,290,512,'#b9ccb6',13);const m=i.mode;
 if(m==='photo'){label(g,'Mom',1004,337,30,'#425f50');g.save();g.beginPath();g.rect(871,378,264,239);g.clip();framedPhoto(g,1004,490,.48);g.restore();label(g,'Look who I met!',1004,680,22,'#45654e');}
 if(m==='balance'){label(g,'SAVINGS',1004,377,29,'#425f50');label(g,'CHECK BALANCE',1004,531,24,'#425f50');ring(g,1004,670,31,3,'#608570');}
 if(m==='referral'){label(g,'RENEW',1004,360,32,'#425f50');label(g,'INVITE A FRIEND',1004,470,23,'#425f50');box(g,885,549,237,74,'#7fa38a',9);label(g,'SEND TO MOM',1004,586,24,C.cream);}
 if(m==='resignation'){label(g,'DRAFT',1004,350,30,'#425f50');label(g,'RESIGNATION',1004,436,24,'#425f50');for(let j=0;j<6;j++)seg(g,[[890,495+j*29],[1113-(j%3)*23,495+j*29]],2,'#7d947b');if(t>1.4)box(g,875,705,260,50,'#acbba2',6);}
 if(m==='classCall'||m==='accept'){label(g,'LEARNING CENTRE',1004,357,23,'#425f50');label(g,'Can you cover',1004,468,25,'#425f50');label(g,'another class?',1004,507,25,'#425f50');box(g,886,594,238,78,'#7ba18b',11);label(g,m==='accept'?'YES, I CAN':'REPLY',1004,634,24,C.cream);}
 g.restore();});}
function photo(g,t,i){blurLayer(g,9,g=>W.apartment(g,i.globalT,{},{}));layer(g,camera(t,i),1,g=>{const q=i.globalT-(i.groupStart??i.shot.start),k=P(q,0,.7),angle=-.065*(1-k);g.save();g.translate(960,551+(1-k)*66);g.rotate(angle);framedPhoto(g,0,0,1.18,{memory:['memory','sameMom'].includes(i.mode),family:i.mode==='family'});g.restore();});}

function faceScene(g,t,i){const name=i.globalT>300?'apartment':'cafe';blurLayer(g,11,g=>W[name](g,i.globalT,{}, {bare:true}));veil(g,C.ink,.06);const k=P(t,.2,1.15),look=i.mode==='read'?[-.5+1.0*k,.15]:[-1+1.5*k,-.1];closeFace(g,960-9*k,554,238,{expr:i.mode==='surprise'?'shock':'sad',look,tilt:-.035*k,blink:(i.globalT%3.7)>3.55});}

function stairs(g,t,i){const c=set(g,t,i,'stairs');layer(g,c,1,g=>{
 const aunt=i.mode==='auntBefore',old=i.mode!=='momAfter';
 const st=stairStep(Math.max(0,t-.12),{start:2,speed:old?2.1:1.15,steps:old?1:2,s:1.94});
 for(const [xx,yy]of st.feet){const j=clamp(Math.floor((xx-469)/157),0,7);shadow(g,xx,907-j*57+4,20,5);}
 person(g,{x:st.x,y:st.y,s:1.94,cast:aunt?AUNT:MOM,bun:true,old,pose:st.pose,expr:old?'tired':'happy',shadow:false});
 });}

function hiking(g,t,i){backdrop(g,['#6fb7d6','#d5eef0']);poly(g,[[-200,724],[372,218],[871,724]],'#72a994');poly(g,[[581,724],[1214,112],[2118,724]],'#548e95');poly(g,[[1068,263],[1214,112],[1393,298],[1242,263]],'#ebf6ed');box(g,-200,723,2300,600,'#b8cf86');
 const x=810+t*47,phase=t*2.6,p=walkPose(phase,{stride:19,lift:8,arm:8,bob:2});
 person(g,{x,y:909,s:1.9,cast:AUNT,bun:true,old:false,pose:p,expr:'happy',prop:(q,h)=>{seg(q,[[h[0],h[1]],[h[0]+34,-1]],3,'#8a6844');}});L.dust(g,i.globalT);}

function advert(g,t,i){board(g,i.globalT,'billboard');label(g,i.mode==='possibilities'?'MORE YEARS':'YOUTH',960,389,97,C.gold);label(g,i.mode==='possibilities'?'MORE POSSIBILITIES':'NOW AVAILABLE MONTHLY',960,562,47);if(i.mode==='subscription')label(g,'A SUBSCRIPTION',960,794,38,C.gold);}
function title(g,t,i){board(g,i.globalT,'billboard');label(g,'WHAT IF YOUTH',960,337,74);label(g,'BECAME A SUBSCRIPTION?',960,491,76,C.gold);label(g,'AN IMAGINED FUTURE',960,733,27);}
function clinic(g,t,i){const c=set(g,t,i,'clinic');layer(g,c,1,g=>{
 mom(g,1112,912,1.7,{young:motherAge(i.globalT),T:i.globalT,expr:i.mode==='helps'?'happy':'neutral'});others(g,1574,912,1.75,{cast:{color:'#d2cfb4',hat:false},T:i.globalT,pose:POSES.holdFront});if(i.mode==='establish'||i.mode==='noGuard')hero(g,493,912,1.8,{T:i.globalT});
 if(i.mode==='capacity'){clipboard(g,608,675,1.05);others(g,484,912,1.7,{cast:{color:'#c7c8ac',hat:false},T:i.globalT});}
 });}
function repair(g,t,i){board(g,i.globalT,'clinic');label(g,'REPAIR AGE-RELATED DAMAGE',960,178,46,C.gold);if(i.mode==='muscle'){for(let j=0;j<8;j++){let y=357+j*49;seg(g,[[495,y],[1419,y+17*Math.sin(j)]],16,'#819a76');if(j<3){const k=P(t,0,1.3);box(g,837-k*25,y-17,44+50*k,34,'#b6bb8e',7);}}label(g,'MUSCLE RECOVERY',960,864,34);}else{for(let side of[-1,1])seg(g,[[960+side*70,313],[960,536],[960+side*70,755]],71,'#88a184');ring(g,960,536,77,10,'#b4c19a');ring(g,960,536,98+P(t,0,1)*13,2,'#d0c89e66');label(g,'JOINT FUNCTION',960,875,34);}}
function calendar(g,t,i){board(g,i.globalT,'calendar');const m=i.mode;label(g,m==='younger'?'BIOLOGICAL AGE':m==='monthly'?'MONTHLY MAINTENANCE':'THE COURSE TAKES WEEKS',960,173,46,C.gold);
 const q=i.globalT-(i.groupStart??i.shot.start),turn=Math.floor(q/1.55),f=(q%1.55)/1.55;
 const days=['MON','TUE','WED','THU','FRI','SAT','SUN'];for(let k=0;k<4;k++)for(let j=0;j<7;j++){let x=488+j*156,y=361+k*115;box(g,x,y,133,93,['#6b8ac0','#9888bd','#6fadb7'][turn%3],10);label(g,String(k*7+j+1),x+66,y+46,28,'#f4edd4');if(k*7+j<Math.floor(f*28))seg(g,[[x+31,y+46],[x+55,y+65],[x+100,y+23]],4,'#ffdc86');if(k===0)label(g,days[j],x+66,304,19);}
 if(f>.80){const lift=(f-.80)/.2;poly(g,[[1702,929],[1702-280*lift,929],[1702,929-260*lift]],'#f5e8c5');seg(g,[[1702-280*lift,929],[1702,929-260*lift]],2,'#bba483');}
 if(m==='younger')label(g,'YOUR BODY. YEARS EARLIER.',960,924,34);
}

function memory(g,t,i){board(g,i.globalT,'book');for(let j=0;j<3;j++){let x=504+j*460;box(g,x-156,371,312,285,'#718669',13);if(j===0)framedPhoto(g,x,508,.32,{memory:true});if(j===1)book(g,x-54,439,108,139,'#a78759');if(j===2){circle(g,x,514,58,C.cream);circle(g,x,514,16,'#5a7460');}}label(g,'MEMORIES • EXPERIENCE • PERSONALITY',960,207,40,C.gold);}
function music(g,t,i){const c=set(g,t,i,'apartment');layer(g,c,1,g=>{mom(g,904,911,1.9,{T:i.globalT,expr:'sad'});box(g,1210,665,318,161,'#556d5e',14);for(let x of[1274,1460]){circle(g,x,747,43,'#2b433b');ring(g,x,747,27,3,'#8ea280');}seg(g,[[1368,692],[1368,650]],5,'#99af90');label(g,'SAME TASTE IN MUSIC',960,228,40,C.cream);});}
function plans(g,t,i){board(g,i.globalT,'screen');label(g,'RENEW • MEMBERSHIP PLANS',960,164,43,C.gold);
 const group=i.groupStart??i.shot.start,q=i.globalT-group;let active=i.mode.startsWith('five')?0:i.mode==='ten'?1:['fifteen','momFifteen','smaller'].includes(i.mode)?2:i.mode==='twenty'||i.mode==='momTwenty'?3:-1;
 for(let j=0;j<4;j++){let x=391+j*380,a=COST[j],k=P(q,j*.13,j*.13+.6);g.save();g.translate(0,(1-k)*65);g.globalAlpha=k;box(g,x-169,285,338,536,j===active?['#419bc3','#746ac7','#c86d9f','#d6a04b'][j]:['#37617f','#555487','#874d77','#8e724e'][j],15);label(g,a[0],x,360,33);label(g,usd(a[1]),x,494,45);label(g,'UP FRONT',x,548,19);label(g,usd(a[2])+'/mo',x,659,36,C.gold);label(g,'MAINTENANCE',x,717,18);if(j===active){const a=P(t,.1,.65);seg(g,[[x-109,760],[x-109+218*a,760]],5,'#f6dc9c');}g.restore();}
 if(i.mode==='hiddenCost')label(g,'THE PRICE ISN’T THE WHOLE COST',960,929,33,C.gold);
 if(i.mode==='momTwenty'||i.mode==='momFifteen'){const j=i.mode==='momTwenty'?3:2,x=391+j*380,y=lerp(1085,779,P(t,0,.5));seg(g,[[x+65,1174],[x+19,906],[x,y+13]],49,MOM.color);ellipse(g,x,y,19,28,C.ink,.1);}
}

function rules(g,t,i){board(g,i.globalT,'brochure');const k=P(t,.05,1.5);if(i.mode==='minimum'){label(g,'THERE IS A MINIMUM BIOLOGICAL AGE',960,244,43,C.gold);for(let j=0;j<3;j++){let x=559+j*416;head(g,x,484,64,{front:true,blink:(i.globalT+j*.4)%3.5>3.35});poly(g,[[x-52,581],[x+52,581],[x+60,762],[x-60,762]],['#7298c4','#9983bb','#66a9b4'][j]);if(j<2)arrow(g,x+91,616,x+304,616,P(t,j*.2,j*.2+.8),C.gold,3);}seg(g,[[1509,358],[1509,817]],9,'#d37388');label(g,'NO ENDLESS RESET',960,929,32);}else{label(g,i.mode==='accidents'?'ACCIDENTS STILL HAPPEN':i.mode==='illness'?'NOT A CURE FOR EVERY ILLNESS':'YOUNGER DOESN’T MEAN INVINCIBLE',960,219,46,C.gold);g.beginPath();g.arc(960,540,173,-Math.PI/2,-Math.PI/2+Math.PI*2*k);g.strokeStyle='#729ac7';g.lineWidth=8;g.stroke();seg(g,[[900,537],[941,579],[1026,488]],11,'#8b82ba');seg(g,[[789,369],[789+342*k,369+342*k]],8,'#d38379');}}

function aging(g,t,i){board(g,i.globalT,'paper');label(g,i.mode==='cancel'?'CANCEL THE SUBSCRIPTION':i.mode==='keepYears'?'YOU KEEP THE YEARS REGAINED':'ORDINARY AGING RESUMES',960,201,45,C.gold);const q=i.globalT-(i.groupStart??i.shot.start),k=P(q,.1,i.mode==='keepYears'?2:5.5);arrow(g,451,626,1482,626,1,'#7ba8bc',5);circle(g,707,626,18,'#a9bdcb');circle(g,1159,626,18,'#a9bdcb');circle(g,lerp(707,1159,k),626,22,'#eead46');label(g,'YOUNGER STATE',708,738,26);label(g,'NORMAL AGING',1158,738,26);label(g,'NO SUDDEN AGE JUMP',960,414,46);}

function cta(g,t,i){board(g,i.globalT,'screen');head(g,960,340,101,{hat:true,front:true,expr:'happy'});box(g,678,573,564,117,'#b6463c',18);playIcon(g,747,631,.5);label(g,'SUBSCRIBE',1000,632,43);box(g,823,778,274,75,'#347caf',12);label(g,'LIKE',960,816,29);}
function momMenu(g,t,i){const c=pair(g,t,i,'apartment',{seated:true,mom:{young:false,expr:i.mode==='awkward'?'sad':'neutral'},hero:{expr:'sad'}});layer(g,c,1.03,g=>{g.save();g.translate(963,815);g.rotate(-.08);box(g,-121,-160,242,160,'#d3c8a6',5);label(g,i.mode==='close'?'CLOSED':'RENEW',0,-119,23,'#536c52');if(i.mode!=='close')for(let j=0;j<4;j++)seg(g,[[-91,-77+j*15],[91,-77+j*15]],2,'#7b8a6a');g.restore();});}
function age(g,t,i){board(g,i.globalT,'book');label(g,'MOM',960,201,47,C.gold);label(g,'64',610,486,151);arrow(g,805,486,1094,486,P(t,0,.9),C.gold,7);label(g,'49',1301,486,151,C.gold);label(g,'15 YEARS YOUNGER',960,750,41);}
function dance(g,t,i){const c=set(g,t,i,'apartment');layer(g,c,1,g=>{
 const ph=t*2.4,side=Math.sin(ph),p={...POSES.stand,hip:[side*5,-102],sh:[side*3,-178],head:[side*4,-212],eF:[31,-164+side*5],hF:[48,-188+side*10],eB:[-30,-165-side*5],hB:[-48,-185-side*10],kF:[8+side*6,-50],kB:[-8+side*6,-50],fF:[6+Math.max(0,side)*11,0],fB:[-12+Math.min(0,side)*11,0]};
 person(g,{x:960,y:915,s:2.04,cast:MOM,bun:true,old:false,pose:p,expr:'happy'});
 });}

function beach(g,t,i){const c=set(g,t,i,'beach',{hotel:i.globalT>423});layer(g,c,1,g=>{
 if(i.mode==='wish'){mom(g,960,938,1.9,{young:true,T:i.globalT,expr:'happy'});return;}
 hero(g,718,968,1.8,{T:i.globalT,expr:'sad'});mom(g,1156,968,1.8,{young:true,T:i.globalT,expr:'sad'});
 });}
function cost(g,t,i){board(g,i.globalT,'paper');const q=i.globalT-(i.groupStart??i.shot.start);label(g,'MOM’S FIRST YEAR',960,181,47,C.gold);label(g,'$5,000',589,419,76);label(g,'INITIAL COURSE',589,505,24);label(g,'12 × $999',1286,419,66);label(g,'MONTHLY VISITS',1286,505,24);label(g,'+',960,418,66);seg(g,[[476,610],[1431,610]],3,'#a9b69a');
 const k=P(q,.7,2.4);g.save();g.beginPath();g.rect(613,655,720*k,170);g.clip();label(g,'$16,988',960,757,100,C.gold);g.restore();if(k>.95)label(g,'ALMOST $17,000',960,903,30);
 const hx=613+720*k,hy=815;seg(g,[[1820,1250],[hx+140,1001],[hx,hy]],73,HERO.color);ellipse(g,hx,hy-13,31,40,C.ink,-.5);seg(g,[[hx-30,hy-51],[hx+17,hy+13]],10,'#59719e');}

function savings(g,t,i){blurLayer(g,10,g=>W.apartment(g,i.globalT,{},{}));box(g,480,190,960,701,'#dbe9fa',21);label(g,'MOM — FIRST YEAR',960,286,36,'#42597c');
 const end={create:0,'3000':3000,'6000':6000,'9000':9000,targetMoves:9000,empty:0}[i.mode]??0,start={create:0,'3000':0,'6000':3000,'9000':6000,targetMoves:9000,empty:16988}[i.mode]??0,k=P(t,.12,Math.min(i.dur-.12,1.7)),value=Math.round(lerp(start,end,k)/10)*10;
 label(g,i.mode==='empty'&&k>.95?'RESERVE: LOW':usd(value),960,475,i.mode==='empty'&&k>.95?61:95,'#42597c');box(g,607,609,707,34,'#a6bed6',15);if(value)box(g,607,609,707*Math.min(1,value/16988),34,'#efad46',15);label(g,i.mode==='targetMoves'?'THE TARGET HAS MOVED':'GOAL: $16,988',960,744,32,'#526a8a');}

function bicycleScene(g,t,i){const c=set(g,t,i,'street',{clean:true});layer(g,c,1,g=>{
 const x=930+t*48,ph=t*3.7,bx=x,by=922; bicycle(g,bx,by,1.39,-t*1.0);
 const px=bx-63,py=837,S=1.58,crank=[bx+14,by-70],r=23;
 const f1=[(crank[0]+Math.cos(ph)*r-px)/S,(crank[1]+Math.sin(ph)*r-py)/S],f2=[(crank[0]-Math.cos(ph)*r-px)/S,(crank[1]-Math.sin(ph)*r-py)/S];
 const p={...POSES.sit,eF:[56,-120],hF:[99,-91],eB:[36,-117],hB:[78,-96],kF:[42,-61],kB:[29,-65],fF:f1,fB:f2};
 person(g,{x:px,y:py,s:S,cast:FRIEND,beard:true,expr:'happy',pose:p,shadow:false});
 });}

function classroom(g,t,i){const c=set(g,t,i,'classroom');layer(g,c,.89,g=>{
 const k=P(t,.12,Math.min(i.dur-.1,2.25)),px=1370,py=887,S=1.8,wx=1420+k*94,wy=555+Math.sin(k*16)*3;
 const tx=(wx-px)/S,ty=(wy-py)/S,dx=tx-12,dy=ty+172,D=Math.min(73.99,Math.hypot(dx,dy)),A=Math.atan2(dy,dx)+Math.acos(D/74);const pose={...POSES.stand,eF:[37*Math.cos(A),-172+37*Math.sin(A)],hF:[tx-13,ty]};
 const prop=(q,h)=>seg(q,[[h[0]+3,h[1]-2],[h[0]+8,h[1]-5]],2,'#f1e8c4');
 if(i.mode==='retired')person(g,{x:px,y:py,s:S,cast:{color:'#689ad0'},beard:true,pose,expr:'happy',prop});
 else person(g,{x:px,y:py,s:S,cast:MOM,bun:true,old:false,pose,expr:'happy',prop});
 seg(g,[[1423,555],[wx+8,wy-4]],2.5,'#f0e2b5');
 });layer(g,c,1,g=>{for(let j=0;j<3;j++){const x=326+j*457;ellipse(g,x,1041,77,107,['#e7b256','#6baac8','#d783a8'][j]);circle(g,x,927+Math.sin(i.globalT*.9+j)*2,36,C.ink);}});}

function dating(g,t,i){const c=set(g,t,i,'cafe',{bare:true});layer(g,c,1,g=>{
 chair(g,636,950);chair(g,1324,950);let base={...POSES.sit,fF:[46,-10],fB:[38,-10]},k=envelope(t,.2,.85,1.25,2.25);
 const pose={...base,eF:[lerp(48,30,k),lerp(-118,-154,k)],hF:[lerp(93,5,k),lerp(-88,-164,k)]};
 person(g,{x:638,y:968,s:1.9,cast:FRIEND,pose,expr:i.mode==='brother'?'sad':'happy'});
 others(g,1323,968,1.9,{cast:AUNT,bun:true,facing:-1,pose:base,expr:'happy',T:i.globalT});table(g,960,822,534);cup(g,1125,801,.58);
 const hx=638+(pose.hF[0]+13)*1.9,hy=968+pose.hF[1]*1.9;cup(g,hx-12,hy+18,.48);
 });if(['35','60'].includes(i.mode)){box(g,842,185,236,112,'#627dbc',15);label(g,i.mode==='35'?'LOOKS 35':'AGE 60',960,242,42,C.gold);}}

function office(g,t,i){const c=set(g,t,i,'office',{night:i.mode==='executive'});layer(g,c,.93,g=>{
 hero(g,539,924,1.8,{T:i.globalT});others(g,1443,924,1.8,{cast:BOSS,T:i.globalT,pose:i.mode==='announcement'?POSES.explain:POSES.stand});
 if(i.mode==='body'||i.mode==='rent')others(g,1060,924,1.7,{T:i.globalT,pose:POSES.phone,prop:(g,h)=>phone(g,h[0],h[1]-13,.23)});
 });}
function benefits(g,t,i){board(g,i.globalT,'screen');box(g,487,261,946,534,'#dce8fb',12);label(g,'EMPLOYER CONTRIBUTIONS',960,359,42,'#4c6491');label(g,i.mode==='quit'?'LEAVE THE JOB?':'TREATMENT BENEFIT',960,512,43,'#4c6491');label(g,i.mode==='quit'?'THE PAYMENTS STOP':'TIED TO YOUR EMPLOYMENT',960,666,34,'#af697e');const k=P(t,.15,1.45),hx=671+572*k;seg(g,[[1560,1250],[hx+111,971],[hx,742]],74,HERO.color);ellipse(g,hx,725,28,40,C.ink,-.2);seg(g,[[hx-24,694],[hx+16,755]],9,'#556fa5');seg(g,[[672,702],[672+570*k,702]],3,'#bf819b');}

function shift(g,t,i){const c=set(g,t,i,'office',{night:true});layer(g,c,1,g=>{
 if(t<1){chair(g,946,970);hero(g,946,990,2,{T:i.globalT,expr:'tired',pose:{...POSES.sit,fF:[46,-10],fB:[38,-10],eF:[37,-126],hF:[65,-126],eB:[26,-127],hB:[47,-126]}});table(g,1011,824,692);laptop(g,1072,803,1.05);cup(g,1358,809,.65);return;}
 box(g,-200,848,2400,500,'#d3a47b');laptop(g,979,733,3.15);
 const z=t-1;for(let j=0;j<6;j++){const w=clamp((z-j*.12)/.6)*270;seg(g,[[773,433+j*35],[773+w,433+j*35]],6,['#8de0dd','#f1cf91','#a2bcec'][j%3]);}
 for(let j=0;j<2;j++){const x=839+j*333,tap=Math.sin(t*13+j*Math.PI)*5;seg(g,[[x+(j?97:-97),1300],[x,1034],[x,836+tap]],92,HERO.color);ellipse(g,x,817+tap,41,47,C.ink,.1);for(let k=0;k<3;k++)seg(g,[[x-21+k*20,806+tap],[x-21+k*20,787+tap]],10,C.ink);}
 });}

function clipboard(g,x,y,s=1){g.save();g.translate(x,y);g.scale(s,s);box(g,-70,-96,140,191,'#7b805e',7);box(g,-61,-85,122,169,C.paper,3);box(g,-21,-101,42,17,'#687958',3);for(let j=0;j<6;j++)seg(g,[[-45,-52+j*21],[43,-52+j*21]],2,'#7c8c6b');g.restore();}
function boardroom(g,t,i){board(g,i.globalT,'cork');label(g,'WHO SHOULD PAY?',960,214,58,C.gold);for(let j=0;j<3;j++){let x=503+j*456;box(g,x-128,390,256,327,['#6588b7','#a37db5','#6fa9b0'][j],11);const k=envelope(t,.1+j*.15,.6+j*.15,1.4+j*.15,2.5);const p={...POSES.stand,eF:[9+25*k,-137-20*k],hF:[13+36*k,-101-42*k]};person(g,{x,y:701,s:1.03,cast:{color:['#d69572','#95b7df','#b791c5'][j]},pose:p,expr:'sad'});}seg(g,[[401,755],[1533,755]],19,'#e6b886');}

function waiting(g,t,i){const c=set(g,t,i,'waiting');layer(g,c,1,g=>{
 for(let j=0;j<4;j++){const x=337+j*329,k=j===3?P(t,.6,2):0,y=lerp(864,849,k),base={...POSES.sit,fF:[46,-9],fB:[38,-9]},p={};for(const name of Object.keys(base))p[name]=[lerp(base[name][0],POSES.stand[name][0],k),lerp(base[name][1],POSES.stand[name][1],k)];person(g,{x,y,s:1.61,cast:j%2?MOM:FRIEND,bun:j%2===1,old:j%2===1,pose:p,expr:j===3?'neutral':'sad'});}
 });}

function capacity(g,t,i){board(g,i.globalT,'cork');label(g,i.mode==='patent'?'PATENTS • INVESTORS':'PREMIUM APPOINTMENTS',960,214,48,C.gold);for(let j=0;j<3;j++){let x=548+j*413;box(g,x-141,390,282,302,'#657f63',14);label(g,i.mode==='patent'?['PATENT','CAPITAL','SUPPLIES'][j]:['STAFF','EQUIPMENT','ACCESS'][j],x,534,27);}}
function access(g,t,i){board(g,i.globalT,'screen');label(g,'ACCESS IS UNEQUAL',960,178,49,C.gold);for(let j=0;j<2;j++){let x=568+j*781;box(g,x-238,333,476,413,j?'#8f9c76':'#536f58',17);label(g,j?'PRIVATE':'PUBLIC',x,407,38);label(g,j?'THURSDAY':'MONTHS',x,552,57,C.gold);label(g,j?'CHOOSE A DATE':'WAITING LIST',x,675,25);} }
function appointment(g,t,i){board(g,i.globalT);if(i.mode==='40min'){paperLabels=false;blurLayer(g,7,g=>W.apartment(g,i.globalT,{}, {kind:'bed'}));box(g,623,738,747,284,'#a87748',10);box(g,606,723,780,26,'#c99559',7);seg(g,[[664,842],[1317,842]],3,'#795c3e');box(g,922,824,84,13,'#c8b487',6);clock(g,968,496,220,40*P(t,0,Math.min(2.0,i.dur-.1)));book(g,1250,643,99,80,'#5b927c');cup(g,728,717,.73);label(g,'40 MINUTES',968,919,45,C.cream);}else{box(g,563,252,794,574,'#dce9fa',18);label(g,'PREMIUM APPOINTMENT',960,347,37,'#4c6e55');label(g,'THURSDAY',960,542,80,'#4c6e55');label(g,'YOUR CHOICE',960,719,30,'#4c6e55');}}
function retirement(g,t,i){board(g,i.globalT,'book');label(g,'RETIREMENT RULES CHANGE',960,183,47,C.gold);arrow(g,518,593,1440,593,P(t,0,1.3),C.gold,5);for(let j=0;j<5;j++){let x=548+j*210;circle(g,x,593,10,C.cream);label(g,String(60+j*5),x,693,35);}label(g,i.mode==='unequal'?'ACCESS STILL ISN’T EQUAL':'LONGER LIVES. LATER RETIREMENT.',960,838,35);}
function comparison(g,t,i){board(g,i.globalT,'book');for(let j=0;j<2;j++){let x=573+j*773;box(g,x-221,273,442,513,'#7c8bb8',15);others(g,x,757,1.78,{cast:j?{color:'#9c8963'}:BOSS,beard:!!j,expr:j?'tired':'happy',pose:j?POSES.sad:POSES.stand,T:i.globalT});label(g,'70',x,207,70,C.gold);label(g,j?'50 YEARS OF HARD WORK':'BIOLOGICAL AGE 50',x,877,27);}}
function yacht(g,t,i){const c=set(g,t,i,'yacht');const dx=-Math.max(0,Math.min(t,4))*24;layer(g,c,.8,g=>others(g,1450+dx,667,1.14,{cast:BOSS,expr:'happy',T:i.globalT}));}

function cakeProp(g,x,y,s=1,age='100'){g.save();g.translate(x,y);g.scale(s,s);ellipse(g,0,2,125,33,'#e4d5b3');box(g,-97,-102,194,94,'#c59b6a',13);ellipse(g,0,-101,97,25,'#eddfbb');for(let j=0;j<9;j++){let xx=-77+j*19;box(g,xx,-105,5,17,'#dfcda6',2);}label(g,age,0,-151,69,C.cream);for(let j of[-1,1]){box(g,j*72-3,-163,6,61,'#c88c5f',2);ellipse(g,j*72,-172,5,11,'#edc584');}g.restore();}
function party(g,t,i){const c=set(g,t,i,'terrace');layer(g,c,1,g=>{
 const k=envelope(t,.15,.8,Math.max(.95,i.dur*.65),Math.max(1.4,i.dur-.05));
 const base=POSES.stand,ps={...base,eF:[27,-155-20*k],hF:[45,-163-28*k]};
 person(g,{x:908,y:927,s:2.0,cast:BOSS,expr:'happy',pose:ps,prop:(q,h)=>cup(q,h[0],h[1]+16,.3)});
 others(g,1473,922,1.85,{cast:{color:'#cf8c99'},expr:'happy',T:i.globalT});table(g,1053,810,775);cakeProp(g,1192,794,.71,i.globalT<300?'90':'100');
 });if(i.mode==='50'||i.mode==='youngMan')label(g,i.mode==='50'?'LOOKS 50':'YOUNGER THAN YOUR MOM',960,190,40,C.cream);}

function terrace(g,t,i){party(g,t,{...i,mode:'clinics'});}
function busStop(g,t,i){const c=set(g,t,i,'busStop');layer(g,c,1,g=>{
 const continuation=i.mode==='hotel',mx=1031-(456.1-453.2)*37,hx=mx-257,ph=(mx-800)/(1.86*26)*Math.PI;
 const hp=continuation?posesAt(t,[[0,walkPose(ph+.4,{stride:20,lift:7,arm:7,bob:1.5})],[.05,POSES.stand]],.6):POSES.stand;
 hero(g,continuation?hx:615,continuation?955:926,continuation?1.87:1.9,{T:i.globalT,expr:'tired',pose:hp});
 if(i.globalT>450){const mp=posesAt(t,[[0,walkPose(ph,{stride:20,lift:7,arm:7,bob:1.5})],[.05,POSES.stand]],.6);mom(g,mx,955,1.86,{young:true,T:i.globalT,expr:'sad',pose:mp});}
 });if(i.mode==='wait')label(g,'AFTER WORK',960,207,35,C.cream);}

function split(g,t,i){board(g,i.globalT);box(g,959,86,3,874,'#ece3c6');
 g.save();g.beginPath();g.rect(0,60,960,960);g.clip();L.beach(g,i.globalT,{x:-470},{hotel:true});const k=envelope(t,.2,.8,2.0,2.8),p=posesAt(k,[[0,POSES.stand],[.1,POSES.explain]],.5);person(g,{x:487,y:917,s:2.03,cast:BOSS,expr:'happy',pose:p,prop:(q,h)=>cup(q,h[0],h[1]+13,.28)});label(g,'MORE SUMMERS',480,218,37,C.cream);g.restore();
 g.save();g.beginPath();g.rect(964,60,956,960);g.clip();L.classroom(g,i.globalT,{x:475});chair(g,1440,950);const ph=t*7,pose={...POSES.sit,fF:[46,-10],fB:[38,-10],eF:[25,-111],hF:[55,-103+Math.sin(ph)*2]};person(g,{x:1440,y:969,s:1.9,cast:MOM,bun:true,old:false,expr:'tired',pose});table(g,1445,827,600);box(g,1464,771,175,42,C.paper,3);seg(g,[[1532,765],[1552+Math.sin(ph)*4,796]],7,'#506ba0');box(g,1230,161,422,95,'#5e5489',10);label(g,'MORE SHIFTS',1440,208,37,C.cream);g.restore();}

function wealth(g,t,i){board(g,i.globalT,'paper');label(g,i.mode==='assets'?'COMPANIES • PROPERTY • INVESTMENTS':'MORE TIME FOR MONEY TO GROW',960,184,43,C.gold);const q=i.globalT-(i.groupStart??i.shot.start);for(let j=0;j<6;j++){let h=(60+j*60)*P(q,j*.13,j*.13+.95);box(g,516+j*156,793-h,100,h,['#4f93ca','#7979c6','#bd76ad'][j%3],7);}seg(g,[[469,803],[1491,803]],4,'#b4ba95');}

function staircase(g,t,i){board(g,i.globalT,'book');for(let j=0;j<6;j++){box(g,466+j*164,831-j*91,174,500,'#6e8666');box(g,466+j*164,831-j*91,174,11,'#bcc29d');}box(g,1249,183,60,303,'#8d9c79',5);label(g,'THE BLOCKED STAIRCASE',960,159,43,C.gold);others(g,751,740,1.55,{T:i.globalT,expr:'sad'});}
function housing(g,t,i){board(g,i.globalT,'book');label(g,{sameOwner:'SAME OWNERS. MORE YEARS.',inheritance:'INHERITANCE ARRIVES LATER',family:'FAMILIES POSTPONE DECISIONS',affordable:'LONGER LIVES ≠ AFFORDABLE HOMES',century:'ANOTHER CENTURY OF RENT'}[i.mode],960,193,41,C.gold);const q=i.globalT-(i.groupStart??i.shot.start);for(let j=0;j<4;j++){let x=461+j*335,k=P(q,j*.12,j*.12+.75);g.save();g.translate(0,(1-k)*80);g.globalAlpha=k;box(g,x-119,398,238,402,['#7b98c8','#b68dbd','#d38c77','#75aeb2'][j],7);poly(g,[[x-148,400],[x,279],[x+148,400]],'#d5a866');for(let n=0;n<3;n++){box(g,x-80,469+n*77,54,51,'#e6e9c7');box(g,x+28,469+n*77,54,51,'#e6e9c7');}g.restore();}}

function population(g,t,i){board(g,i.globalT,'book');label(g,'POPULATION DEPENDS ON',960,199,46,C.gold);for(let j=0;j<3;j++){let x=523+j*437;box(g,x-169,400,338,294,'#7d73b2',13);label(g,['BIRTHS','DEATHS','ACCESS'][j],x,544,35,'#f1e4bf');}}
function email(g,t,i){blurLayer(g,10,g=>W.apartment(g,i.globalT,{},{}));box(g,412,180,1096,714,'#e7e8fb',18);label(g,'RENEW • PLAN UPDATE',960,280,43,'#456091');seg(g,[[515,346],[1403,346]],2,'#a9bad7');label(g,'15-YEAR PLAN MAINTENANCE',960,422,31,'#456091');const q=i.globalT-(i.groupStart??i.shot.start),k=P(q,.2,1.1);label(g,'$999',691,562,64,'#7895b7');seg(g,[[572,562],[572+236*k,562]],5,'#dc7475');g.save();g.globalAlpha=k;label(g,'$1,200 / MONTH',1109,561,58,'#bd646c');g.restore();label(g,'PREPAID PACKAGES WILL BE HONORED',960,733,27,'#456091');if(i.mode==='honored'){const v=P(t,.1,.8);seg(g,[[748,801],[782,830],[782+370*v,772]],5,'#8d83c5');}}

function cameraProp(g,x,y,s=1){g.save();g.translate(x,y);g.scale(s,s);box(g,-111,-75,222,143,'#344a42',16);box(g,-73,-98,88,35,'#425b4d',5);circle(g,10,-4,63,'#273d37');ring(g,10,-4,47,8,'#8b9f82');circle(g,10,-4,34,'#4b6f63');box(g,74,-61,24,19,'#bbc7a6',3);g.restore();}
function sacrifice(g,t,i){const m=i.mode;if(m==='camera'){blurLayer(g,9,g=>W.apartment(g,i.globalT,{},{}));box(g,-200,765,2400,500,'#d1a57e');const k=P(t,.25,1.65),x=lerp(763,1170,k);seg(g,[[201,1300],[499,969],[x-145,716]],87,HERO.color);ellipse(g,x-129,700,40,52,C.ink,.1);seg(g,[[1800,1300],[1525,970],[x+159,718]],87,'#6a9dcc');ellipse(g,x+146,704,40,52,C.ink,-.1);cameraProp(g,x,647,1.52);label(g,'SELL THE CAMERA',960,236,42,C.cream);return;}
 board(g,i.globalT,'paper');if(m==='trip'||m==='weekend'){box(g,633,344,653,365,'#829fc4',14);label(g,'TRIP',960,433,55,'#f3e9cc');seg(g,[[741,613],[1151,613]],6,C.cream);poly(g,[[1091,586],[1162,613],[1091,640]],C.cream);const k=P(t,.25,1.4);seg(g,[[711,365],[711+478*k,692]],7,'#e17c84');if(k>.6)seg(g,[[1208,365],[1208-478*(k-.6)/.4,692]],7,'#e17c84');label(g,m==='trip'?'CANCEL THE TRIP':'ALMOST A TREATMENT',960,860,41,C.gold);}else if(m==='repair'){phone(g,960,533,2.8,-.07);seg(g,[[911,348],[938,460],[919,546],[982,664]],4,'#536958');const y=lerp(971,710,P(t,.2,.75));seg(g,[[1196,1300],[1089,947],[998,y]],74,HERO.color);ellipse(g,998,y-10,30,41,C.ink);label(g,'IT STILL WORKS',960,867,41,C.gold);}else{for(let j=0;j<2;j++){let x=726+j*458;box(g,x-99,449,183,187,['#ad8dc5','#7b9fc7'][j],19);ellipse(g,x+32,661,162,57,'#647fa9');}const k=P(t,.2,1);arrow(g,804,764,1118,764,k,'#bd7e96',5);label(g,'PART OF A MONTH',960,877,43,C.gold);}}

function booking(g,t,i){board(g,i.globalT,'screen');box(g,501,240,918,591,'#e1e9fb',18);label(g,'COURSE + PREPAID YEAR',960,348,40,'#405d93');label(g,'$16,988',960,514,96,'#405d93');const k=P(t,.55,.9);box(g,678,651,564,102,k>.6?'#7686c7':'#4d8fbf',14);label(g,k>.6?'BOOKED':'BOOK COURSE',960,702,44,C.cream);
 const y=lerp(1030,715,P(t,0,.65));seg(g,[[1560,1300],[1290,1024],[1098,y]],83,HERO.color);ellipse(g,1098,y-12,33,46,C.ink,.12);if(k>.7)seg(g,[[728,704],[744,720],[778,682]],5,'#f7e8bb');}

function receipt(g,t,i){blurLayer(g,10,g=>W.apartment(g,i.globalT,{},{}));g.save();g.translate(0,66*(1-P(t,0,.6)));box(g,647,157,626,771,C.paper,8);label(g,'RENEW',960,249,47,'#5a6f55');for(let j=0;j<3;j++){label(g,['INITIAL COURSE','$5,000','12 × $999'][j],960,388+j*92,37,'#5a6f55');}seg(g,[[728,691],[1192,691]],2,'#889578');label(g,'TOTAL $16,988',960,763,47,'#5a6f55');if(i.mode==='nextYear')label(g,'NEXT YEAR: TOGETHER',960,874,27,'#5a6f55');seg(g,[[567,1310],[695,1002],[704,900]],75,MOM.color);ellipse(g,706,892,29,39,C.ink);g.restore();}
function hands(g,t,i){blurLayer(g,10,g=>W.apartment(g,i.globalT,{},{}));box(g,-100,761,2200,500,'#c79366');const k=P(t,.12,.85),a=lerp(748,919,k),b=lerp(1181,1000,k);seg(g,[[291,1183],[551,900],[a-55,699]],85,HERO.color);seg(g,[[1774,1166],[1512,904],[b+31,704]],85,MOM.color);ellipse(g,a,697,91,39,C.ink,.1);ellipse(g,b,705,63,35,C.ink,-.1);}

function walk(g,t,i){const bus=i.mode==='bus';const c=set(g,t,i,bus?'busStop':'street',{clean:true});layer(g,c,1,g=>{
 const x=bus?1031-t*37:800+t*38,s=1.86,phase=(x-800)/(s*26)*Math.PI;
 mom(g,x,bus?955:911,s,{young:true,T:i.globalT,expr:bus?'sad':'happy',pose:walkPose(phase,{stride:20,lift:7,arm:7,bob:1.5})});
 if(bus)hero(g,x-257,955,1.87,{T:i.globalT,pose:walkPose(phase+.4,{stride:20,lift:7,arm:7,bob:1.5})});
 });}
function income(g,t,i){board(g,i.globalT,'book');label(g,'NEXT YEAR’S BUDGET',960,178,47,C.gold);for(let j=0;j<2;j++){let x=577+j*766;box(g,x-226,348,452,394,j?'#8e76be':'#648eb9',15);label(g,j?'TUTORING':'PENSION',x,431,38,'#f1e4bf');label(g,j?'TREATMENT':'ORDINARY EXPENSES',x,682,30,'#f5ce8f');for(let n=0;n<4;n++){const k=P(t,n*.2,n*.2+.65),xx=x-68+n*44,yy=lerp(799,570-n%2*10,k);circle(g,xx,yy,18,'#efbd58');ring(g,xx,yy,12,1.5,'#bd8b41');}}}

function schedule(g,t,i){board(g,i.globalT,'calendar');label(g,'TEACHING SCHEDULE',960,168,45,C.gold);for(let j=0;j<6;j++){let x=473+j*168;label(g,['MON','TUE','WED','THU','FRI','SAT'][j],x+67,329,25);for(let k=0;k<3;k++){let y=386+k*138;let filled=k===1&&j%2===0||(i.mode==='mornings'&&k===0)||(i.mode==='saturdays'&&j===5);box(g,x,y,139,114,filled?'#b4ae79':'#59765d',10);if(filled)label(g,'CLASS',x+69,y+56,23,'#385b45');}}}
function reminder(g,t,i){board(g,i.globalT,'paper');box(g,503,277,914,489,'#cad0b2',19);label(g,'TREATMENT RENEWAL',960,365,43,'#4b6d52');label(g,'60 DAYS',960,531,110,'#8c7353');label(g,'APPOINTMENT REMINDER',960,680,29,'#4b6d52');}
function cafe(g,t,i){pair(g,t,i,'cafe',{seated:true,mom:{young:true,expr:'sad'},hero:{expr:'sad'}});}
function jobs(g,t,i){board(g,i.globalT,'cork');label(g,i.mode==='allowed'?'CANCELLING IS ALLOWED':'KEEPING UP AT WORK',960,180,47,C.gold);for(let j=0;j<3;j++){let x=513+j*451;box(g,x-157,341,314,417,'#7a87b6',14);others(g,x,735,1.49,{cast:j?{color:'#859875'}:MOM,bun:j===0,old:j===0,expr:'sad',T:i.globalT});label(g,j===0?'SLOWING DOWN':'MAINTAINED',x,847,25);} }
function pressure(g,t,i){board(g,i.globalT,'cork');const pts=[[526,433],[1389,433],[961,819]];ring(g,960,536,92,5,C.gold);for(let j=0;j<3;j++){let[x,y]=pts[j],k=P(t,j*.15,j*.15+.85);seg(g,[[960,536],[lerp(960,x,k),lerp(536,y,k)]],4,'#f2dcb0');g.save();g.globalAlpha=k;box(g,x-173,y-68,346,136,['#6986bc','#b87fa7','#629eaf'][j],14);label(g,['PAYMENTS','WORK SCHEDULE','RENT'][j],x,y,31);g.restore();}}

function cups(g,t,i){blurLayer(g,8,g=>L.beach(g,i.globalT,{}, {hotel:true}));box(g,-100,874,2200,500,'#9d9274');for(let j=0;j<2;j++){let x=745+j*454;cup(g,x,856,2.3);seg(g,[[x+(j?171:-171),1266],[x+(j?63:-63),972],[x+(j?43:-43),817]],82,j?MOM.color:HERO.color);ellipse(g,x+(j?43:-43),804,35,46,C.ink,j?.3:-.3);}}
function cake(g,t,i){blurLayer(g,9,g=>L.terrace(g,i.globalT,{}));layer(g,camera(t,i),1,g=>{box(g,-200,843,2500,500,'#a28d68');box(g,706,532,509,291,'#c5a379',22);ellipse(g,960,532,255,61,'#e5d7b4');ellipse(g,960,824,277,49,'#d9c9a6');label(g,'100',960,391,126,C.cream);for(let j=0;j<17;j++){let a=j*Math.PI*2/17,x=960+Math.cos(a)*198,y=531+Math.sin(a)*38;box(g,x-4,y-55,8,56,'#ad8e5e',3);ellipse(g,x+Math.sin(i.globalT*6+j)*1.5,y-64,4+Math.sin(i.globalT*5+j)*.7,11+Math.sin(i.globalT*7+j)*1.5,'#ffd679');}});}
function momSea(g,t,i){blurLayer(g,8,g=>L.beach(g,i.globalT,{}, {hotel:true}));closeFace(g,960,555,242,{cast:MOM,bun:true,old:false,expr:'sad',look:[-.8,0],blink:i.globalT%4.4>4.26});}
function end(g,t,i){board(g,i.globalT,'book');if(i.mode==='life'){label(g,'IF YOUTH BECAME A SUBSCRIPTION…',960,350,53);label(g,'WOULD WE BUY MORE LIFE?',960,573,63,C.gold);}else{label(g,'FREEDOM FOR SOME?',960,363,65,C.gold);label(g,'MORE TIME TO PAY FOR OTHERS?',960,559,54);label(g,'WHAT DO YOU THINK?',960,815,31);}}
const views={phone:phoneScene,photo,face:faceScene,stairs,hiking,advert,title,clinic,repair,calendar,memory,music,plans,rules,aging,cta,momMenu,age,dance,beach,cost,savings,bicycle:bicycleScene,classroom,dating,office,benefits,shift,boardroom,waiting,capacity,access,appointment,retirement,comparison,yacht,party,terrace,busStop,split,wealth,staircase,housing,population,email,sacrifice,booking,receipt,hands,walk,income,schedule,reminder,cafe,jobs,pressure,cups,cake,momSea,end};
for(let n=1;n<=156;n++)registerShot('bt'+String(n).padStart(3,'0'),{draw(g,t,i){paperLabels=false;CURRENT=i;const fn=views[i.view];if(!fn)throw Error('Unknown view '+i.view);fn(g,t,i);}});
