# What If You Could Stop Time?

Full illustrated film from the supplied `v2.1.mp3` narration. English, 16:9, 1920×1080, 24 fps. The story timeline contains 186 contiguous shots and ends at 488 seconds; the original narration is 486.635 seconds long. No added speech, subtitles, music or ambience.

The visual language continues the approved Five Doors project: black round-headed figures, warm restrained colour, thin rim light, paper grain, layered sets and selective focus. Every frame is drawn with Canvas 2D; depth comes from framing and parallax. Hero wears the same ochre hoodie and turquoise knitted beanie throughout.

The source audio is the authority. `timeline/rough-asr.json` and `transcript-rough.txt` contain independent PocketSphinx recognition, used only to find editing anchors. They contain recognition errors and are not a verified script or captions. Whisper's model host was unavailable in the execution environment. The published video uses the original audio, not the recognized text.

`story/shots.json` owns all timing. `story/bible.md` records the visual and narrative direction. `scenes/cast.js` defines the character drawing; `scenes/sets` defines locations and props; `scenes/shots` implements the daily-life, explanatory and station-rescue scenes.

## Rebuild from the source archive

The archive contains the project, source narration, engine, renderers and npm manifests. Unpack it and run commands from its `2d-video` directory. Install Node.js and ffmpeg first.

```sh
npm ci
npx playwright install chromium
node render.mjs --project projects/stop-time --sheet --scale 0.4 --gl auto
node render-native.mjs --project projects/stop-time --workers 3 --gl auto --crf 23 --out projects/stop-time/build/full-silent.mp4
ffmpeg -y -i projects/stop-time/build/full-silent.mp4 -i projects/stop-time/input/voiceover.mp3 -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -af apad -t 488 -movflags +faststart stop-time-complete.mp4
```

For this cloud workspace's system Chromium, add `--import ./tools/local-runtime.mjs` immediately after `node`. Keep `--gl auto` for this pure 2D film; forcing SwiftShader significantly slows rendering here.

The final file is checked for the expected frame count, audio/video duration and decoding errors. Representative frame sheets are visually inspected before and after encoding, including carrying people, the table collapse and the spoon drop.
