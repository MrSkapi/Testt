# Stop Time — an afternoon nobody remembers

Source: supplied v2.1.mp3, English narration, 486.635 seconds. Preserve it unchanged. The rough local ASR provides editing anchors, not published captions or a verified verbatim script.

## Look
Continue the approved Five Doors illustrated style: Canvas 2D silhouettes, restrained faces, warm ochre/plum/green sets, thin amber edge light, paper grain, contact shadows. Depth comes from parallax, scale, foreground occlusion and selective focus. No volumetric or plastic 3D characters. The main figure wears an ochre hoodie and turquoise knitted beanie consistently; friend wears gray-green. Separate shoulder roots keep hands clear of the torso. Walking displacement drives the step cycle. Close views retain the same face and beanie geometry.

## Story and locations
1. A phone, a cyclist and a pigeon stop: warm city street, tactile closeups and an expanding freeze ring.
2. Rules and small mischief: a grape becomes an olive at a cafe, then compact red SUBSCRIBE and blue LIKE graphics.
3. Life with a pause button: bedroom, kitchen, office, supermarket, cafe and train platform. Faster cuts, inserts, concise standalone diagrams. A frozen console and microwave preserve the rules.
4. The cost: personal time versus world time, worn shoes, extra meals, aging and lonely crowds. Gradually longer, quieter compositions; subdued warm night palette.
5. The station: establish the concourse, failing bracket, departure board and glass roof. Hold all hazards and bystanders still during the evacuation. Carry the child first, then adults; use trolley and wheelchair for repeated journeys. Cut between interior danger, a top-down clearance plan and the exterior fountain assembly point. No random movement among frozen people. Restore motion only after the final check. Collapse in the empty hall; show families safe outside.
6. Dinner: two meals, a dropped spoon the hero deliberately leaves alone, and time willingly spent listening to his friend. End with the question and grape callback.

## Sound and editorial rules
Only supplied narration. No added wind loop, generated speech, music or effects beds. English labels on separate explanatory graphics; no burned subtitles, head labels or narrator lip sync. Hard cuts dominate, with short freeze flashes, chapter dips and occasional whips. All timing is in shots.json. Build sheets and inspect motion before final rendering.
