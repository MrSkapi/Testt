import {seg,circle,poly,alpha,shade,lerp,clamp} from '/engine/core.js';
import {POSES,walkPose,breathe,posesAt} from '/engine/rig2d.js';
import {C,box,ellipse,shadow} from './sets/props.js';
export {POSES,walkPose,breathe,posesAt};
export const HERO={color:'#bd824e',hat:true};
export const FRIEND={color:'#7c8987',hat:false};
export const WOMAN={color:'#ab6960',hat:false};
export const CLEANER={color:'#7c947e',hat:false};
export const FATHER={color:'#7c8099',hat:false};
export const CHILD={color:'#d2aa64',hat:false};
export function hat(g,x,y,r){
 ellipse(g,x,y-r*.63,r*1.39,r*.20,'#382d2b');
 g.fillStyle='#4e3b31';g.beginPath();g.moveTo(x-r*.83,y-r*.65);g.lineTo(x-r*.69,y-r*1.36);g.quadraticCurveTo(x-r*.4,y-r*1.55,x-r*.02,y-r*1.34);g.quadraticCurveTo(x+r*.32,y-r*1.53,x+r*.66,y-r*1.35);g.lineTo(x+r*.79,y-r*.65);g.closePath();g.fill();
 box(g,x-r*.8,y-r*.83,r*1.59,r*.2,'#201d22',r*.04);seg(g,[[x-r*1.24,y-r*.67],[x-r*.74,y-r*.8],[x-r*.66,y-r*1.28]],r*.04,alpha(C.gold,.6));
}
export function head(g,x,y,r,o={}){
 const f=o.facing??1;g.save();g.translate(x,y);g.scale(f,1);if(o.tilt)g.rotate(o.tilt);
 circle(g,-r*.025,-r*.025,r*1.033,alpha(C.gold,o.rim??.85));circle(g,0,0,r,C.ink);
 const tired=o.expr==='tired',sad=o.expr==='sad',happy=o.expr==='happy',shock=o.expr==='shock';
 const front=o.front??false,ex=front?0:r*.21,yy=-r*.08,l=o.look||[0,0];
 for(let i=0;i<2;i++){let xx=ex+(i?1:-1)*r*(front?.30:.26),sz=i||front?1:.83;if(o.blink){seg(g,[[xx-r*.10,yy],[xx+r*.10,yy]],r*.05,C.cream);}else if(happy){g.strokeStyle=C.cream;g.lineWidth=r*.06;g.beginPath();g.arc(xx,yy+r*.08,r*.13,Math.PI*1.1,Math.PI*1.9);g.stroke();}else{ellipse(g,xx,yy,r*.13*sz,r*(shock?.21:tired?.10:.17),C.cream);circle(g,xx+l[0]*r*.04,yy+l[1]*r*.04,r*.055,C.ink);}}
 if(shock)ellipse(g,ex+r*.03,r*.39,r*.07,r*.10,C.cream);else if(happy){g.strokeStyle=C.cream;g.lineWidth=r*.045;g.beginPath();g.arc(ex+r*.03,r*.24,r*.16,0,Math.PI);g.stroke();}else seg(g,[[ex-r*.07,r*.35],[ex+r*.09,r*(sad?.38:.35)]],r*.045,C.cream);
 if(sad||shock||tired){for(let i=0;i<2;i++){let xx=ex+(i?1:-1)*r*.28;seg(g,[[xx-r*.10,-r*.40+(i?-1:1)*r*.035],[xx+r*.10,-r*.41]],r*.04,alpha(C.cream,.7));}}
 if(o.beard){for(let i=0;i<19;i++){let xx=((i*37)%83-41)*r/100,yy=(.42+Math.abs(xx/r)*.24+(i%3)*.064)*r;seg(g,[[xx,yy],[xx+r*.013,yy+r*.026]],r*.014,'#8b8376');}}
 if(o.hat)hat(g,0,0,r);g.restore();
}
export function person(g,o={}){
 const p=o.pose||POSES.stand,f=o.facing??1,s=o.s??1,c=(o.cast||HERO),cc=c.color;
 if(o.shadow!==false){poly(g,[[o.x-17*s,o.y],[o.x+22*s,o.y+3*s],[o.x-99*s,o.y+39*s],[o.x-138*s,o.y+25*s]],'#090a1124');shadow(g,o.x,o.y+3,36*s,7*s);}
 g.save();g.translate(o.x,o.y);g.scale(f*s,s);if(o.rot)g.rotate(o.rot);if(o.alpha!=null)g.globalAlpha*=o.alpha;
 const sh=p.sh,hip=p.hip,farRoot=[sh[0]-12,sh[1]+2],nearRoot=[sh[0]+12,sh[1]+2];
 // The arms attach to separate shoulders. Neutral hands stay outside the tunic.
 let eb=[p.eB[0]-12,p.eB[1]],hb=[p.hB[0]-13,p.hB[1]],ef=[p.eF[0]+12,p.eF[1]],hf=[p.hF[0]+13,p.hF[1]];
 const leg=(k,foot,col)=>{seg(g,[hip,k,foot,[foot[0]+12,foot[1]]],12,col);seg(g,[[foot[0]-3,foot[1]+3],[foot[0]+13,foot[1]+3]],3,'#4c454244');};
 leg(p.kB,p.fB,'#302b31');
 const arm=(root,e,h,col)=>{seg(g,[root,e,h],12,C.ink);seg(g,[root,e,[lerp(e[0],h[0],.64),lerp(e[1],h[1],.64)]],17,col);circle(g,h[0],h[1],6.5,C.ink);};
 arm(farRoot,eb,hb,shade(cc,-.24));
 poly(g,[[sh[0]-17,sh[1]-4],[sh[0]+16,sh[1]-4],[hip[0]+16,hip[1]+9],[hip[0]-15,hip[1]+9]],cc);
 poly(g,[[sh[0]-17,sh[1]-3],[sh[0]-8,sh[1]+3],[hip[0]-7,hip[1]+8],[hip[0]-15,hip[1]+9]],shade(cc,-.15));
 seg(g,[[sh[0]+6,sh[1]+9],[hip[0]+7,hip[1]+3]],1.3,alpha(C.cream,.2));
 seg(g,[[hip[0]-12,hip[1]+5],[hip[0]+13,hip[1]+5]],4,shade(cc,-.24));
 if(c===HERO){ellipse(g,sh[0]-2,sh[1]-4,20,8,shade(cc,-.23),-.1);seg(g,[[sh[0]+1,sh[1]+4],[sh[0]+1,sh[1]+26]],1.9,C.cream);seg(g,[[sh[0]+8,sh[1]+4],[sh[0]+8,sh[1]+25]],1.9,C.cream);}
 leg(p.kF,p.fF,C.ink);arm(nearRoot,ef,hf,cc);
 seg(g,[[sh[0]-15,sh[1]+3],[hip[0]-14,hip[1]-5]],1.5,alpha(C.gold,.5));
 head(g,p.head[0],p.head[1],27,{hat:c.hat,expr:o.expr,look:o.look,blink:o.blink,beard:o.beard});
 if(o.prop)o.prop(g,hf,hb);g.restore();
}
export function closeFace(g,x,y,r,o={}){
 const c=o.cast||HERO;ellipse(g,x,y+r*1.53,r*1.15,r*.57,c.color);
 if(c===HERO){ellipse(g,x,y+r*1.1,r*.65,r*.21,shade(c.color,-.25));seg(g,[[x-r*.1,y+r*1.1],[x-r*.12,y+r*1.57]],r*.023,C.cream);seg(g,[[x+r*.1,y+r*1.1],[x+r*.12,y+r*1.57]],r*.023,C.cream);}
 head(g,x,y,r,{...o,hat:c.hat,front:true});
}
