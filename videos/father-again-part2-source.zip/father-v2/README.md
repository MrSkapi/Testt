# AGAIN, Part 2 — Better Than Ever

Complete illustrated continuation for fatherV2.mp3. 1920×1080, 24fps, 16:9, 60px letterbox bars. 477 seconds (7:57), 160 shots, 11,448 frames. Original audio duration: 475.924898 seconds; the last visual hold adds about one second. The narration is neither retimed nor replaced. No subtitles, added music or SFX.

The established hero remains black with an orange hoodie and no hat. The two independent accounts keep their teal/mauve shirts and phone/laptop positions. The one-day physical body uses the same teal Father design.

Install father-v2/ as projects/father-v2/ in the 2d-video toolkit. Apply kit-overrides/ to the toolkit root. Install npm dependencies, ffmpeg and Chromium. tools/local-runtime.mjs selects /usr/bin/chromium here; adjust that path on another machine.

Render:

    node --import ./tools/local-runtime.mjs render-native.mjs --project projects/father-v2 --workers 3 --gl auto --crf 21 --out projects/father-v2/build/full-silent.mp4

Mux the original narration without retiming:

    ffmpeg -i projects/father-v2/build/full-silent.mp4 -i projects/father-v2/input/voiceover.mp3 -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -af apad -t 477 -movflags +faststart father-again-part2.mp4

The authoritative timeline is story/shots.json. story/beats.tsv and build_story.py document/reproduce the editorial shot plan. timeline/rough-asr.json and words.json contain imperfect local ASR for timing, never verified captions.

scenes/main.js contains the scene-specific acting and prop actions. animation.js supplies planted footsteps and shoulder-attached arm IK; cast.js preserves the previous characters; objects.js draws the actual screens/props. sets/continuation.js adds the new morning entry, evening rooms/garage and moving drive scenery. base.js contains only shared figure/card helpers.

Use --from A --to B --scale .5 for previews. Do not run two native video renders into this same project's build directory simultaneously because the intermediate encoder files are shared.

validation/ contains timing/source checks, final media/audio QC, and representative silent motion proof clips. story/bible.md records narrative, visual and continuity decisions.
