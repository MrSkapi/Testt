# AGAIN, Part 2 — Better Than Ever

## Story and continuity

The supplied English narration is the source of truth. This is a continuation of the completed fatherV1.1 chapter, not a replacement edit. At Mother's kitchen table, Evan's teal reconstruction and Mother's mauve reconstruction disagree because their accounts contain different conversations. AGAIN 2.0 will rebuild both from saved records while retiring their running instances. Evan discovers product recommendations influenced the request to sell the blue car. A refundable one-day physical-body demonstration gives the family one last shared day before the upgrade deadline.

The first physical hug has a delayed response; the final hug has simultaneous arm movement. The body does not breathe, drink or eat. It can hold a cup, work on the car, joke and handle a phone. Mother says goodbye to her own copy in a clearly warm/daylight flashback. Automatic renewal and rebuild stay off after cancellation, including during the discount offers. The repaired blue car remains with the family. The next-day drive has Evan and Mother only. The final email contains a still archived portrait, not a live surviving instance.

## Cast

- Evan: the established black round head, minimal cream face, orange hoodie #ed9437, black limbs, no headwear. Same proportions and silhouette as Part 1.
- Father's original reconstruction: crooked pale rectangular glasses, black round head, teal geometric-patterned shirt #459b91. Phone on the left in the opening device pair; the same account can also appear on Evan's laptop.
- Mother's separate reconstruction: the same recognisable face/glasses, mauve patterned shirt #a26a98, laptop on the right. Never recolour or swap the two copies in the opening.
- Physical demonstration body: same teal Father design, not a generic shiny 3D robot. Appears only at the narrated delivery. No breathing idle; purposeful poses and blinks remain.
- Mother: purple top #ac7bc6, grey hair/bun, minimal black/cream face.
- Technician: restrained pale blue #7babc4, tablet, delivery van.
- Live support representative: blue #749bb5, headset, shown within a physical call screen.

## Locations and colour

- Mother's kitchen: established peach walls, lilac cupboards, cups, towel, coffee tin and framed art; stable conversation positions.
- Update/settings/support pages: physical devices and table, never floating paragraphs over heads. Teal/gold UI, readable English labels.
- Server explanation: navy/cyan racks with records flowing between clearly framed current/new models. No literal brain transfer is depicted.
- Morning entry: cream pavement, turquoise door, pastel houses, plant, trees, delivery van; warm sunlight and contact/cast shadows.
- Garage: established blue masonry, red tool drawers, overhead warm strip, tyres, familiar blue car. Roof-touch macro, dropped bolts, repair montage and bench conversation.
- Evening kitchen/garage: violet shadows, muted warm practicals, deeper blue car scene. A physical 23:00 clock marks the narrated hour before midnight.
- Car interior: drawn two-person windshield composition; layered green/cyan/gold scenery moves independently of the car. Driver and Mother are visible and Father's absence is clear.
- Closing room: night window and warm lamp, unread email, family photograph, keys, coffee and closed laptop.

## Animation and editing

160 contiguous shots, median 3 seconds, on a 24fps grid. The original narration is never retimed, reordered, replaced or supplemented. Rough local ASR is only an editorial aid and is never displayed as verified captions.

The camera uses constant scale 1.025 and one absolute sequence clock for subtle lateral motion. Medium shots are intentional composition cuts at fixed scale. No animated zoom transitions, repeated zoom restarts, arbitrary shaking or position-swapping characters.

Footsteps use fixed world-space supporting feet. Hands connect to rig shoulders through a two-bone arm solver. Key actions include the update popup, separate histories, settings toggle and cancellation, delayed/instant hugs, three coffees, a two-hand cup hold without sipping, roof contact, dropped bolts, covering the wrist alert, playing/pausing a repair video, Mother's hand taking Evan's, and putting the old phone away. Prop close-ups provide editorial action without making every scene a generic gesturing portrait.

Use layered sets, practical glows, dust, silhouette rim light, foot/cast shadows, and selective foreground/background blur. Preserve flat drawn forms; depth comes from composition/parallax, not a realistic 3D redesign.

## Audio and text

Original fatherV2.mp3 only. No added music, wind, SFX or replacement speech. All authored UI and closing question text is English. No subtitles or dialogue labels above heads. An unread portrait/email stays visually still after the farewell.
