from pathlib import Path
import json,csv,statistics
p=Path(__file__).resolve().parent.parent
words=json.loads((p/'timeline/rough-asr.json').read_text())['words']
beats=[]
for row in (p/'story/beats.tsv').read_text().strip().splitlines():
 a=row.split('|');beats.append({'start':float(a[0]),'view':a[1],'mode':a[2],'tag':a[3] if len(a)>3 else ''})
groups=[(0,54),(54,77.7),(77.7,100.1),(100.1,144),(144,193.1),(193.1,208.3),(208.3,223.3),(223.3,243.8),(243.8,272.2),(272.2,298.3),(298.3,307.6),(307.6,339.2),(339.2,370.5),(370.5,385),(385,406.7),(406.7,437.8),(437.8,456.8),(456.8,477)]
scenes={'tableCalls':'Mother and Evan sit at the same stable kitchen table; teal Father remains on the held phone and mauve Father on the laptop.','twoScreens':'Close two-device composition continues the previous film: phone left, laptop right, two independent reconstructions.','oneScreen':'Insert of the appropriate physical device, with meaningful eye line and restrained quoted-dialogue mouth motion.','reaction':'A held character reaction in the real location, changing expression on the narration beat.','update':'Readable product-update notice inside a real screen; details and the rebuild warning are disclosed in order.','histories':'Separate conversation histories show different information reaching the two independent accounts.','support':'A live human representative in a physical support-call screen, not an automated FAQ answer.','rebuild':'A server diagram illustrates that records transfer while the running reconstruction does not.','settings':'Product recommendations and their history reveal the suggestion to sell unused assets; the toggle can be disabled without erasing Dad.','booking':'The one-day Presence demonstration is booked without a purchase promise.','coffeeLocation':'Two copies compare the kitchen coffee location while Mother reacts; Dad remains on the devices.','arrival':'A technician and delivery van arrive; the physical body wears Dad’s unchanged teal patterned shirt and crooked glasses.','awake':'Close-up: the delivered body opens its eyes.','hug':'A grounded hug with attached arms; the first response is delayed, the final response is immediate.','shoulder':'Close-up of a warm but unmoving shoulder; Evan continues to hold on.','motherDoor':'Mother appears in the kitchen doorway and recognises the familiar terrible shirt.','kitchenBody':'Three people share a physical table; Dad can hold a cup but never drinks or eats.','pour':'Mother pours three coffees, then remembers the body cannot drink.','holdCup':'Both hands close around the untouched coffee cup.','garagePair':'The same blue car and tool wall; Father and Evan work, joke and share their limited day.','roof':'Macro: Dad runs a teal-sleeved hand along the car roof.','bolt':'A bolt falls from the active character’s hand and hits the garage floor.','wrist':'A wrist system-upgrade indicator lights; the sleeve covers it.','repairVideo':'A family repair video is played/paused on a real phone, distinct from the physical Father watching it.','bench':'Evan sits beside the physical Father and talks about continuity and replacement.','purchase':'The purchase page cannot preserve this running version, even if they buy the body.','records':'Successive model/server replacements explain the repeated dilemma.','work':'Evan checks Dad’s phone call at work instead of looking at his surroundings.','night':'A late-night call and tired Evan make the emotional dependence concrete.','hands':'Mother takes Evan’s hand across the kitchen table.','motherGoodbye':'Daylight flashback: Mother closes her separate mauve account before the evening decision.','cancel':'Automatic renewal and rebuild are cancelled; sequential discount offers do not change the decision.','farewell':'Warm night garage, running blue car, approaching collection van and a restrained farewell.','drive':'Next afternoon: Evan drives Mother in the repaired blue car; warm moving scenery, Father absent.','habit':'A hand reaches for the old Dad app, finds it offline, then puts the phone away.','email':'An unread evening email offers a new reconstruction; the archived face is a still image.','ending':'The unopened laptop, family photograph, keys and coffee hold the closing question in the real room.'}
shots=[]
for n,b in enumerate(beats):
 start=round(b['start']*24)/24;end=round(beats[n+1]['start']*24)/24 if n+1<len(beats) else 477
 group=next(x for x in groups if x[0]<=b['start']<x[1]);v=b['view'];m=b['mode'];tag=b['tag'];place='kitchen'
 if 223.3<=start<243.8:place='entry'
 elif 272.2<=start<339.2:place='garage'
 elif 339.2<=start<406.7:place='kitchenNight'
 elif 406.7<=start<437.8:place='garageNight'
 elif 437.8<=start<456.8:place='parkRoad'
 elif start>=456.8:place='room'
 params={'view':v,'mode':m,'place':place,'groupStart':group[0],'groupEnd':group[1],'speaker':tag if tag in ['a','b'] else None,'variant':tag=='b','role':tag if tag in ['mom','dad'] else 'hero','speak':tag in ['a','b'],'night':start>=339.2}
 if v=='oneScreen' and start>385:params['place']='kitchenNight'
 if v in ['tableCalls','kitchenBody','bench','garagePair','farewell'] and n%3==1 and m not in ['cover','clock','hour','van','reach']:
  params.update(frame='medium',focusX=1000,focusY=660)
 if v=='motherDoor':params.update(frame='medium',focusX=1130,focusY=625)
 # Avoid artificial motion reset: static framing scale, shared absolute sequence pan.
 tr='cut'
 if b['start'] in [223.3,272.2,406.7,437.8,456.8]:tr='dip'
 if b['start'] in [92.0,193.1,363.6]:tr='fade'
 line=' '.join(w['word'] for w in words if start<=w['start']<end)
 shots.append({'id':f'fb{n+1:03}','start':start,'end':end,'line':line,'scene':scenes[v]+' Beat: '+m,'set':place,'bars':'wide','captions':False,'in':{'type':tr,'dur':.20},'params':params,'sfx':[],'notes':'Editorial timing from rough local ASR; original voiceover is authoritative. No captions.'})
(p/'story/shots.json').write_text(json.dumps({'title':'AGAIN Part 2 — Better Than Ever','duration':477,'shots':shots,'music':[],'sfx':[]},indent=2))
(p/'timeline/words.json').write_text(json.dumps(words,indent=2))
with (p/'story/scene-markers.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['id','start','end','view','mode','scene']);w.writerows([x['id'],x['start'],x['end'],x['params']['view'],x['params']['mode'],x['scene']] for x in shots)
print(len(shots),'shots, duration',shots[-1]['end'],'median',statistics.median(s['end']-s['start'] for s in shots))
