# 24 hours as North Korea’s leader

A hypothetical day, following the supplied English narration exactly. Comedy about a fallen spoon gives way to the limits of power, an ordinary travel request, and the sound of a mother and son speaking naturally. The real-world background and the imagined deliveryman are kept distinct by the narration; authored labels do not add unsourced statistics or personal details.

## Cast

- Protagonist: approved rounded-square black face, swept hair, charcoal four-pocket high-collar tunic, trousers, shoes. Amber left rim and blue right rim use the actual composed alpha silhouette. Rim is approximately 1.5 output pixels thicker than the approved v2 preview, consistently across shot scales.
- Aides and officers: short hair, olive buttoned jackets, black faces; clipboards and restrained nervous reactions.
- Deliveryman: brown jacket, delivery cart, later a phone held at his ear. A single persistent person at every stage of the request.
- Shopkeeper: muted blouse and apron, hair bun.
- Mother: grey hair and bun, glasses and shawl, rural home. Only mother and son appear in the reunion and call.

## Locations and visual progression

Breakfast room with tall windows and curtains; palace corridor with doors and guards; workshop with a machine and empty operator chair; Pyongyang streets and motorcade; military briefing with maps and illustrative photographs; ordinary grocery shop; building steps and delivery cart; wood-paneled office; crowd and lectern; rural home; the viewer’s own bedroom.

Warm muted palette, black figures, contact shadows, parallax planes, shallow depth of field, restrained grain and slow camera movement. Drawn shapes throughout, no photorealistic anatomy or 3D character meshes.

## Motifs and timing

Spoon -> frightened reactions -> empty chair -> travel permit -> missing transport -> one car redirected to an ordinary person -> speech and unkept promises -> ordinary family conversation -> reply to Mom.

211 shots across 495 seconds; 24 fps, 1920x1080. Source voiceover is 493.844898 seconds, unretimed and complete; final hold adds approximately 1.16 seconds. No subtitles, added speech, music or SFX. Red SUBSCRIBE / blue LIKE appear once at the spoken subscription cue. No dialogue text above heads.
