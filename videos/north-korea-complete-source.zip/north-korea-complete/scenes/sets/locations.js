import {layer,blurLayer,backdrop,veil,seg,poly,circle,ring,alpha,shade,text,FONTS,lerp,ease,rng} from '/engine/core.js';
import * as FX from '/engine/fx2d.js';
import {C,box,ellipse,shadow,car,plant,clock,phone,book} from './props.js';
export const GY=948;
export const camera=(t,i,o={})=>({z:1+.04*ease.inOut(t/i.dur),x:lerp(-12,12,ease.inOut(t/i.dur)),y:0,...o});
function floor(g,y=865,c='#655e55'){box(g,-2000,y,6000,1800,c);for(let j=0;j<11;j++)seg(g,[[-2000,y+17+j*j*5],[4000,y+17+j*j*5]],1,'#c3b49421');for(let j=-7;j<14;j++)seg(g,[[960+j*110,y],[960+j*390,1700]],1,'#c8b99e16');}
export function dust(g,t){FX.dust(g,t,{count:24,color:C.gold,a:.12,size:1.4,speed:5});}
export function flag(g,x,y,s=1){g.save();g.translate(x,y);g.scale(s,s);box(g,0,0,168,87,'#476a84');box(g,0,13,168,61,'#d1c5ad');box(g,0,18,168,51,'#9f5147');circle(g,49,43,19,'#dccfb5');star(g,49,43,14,'#a4473f');g.restore();}
function star(g,x,y,r,c){let p=[];for(let j=0;j<10;j++){const a=j*Math.PI/5-Math.PI/2;p.push([x+Math.cos(a)*(j%2?r*.42:r),y+Math.sin(a)*(j%2?r*.42:r)]);}poly(g,p,c);}
export function corridor(g,t,c,o={}){
 layer(g,c,.15,g=>backdrop(g,['#4c4543','#a58c6b']));
 layer(g,c,.42,g=>{
  poly(g,[[400,70],[1520,70],[1295,850],[625,850]],'#89765c');
  box(g,714,268,492,584,'#413b34');box(g,733,284,454,568,'#6c5541');
  for(let j=0;j<3;j++)seg(g,[[745,405+j*127],[1171,405+j*127]],3,'#b0926b');
  for(let x of[901,1017])circle(g,x,598,7,C.gold);
  floor(g,852,'#756c60');poly(g,[[746,854],[1174,854],[1530,1600],[390,1600]],'#774b43');
  for(let j=0;j<5;j++)for(let side of[-1,1]){let x=960+side*(340+j*177);box(g,x-29,50+j*22,58,816-j*18,'#b3a086');box(g,x-39,52+j*22,78,24,'#cbbb9d');box(g,x-38,850,76,22,'#978166');}
 });
 layer(g,c,.69,g=>{if(o.open){const k=ease.inOut(o.open);box(g,737,288,446,566,'#c4b194');poly(g,[[737,288],[737+194*(1-k*.75),310],[737+194*(1-k*.75),850],[737,850]],'#6c5541');poly(g,[[1183,288],[1183-194*(1-k*.75),310],[1183-194*(1-k*.75),850],[1183,850]],'#6c5541');}plant(g,289,886,1.4);plant(g,1645,886,1.4);});dust(g,t);
}
function tower(g,x,y,w,h,c){box(g,x,y-h,w,h,c);for(let j=0;j<Math.floor(w/23);j++)for(let k=0;k<Math.floor(h/36);k++)box(g,x+8+j*23,y-h+13+k*36,10,17,'#b6b3a55c');}
export function city(g,t,c,o={}){
 layer(g,c,.15,g=>{backdrop(g,o.night?['#242b35','#71665d']:['#6a7a82','#c4b18e']);if(!o.night)FX.sun(g,1470,175,43,'#ead4a5',C.gold,3);});
 layer(g,c,.38,g=>{
  for(let j=-2;j<11;j++)tower(g,j*224,716,185,230+(j*83%200),['#69797b','#92968a','#7b8581'][((j%3)+3)%3]);
  poly(g,[[1260,713],[1368,156],[1459,713]],'#8b928b');poly(g,[[1368,156],[1380,713],[1459,713]],'#697b7b');
  for(let k=0;k<13;k++)seg(g,[[1300+k*4,641-k*28],[1423-k*3,641-k*28]],1,'#d3c9ac55');
 });
 layer(g,c,.64,g=>{
  floor(g,800,'#857e70');box(g,-2000,724,6000,173,'#4c5358');for(let j=-4;j<12;j++)box(g,j*260,813,121,8,'#cabfaa');
  box(g,128,569,21,193,'#8c9181');box(g,80,472,120,104,'#9ca18e');poly(g,[[111,472],[123,401],[136,401],[145,472]],'#939d8a');
  box(g,1621,480,220,191,'#4e605b',6);box(g,1633,490,196,137,'#8c9d89');
  if(o.display){box(g,1641,497,180,121,'#acb79e');circle(g,1731,537,22,C.ink);poly(g,[[1697,608],[1707,563],[1757,563],[1770,608]],'#45474a');}
  for(let x of[495,1011,1558]){seg(g,[[x,752],[x,398],[x+35,398]],6,'#465750');circle(g,x+35,402,11,'#d8ca9b');}
 });dust(g,t);
}
export function motorcade(g,t,c,o={}){city(g,t,c,o);layer(g,c,.86,g=>{for(let j=2;j>=0;j--){let x=597+j*481-(o.move?((t*84)%481):0);car(g,x,888,.88,'#292e33');}});}
export function carInterior(g,t,c,o={}){
 blurLayer(g,3,g=>city(g,o.moving===false?0:t,{...c,x:c.x-(o.moving===false?0:(t*31)%160)},{display:o.display,night:o.night}));
 layer(g,c,.77,g=>{box(g,-300,-200,2500,390,'#292e31');box(g,-300,694,2500,700,'#353637');box(g,-300,693,2500,18,'#a59270');box(g,1572,165,62,533,'#292f32');box(g,-20,161,84,537,'#292f32');poly(g,[[65,165],[191,165],[65,699]],'#2d3436');box(g,469,791,810,311,'#4f4b46',60);box(g,487,732,785,146,'#57514a',43);seg(g,[[491,854],[1251,854]],2,'#8c7e6955');box(g,1267,786,480,157,'#45443f',25);box(g,1349,840,134,14,'#a3a28d',7);});
}
export function factory(g,t,c,o={}){
 layer(g,c,.12,g=>backdrop(g,['#455a58','#858f7c']));
 layer(g,c,.32,g=>{
  for(let j=0;j<6;j++){let x=60+j*352;box(g,x,108,280,405,'#394d4b',5);box(g,x+11,120,258,378,'#8baca0');for(let k=0;k<4;k++)box(g,x+66+k*54,120,5,377,'#536c63');box(g,x+11,307,258,8,'#536c63');}
  floor(g,821,'#697268');for(let x of[11,693,1375])box(g,x,30,19,800,'#52665b');
 });
 layer(g,c,.65,g=>{
  seg(g,[[-100,78],[2000,78]],26,'#6a7867');for(let x of[256,946,1641]){seg(g,[[x,79],[x,151]],4,'#394d47');ellipse(g,x,162,61,16,'#9caa85');FX.lightCone(g,x,180,{color:C.gold,a:.07,len:650,spread:.4});}
  machine(g,1160,830,1.25,t,o);box(g,1681,653,139,180,'#4c6055',8);box(g,1700,673,101,67,'#273f3c',5);
  box(g,409,676,72,11,'#686755',4);for(let dx of[-24,24])seg(g,[[445+dx,683],[445+dx*1.4,833]],8,'#3d4942');box(g,467,558,10,123,'#5c6653',4);box(g,405,555,71,20,'#6d715b',5);
 });dust(g,t);
}
export function machine(g,x,y,s,t,o={}){g.save();g.translate(x,y);g.scale(s,s);
 shadow(g,0,4,270,19);box(g,-275,-246,550,246,'#536e60',12);box(g,-266,-235,335,165,'#6c8a72',7);box(g,88,-228,165,193,'#3b574e',9);
 for(let j=0;j<4;j++){circle(g,-204+j*76,-150,23,'#233f3a');ring(g,-204+j*76,-150,17,3,'#9eae8c');let a=t*.4+j;seg(g,[[-204+j*76,-150],[-204+j*76+Math.sin(a)*13,-150-Math.cos(a)*13]],2,C.gold);}
 box(g,-264,-61,333,37,'#3c5147',6);for(let j=0;j<12;j++)box(g,-246+j*25,-55,12,24,'#6f8370',2);
 box(g,113,-211,112,68,'#213c39',6);for(let j=0;j<3;j++)seg(g,[[127,-193+j*15],[205,-193+j*15]],2,'#8da889');
 for(let j=0;j<3;j++)circle(g,136+j*32,-107,8,j===0?'#b08453':'#667c60');
 seg(g,[[-273,-241],[66,-241]],2,'#b3b991');g.restore();}
export function office(g,t,c,o={}){
 layer(g,c,.2,g=>{
  backdrop(g,o.night?['#2f343a','#655b50']:['#535a59','#9b9279']);
  box(g,300,101,598,556,'#354747',8);box(g,320,121,558,516,o.night?'#485964':'#b7beaa');
  for(let j=0;j<7;j++)tower(g,334+j*81,638,61,190+(j*37%116),o.night?'#33434d':'#798d84');
  box(g,597,120,14,520,'#505b52');box(g,321,373,557,12,'#505b52');
  floor(g,822,'#5c554d');
 });
 layer(g,c,.59,g=>{
  box(g,1163,90,561,639,'#4b463d',4);
  for(let j=0;j<4;j++){box(g,1176,221+j*137,534,12,'#9b855c');for(let k=0;k<14;k++){let x=1195+k*36;book(g,x,126+j*137,22,90,['#756348','#5c7265','#845e4b'][k%3]);}}
  plant(g,1830,849,1.5);flag(g,75,159,.9);seg(g,[[72,156],[72,830]],5,'#a68b57');
  box(g,333,814,1215,55,'#846044',10);box(g,333,869,1215,106,'#644d3b',5);for(let x of[385,1450])box(g,x,949,36,200,'#42382f');
  box(g,1143,744,92,61,'#8d7752',8);seg(g,[[1154,743],[1225,743]],12,'#1f2d2e');
  box(g,1263,793,169,16,'#bfad8b',3);
 });dust(g,t);
}
export function briefing(g,t,c,o={}){
 layer(g,c,.2,g=>backdrop(g,['#283e3f','#626d5d']));
 layer(g,c,.48,g=>{
  floor(g,843,'#525b55');box(g,370,106,1182,573,'#344c47',10);box(g,384,119,1154,548,'#64796b');
  for(let j=0;j<12;j++)seg(g,[[395+j*99,128],[395+j*99,653]],1,'#b2be9c22');for(let j=0;j<6;j++)seg(g,[[395,150+j*91],[1525,150+j*91]],1,'#b2be9c22');
  peninsula(g,974,382,1.6,'#b2b695');
  for(let j=0;j<2;j++){box(g,72+j*1551,253,194,265,'#d0c3a3',5);box(g,85+j*1551,266,168,237,'#758578');poly(g,[[143+j*1551,456],[164+j*1551,300],[185+j*1551,456]],'#3a504e');box(g,139+j*1551,457,49,12,'#354947');}
 });layer(g,c,.85,g=>{ellipse(g,960,871,691,102,'#384b43');ellipse(g,960,845,691,102,'#87947d');box(g,791,801,205,45,'#ddd0ac',3);box(g,1117,814,124,15,'#ddd0ac',3);});dust(g,t);
}
export function peninsula(g,x,y,s=1,color=C.gold){g.save();g.translate(x,y);g.scale(s,s);poly(g,[[-42,-143],[30,-123],[14,-86],[52,-47],[34,-23],[61,32],[29,59],[22,111],[-1,138],[-20,91],[-47,47],[-26,12],[-59,-33],[-38,-72],[-64,-104]],color);seg(g,[[-40,13],[44,-13]],2,'#5d7160');circle(g,-14,-20,4,'#aa6550');g.restore();}
export function shop(g,t,c,o={}){
 layer(g,c,.2,g=>{backdrop(g,['#5c655c','#a59677']);floor(g,832,'#7c7666');});
 layer(g,c,.46,g=>{
  for(let j=0;j<3;j++){let x=197+j*557;box(g,x,140,450,514,'#506455',5);for(let k=0;k<4;k++){box(g,x+7,249+k*108,435,12,'#b7a278',3);for(let n=0;n<9;n++){let xx=x+22+n*46;box(g,xx,198+k*108,28,47,['#a18153','#73836b','#b4a47b','#9b6d50'][n%4],3);seg(g,[[xx+6,219+k*108],[xx+22,219+k*108]],3,'#d2c49d');}}}
  box(g,137,720,1637,33,'#ab916b',5);box(g,154,753,1603,214,'#6c745f');for(let j=0;j<6;j++)box(g,178+j*261,787,228,141,'#79836b',3);
 });dust(g,t);
}
export function cart(g,x,y,s=1){g.save();g.translate(x,y);g.scale(s,s);shadow(g,0,5,146,15);for(let a of[-94,94]){circle(g,a,-16,22,'#222b2c');circle(g,a,-16,11,'#8c967e');}box(g,-139,-160,278,135,'#8b7751',8);box(g,-145,-36,290,14,'#514d3f');for(let j=0;j<4;j++){box(g,-127+j*69,-145,59,98,'#ab9366',3);seg(g,[[-98+j*69,-145],[-98+j*69,-47]],9,'#ccb180');}seg(g,[[-138,-27],[-181,-38],[-186,-150],[-222,-150]],8,'#4e594d');g.restore();}
export function exterior(g,t,c,o={}){city(g,t,c,o);layer(g,c,.75,g=>{
 box(g,129,111,640,712,'#8f8f7b');box(g,191,224,495,592,'#3f524c',4);box(g,210,244,454,570,'#a5b39b');box(g,414,245,13,569,'#536959');box(g,191,812,495,19,'#c2baa0');
 box(g,136,824,622,28,'#a9a28b');box(g,113,851,667,28,'#939481');box(g,91,879,713,28,'#b7ad92');
 if(o.cars){car(g,1357,893,.89,'#2e3338');car(g,1830,891,.89,'#2b3035');}
 });}
export function venue(g,t,c,o={}){
 layer(g,c,.15,g=>backdrop(g,['#393f3c','#a8906c']));
 layer(g,c,.42,g=>{box(g,-500,120,3000,645,'#76584a');for(let j=0;j<10;j++){let x=j*220-100;poly(g,[[x,120],[x+166,120],[x+181,756],[x-7,756]],j%2?'#7f5948':'#6a4a40');seg(g,[[x+33,145],[x+29,716]],3,'#b48e6655');}flag(g,402,191,1.3);flag(g,1324,191,1.3);floor(g,766,'#706250');});
 layer(g,c,.68,g=>{box(g,786,611,348,270,'#75543d',10);box(g,768,594,383,31,'#a4835d',7);seg(g,[[973,595],[979,509],[1026,491]],6,'#303f3c');circle(g,1034,489,11,'#263532');});
 layer(g,c,1.18,g=>{for(let row=0;row<3;row++)for(let j=0;j<14;j++){let x=-40+j*158+(row%2)*79,y=954+row*79;ellipse(g,x,y+61,56+row*5,64,'#2d3833');circle(g,x,y,29+row*4,'#151b1c');if(o.faces&&row===0){ellipse(g,x-9,y-4,4,5,C.cream);ellipse(g,x+8,y-4,4,5,C.cream);}}});dust(g,t);
}
export function bedroom(g,t,c){
 layer(g,c,.25,g=>{backdrop(g,['#373e48','#817460']);floor(g,827,'#665a4c');box(g,256,100,535,551,'#33444a');box(g,276,119,495,511,'#657d89');circle(g,615,243,30,'#d4d4ba');box(g,515,120,13,510,'#444f52');box(g,278,379,494,12,'#444f52');});
 layer(g,c,.65,g=>{box(g,728,619,826,291,'#4c4941',24);box(g,748,636,784,79,'#c5b496',27);box(g,866,663,675,190,'#66817b',35);box(g,750,621,191,79,'#dbd0b4',20);box(g,1609,656,244,224,'#8e6b48',8);clock(g,1731,619,58,'00:00',true);});dust(g,t);
}
