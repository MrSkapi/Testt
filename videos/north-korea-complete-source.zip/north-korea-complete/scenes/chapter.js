import {layer,blurLayer,backdrop,veil,seg,poly,circle,ring,alpha,shade,text,FONTS,ease,prog,lerp,clamp} from '/engine/core.js';
import * as FX from '/engine/fx2d.js';
import {hero,aide,face} from './cast.js';
import {C,box,ellipse,shadow,plate,cup,clock,phone,car,book,arrow,playIcon} from './sets/props.js';
import {room,chair,diningTable,spoon,wide,closeHero} from './opening.js';
import * as W from './sets/locations.js';
const P=(t,a=0,b=1)=>ease.inOut(prog(t,a,b));
const CAM=W.camera;
function label(g,s,x,y,size=30,c=C.cream){text(g,s,x,y,{size,font:FONTS.ui,color:c});}
function board(g,t){backdrop(g,['#384b46','#242f31']);for(let j=0;j<24;j++)seg(g,[[j*89,-100],[j*89,1400]],1,'#b2c4a50a');for(let j=0;j<14;j++)seg(g,[[-100,j*91],[2100,j*91]],1,'#b2c4a50a');W.dust(g,t);}
function set(g,t,i,name='office',o={}){const c=CAM(t,i);if(name==='room')room(g,i.globalT,c);else W[name](g,i.globalT,c,o);return c;}
function personAt(g,x,y,s,o={}){hero(g,x,y,s,{blink:(o.T||0)%4.6>4.47,...o});}
function page(g,x=960,y=570,s=1,o={}){g.save();g.translate(x,y);g.scale(s,s);g.rotate(o.rot??-.025);box(g,-262,-333,524,666,C.paper,5);box(g,-247,-318,493,637,'#ded1b3',3);if(o.heading)label(g,o.heading,0,-255,27,'#4c5e50');for(let j=0;j<(o.lines??10);j++)seg(g,[[-201,-172+j*43],[170-(j%3)*38,-172+j*43]],3,'#79816c77');g.restore();}
function clipboard(g,x,y,s=1){g.save();g.translate(x,y);g.scale(s,s);box(g,-60,-94,120,170,'#5c5b46',7);box(g,-50,-83,100,148,C.paper,2);box(g,-19,-98,38,15,'#787d66',3);for(let k=0;k<5;k++)seg(g,[[-33,-49+k*21],[32,-49+k*21]],2,'#929179');g.restore();}
function civilian(g,x,y,s=1,o={}){
 aide(g,x,y,s,{color:o.mother?'#7e8270':o.woman?'#82756b':'#8a7a62',bend:o.bend||0,phone:o.phone,prop:o.phone?(g,hx,hy)=>phone(g,hx-10,hy-5,.22):null,blink:o.blink});
 if(o.woman){ellipse(g,x-31*s,y-326*s,14*s,17*s,C.ink);poly(g,[[x-20*s,y-239*s],[x+20*s,y-239*s],[x+30*s,y-114*s],[x-30*s,y-114*s]],'#b3ad91');seg(g,[[x-19*s,y-239*s],[x-22*s,y-251*s]],2*s,C.paper);}
 if(o.mother){
  g.save();g.translate(x,y);g.scale(s,s);
  ellipse(g,-37,-320,13,15,'#939889');
  g.beginPath();g.moveTo(-36,-310);g.bezierCurveTo(-47,-335,-12,-342,14,-337);g.quadraticCurveTo(34,-334,36,-313);g.lineTo(29,-308);g.quadraticCurveTo(11,-326,-13,-320);g.quadraticCurveTo(-31,-319,-33,-302);g.closePath();g.fillStyle='#9c9e8d';g.fill();
  for(let xx of[-15,16])ring(g,xx,-294,11,1.1,'#b8b8a1');seg(g,[[-4,-294],[5,-294]],1,'#b8b8a1');
  poly(g,[[-33,-247],[0,-230],[31,-247],[33,-166],[0,-191],[-33,-166]],'#68766c');
  g.restore();
 }

}
function locationFor(T){return T<95?'room':T<114?'corridor':T<163?'factory':T<192?'carInterior':T<223?'briefing':T<242?'carInterior':T<267?'shop':T<314?'exterior':T<361?'office':T<389?'office':T<430?'venue':T<450?'office':'office';}
function faceShot(g,t,i){const where=locationFor(i.globalT);blurLayer(g,10,g=>set(g,t,i,where,{night:i.globalT>440}));veil(g,C.ink,.15);layer(g,CAM(t,i),1,g=>{
 if(['official','aide'].includes(i.mode)){aide(g,1030,1645,4.2,{bend:i.mode==='aide'?-.045:0,flinch:false,blink:t>1.5&&t<1.64});return;}
 const nod=i.mode==='nod'?Math.sin(Math.min(t,1.3)*5)*.035:0;
 personAt(g,970,1530,2.2,{T:i.globalT,turn:lerp(-.15,.35,P(t,0,1.1)),look:[i.mode==='relief'?-.4:i.mode==='uncertain'?-.6:.55,i.mode==='nod'?.3:0],tilt:nod,down:i.mode==='nod'?.4:0});
 });}
function portraits(g,t,i){blurLayer(g,5,g=>room(g,i.globalT,CAM(t,i)));layer(g,CAM(t,i),1,g=>{for(let j=0;j<2;j++){let x=678+j*565;box(g,x-181,229,362,498,'#a38654',7);box(g,x-167,243,334,470,'#554b3f');box(g,x-155,255,310,446,'#8e9079');face(g,{x,y:419,s:.96,simplehair:true,turn:0,look:[0,0]});poly(g,[[x-110,683],[x-91,518],[x+92,518],[x+117,683]],j?'#686d5c':'#626859');seg(g,[[x-172,242],[x+172,242]],2,'#d6b584');} });}
function uniform(g,t,i){blurLayer(g,10,g=>room(g,i.globalT,{}));layer(g,CAM(t,i),1,g=>{aide(g,1040,1940,5.2,{bend:0});clipboard(g,1340,800,1.15);});}
function reflection(g,t,i){blurLayer(g,12,g=>room(g,i.globalT,{}));layer(g,CAM(t,i),1,g=>{
 box(g,-200,935,2400,300,'#a09175');
 const glass=()=>{g.beginPath();g.moveTo(720,237);g.lineTo(1215,237);g.lineTo(1166,910);g.quadraticCurveTo(960,954,772,910);g.closePath();};
 glass();g.fillStyle='#66857c55';g.fill();g.save();glass();g.clip();g.globalAlpha=.61;face(g,{x:971,y:530,s:2.0,turn:.2,look:[.6,0]});g.restore();
 ellipse(g,967,237,248,35,'#d3dcc180');seg(g,[[736,277],[785,885]],5,'#e2e3c38c');seg(g,[[1198,274],[1152,886]],3,'#d1d9bf69');ellipse(g,968,908,198,21,'#acbea185');
 });}
function clockShot(g,t,i){board(g,i.globalT);layer(g,CAM(t,i),1,g=>{const m=i.mode;if(m==='24'){label(g,'24 HOURS',960,373,115,C.gold);label(g,'ONE UNFAMILIAR LIFE',960,699,32);}else if(m==='4hours'){clock(g,960,526,209,18);label(g,'4 HOURS INTO THE JOB',960,852,39,C.gold);}else{const str=m==='noon'?'12:00':m==='3pm'?'15:00':'00:00';clock(g,960,523,240,str,true);label(g,m==='noon'?'NOON':m==='3pm'?'THREE IN THE AFTERNOON':'MIDNIGHT',960,817,37,C.gold);}});}
function breakfastWide(g,t,i){wide(g,t,i,{third:true});if(i.mode==='dinner')veil(g,'#293945',.15);}
function silence(g,t,i){if(i.mode==='factory'){const c=set(g,t,i,'factory');layer(g,c,1,g=>{aide(g,913,1020,2.1,{});aide(g,1442,1020,2.1,{bend:-.025});});}else{wide(g,t,i,{third:true});}}
function pickSpoon(g,t,i){blurLayer(g,10,g=>room(g,i.globalT,{}));layer(g,CAM(t,i),1,g=>{box(g,-300,883,2500,500,'#686357');seg(g,[[1530,-100],[1320,437],[1080,753]],92,'#424144');ellipse(g,1077,765,35,46,C.ink,.4);const k=P(t,.2,.8);spoon(g,1095,830-55*k,1.9,1.58-.22*k);shadow(g,1064,894,92,12);});}
function title(g,t,i){board(g,i.globalT);layer(g,CAM(t,i),1,g=>{label(g,'24 HOURS',960,357,102,C.gold);label(g,'AS NORTH KOREA’S LEADER',960,524,59);label(g,'WHAT WOULD YOU ACTUALLY DO?',960,746,31);});}
function family(g,t,i){board(g,i.globalT);layer(g,CAM(t,i),1,g=>{
 const n=i.mode==='2011'?1:i.mode==='father'?2:3;
 for(let j=0;j<n;j++){let x=n===1?960:515+j*(n===2?890:447);box(g,x-169,300,338,383,'#56685c',12);face(g,{x,y:455,s:1.0,simplehair:j!==n-1,turn:0,look:[0,0]});poly(g,[[x-110,648],[x-79,550],[x+78,550],[x+110,648]],'#4b5050');label(g,n===1?'KIM JONG UN':['GRANDFATHER','FATHER','SON'][j],x,746,25,C.gold);if(j<n-1)arrow(g,x+182,495,x+253,495,1,C.gold,2);}
 if(i.mode==='2011')label(g,'2011',960,843,66,C.gold);else label(g,'THREE GENERATIONS',960,192,45,C.gold);
 });}
function cult(g,t,i){if(i.mode==='monument'){const c=set(g,t,i,'city');layer(g,c,.8,g=>{box(g,785,654,340,183,'#a7a08a');box(g,825,462,260,202,'#969b85');poly(g,[[881,472],[879,355],[1035,355],[1047,472]],'#8e9c85');circle(g,958,306,57,'#9ca68b');seg(g,[[832,843],[1091,843]],13,'#bdb498');});return;}
 board(g,i.globalT);layer(g,CAM(t,i),1,g=>{face(g,{x:960,y:479,s:1.25,turn:0,look:[0,0]});for(let j=0;j<6;j++){let a=j*Math.PI/3,x=960+Math.cos(a)*553,y=501+Math.sin(a)*294;seg(g,[[960+Math.cos(a)*145,490+Math.sin(a)*100],[x,y]],2,'#b7bf9a55');if(j%3===0){box(g,x-52,y-59,104,118,'#8c825e',3);circle(g,x,y-10,24,C.ink);}else if(j%3===1){book(g,x-36,y-49,72,100,'#8b6851');}else{for(let k=0;k<3;k++)circle(g,x-29+k*29,y,12,C.cream);}}label(g,'THE CULT OF PERSONALITY',960,160,45,C.gold);});}
function school(g,t,i){backdrop(g,['#69735e','#b1ac83']);layer(g,CAM(t,i),.6,g=>{box(g,487,173,974,395,'#3b5b4b',9);box(g,807,99,306,57,'#816b4c',3);face(g,{x:959,y:128,s:.25,turn:0});for(let j=0;j<5;j++){let x=277+j*342;box(g,x,775,250,21,'#9f855a',5);for(let d of[20,212])box(g,x+d,794,13,210,'#5e5e47');circle(g,x+126,724,30,C.ink);poly(g,[[x+77,870],[x+88,759],[x+161,759],[x+176,870]],'#6e7a60');book(g,x+82,769,93,16,C.paper);}label(g,'LESSONS BEGIN IN CHILDHOOD',974,365,38,C.paper);});}
function document(g,t,i){board(g,i.globalT);layer(g,CAM(t,i),1,g=>{
 const h={un:'UNITED NATIONS',obedience:'HUMAN RIGHTS REPORT',travelRule:'INTERNAL TRAVEL',noThreat:'NO DRAMATIC THREATS',noFreestyle:'ASK. LISTEN. UNDERSTAND.',change:'PROMISES ≠ CHANGE'}[i.mode]||'REPORT';
 page(g,960,566,1.13,{heading:h,lines:i.mode==='noThreat'||i.mode==='noFreestyle'||i.mode==='change'?0:9});
 if(['un','obedience'].includes(i.mode)){ring(g,960,448,53,2,'#658777');seg(g,[[917,445],[1003,445]],2,'#658777');label(g,'DOCUMENTED RESTRICTIONS',960,727,22,'#5e6f5c');}
 if(i.mode==='travelRule'){box(g,761,582,393,112,'#9eab8d',9);label(g,'AUTHORIZATION',958,638,31,'#3d5b4b');}
 if(i.mode==='change'){label(g,'TOMORROW STILL MATTERS',960,591,28,'#586a54');}
 });}
function compare(g,t,i){board(g,i.globalT);layer(g,CAM(t,i),1,g=>{for(let j=0;j<2;j++){let x=573+j*772;box(g,x-227,290,454,419,'#4b5f52',15);face(g,{x,y:464,s:1.25,simplehair:true,turn:j?-.2:.2,look:[j?-1:1,0],fear:!!j});label(g,j?'FEAR?':'BELIEF?',x,787,43,C.gold);}label(g,'FROM HERE, YOU CANNOT TELL',960,171,39);});}
function schedule(g,t,i){blurLayer(g,9,g=>room(g,i.globalT,{}));layer(g,CAM(t,i),1,g=>{page(g,960,568,1.12,{heading:'TODAY',lines:0});for(let j=0;j<3;j++){let y=400+j*149,active=(i.mode==='factory'&&j===0)||(i.mode==='military'&&j===1)||(i.mode==='crowd'||i.mode==='appearance')&&j===2;if(active)box(g,735,y-38,451,91,'#b1b696',6);label(g,['FACTORY INSPECTION','MILITARY BRIEFING','PUBLIC APPEARANCE'][j],960,y,27,'#475e4d');seg(g,[[770,y+62],[1150,y+62]],2,'#92967955');}});}
function phoneInsert(g,t,i){blurLayer(g,10,g=>set(g,t,i,i.mode==='avoid'?'room':'bedroom'));layer(g,CAM(t,i),1,g=>{
 seg(g,[[598,1300],[719,887],[793,715]],113,i.mode==='avoid'?'#444246':'#80755e');ellipse(g,806,707,44,69,C.ink,.17);phone(g,1005,542,3.42,-.045);
 box(g,881,326,249,429,'#b7c7b0',12);label(g,i.mode==='avoid'?'INCOMING CALL':'MESSAGES',1004,400,27,'#3c5751');label(g,i.mode==='avoid'?'UNKNOWN NUMBER':'Mom',1004,487,29,'#3c5751');if(i.mode==='avoid'){ring(g,1004,618,43,3,'#668b78');}else{label(g,'1 NEW MESSAGE',1004,618,24,'#4f6c5d');}
 });}
function cta(g,t,i){board(g,i.globalT);layer(g,CAM(t,i),1,g=>{face(g,{x:960,y:341,s:1.4,turn:.2,look:[.5,0]});box(g,672,571,576,124,'#b6463d',19);playIcon(g,735,633,.5);label(g,'SUBSCRIBE',1006,633,45);box(g,818,777,284,77,'#347daf',12);label(g,'LIKE',960,815,30);});}
function corridor(g,t,i){const c=set(g,t,i,'corridor',{open:i.mode==='door'?P(t,0,.75):i.mode==='alone'?1:0});layer(g,c,.91,g=>{
 for(let x of[446,1469])aide(g,x,963,1.7,{bend:i.mode==='still'?-.1:0});if(i.mode!=='establish')personAt(g,952,996,1.03,{T:i.globalT,look:[.5,0]});
 });}
function factory(g,t,i){const c=set(g,t,i,'factory');layer(g,c,.96,g=>{
 personAt(g,622,994,.96,{T:i.globalT,lean:i.mode==='approach'?P(t,0,.7)*7:0,look:[.8,0],handUp:i.mode==='explain'?.6:0});
 aide(g,1539,986,1.72,{bend:i.mode==='stop'?-.035:0});aide(g,1821,986,1.67,{});
 clipboard(g,1571,756,.43);clipboard(g,1853,761,.43);
 });}
function machine(g,t,i){blurLayer(g,6,g=>W.factory(g,i.globalT,{}));layer(g,CAM(t,i),1,g=>{W.machine(g,1010,1024,2.86,i.globalT);if(i.mode==='part'){seg(g,[[621,1240],[723,812],[847,594]],54,'#464346');ellipse(g,848,592,23,28,C.ink,.2);}});}
function notebook(g,t,i){blurLayer(g,10,g=>set(g,t,i,i.globalT<163?'factory':'office'));layer(g,CAM(t,i),1,g=>{
 clipboard(g,969,582,3.31);seg(g,[[1563,1311],[1374,967],[1223,676]],97,'#5e6254');ellipse(g,1209,655,40,54,C.ink,-.3);seg(g,[[1153,564],[1207,669]],13,'#3c4a45');
 if(i.mode!=='blank'){for(let j=0;j<5;j++){let p=P(t,j*.12,j*.12+.5);seg(g,[[838,478+j*55],[838+p*(221-(j%2)*51),478+j*55]],3,'#5c6e59');}}else{label(g,'…',966,526,74,'#7e886e');}
 });}
function emptyChair(g,x,y,s=1){g.save();g.translate(x,y);g.scale(s,s);shadow(g,0,0,69,10);box(g,-61,-145,122,20,'#75826a',7);box(g,-50,-267,103,27,'#75826a',8);for(let dx of[-48,48])seg(g,[[dx,-132],[dx*1.15,0]],9,'#394b43');seg(g,[[48,-149],[48,-258]],7,'#43564a');g.restore();}
function chairShot(g,t,i){if(i.mode==='wide'){factory(g,t,i);return;}blurLayer(g,10,g=>W.factory(g,i.globalT,{}));if(i.mode==='memory')veil(g,'#293937',.22);layer(g,CAM(t,i),1,g=>emptyChair(g,968,940,2.8));}
function carShot(g,t,i){const c=set(g,t,i,'carInterior',{display:i.mode==='wave',night:i.globalT>430});layer(g,c,.94,g=>{
 personAt(g,733,1098,1.22,{T:i.globalT,look:[i.mode==='window'?.9:.4,0],handUp:i.mode==='wave'?.8:i.mode==='halt'?1:0});
 if(['aidePhone','halt','stop','ask','return'].includes(i.mode))aide(g,1436,1090,2.09,{phone:i.mode==='aidePhone',prop:i.mode==='aidePhone'?(g,hx,hy)=>phone(g,hx-10,hy-4,.24):null});
 });layer(g,c,1.2,g=>{box(g,35,1009,1850,260,'#303637',34);box(g,1360,1022,300,20,'#6f6b5a',9);});}
function cityShot(g,t,i){const c=set(g,t,i,'city',{display:i.mode==='display'});if(i.mode==='monument')layer(g,c,.81,g=>{box(g,786,676,340,164,'#9b9c88');poly(g,[[892,676],[934,178],[971,178],[1014,676]],'#a8ac92');circle(g,952,168,18,'#a4794f');});if(i.mode==='ordinary')layer(g,c,.88,g=>{for(let j=0;j<4;j++)civilian(g,547+j*337,965,1.4,{});});}
function mapShot(g,t,i){board(g,i.globalT);layer(g,CAM(t,i),1,g=>{
 W.peninsula(g,960,532,2.45,'#a4ad88');if(i.mode==='country'){label(g,'BEYOND THE CAPITAL',960,169,46,C.gold);circle(g,925,486,11,C.rust);label(g,'PYONGYANG',665,481,24);seg(g,[[773,480],[909,486]],2,C.gold);}else{const p=P(t,.1,1);arrow(g,911,551,1015,331,p,C.gold,4);circle(g,911,551,10,C.cream);circle(g,1015,331,10,C.cream);label(g,'ANOTHER PROVINCE',960,173,43,C.gold);}
 });}
function rules(g,t,i){board(g,i.globalT);layer(g,CAM(t,i),1,g=>{
 const m=i.mode;label(g,{movement:'MOVEMENT',information:'INFORMATION',residence:'WHERE YOU MAY LIVE'}[m],960,191,53,C.gold);
 if(m==='movement'){W.peninsula(g,961,574,2.4,'#9ca989');seg(g,[[735,558],[1198,558]],10,'#b78d5e');for(let x of[754,885,1020,1154])box(g,x,505,15,131,'#596e5b');}
 if(m==='information'){box(g,660,328,600,373,'#748778',21);box(g,681,350,558,310,'#304a43',10);for(let j=0;j<5;j++)seg(g,[[746,421+j*40],[1174,421+j*40]],4,'#adc4a066');seg(g,[[768,392],[1158,622]],8,'#ba8b62');}
 if(m==='residence'){for(let j=0;j<3;j++){let x=621+j*340;box(g,x-89,490,178,172,'#87997a',4);poly(g,[[x-115,492],[x,391],[x+115,492]],'#b39c72');box(g,x-16,578,33,84,'#435e50');}ring(g,961,550,180,3,C.gold);}
 });}
function briefing(g,t,i){const c=set(g,t,i,'briefing');layer(g,c,.85,g=>{
 aide(g,453,994,1.86,{});aide(g,1460,994,1.86,{});personAt(g,930,1041,.92,{T:i.globalT,look:[.6,0]});
 });layer(g,c,1.1,g=>{ellipse(g,960,1000,667,112,'#798b76');page(g,961,1024,.33,{heading:'BRIEFING',lines:5});});}
function missiles(g,t,i){board(g,i.globalT);layer(g,CAM(t,i),1,g=>{
 for(let j=0;j<3;j++){let x=492+j*466;box(g,x-173,286,346,457,C.paper,4);box(g,x-158,300,316,413,'#728578');poly(g,[[x-32,652],[x-13,386],[x+2,344],[x+17,386],[x+37,652]],'#344c45');poly(g,[[x-49,648],[x-12,566],[x+25,566],[x+54,648]],'#465d50');box(g,x-70,653,143,18,'#2b403c',2);}
 label(g,i.mode==='nuclear'?'NUCLEAR WEAPONS':'THE BRIEFING',960,180,53,C.gold);
 });}
function hands(g,t,i){blurLayer(g,9,g=>set(g,t,i,i.mode==='phonePause'?'carInterior':'briefing'));layer(g,CAM(t,i),1,g=>{
 box(g,-100,636,2200,600,i.mode==='phonePause'?'#504e45':'#80927b');
 for(let j=0;j<2;j++){let x=655+j*603;seg(g,[[x+(j?94:-94),1300],[x,859],[x,691]],109,i.mode==='phonePause'?'#5c6453':'#424144');ellipse(g,x,661,47,61,C.ink);}
 if(i.mode==='phonePause')phone(g,1258,477,1.8,.04);else{page(g,981,705,.46,{heading:'BRIEFING',lines:4});}
 });}
function shop(g,t,i){const c=set(g,t,i,'shop');layer(g,c,.79,g=>{civilian(g,1301,898,1.67,{woman:true,bend:i.mode==='refuse'?-.13:0});});layer(g,c,1,g=>{
 personAt(g,565,1020,1.02,{T:i.globalT,handUp:i.mode==='refuse'?.7:0,look:[.7,0]});aide(g,1784,995,1.75,{bend:i.mode==='hurry'?-.16:0});
 });layer(g,c,1.12,g=>{box(g,945,829,887,43,'#a69069',6);box(g,962,872,855,218,'#69735f');});}
function goods(g,t,i){blurLayer(g,9,g=>W.shop(g,i.globalT,{}));layer(g,CAM(t,i),1,g=>{
 box(g,-300,806,2600,500,'#a89570');for(let j=0;j<4;j++){let x=514+j*307;box(g,x-88,371,176,430,['#9c7c50','#8f9d77','#b6a57c','#9a7656'][j],12);box(g,x-91,352,182,25,'#c4b692',6);label(g,'SNACK',x,527,27,'#4c5d4b');seg(g,[[x-47,594],[x+47,594]],3,'#d7c8a0');}
 if(i.mode==='choose'){seg(g,[[931,1277],[951,925],[1118,740]],93,'#434145');ellipse(g,1126,727,42,57,C.ink,.3);}
 });}
function money(g,t,i){blurLayer(g,10,g=>W.shop(g,i.globalT,{}));layer(g,CAM(t,i),1,g=>{
 box(g,-100,797,2200,400,'#a49470');const k=i.mode==='withdraw'?1-P(t,.1,.8):P(t,.1,.7),x=lerp(520,926,k);
 seg(g,[[142,1250],[x-100,966],[x,677]],94,'#424144');ellipse(g,x,650,39,57,C.ink,.2);g.save();g.translate(x+57,609);g.rotate(-.13);box(g,-94,-43,188,86,'#8f9f7b',5);ring(g,0,0,27,2,'#4a6652');seg(g,[[-67,-24],[63,-24]],2,'#bac8a0');g.restore();
 seg(g,[[1733,-100],[1476,311],[1278,579]],82,'#81756a');ellipse(g,1260,592,37,53,C.ink,-.9);
 });}
function cartTalk(g,t,i){const c=set(g,t,i,'exterior',{cars:i.globalT>319});layer(g,c,.96,g=>{
 W.cart(g,1339,943,1.04);civilian(g,1147,985,1.76,{bend:i.mode==='bow'?-.16:P(t,0,.5)*-.025});
 personAt(g,633,995,1.02,{T:i.globalT,look:[.6,0],handUp:i.mode==='ask'?.5:0});aide(g,1796,994,1.71,{});
 });}
function cartHands(g,t,i){blurLayer(g,9,g=>W.exterior(g,i.globalT,{}));layer(g,CAM(t,i),1,g=>{
 box(g,410,710,1120,370,'#9c845d',12);seg(g,[[456,572],[1454,572]],35,'#4a594d');
 for(let j=0;j<2;j++){let x=681+j*552;seg(g,[[x-56,-100],[x-9,344],[x,557]],95,'#8b7b62');ellipse(g,x,565,43,56,C.ink,.15);seg(g,[[x-18,553],[x-16,584]],2,'#686557');}
 });}
function home(g,t,i){const c=CAM(t,i);backdrop(g,['#65736b','#b9ad8d']);layer(g,c,.5,g=>{
 box(g,425,194,1070,680,'#9c947b');poly(g,[[338,198],[962,-36],[1574,198]],'#625e4b');box(g,569,313,352,330,'#526b5e');box(g,585,328,321,299,'#bfd0ad');box(g,741,328,12,299,'#526b5e');box(g,585,481,320,11,'#526b5e');box(g,1092,327,220,507,'#696854',6);W.dust(g,i.globalT);
 box(g,474,729,543,134,'#777d64',25);box(g,471,677,547,100,'#7b826a',27);
 civilian(g,763,899,1.45,{mother:true});
 });
 if(i.mode==='notMoney'){layer(g,c,1,g=>{box(g,1360,432,176,85,'#9ead8b',4);ring(g,1448,473,28,2,'#57735a');seg(g,[[1364,428],[1534,521]],5,C.rust);});}
 if(i.mode==='reunited'||i.mode==='tomorrow')layer(g,c,.97,g=>civilian(g,1090,932,1.68,{bend:-.04}));
 if(i.mode==='permission'||i.mode==='home')label(g,'PERMISSION TO GO HOME',960,979,35,C.cream);
}
function permit(g,t,i){blurLayer(g,9,g=>W.office(g,i.globalT,{}));layer(g,CAM(t,i),1,g=>{
 page(g,960,562,1.14,{heading:'TRAVEL PERMIT',lines:0});label(g,'NAME',756,405,20,'#64745d');seg(g,[[835,408],[1182,408]],3,'#70806a');label(g,'DESTINATION',798,513,20,'#64745d');seg(g,[[914,516],[1182,516]],3,'#70806a');for(let j=0;j<3;j++)seg(g,[[747,621+j*37],[1158-j%2*74,621+j*37]],2,'#8a937a');
 if(['stamp','arrival','name','permission'].includes(i.mode)){const k=i.mode==='stamp'?P(t,.15,.7):1;g.save();g.translate(1084,748);g.rotate(-.14);g.globalAlpha=k;ring(g,0,0,71,5,'#a6604f');ring(g,0,0,60,1.5,'#a6604f');label(g,'APPROVED',0,0,20,'#a6604f');g.restore();if(i.mode==='stamp'&&t<.8){const yy=lerp(375,707,P(t,0,.4));box(g,1029,yy,108,63,'#413f36',6);box(g,1056,yy-96,54,102,'#6d6250',13);}}
 });}
function travel(g,t,i){board(g,i.globalT);layer(g,CAM(t,i),1,g=>{
 if(i.mode==='ticket'){box(g,675,399,571,295,C.paper,9);label(g,'TICKET',960,486,53,'#526b55');seg(g,[[749,552],[1177,552]],3,'#849378');label(g,'NOT ENOUGH',960,807,39,C.gold);}
 else{page(g,585,577,.7,{heading:'PERMISSION',lines:5});car(g,1310,714,1.03,'#697d6d');seg(g,[[1100,413],[1495,789]],8,'#b18561');label(g,i.mode==='none'?'NO TRANSPORT AVAILABLE':'A PERMIT ISN’T A RIDE',960,190,47,C.gold);}
 });}
function office(g,t,i){const c=set(g,t,i,'office',{night:i.mode==='confirmation'});layer(g,c,.85,g=>{
 personAt(g,794,1015,1.04,{T:i.globalT,look:[.6,0],handUp:i.mode==='instruct'?.7:0});aide(g,1554,1001,1.91,{bend:i.mode==='confirmation'?-.07:0});
 if(i.mode==='confirmation')clipboard(g,1579,761,.46);
 });layer(g,c,1.03,g=>{box(g,321,870,1224,100,'#6c513c',6);page(g,1032,886,.3,{heading:'TRAVEL',lines:4});});}
function cars(g,t,i){const c=set(g,t,i,'exterior',{cars:true});layer(g,c,.94,g=>{
 personAt(g,683,993,1.03,{T:i.globalT,handUp:i.mode==='point'?.9:0,look:[.7,0]});civilian(g,1114,984,1.7,{});aide(g,1765,985,1.73,{});if(i.mode==='drivers')aide(g,1510,985,1.68,{});
 });}
function motorcade(g,t,i){
 const single=i.mode==='forHim'||i.mode==='arrived';
 const c=set(g,t,i,single?'city':'motorcade',{move:i.mode!=='expected',night:i.mode==='arrived'});
 if(single)layer(g,c,.9,g=>{const x=lerp(1450,600,P(t,0,i.dur));car(g,x,901,.99,'#36443f');circle(g,x-42,773,14,C.ink);circle(g,x+24,773,14,C.ink);});
}
function apparatus(g,t,i){board(g,i.globalT);layer(g,CAM(t,i),1,g=>{
 const pos=[[477,396],[960,297],[1439,398],[1486,755],[959,819],[432,751]];
 for(let j=0;j<6;j++){let[x,y]=pos[j],k=P(t,j*.08,j*.08+.7);seg(g,[[960,570],[lerp(960,x,k),lerp(570,y,k)]],3,'#b7bd9a66');box(g,x-105,y-58,210,116,j===({calls:2,routes:0,approvals:1,power:4}[i.mode])?'#a2976a':'#627a65',13);label(g,['ROUTES','APPROVALS','CALLS','DRIVERS','SECURITY','CONFIRMATION'][j],x,y,21);}
 ring(g,960,570,95,4,C.gold);label(g,'ORDER',960,570,31,C.gold);label(g,'THE APPARATUS OF POWER',960,137,45,C.gold);
 });}
function speech(g,t,i){blurLayer(g,10,g=>set(g,t,i,i.globalT<389?'carInterior':'venue'));layer(g,CAM(t,i),1,g=>{
 page(g,960,568,1.13,{heading:'PREPARED SPEECH',lines:0});
 for(let j=0;j<3;j++){let y=425+j*118;if((i.mode==='achievements'&&j===0)||(i.mode==='loyalty'&&j===2))box(g,726,y-32,468,64,'#b4bc97',7);label(g,['ACHIEVEMENTS','CONFIDENCE','LOYALTY'][j],960,y,33,'#53684f');seg(g,[[756,y+51],[1163,y+51]],2,'#8c967b');}
 if(i.mode==='missing')label(g,'NOT A WORD ABOUT HIM',960,876,26,'#916448');
 if(i.mode==='promises'||i.mode==='lower'){seg(g,[[615,1220],[714,876],[749,790]],88,'#424144');ellipse(g,751,775,37,52,C.ink);}
 });}
function stage(g,t,i){const c=set(g,t,i,'venue',{faces:i.mode==='faces'});layer(g,c,.66,g=>{
 personAt(g,966,1050,1.05,{T:i.globalT,handUp:i.mode==='hand'?1:0,look:[i.mode==='faces'?-.4:.3,0]});
 });layer(g,c,.96,g=>{box(g,787,736,348,200,'#75543d',9);box(g,768,719,383,28,'#a4835d',7);seg(g,[[973,719],[979,586],[1026,569]],6,'#303f3c');circle(g,1034,567,10,'#263532');});
 if(i.mode==='crowd'||i.mode==='faces')layer(g,c,1.25,g=>{for(let j=0;j<10;j++){let x=104+j*190;circle(g,x,916,35,C.ink);if(i.mode==='faces'){ellipse(g,x-11,912,5,7,C.cream);ellipse(g,x+11,912,5,7,C.cream);seg(g,[[x-6,930],[x+6,930]],2,C.cream);}}});}
function spoonMemory(g,t,i){blurLayer(g,9,g=>room(g,i.globalT,{}));veil(g,'#273d3d',.18);layer(g,CAM(t,i),1,g=>{box(g,-100,850,2200,400,'#676052');spoon(g,954,828,3.5,1.55);shadow(g,986,904,191,17);});}
function report(g,t,i){blurLayer(g,9,g=>W.office(g,i.globalT,{}, {night:true}));layer(g,CAM(t,i),1,g=>{page(g,960,566,1.1,{heading:'TRAVEL UPDATE',lines:5});box(g,761,609,394,122,'#b9ad85',10);label(g,'NOT YET',959,671,47,'#6b7052');});}
function call(g,t,i){const c=set(g,t,i,'office',{night:true});layer(g,c,.9,g=>{
 personAt(g,852,1176,1.51,{T:i.globalT,handUp:3.4,look:[-.5,.15],prop:(g,x,y)=>phone(g,x+14,y-14,.3,-.1)});
 if(i.mode==='request')aide(g,1645,1045,1.93,{});
 });}
function mother(g,t,i){home(g,t,{...i,mode:'callHome'});layer(g,CAM(t,i),1,g=>{
 civilian(g,1304,974,1.8,{phone:true});if(i.mode==='receiver')seg(g,[[1338,591],[1344,607]],4,C.ink);
 });}
function bedroom(g,t,i){const c=set(g,t,i,'bedroom');layer(g,c,.85,g=>{
 // The return to the viewer's own body is a POV, not the leader in his uniform.
 circle(g,836,656,46,C.ink);ellipse(g,836,666,17,5,C.cream);box(g,871,681,659,165,'#66817b',35);
 });}
function message(g,t,i){blurLayer(g,10,g=>W.bedroom(g,i.globalT,{}));layer(g,CAM(t,i),1,g=>{
 seg(g,[[557,1255],[738,912],[820,745]],114,'#80755e');ellipse(g,833,731,43,68,C.ink,.1);
 phone(g,1007,548,3.8,-.025);box(g,867,297,279,495,'#bdcdb5',13);label(g,'Mom',1006,353,33,'#36574c');
 box(g,883,402,243,161,'#e0e1c4',14);label(g,'Coming over',1005,452,25,'#46634f');label(g,'tomorrow?',1005,503,25,'#46634f');
 if(i.mode==='excuse'){box(g,924,614,202,91,'#9db69c',12);label(g,'I’m busy…',1022,657,25,'#3f5c4d');}
 if(i.mode==='yes'){box(g,967,614,158,91,'#7fa189',12);label(g,'Yes.',1045,657,30,'#f1e5c5');}
 });}
function end(g,t,i){board(g,i.globalT);layer(g,CAM(t,i),1,g=>{
 if(i.mode==='question'||i.mode==='change'){label(g,'24 HOURS IN POWER',960,325,67,C.gold);label(g,'WHAT WOULD YOU CHANGE?',960,533,54);label(g,'AND WHO WOULD TELL YOU THE TRUTH?',960,739,33);}
 else{label(g,'WHO WOULD TELL YOU',960,386,63);label(g,'THE TRUTH?',960,526,92,C.gold);label(g,'TELL US IN THE COMMENTS',960,788,30);}
 });}
export const chapter={portraits,uniform,reflection,clock:clockShot,breakfastWide,silence,pickSpoon,title,family,cult,school,document,compare,face:faceShot,schedule,phone:phoneInsert,cta,corridor,factory,machine,notebook,chair:chairShot,car:carShot,city:cityShot,map:mapShot,rules,briefing,missiles,hands,shop,goods,money,cartTalk,cartHands,homeThought:home,permit,travel,office,cars,motorcade,apparatus,speech,stage,spoonMemory,report,call,mother,bedroom,message,end,breakfast:(g,t,i)=>wide(g,t,i,{third:true})};
