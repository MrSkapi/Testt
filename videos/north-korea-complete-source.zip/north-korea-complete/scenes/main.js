import {registerShot} from '/engine/core.js';
import './opening.js';
import {chapter} from './chapter.js';
for(let n=1;n<=203;n++)registerShot('ch'+String(n).padStart(3,'0'),{draw(g,t,i){const fn=chapter[i.view];if(!fn)throw Error('Unknown chapter view '+i.view);fn(g,t,i);}});
