# North Korea — complete chapter

Entire supplied NorthKorea.mp3 story, rendered as a 1920x1080, 24 fps H.264/AAC film. Source narration is preserved without retiming. Final duration: 495 seconds (8:15), including a short final visual hold after the 493.845-second narration. No added speech, music, SFX or subtitles.

The approved character design uses a true silhouette rim, now about 1.5 output pixels thicker than preview v2. Scenes are defined by code; see scenes/cast.js, scenes/chapter.js, scenes/opening.js, scenes/sets/locations.js and story/shots.json.

Copy this project directory into projects/north-korea-complete inside the installed 2d-video plugin toolkit. Apply kit-overrides/ over the installed toolkit root to retain the custom historical style, engine and native renderer. Run npm install in the toolkit if dependencies are missing. tools/local-runtime.mjs uses /usr/bin/chromium in this workspace; select a local Chromium executable when moving to another system.

Render:

    node --import ./tools/local-runtime.mjs render-native.mjs --project projects/north-korea-complete --workers 3 --gl auto --crf 23 --out projects/north-korea-complete/build/full-silent.mp4

Mux original voice:

    ffmpeg -i projects/north-korea-complete/build/full-silent.mp4 -i projects/north-korea-complete/input/voiceover.mp3 -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -af apad -t 495 -movflags +faststart north-korea-complete.mp4

The original input audio is included. timeline/rough-asr.json is rough local recognition used for editorial timing, not verified subtitles. The original recording is authoritative. story/shots.json is the source of shot boundaries.
