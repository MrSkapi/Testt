# WITHOUT YOU — What If Robots Did Everything?

An intimate science-fiction suspense film for airobot.mp3. Automation provides real material benefits, but Adam has delegated his own social life. After twelve years, he discovers that his and Daniel’s representatives have maintained a friendship while the actual people remain isolated. Adam visits the real Daniel, disables interruption filtering, and accepts useful assistance while reclaiming human contact. The ending leaves room for the representative’s own possible attachment and autonomy.

## Cast

Adam: the returning black round-headed hero, orange hoodie #ed9437, black limbs, cream face, no headwear. Tired, awkward and determined rather than physically heroic. His representative shares exactly the same clothing and face, with younger upright posture and a rehearsed smile. No villain glow or gratuitous threat imagery.

Daniel: teal #4b9f9c. His representative is upright and unchanged; the real Daniel has restrained fatigue/stubble and uses a chair. He is 12 years older, not elderly. No miraculous recovery: he still needs help at the end.

Milo: pearl/turquoise service robot, blank dark face panel, soft rounded hands, a connected wheeled base. It provides physical assistance and follows previously selected preferences. Human dependency and delegation drive the conflict; no arbitrary evil robot behavior.

Background adults use muted blue, mauve and green. The artificial passersby remain abnormally upright. Three people react to one falling cup on the same global clock.

## Visual language and sets

Code-drawn flat 2D characters with thin silhouette rim light, layered 2.5D sets, shadows, atmosphere and shallow depth of field. Preserve the established hero design. All authored text is English. No subtitles or labels floating over heads. Device and paper inserts carry only story information.

Warm cream/turquoise home: living chair at the left, service/kitchen wall at center, actual door on the right, window/city at the left. Specific props include the breakfast tray, folded laundry, books, side table, plant, wall controls and screen.

Factory: windows, conveyors, repetitive robot arms and goods explain real production and the basic allowance.

Cafe: three large windows, pendant lamps, warm wooden floor and tables. Initially populated by service machines; later the human-looking representatives continue the relationship here. The remembered mountain photograph contrasts with a spotless automated present.

Night bedroom and home: blue/plum shadows, warm bedside lamp, clock at 03:00. The double sits in the same living chair as Adam. Their identities and screen positions stay distinct.

Day city: colorful facades, trees, shopfront, clean paving, cafe and a real bench. The cup sequence uses a shared slow-motion drop, synchronized attention and one physical catch. The tired Adam must sit after two blocks.

Daniel’s building: face-recognition lobby, corridor and a furnished home with the same automated service layout. His bedroom has a blue blanket, pillow, lamp, book and adjacent chair. Transfers show support and effort; assistance is retained.

Courtyard: greenery and layered skyline by day; navy/violet sky, lit windows, amber lamps and soft light pools in the final evening. A real spill stays spilled. The representative walks in voluntarily and asks the final question.

## Action and editing

204 contiguous shots on the 24fps grid; 486 seconds. Shot scales are fixed, with one shared continuous lateral camera clock per sequence. Medium compositions are intentional editorial cuts. No restarting zoom tween or arbitrary camera shake.

Anchored actions include the breakfast delivery, chair transport, laundry, rapid typing versus one-finger memory, wall closure, doorway wave, lying-to-sitting body turn, representative getting up and walking, Adam’s reluctant steps, cup drop/catch, bench sit, assisted bed rise, original-message inspection, voice-command preference switch, a supported bed-to-chair transfer, copies leaving on footsteps, limited recovery and a spilled drink.

Night body rotations happen outside the rig’s raster bounds to avoid clipping heads. Transfer support points track the patient throughout the move. Characters and props are staged in one consistent space; the robot and empty chair stand outside the walking path.

Audio: original uploaded narration unchanged in speed and order, no added music, wind or replacement voice. The final visual hold after the recording is approximately 1.56 seconds.
