from pathlib import Path
import json,csv,statistics
p=Path(__file__).resolve().parent.parent
w=json.loads((p/'timeline/words.json').read_text());w=w.get('words',[]) if isinstance(w,dict) else w
beats=[l.split('|') for l in (p/'story/beats.tsv').read_text().strip().splitlines()]
groups=[0,15.6,23.8,43.3,56.4,61.3,80.2,88.5,102.5,119.3,142.3,150.3,182.6,193.7,215.6,233.6,243.7,257.3,264.5,273.1,281,287.3,304.7,323.2,338.1,348.8,367.2,380.7,393.5,401,420.6,439.4,451.8,486]
shots=[]
for j,(st,v,mode,loc) in enumerate(beats):
 st=float(st);start=round(st*24)/24;end=round(float(beats[j+1][0])*24)/24 if j+1<len(beats) else 486
 gi=next(k for k in range(len(groups)-1) if groups[k]<=st<groups[k+1]);params=dict(view=v,mode=mode,place=loc,groupStart=groups[gi],groupEnd=groups[gi+1],night=182.6<=st<233.6 or 150.3<=st<182.6 or st>=451.8)
 if v in ['care','duplicate','bedTalk','cafePair','courtyard','recovery'] and j%4==1:params.update(frame='medium',focusX=970,focusY=650)
 tr='dip' if st in [18.2,88.5,182.6,233.6,281,420.6,451.8] else 'fade' if st in [105.3,465.4] else 'cut'
 shots.append(dict(id=f'ar{j+1:03}',start=start,end=end,line=' '.join(x['word'] for x in w if start<=x['start']<end),scene=f'{v}: {mode}. Specific authored action in {loc}; narration-synchronous, grounded figures and no head labels.',set=loc,bars='wide',captions=False,params=params,**{'in':dict(type=tr,dur=.18)},sfx=[]))
title='WITHOUT YOU — What If Robots Did Everything?'
(p/'story/shots.json').write_text(json.dumps(dict(title=title,duration=486,shots=shots,music=[],sfx=[]),indent=2))
c=json.loads((p/'config.json').read_text());c['title']=title;(p/'config.json').write_text(json.dumps(c,indent=2))
with (p/'story/scene-markers.csv').open('w') as f:
 z=csv.writer(f);z.writerow(['id','start','end','view','mode','location']);z.writerows([s['id'],s['start'],s['end'],s['params']['view'],s['params']['mode'],s['set']] for s in shots)
assert shots[0]['start']==0 and shots[-1]['end']==486
assert all(s['end']>s['start'] for s in shots)
print(len(shots),'shots; median',statistics.median(s['end']-s['start'] for s in shots),'seconds')
