# WITHOUT YOU — What If Robots Did Everything?

Complete film for airobot.mp3: 486 seconds (8:06), 1920×1080, 24fps, 16:9, 204 shots, 11,664 frames. Original source duration 484.440813 seconds. Original English voiceover, unchanged speed/order; no subtitles or extra audio tracks.

Hero: established black/orange character without a hat. All scenes are drawn by code with the 2d-video toolkit, using the previous rig plus new robot, sets, props and actions.

Use kit-overrides/ as the studio root (or apply it over an existing 2d-video toolkit). Put ai-robot/ in that root’s projects/ai-robot/ directory. Run npm install there and install ffmpeg and Chromium. The local runtime selects /usr/bin/chromium; adjust that executable on another machine.

Render from the toolkit root:

    node --import ./tools/local-runtime.mjs render-native.mjs --project projects/ai-robot --workers 3 --gl auto --crf 21 --out projects/ai-robot/build/full-silent.mp4

Mux the original narration without retiming:

    ffmpeg -i projects/ai-robot/build/full-silent.mp4 -i projects/ai-robot/input/voiceover.mp3 -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -af apad -t 486 -movflags +faststart ai-robot.mp4

story/shots.json owns timing. story/beats.tsv and build_story.py regenerate the plan from the supplied Whisper word timeline. The uploaded voiceover is authoritative; transcription is an editorial aid and is not displayed as captions. story/bible.md explains the acting, atmosphere, locations and continuity.

Use --from A --to B --scale .5 for partial previews. Do not run two native video renders into the same project build directory concurrently: intermediate encoder files are shared. No image/video generation assets are required.

validation/ includes exact media/audio checks, the final contact sheet and a 29.375-second motion excerpt beginning at 4:03.708.

The delivered master includes one exact-frame city insert, made from the final source, for the simultaneous cup reaction and a consistent clean-faced hero. Rendering the included source produces that correction directly. validation/assembly-validation.json documents the frame ranges; all narration timing is unchanged.
