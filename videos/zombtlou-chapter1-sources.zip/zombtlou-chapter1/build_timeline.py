from pathlib import Path
import json,re,difflib,textwrap
from plan import PLAN
P=Path(__file__).resolve().parent;words=json.loads((P/'words.json').read_text());duration=730.488125
def norm(t):return re.sub('[^a-z0-9]','',t.lower().replace('’',"'"))
# Repair orthography only; audio and word order are never changed.
for w in words:
 if w['text']=='youre':w['text']="You're"
 if w['text'].lower()=='daniel':w['text']='Daniel'
 if w['text'].lower()=='mara':w['text']='Mara'
N=[norm(w['text']) for w in words]
shots=[];cursor=0;issues=[]
for anchor,loc,action,title,detail in PLAN:
 q=[norm(t) for t in anchor.split()];best=(-1,None,None)
 for i in range(cursor,min(len(N),cursor+240)):
  for length in range(max(1,len(q)-2),len(q)+3):
   cand=N[i:i+length];score=difflib.SequenceMatcher(None,q,cand,autojunk=False).ratio()-.00012*(i-cursor)
   if score>best[0]:best=(score,i,length)
 score,i,length=best
 if score<.61:issues.append((anchor,round(score,2),words[i]['start'], ' '.join(x['text'] for x in words[i:i+length])))
 start=max(0,words[i]['start']-.08)
 shots.append(dict(id=f's{len(shots)+1:03}',start=start,anchor=anchor,location=loc,action=action,title=title,detail=detail))
 cursor=i+1
shots[0]['start']=0
for i,s in enumerate(shots):s['end']=shots[i+1]['start'] if i+1<len(shots) else duration
# Cues are short phrases, max two lines; retain every recognized spoken word.
cues=[];buf=[]
def emit():
 if not buf:return
 a=buf[0]['start'];b=min(duration,max(buf[-1]['end']+.12,a+.48))
 text=' '.join(x['text'] for x in buf)
 for src,dst in [('907','9:07'),('908','9:08'),('910','9:10'),('913','9:13'),('917','9:17')]:text=re.sub(r'\b'+src+r'\b',dst,text)
 text=re.sub(r'\b9[ .]+10\b','9:10',text)
 lines=textwrap.wrap(text,46,break_long_words=False,break_on_hyphens=False)
 cues.append({'start':a,'end':b,'text':'\n'.join(lines)});buf.clear()
for i,w in enumerate(words):
 if buf and (len(' '.join(x['text'] for x in buf))+len(w['text'])>86 or w['start']-buf[0]['start']>3.3):emit()
 buf.append(w)
 strong=w['text'][-1:] in '.!?;'
 if (strong and len(buf)>=3) or (i+1<len(words) and words[i+1]['start']-w['end']>.38):emit()
emit()
for a,b in zip(cues,cues[1:]):a['end']=min(a['end'],b['start'])
for c in cues:
 if len(c['text'].splitlines())>2:raise RuntimeError('Caption >2 lines')
(P/'timeline.json').write_text(json.dumps({'duration':duration,'shots':shots,'captions':cues},ensure_ascii=False,indent=2))
def ts(t):
 n=round(t*1000);return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02},{n%1000:03}'
(P/'zombtlou-full.srt').write_text('\n\n'.join(f"{i}\n{ts(c['start'])} --> {ts(c['end'])}\n{c['text']}" for i,c in enumerate(cues,1))+'\n')
(P/'storyboard.txt').write_text('\n'.join(f"{s['start']:7.2f}–{s['end']:7.2f} {s['location']:12} {s['action']:14} {s['anchor']}" for s in shots))
print('SHOTS',len(shots),'CAPTIONS',len(cues),'WORDS',len(words));print('LOW CONFIDENCE ANCHORS',issues)
print((P/'storyboard.txt').read_text())
