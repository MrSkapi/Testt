# Five days — Chapter 1, full illustrated film

Complete user-supplied narration, 730.488125 seconds (12:10), with English captions and original code-drawn scenes. Delivery: 1920×1080, 24 fps H.264 MP4 with AAC narration. No music, sound effects, synthetic speech, narration edits or speed changes were added.

## Visual continuity

The latest approved workroom and tall rectangular orange hoodie are the opening. The hero has a round pale face (#EEE7DA), teal fitted cap, black fringe, thin black legs and round hands. Standing legs are straight; walking and interactions use articulated limbs. Other sets include the kitchen, bedroom, front/rear doors, garage, garden, safety supplier, street, driveway, laboratory and parents' house. Plans, notes and explanatory diagrams are shown on paper or inside screens. Textures are static and do not flicker.

The chapter contains 177 contiguous shots and 362 timed caption cues. The supplied style-reference recordings are used as visual references only; their pixels and sound are not included. The protagonist's colours and starting-room layout follow the user's accepted revisions.

## Editable files

- `chapter1.html`: self-contained drawing code and timeline, plus audio playback from adjacent `narration.mp3`.
- `base.js`: primitive drawing helpers, paper texture, approved workroom, cap and inverse-kinematics solver.
- `film.js`: props, cast, locations, staging, shot actions and caption rendering.
- `timeline.json`: all shot boundaries, screen text and captions.
- `plan.py` and `build_timeline.py`: narrative anchors and timeline/caption construction from `words.json`.
- `narration.mp3`: unchanged supplied audio.
- `zombtlou-full.srt`: editable caption file.
- `build.py`: regenerates chapter1.html and chapter1.js.
- `render-worker.mjs`, `assemble.py`: reproducible rendering and final assembly.

The animation uses held drawings on twos (12 drawing samples per second); the encoded file is 24 fps. Caption timing is sampled at the same drawing rate. The original audio is encoded once after joining the video parts, preserving continuous timing across the part boundaries.

## Preview and render

Use Python 3, Node.js 22+ (built-in WebSocket), Chromium and FFmpeg.

1. Run `python3 build.py` in this directory.
2. Run `python3 -m http.server 8765 --bind 127.0.0.1` here, then open chapter1.html through that local server. Click Play for audio. `?t=123.4` opens a deterministic still with audio paused.
3. Launch two headless Chromium instances with dedicated writable user-data directories and remote-debugging ports 9223 and 9224. Container environments may require `--no-sandbox --disable-dev-shm-usage`; retain the environment's inherited proxy and TLS trust.
4. Run `node render-worker.mjs --port 9223 --worker 0 --workers 2` and `node render-worker.mjs --port 9224 --worker 1 --workers 2` in parallel. Each worker uses one FFmpeg encoding thread. Sixty-second parts are checkpointed under parts/.
5. Run `python3 assemble.py` after both workers finish. It verifies every part's dimensions, frame count, rate and duration before joining the parts and adding the complete narration.

Clear `parts/` before rerendering after source/timeline changes. Checkpoints are intended to resume an unchanged render, not reuse footage after editing.

The optional local transcription scripts use the separately installed sherpa-onnx Whisper/CTC models. Models and dependencies are not needed to edit or render the supplied timeline, and are not included in this source archive.
