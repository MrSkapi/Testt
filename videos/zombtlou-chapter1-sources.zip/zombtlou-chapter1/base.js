const canvas=document.getElementById('scene'),g=canvas.getContext('2d');
const W=1920,H=1080,D=DATA.duration,INK='#2c2d2d';
const clamp=x=>Math.max(0,Math.min(1,x));const ease=x=>{x=clamp(x);return x*x*(3-2*x)};
let seed=97621;function rand(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296}
function path(points,fill,stroke=INK,lw=3,close=true){g.beginPath();g.moveTo(...points[0]);for(const p of points.slice(1))g.lineTo(...p);if(close)g.closePath();if(fill){g.fillStyle=fill;g.fill()}if(stroke){g.strokeStyle=stroke;g.lineWidth=lw;g.lineJoin='round';g.lineCap='round';g.stroke()}}
function line(x,y,X,Y,c=INK,w=3){path([[x,y],[X,Y]],null,c,w,false)}
function rect(x,y,w,h,fill,r=2,stroke=INK,lw=3){g.beginPath();g.roundRect(x,y,w,h,r);if(fill){g.fillStyle=fill;g.fill()}if(stroke){g.strokeStyle=stroke;g.lineWidth=lw;g.stroke()}}
function ellipse(x,y,rx,ry,fill,stroke=INK,lw=3){g.beginPath();g.ellipse(x,y,rx,ry,0,0,Math.PI*2);if(fill){g.fillStyle=fill;g.fill()}if(stroke){g.strokeStyle=stroke;g.lineWidth=lw;g.stroke()}}
function text(s,x,y,size=25,c=INK,bold=false){g.font=`${bold?'700':'400'} ${size}px "DejaVu Sans",Arial,sans-serif`;g.fillStyle=c;g.fillText(s,x,y)}
function hatch(x,y,w,h,n=30,color='#292d2b38'){for(let i=0;i<n;i++){const xx=x+(i*17.79)%w,yy=y+(i*7.23)%h;line(xx,yy,xx+7,yy-10,color,1)}}
// Static scanned-paper grain. Texture never swims or flickers between frames.
const paper=document.createElement('canvas');paper.width=W;paper.height=H;
const pg=paper.getContext('2d'),data=pg.createImageData(W,H);
for(let i=0;i<data.data.length;i+=4){let k=rand();const v=k>.5?239:43;data.data[i]=v;data.data[i+1]=v;data.data[i+2]=v;data.data[i+3]=Math.floor(2+rand()*9)}pg.putImageData(data,0,0);
const wall=document.createElement('canvas');wall.width=W;wall.height=H;const wg=wall.getContext('2d');
for(let i=0;i<180;i++){wg.strokeStyle=i%3?'#333a3620':'#d6d8c519';wg.lineWidth=.7+rand()*2;const x=rand()*1920,y=rand()*750;wg.beginPath();wg.moveTo(x,y);wg.lineTo(x+rand()*4,y+50+rand()*300);wg.stroke()}
function workroom(t){
 g.fillStyle='#a7aaa0';g.fillRect(0,0,W,H);g.drawImage(wall,0,0);
 g.fillStyle='#818f86';g.fillRect(0,535,W,270);rect(-10,803,1940,15,'#d0cbb8',0,INK,2);hatch(0,807,1920,10,130);
 g.fillStyle='#a29880';g.fillRect(0,818,W,262);
 for(let j=0;j<5;j++){const y=837+j*56;line(0,y,1920,y,'#756e5b55',1.3);for(let i=0;i<7;i++){const x=i*300+(j%2?150:0);line(x,y,x,y+56,'#756e5b55',1.3)}}
 // A narrow side window with a roller blind, not the sofa-centred curtain composition.
 rect(197,153,325,365,'#d4d0bf',1,INK,3);rect(213,169,293,330,'#9aa6b0',0,INK,2);
 for(let i=0;i<3;i++){let x=219+i*96;path([[x,490],[x,367-i*12],[x+45,333-i*12],[x+90,367-i*12],[x+90,490]],'#9b999b',INK,1.5)}
 rect(215,169,288,118,'#b0ad99',0,INK,2);for(let j=0;j<8;j++)line(218,179+j*14,500,179+j*14,'#858773',1);
 line(359,290,359,497,'#d4d0bf',8);line(214,396,504,396,'#d4d0bf',7);line(532,177,532,414,'#52584d',2);ellipse(532,420,4,7,'#74775f',INK,1);hatch(217,492,280,10,40);
 // Asymmetric workspace: desk and monitor to the left, shelves and gear to the right.
 rect(139,658,627,25,'#866e51',3,INK,3);rect(164,683,17,153,'#735b42',1,INK,2);rect(728,684,17,152,'#735b42',1,INK,2);
 rect(521,691,174,142,'#8f7c61',3,INK,2);rect(536,705,145,44,'#9a8769',2,INK,1.5);line(596,726,620,726,INK,3);rect(536,761,145,59,'#9a8769',2,INK,1.5);line(596,780,620,780,INK,3);
 rect(296,445,294,173,'#4b5351',7,INK,3);rect(309,457,269,145,'#6c7e7d',2,INK,1.5);
 // A quiet game lobby ties the room to the squad chat without inventing an emergency.
 text('SQUAD LOBBY',329,488,20,'#d6d5c2',true);line(329,505,551,505,'#9ba9a1',1);for(let i=0;i<3;i++){ellipse(345,529+i*24,6,6,'#b8bd9f',null);line(365,529+i*24,485-i*18,529+i*24,'#b1b9ab',4)}
 rect(427,619,26,30,'#48504c',2,INK,2);rect(393,648,99,9,'#4b5351',2,INK,2);rect(265,641,130,12,'#686e60',3,INK,1.5);
 rect(635,609,42,49,'#d7ceba',5,INK,2);g.beginPath();g.arc(681,630,9,-Math.PI/2,Math.PI/2);g.stroke();
 // Small angled desk lamp.
 ellipse(211,651,32,7,'#565b51',INK,2);line(209,646,190,551,'#53594d',7);line(190,551,228,506,'#53594d',6);path([[217,488],[256,508],[247,537],[204,516]],'#a59a6e',INK,2);
 // Pegboard of ordinary equipment behind the protagonist.
 rect(685,176,418,184,'#aaa187',4,INK,2);for(let i=0;i<15;i++)for(let j=0;j<5;j++)ellipse(704+i*26,195+j*32,1.5,1.5,'#6d715f',null);
 path([[730,219],[751,219],[755,284],[726,284]],'#626f60',INK,2);line(740,215,740,203,INK,2);rect(797,215,107,84,'#ccc6a9',1,INK,1.5);text('FRIDAY',810,245,18,'#68664f',true);text('RAID · 22:00',807,274,14,'#68664f');line(812,293,891,293,'#999474',1);
 path([[962,207],[1005,207],[1022,227],[1010,265],[956,258]],'#7a8881',INK,2);hatch(964,231,45,20,12);
 // Open shelves, books, a radio and a backpack. No sofa, oval rug or mustard curtains.
 rect(1289,185,343,646,'#797e6a',3,INK,3);rect(1307,201,307,611,'#949983',1,INK,2);
 for(const y of [350,506,664])rect(1304,y,313,12,'#797f6b',1,INK,2);
 for(let i=0;i<7;i++){const x=1325+i*35,h=95+(i%3)*9;rect(x,345-h,28,h,['#897c67','#607a77','#a39365'][i%3],1,INK,1.5);line(x+5,335-h,x+22,335-h,'#d0c6a7',2)}
 rect(1341,418,230,78,'#696f65',5,INK,2);rect(1357,433,97,28,'#a7ac94',2,INK,1.5);line(1367,448,1440,448,'#65715a',2);for(let i=0;i<5;i++)line(1483+i*14,434,1483+i*14,479,'#3c453c',2);ellipse(1378,481,7,7,'#414c40',INK,1);line(1548,417,1575,368,'#555e50',3);
 rect(1345,565,205,84,'#a29473',3,INK,2);rect(1427,565,39,84,'#8a8166',0,null);line(1359,586,1405,586,'#cec3a2',2);
 path([[1384,811],[1378,746],[1399,695],[1476,695],[1505,742],[1502,811]],'#687e68',INK,3);rect(1401,749,78,48,'#758a70',10,INK,2);line(1410,709,1398,764,INK,2);line(1466,710,1489,760,INK,2);
 // Plain door on the far right establishes a different room layout.
 rect(1710,315,174,499,'#c1baa2',0,INK,3);rect(1726,330,142,484,'#aaa38a',1,INK,2);rect(1743,352,107,176,'#b6af97',1,'#8c8e76',1);rect(1743,548,107,201,'#b6af97',1,'#8c8e76',1);ellipse(1748,568,7,7,'#626c5c',INK,1);hatch(1731,792,130,15,24);
 ellipse(967,900,91,8,'#62695735',null);
}
function knee(a,b,A,B,side){const dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy);if(d>A+B+.01)throw Error('Unreachable joint');const q=(A*A-B*B+d*d)/(2*d),h=Math.sqrt(Math.max(0,A*A-q*q));return[a[0]+dx*q/d+side*dy*h/d,a[1]+dy*q/d-side*dx*h/d]}
function cap(){// fitted to the head, with a low brim and two panel seams
 g.beginPath();g.moveTo(-65,-26);g.bezierCurveTo(-70,-70,-32,-81,1,-80);g.bezierCurveTo(40,-80,61,-57,65,-42);g.quadraticCurveTo(-7,-50,-65,-26);g.closePath();g.fillStyle='#4c8580';g.fill();g.lineWidth=2.5;g.strokeStyle=INK;g.stroke();
 g.beginPath();g.moveTo(-65,-26);g.quadraticCurveTo(4,-52,65,-42);g.quadraticCurveTo(94,-42,101,-31);g.quadraticCurveTo(95,-24,83,-29);g.quadraticCurveTo(34,-43,-23,-26);g.closePath();g.fillStyle='#3f7773';g.fill();g.stroke();line(-11,-78,17,-47,INK,1.5);hatch(-54,-48,27,15,12,'#253b3440')}
function phoneBack(x,y,w,h){rect(x,y,w,h,'#343942',5,INK,2);rect(x+5,y+5,17,24,'#272b32',3,null);ellipse(x+10,y+12,3,3,'#728078',INK,1);ellipse(x+17,y+22,3,3,'#728078',INK,1)}
