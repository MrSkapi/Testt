from pathlib import Path
import json,subprocess,math
P=Path(__file__).resolve().parent;data=json.loads((P/'timeline.json').read_text());samples=math.ceil(data['duration']*12);parts=[]
for k in range(math.ceil(samples/720)):
 p=P/'parts'/f'part-{k:03}.mp4';m=p.with_suffix('.mp4.ok')
 if not p.exists() or not m.exists():raise SystemExit(f'Missing completed part {k}')
 meta=json.loads(m.read_text());probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_type,width,height,r_frame_rate,nb_frames:format=duration','-of','json',str(p)]));s=probe['streams'][0]
 assert s['width']==1920 and s['height']==1080 and s['r_frame_rate']=='24/1'
 assert int(s['nb_frames'])==meta['frames']*2,(k,s,meta)
 assert abs(float(probe['format']['duration'])-meta['frames']/12)<.02
 parts.append(p)
text='\n'.join("file '"+str(p).replace("'","'\\''")+"'" for p in parts)+'\n';(P/'parts.txt').write_text(text)
subprocess.run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(P/'parts.txt'),'-i',str(P/'narration.mp3'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','160k','-movflags','+faststart',str(P/'zombtlou-chapter1-full.mp4')],check=True)
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_type,codec_name,width,height,r_frame_rate,nb_frames,duration:format=duration,size','-of','json',str(P/'zombtlou-chapter1-full.mp4')]))
v=next(s for s in probe['streams'] if s['codec_type']=='video');a=next(s for s in probe['streams'] if s['codec_type']=='audio')
assert int(v['nb_frames'])==samples*2
assert abs(float(a['duration'])-data['duration'])<.03
assert (P/'zombtlou-chapter1-full.mp4').stat().st_size<100*1024*1024,'File exceeds GitHub normal-file limit'
(P/'final-probe.json').write_text(json.dumps(probe,indent=2));print(json.dumps(probe,indent=2))
