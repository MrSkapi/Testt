import fs from 'node:fs';import {spawn} from 'node:child_process';import path from 'node:path';import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));const opt={};for(let i=2;i<process.argv.length;i+=2)opt[process.argv[i].replace(/^--/,'')]=process.argv[i+1];
const port=+(opt.port||9222),worker=+(opt.worker||0),workers=+(opt.workers||1),rate=12;
const data=JSON.parse(fs.readFileSync(path.join(root,'timeline.json'),'utf8'));const total=Math.ceil(data.duration*rate),per=60*rate,parts=Math.ceil(total/per);
const pages=await(await fetch(`http://127.0.0.1:${port}/json/list`)).json();let page=pages.find(p=>p.type==='page');const ws=new WebSocket(page.webSocketDebuggerUrl);await new Promise(r=>ws.onopen=r);let seq=0;const pending=new Map();
ws.onmessage=e=>{const r=JSON.parse(e.data);if(r.id){const q=pending.get(r.id);pending.delete(r.id);r.error?q.reject(Error(JSON.stringify(r.error))):q.resolve(r.result)}};
function cmd(method,params={}){return new Promise((resolve,reject)=>{const id=++seq;pending.set(id,{resolve,reject});ws.send(JSON.stringify({id,method,params}));setTimeout(()=>{if(pending.delete(id))reject(Error('Timeout '+method))},20000).unref()})}
await cmd('Page.enable');await cmd('Page.navigate',{url:'http://127.0.0.1:8765/chapter1.html?t=1'});for(let i=0;i<60;i++){let r=await cmd('Runtime.evaluate',{expression:'typeof render',returnByValue:true});if(r.result.value==='function')break;await new Promise(r=>setTimeout(r,100))}
await cmd('Runtime.evaluate',{expression:'document.fonts.ready',awaitPromise:true});fs.mkdirSync(path.join(root,'parts'),{recursive:true});
for(let part=worker;part<parts;part+=workers){if(opt.parts&&!opt.parts.split(',').map(Number).includes(part))continue;const a=part*per,b=Math.min(total,a+per),out=path.join(root,'parts',`part-${String(part).padStart(3,'0')}.mp4`);
 if(!opt.force&&fs.existsSync(out)&&fs.existsSync(out+'.ok')){console.log('REUSE',part);continue}
 const start=Date.now();let ff=spawn('ffmpeg',['-y','-v','error','-f','image2pipe','-framerate',String(rate),'-i','-','-an','-c:v','libx264','-threads','1','-preset','fast','-b:v','850k','-maxrate','1000k','-bufsize','2000k','-g','48','-keyint_min','24','-sc_threshold','0','-pix_fmt','yuv420p','-r','24','-movflags','+faststart',out],{stdio:['pipe','inherit','inherit']});
 const done=new Promise((resolve,reject)=>ff.on('close',c=>c?reject(Error('FFmpeg '+c)):resolve()));
 for(let f=a;f<b;f++){const t=f/rate;const r=await cmd('Runtime.evaluate',{expression:`render(${t});C.toDataURL('image/jpeg',.94)`,returnByValue:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));let bytes=Buffer.from(r.result.value.split(',')[1],'base64');if(!ff.stdin.write(bytes))await new Promise(res=>ff.stdin.once('drain',res));if((f-a)%180===0)console.log(`W${worker} PART ${part+1}/${parts}: ${(f-a)}/${b-a}; t=${t.toFixed(1)}s`)}
 ff.stdin.end();await done;fs.writeFileSync(out+'.ok',JSON.stringify({frames:b-a,start:a/rate,end:b/rate,seconds:(Date.now()-start)/1000}));console.log(`DONE PART ${part+1}/${parts} in ${((Date.now()-start)/1000).toFixed(1)}s`);
}
ws.close();console.log('WORKER COMPLETE',worker);
