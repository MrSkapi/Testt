from pathlib import Path
import json,shutil
P=Path(__file__).resolve().parent
data=json.loads((P/'timeline.json').read_text())
js='const DATA='+json.dumps(data,ensure_ascii=False)+';\n'+(P/'base.js').read_text()+'\n'+(P/'film.js').read_text()
player=r'''
const fixed=new URLSearchParams(location.search).get('t');
const audio=document.getElementById('voice'),seek=document.getElementById('seek'),play=document.getElementById('play'),clock=document.getElementById('clock');
seek.max=D;function stamp(x){return Math.floor(x/60)+':'+String(Math.floor(x%60)).padStart(2,'0')}
play.onclick=()=>{if(audio.currentTime>=D-.05)audio.currentTime=0;if(audio.paused)audio.play();else audio.pause()};
document.getElementById('replay').onclick=()=>{audio.currentTime=0;audio.play()};seek.oninput=()=>{audio.currentTime=+seek.value;render(+seek.value)};
function frame(){render(Math.min(D-.001,audio.currentTime));seek.value=audio.currentTime;clock.textContent=stamp(audio.currentTime)+' / '+stamp(D);play.textContent=audio.paused?'Play':'Pause';requestAnimationFrame(frame)}
if(fixed!==null){render(Math.max(0,Math.min(D-.001,+fixed||0)))}else requestAnimationFrame(frame);
'''
html='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Five days — Chapter 1</title><style>*{box-sizing:border-box}body{margin:0;background:#303a32;color:#dedfcb;font:14px sans-serif}main{max-width:1280px;margin:20px auto;padding:12px}canvas{display:block;width:100%;height:auto}footer{display:flex;gap:12px;align-items:center;padding:16px 0}input{flex:1}button{padding:9px 18px;background:#677a64;color:#f2efdb;border:1px solid #89977b;cursor:pointer}small{color:#abb99e}</style></head><body><main><canvas id="scene" width="1920" height="1080"></canvas><audio id="voice" src="narration.mp3" preload="metadata"></audio><footer><button id="play">Play</button><button id="replay">Replay</button><input id="seek" type="range" min="0" step="0.05" value="0"><span id="clock"></span></footer><small>Chapter 1 · English narration and captions</small></main><script>'''+js+player+'''</script></body></html>'''
(P/'chapter1.html').write_text(html);(P/'chapter1.js').write_text(js+player)
src=Path('/workspace/attachments/2d2cbecc-c3b9-459c-ae13-3feef25eed6c/ZombTLOU.mp3')
if not (P/'narration.mp3').exists():shutil.copyfile(src,P/'narration.mp3')
print('Built',len(data['shots']),'shots;',len(data['captions']),'captions;',data['duration'],'seconds')
