import {seg,poly,circle,alpha,shade,lerp,clamp} from '/engine/core.js';
import {C,box,ellipse,shadow} from './sets/props.js';
const INK='#111115',EDGE='#090a0d',SUIT='#424144',LIT='#68615a',BLUE='#46708a';
function path(g,fn,c,stroke=EDGE,w=1.6){g.beginPath();fn(g);g.fillStyle=c;g.fill();if(stroke){g.strokeStyle=stroke;g.lineWidth=w;g.lineJoin='round';g.stroke();}}
function button(g,x,y,r=6){circle(g,x,y,r+1,EDGE);ellipse(g,x,y-1,r,r*.83,'#242528');seg(g,[[x-r*.45,y-r*.4],[x+r*.3,y-r*.55]],1.3,'#77746a');}
function pocket(g,x,y,w,h){
 path(g,g=>{g.moveTo(x,y);g.lineTo(x+w,y-2);g.lineTo(x+w-3,y+h-9);g.quadraticCurveTo(x+w*.5,y+h+3,x+2,y+h-4);g.closePath();},'#3d3d40','#27272b',1);
 path(g,g=>{g.moveTo(x-1,y);g.lineTo(x+w+1,y-2);g.lineTo(x+w-1,y+18);g.quadraticCurveTo(x+w*.5,y+23,x,y+18);g.closePath();},'#474548','#232428',1.1);
 seg(g,[[x+3,y+2],[x+w-3,y]],.8,'#8a817133');button(g,x+w*.52,y+12,3.7);
}
function hair(g){
 path(g,g=>{g.moveTo(-76,-25);g.bezierCurveTo(-95,-73,-74,-104,-26,-107);g.bezierCurveTo(-8,-119,11,-107,32,-109);g.bezierCurveTo(58,-118,87,-99,84,-75);g.bezierCurveTo(99,-55,83,-33,76,-23);g.lineTo(64,-53);g.bezierCurveTo(27,-75,-26,-65,-66,-26);g.closePath();},'#111216',EDGE,2);
 const locks=[[-77,-47,-85,-76,-37,-104,0,-100],[-75,-57,-69,-86,-21,-109,17,-100],[-65,-70,-34,-96,5,-107,34,-96],[-45,-81,-19,-104,27,-108,48,-89],[-13,-88,10,-112,51,-106,61,-80],[18,-90,51,-111,74,-100,72,-73],[40,-84,80,-101,88,-80,76,-59]];
 for(let j=0;j<locks.length;j++){const q=locks[j];g.beginPath();g.moveTo(q[0],q[1]);g.bezierCurveTo(...q.slice(2));g.strokeStyle=j<4?'#444348':'#373b44';g.lineWidth=6-j*.3;g.lineCap='round';g.stroke();}
 for(let j=0;j<16;j++){
  const xx=-73+j*8;g.beginPath();g.moveTo(xx,-42-Math.sin(j*.18)*24);g.quadraticCurveTo(xx-22,-88,xx+16,-96+(j%4)*2);g.strokeStyle=j<6?'#ba865137':'#898c9b21';g.lineWidth=.8;g.stroke();
 }
 seg(g,[[-78,-48],[-78,-70],[-68,-85],[-47,-98],[-21,-105]],2.3,'#e2a35f');
 seg(g,[[39,-106],[61,-102],[78,-87],[82,-66]],1.7,BLUE);
}
export function face(g,o={}){
 g.save();g.translate(o.x||0,o.y||0);g.scale(o.s||1,o.s||1);if(o.tilt)g.rotate(o.tilt);
 const turn=clamp(o.turn??.25,-1,1),shift=turn*12;
 // A softened square jaw, visible ears and swept hair, all drawn as flat shapes.
 path(g,g=>{g.moveTo(-75,-52);g.bezierCurveTo(-85,-3,-79,52,-44,70);g.quadraticCurveTo(8,88,58,65);g.quadraticCurveTo(84,52,78,-14);g.lineTo(73,-55);g.quadraticCurveTo(8,-79,-75,-52);},INK,EDGE,2);
 path(g,g=>{g.moveTo(-73,-11);g.bezierCurveTo(-100,-28,-102,7,-86,21);g.quadraticCurveTo(-78,28,-69,17);},'#1b1b1f',EDGE,1.8);
 if(turn<.5)ellipse(g,77,6,8,19,'#16191f');
 seg(g,[[-75,-39],[-78,-9],[-73,29],[-57,55],[-32,69]],2.1,'#d0995e');
 seg(g,[[78,-28],[80,12],[77,43],[65,59]],1.9,BLUE);
 // Minimal face shading retains a black face, without realistic anatomy.
 path(g,g=>{g.moveTo(-75,-42);g.lineTo(-54,-57);g.lineTo(-56,-20);g.lineTo(-74,-4);g.closePath();},'#29282b',null);
 if(o.simplehair){path(g,g=>{g.moveTo(-75,-28);g.lineTo(-77,-62);g.quadraticCurveTo(-53,-90,13,-84);g.quadraticCurveTo(65,-84,76,-59);g.lineTo(76,-30);g.lineTo(61,-56);g.quadraticCurveTo(0,-65,-75,-28);},'#1c1d20',EDGE,2);seg(g,[[-74,-49],[-64,-67],[-42,-75]],1.7,'#ae895c');}else hair(g);
 const ey=-3+(o.down||0)*5,look=o.look||[0,0],blink=o.blink;
 for(let j=0;j<2;j++){
  const x=(-28+j*66)+shift;
  if(blink)seg(g,[[x-17,ey],[x+15,ey]],3.1,C.cream);
  else{
   ellipse(g,x,ey,19,10.5,o.fear?'#f7e8c9':'#eee4ce',-.055);
   ellipse(g,x+clamp(look[0],-1,1)*9+3,ey+clamp(look[1],-1,1)*4,6.2,9,EDGE);
  }
  const by=ey-23;
  g.beginPath();g.moveTo(x-20,by+(j?0:5));g.quadraticCurveTo(x,by-(j?(o.fear?9:-3):8),x+17,by+(j?-5:0));g.strokeStyle=C.cream;g.lineWidth=2.7;g.lineCap='round';g.stroke();
 }
 g.beginPath();g.moveTo(shift-12,42);g.quadraticCurveTo(shift+1,35+(o.fear?6:0),shift+13,39);g.strokeStyle=C.cream;g.lineWidth=3.1;g.lineCap='round';g.stroke();
 g.restore();
}
export function hero(g,x,y,s=1,o={}){
 shadow(g,x,y+3,105*s,11*s);
 g.save();g.translate(x,y);g.scale(s,s);
 // Shoes and trousers are anchored to the floor; the upper body can lean alone.
 for(let j of[-1,1]){
  const xx=j*43;
  path(g,g=>{g.moveTo(xx-37,-205);g.lineTo(xx+33,-205);g.lineTo(xx+36,-29);g.lineTo(xx+27,-13);g.lineTo(xx-31,-13);g.lineTo(xx-42,-99);g.closePath();},j<0?'#353539':'#3d3d41');
  poly(g,[[xx-31,-188],[xx-17,-168],[xx-22,-30],[xx-31,-24]],'#4e4d4e');
  seg(g,[[xx+18,-171],[xx+10,-83],[xx+19,-49]],1.1,'#1c1d23');
  path(g,g=>{g.moveTo(xx-32,-28);g.quadraticCurveTo(xx-48,-21,xx-51,-7);g.quadraticCurveTo(xx-53,6,xx+41,3);g.lineTo(xx+40,-20);g.lineTo(xx+23,-29);g.closePath();},'#101114');
  seg(g,[[xx-45,-6],[xx-26,-15],[xx+21,-12]],2,'#77736a');seg(g,[[xx-47,1],[xx+38,1]],3,'#09090d');
 }
 g.save();g.translate(o.lean||0,o.bob||0);
 // Far arm tucked naturally behind the back.
 path(g,g=>{g.moveTo(73,-377);g.bezierCurveTo(104,-365,128,-289,110,-257);g.lineTo(82,-226);g.lineTo(66,-273);g.closePath();},'#33373d');
 seg(g,[[101,-342],[114,-289],[104,-264]],2.2,BLUE);
 // Near arm, elbow outside the torso. Its hand follows the sleeve endpoint.
 const lift=o.handUp||0,handY=-195-lift*80;
 path(g,g=>{g.moveTo(-76,-375);g.quadraticCurveTo(-104,-366,-110,-329);g.lineTo(-126,handY-13);g.lineTo(-91,handY-8);g.lineTo(-62,-325);g.closePath();},'#4a4543');
 poly(g,[[-107,-329],[-119,handY-18],[-111,handY-13],[-91,-318]],'#292b30');
 seg(g,[[-91,-361],[-103,-323],[-121,handY-18]],2.4,'#dca25c');
 ellipse(g,-107,handY+10,16,24,INK,-.1);seg(g,[[-111,handY+9],[-110,handY+22]],1,'#454344');
 // Four-pocket high-collar tunic. Broader and shorter than the old stick rig.
 path(g,g=>{g.moveTo(-28,-396);g.quadraticCurveTo(-53,-388,-77,-379);g.quadraticCurveTo(-94,-361,-86,-319);g.lineTo(-98,-190);g.quadraticCurveTo(0,-173,98,-190);g.lineTo(81,-345);g.quadraticCurveTo(85,-369,60,-379);g.lineTo(24,-395);g.closePath();},SUIT);
 poly(g,[[-76,-373],[-63,-367],[-69,-214],[-92,-195],[-84,-323]],'#5f5548');
 poly(g,[[64,-373],[79,-350],[96,-192],[80,-189],[68,-321]],'#2e343e');
 seg(g,[[-78,-372],[-87,-322],[-96,-194]],2.2,'#db9f5c');
 seg(g,[[64,-376],[81,-358],[96,-194]],2.1,BLUE);
 // Fold lines are short and anchored to the garment seams.
 seg(g,[[-78,-288],[-63,-278],[-67,-266]],1.2,'#292a2e');seg(g,[[73,-260],[59,-250],[77,-245]],1.4,'#292b30');
 pocket(g,-66,-338,53,57);pocket(g,15,-340,58,59);
 pocket(g,-76,-233,60,38);pocket(g,22,-235,60,41);
 seg(g,[[-3,-372],[-13,-199]],1.5,'#22232a');
 for(let j=0;j<5;j++)button(g,-4-j*1.8,-363+j*39,5.3);
 // Collar wraps the neck; no exposed floating head or shirt triangle.
 box(g,-22,-425,44,44,INK,5);
 path(g,g=>{g.moveTo(-36,-407);g.lineTo(0,-390);g.lineTo(-5,-369);g.quadraticCurveTo(-38,-372,-41,-391);g.closePath();},'#595454');
 path(g,g=>{g.moveTo(0,-390);g.lineTo(35,-407);g.lineTo(40,-384);g.lineTo(7,-370);g.closePath();},'#4c4c51');
 seg(g,[[-35,-406],[-1,-390],[32,-405]],1.3,'#d3c0a4');
 // Fine deterministic woven strokes, clipped to the centre panel.
 g.save();g.beginPath();g.rect(-52,-275,105,37);g.clip();
 for(let k=0;k<22;k++)seg(g,[[-60+k*6,-273],[-43+k*6,-239]],.45,'#dad4b111');g.restore();
 face(g,{x:0,y:-484,s:1,turn:o.turn??.3,look:o.look||[.4,0],fear:o.fear,blink:o.blink,tilt:o.tilt,down:o.down});
 g.restore();g.restore();
}
export function aide(g,x,y,s=1,o={}){
 shadow(g,x,y,45*s,7*s);g.save();g.translate(x,y);g.scale(s,s);
 const bend=o.bend||0,step=o.walk?Math.sin(o.phase||0)*23:0,lift=o.walk?Math.max(0,Math.cos(o.phase||0))*12:0;seg(g,[[-17,-105],[-19+step*.5,-51],[-19+step,-lift],[-5+step,-lift]],17,INK);seg(g,[[19,-105],[22-step*.5,-51],[22-step,-(o.walk?12-lift:0)],[36-step,-(o.walk?12-lift:0)]],17,INK);
 g.save();g.translate(0,-108);g.rotate(bend);
 poly(g,[[-35,-139],[33,-139],[41,0],[-42,0]],o.color||'#5e6254');
 seg(g,[[-30,-133],[-49,-64],[-44,-10]],18,o.color||'#5e6254');
 seg(g,[[29,-133],[48,-65],[o.flinch?70:43,o.flinch?-97:-10]],18,o.color||'#5e6254');
 circle(g,-44,-9,9,INK);circle(g,o.flinch?70:43,o.flinch?-97:-9,9,INK);
 for(let j=0;j<4;j++)button(g,0,-113+j*29,3);pocket(g,-27,-111,22,27);pocket(g,8,-111,23,27);
 box(g,-12,-157,24,26,INK,4);box(g,-23,-144,45,15,'#696b59',2);face(g,{simplehair:true,x:0,y:-185,s:.47,turn:-.2,look:[-1,0],fear:true,blink:o.blink});
 g.restore();g.restore();
}
