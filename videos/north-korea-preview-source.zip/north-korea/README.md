# North Korea — first 15 seconds

Character preview based on the supplied visual reference. New black square-round head with swept hair, dark four-pocket tunic, stand collar, trousers, black shoes, warm amber and cool edge light. Drawn in Canvas using flat shapes, parallax, grain and depth of field. No generated character images.

Original English NorthKorea.mp3 is retained in input/voiceover.mp3. The source recording is 493.845 seconds; only its first 15 seconds are used here. Do not render the remaining story before the character is reviewed.

1920x1080, 24 fps. No subtitles, speech retiming, music or added SFX. No opening or closing fade.

Eight shots: spoon drop; aide flinch; second aide approaches; third aide apologizes; untouched breakfast; hero reaction; silent aides; glance toward the portraits. Timing uses the original speech; the rough ASR is only editorial guidance.

Render inside the existing 2d-video toolkit:

    node --import ./tools/local-runtime.mjs render-native.mjs --project projects/north-korea --from 0 --to 15 --workers 3 --gl auto --crf 21 --out projects/north-korea/build/preview-00-15-silent.mp4

Use ffmpeg to mux exactly 15 seconds of input/voiceover.mp3, keeping the sample rate and timeline. Runtime bootstrap tools/local-runtime.mjs uses system Chromium.
