# Survival story — workroom opening

15 seconds, 1920×1080, 24 fps; supplied voiceover preserved from 00:00 to 00:15 without speed changes. White bold English captions on compact black boxes.

This version retains the matte illustrated linework, paper texture and hatching while changing the composition: the protagonist stands in a workroom with a desk, game-lobby monitor, narrow roller-blind window, pegboard, equipment shelves, backpack and side door. The reference's centred sofa, mustard curtains, oval rug, floor lamp and coffee table are removed.

The hoodie has a taller rectangular silhouette with straight sides and small corner rounding. Each standing leg is one straight segment; feet are planted at the same floor height. The head remains round and touches the collar. Sleeves use the fixed-length two-bone arm solver. Phone and hands share a coordinate space. Captions sit lower to keep the feet visible in the wide shot.

Source files:
- illustrated-first15.html — self-contained browser animation (silent preview).
- scene.js — editable set, rig, shot timing, messages, caption cues and texture.
- build.py — rebuilds HTML from scene.js.
- render.mjs — renders MP4, using NARRATION_FILE to select the supplied audio. Default renderer output: zombtlou-workroom-first15.mp4.

To render: run build.py; serve the directory on 127.0.0.1:8765 with Python's HTTP server; run Chromium headless with remote debugging on port 9222 and a dedicated writable user-data directory; run render.mjs with Node.js. FFmpeg is required. --preview renders three seconds.

No pixels or audio from the style-reference recording are included in the result.
