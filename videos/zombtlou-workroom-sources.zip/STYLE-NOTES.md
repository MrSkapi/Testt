# Uploaded-reference observations

Both accessible reference recordings were inspected using contact sheets and full-size frames. The second accessible clip is 37.33 seconds long and includes a TV bulletin, an interference transition, hallway and door action, a window shutter, emergency lighting and a row of houses.

Visual language:
- flat frontal and simple side/three-quarter room staging;
- matte dusty colours, charcoal outlines, pencil hatching along surfaces and shape edges;
- small vertical black eyes, restrained mouth changes, round pale faces;
- slender legs and rounded segmented coat sleeves; preserve segment lengths and hand-to-prop contact;
- deliberate wide, reaction and object-insert cuts; camera movement is secondary to acting;
- environment colour changes can convey an alarm, without unrelated floating particles;
- screen interference belongs to a screen/broadcast shot; warning labels sit on the represented object;
- exteriors keep the same drawn outlines, wood siding, window divisions, roof panels, paths and modest paper texture;
- white bold subtitles on compact black boxes; explanatory headings may use separate yellow/white lettering.

Continuity decisions for the current workroom opening: retain the teal cap and rust-orange hoodie, with a round head and a taller rectangular body. The character stands on straight legs on the floor. Sets must have their own composition; preserve the reference’s drawing language without repeating its sofa-centred opening.

Reference footage itself is not included in the delivered animation or source package.
