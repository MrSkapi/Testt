from pathlib import Path
import json,csv,statistics
p=Path(__file__).resolve().parent.parent;w=json.loads((p/'timeline/words.json').read_text());w=w.get('words',[]) if isinstance(w,dict) else w
beats=[x.split('|') for x in (p/'story/beats.tsv').read_text().strip().splitlines()]
groups=[0,22,39.1,58.9,75.6,86.65,92.65,101,111.7,123.7,138.2,156.3,171.1,188.5,215.1,239,253.4,263.6,281.9,291.4,315.9,329.6,349.1,357.2,379.9,393,409.5,425.4,449.5,455.4,487]
shots=[]
for j,(t,v,m,loc) in enumerate(beats):
 t=float(t);st=round(t*24)/24;en=round(float(beats[j+1][0])*24)/24 if j+1<len(beats) else 487
 k=next(k for k in range(len(groups)-1) if groups[k]<=t<groups[k+1]);params=dict(view=v,mode=m,place=loc,groupStart=groups[k],groupEnd=groups[k+1],night=171<=t<253 or 329.6<=t<357.2 or t>=455.4)
 if v in ['cafePair','business','encounter','dinner','shelfWide','clinicPair'] and j%4==1:params.update(frame='medium',focusX=960,focusY=640)
 tr='flash' if t==101 else 'dip' if t in [24.8,101,138.2,171.1,253.4,315.9,349.1,381.2,393,449.5,455.4] else 'fade' if t in [239,476.9] else 'cut'
 shots.append(dict(id=f'ea{j+1:03}',start=st,end=en,line=' '.join(x['word'] for x in w if st<=x['start']<en),scene=f'{v}: {m}; specific action in {loc}, grounded 2D acting with layered depth.',set=loc,bars='wide',captions=False,params=params,**{'in':dict(type=tr,dur=.18)},sfx=[]))
assert shots[0]['start']==0 and all(s['end']>s['start'] for s in shots)
(p/'story/shots.json').write_text(json.dumps(dict(title='SECOND START — Eighteen Again',duration=487,shots=shots,music=[],sfx=[]),indent=2));c=json.loads((p/'config.json').read_text());c.update(title='SECOND START — Eighteen Again',duration=487);(p/'config.json').write_text(json.dumps(c,indent=2))
with (p/'story/scene-markers.csv').open('w') as f:
 z=csv.writer(f);z.writerow(['id','start','end','view','mode','location']);z.writerows([s['id'],s['start'],s['end'],s['params']['view'],s['params']['mode'],s['set']] for s in shots)
print(len(shots),'shots;',statistics.median(s['end']-s['start'] for s in shots),'median; 487 seconds')
