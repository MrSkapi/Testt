# SECOND START — Eighteen Again

A suspenseful, tender speculative story for the supplied 18iarasi.mp3. Alex, 39, returns to his eighteenth birthday while retaining his baseline memories. He saves his father from one illness and improves his career, then discovers six earlier restarts whose memories he chose to erase. Maya remembers their daughter Sophie. Sophie survived treatment in that archived life; the current decisions prevented Alex and Maya from meeting at their old job, so that particular daughter was never born here. The film never presents Sophie as dying during treatment or physically returning in the current timeline.

The company keeps records outside time. The late reveal is Alex’s own instruction to let him believe each reset was the first. At the end he keeps the recordings, stays in an imperfect life, and closes an unconfirmed appointment when Maya calls after his father’s funeral. He leaves the account intact.

## Cast and design

Alex: the established black round head, orange hoodie #ed9437, cream facial features, thin black limbs, rim light on the visible silhouette, no headwear. Present Alex stays clean-faced; changes in age are shown only in clearly framed archived videos with labels. A bad haircut appears only in the explicit graduation photograph.

Father: teal cardigan #459b91, glasses and restrained knitted pattern. Mother: mauve #ac7bc6 with grey bun. Maya: rose #c1779a with a dark bun, preserved in her recordings and family photographs. Sophie: smaller gold-clad child #d8b258 with a paper crown in the family photo; two tiny front teeth separated by a gap. Claire/another young woman: blue. Technician: pale teal #83aeb9. Counselor/reception: muted olive.

Flat code-drawn 2D acting with layered 2.5D environments. No realistic anatomy or generated assets. All authored text is English; no subtitles or dialogue floating above heads. Object labels belong to paper, signs, clothing, files and screens. Generic phone/billing headers remain distinct from the Second Start site.

## Sets and atmosphere

- Clinic: teal daylight, an anchored circular apparatus, padded bed, controls, bookshelf/book, plant, real doorway and a foreground consultation table. The device is a time machine, with no medical injury imagery.
- Original/archival study: plum/night windows, warm practical light, shelves, desktop computer, paper, cup and recordings. Current consent stays unticked; archived consent shows memory relief selected.
- Eighteenth-birthday bedroom: warm morning, the familiar ceiling crack, old computer, poster, pillow, blue blanket, book and plant.
- Family kitchen/garden: peach walls, teal cabinetry, patterned cardigan, fence, trimmed grass and a physical lawn mower. Stair contacts use actual step surfaces. Alex stays beside his father after the hug before walking away continuously.
- Business/medical scenes: bright blue office and calm green hospital. Illness is handled non-graphically, with a supported child seated in bed and both parents present in the archived life.
- Cafe/street: colorful facades, warm windows, hanging lamps, cups, chairs, tables and foreground depth. Alex remains left and Maya right; she walks away right without exchanging places with him. The Northline badge sits inside his clothing silhouette.
- Laundromat/clinic address: the same storefront geometry changes across years. The temporal-anchor explanation distinguishes records outside time from a clinic that has not yet been built.
- Workshop: amber wood, night window and a deliberately crooked shelf. Hands target the two board endpoints. The screw reaches the father’s hand, and Alex withdraws his own hand after passing it.
- Final home: father’s framed photograph, the archived family photograph, a kept recording drive and an unconfirmed booking. No account deletion or new reset is shown.

## Poll

At 1:26.667–1:32.667, the narration asks viewers to vote in the channel Posts tab. Show the user’s complete question, subtitle and all five exact story titles simultaneously. A restrained pointer moves toward the Posts button; no option is selected and no results are invented. This is a film graphic, not an actual published community poll. story/poll.json preserves the supplied text. A full-resolution still is delivered separately.

## Timing and motion

487 seconds, 181 contiguous shots, 24fps; median shot 2.583 seconds. Original voice is authoritative. Word timings come from local Whisper base.en and serve as editorial cues, not displayed captions.

Fixed framing per shot and shared absolute camera clocks prevent repeated zoom resets. Inserts receive a restrained continuous lateral drift. Motions are purposeful: fitting the head strap, lowering the apparatus, an anchored stair step, lawn-mower pull, hug, footsteps, photo flip, paper/cursor interactions, Maya standing and leaving, shelf support, screw transfer, carrying records home and closing the booking page. Talking mouths use one shape rather than a line plus an overlapping oval. Standing bodies breathe slightly while feet remain planted.

Original mono English narration is kept unchanged in speed/order. No added music, wind or replacement voice. The final visual hold is about 1.2 seconds beyond the recording.
