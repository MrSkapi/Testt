# SECOND START — Eighteen Again

Complete illustrated video for 18iarasi.mp3: 487 seconds (8:07), 1920×1080, 24fps, 16:9, 181 shots, 11,688 frames. Original recording duration: 485.799125 seconds. English narration unchanged in speed/order, no subtitles or added audio tracks. The established black/orange hero has no hat.

Use kit-overrides/ as a minimal studio root, or apply it over the 2d-video toolkit. Put eighteen-again/ in that root’s projects/eighteen-again/ directory. Run npm install and install ffmpeg and Chromium. tools/local-runtime.mjs selects /usr/bin/chromium here; adjust the path on another machine.

Render from the studio root:

    node --import ./tools/local-runtime.mjs render-native.mjs --project projects/eighteen-again --workers 3 --gl auto --crf 21 --out projects/eighteen-again/build/full-silent.mp4

Mux without changing narration timing:

    ffmpeg -i projects/eighteen-again/build/full-silent.mp4 -i projects/eighteen-again/input/voiceover.mp3 -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -af apad -t 487 -movflags +faststart eighteen-again.mp4

story/shots.json owns all timing. story/beats.tsv and build_story.py reproduce the editorial plan from timeline/words.json. story/bible.md describes the cast, staging, timeline logic and visual language. The supplied voiceover is authoritative; the transcript is an editorial aid.

story/poll.json contains the five exact user-supplied poll choices. The poll appears at 1:26.667–1:32.667. All choices remain readable at once; the film points viewers to Posts and does not invent a vote or publish a real poll.

Use --from A --to B --scale .5 for partial previews. Never render two native videos concurrently into the same project build directory because their encoder intermediates are shared. No image or video generation assets are needed.

validation/ contains source/timeline checks, full media/voiceover checks, a contact sheet, the full-resolution poll and a narrated family motion excerpt extracted from the master (1:51.708–2:07.500).
