const waveCanvas=document.createElement('canvas');waveCanvas.width=W;waveCanvas.height=H;
const gl=waveCanvas.getContext('webgl',{alpha:false,antialias:false,preserveDrawingBuffer:true});
if(!gl)throw Error('WebGL unavailable');
function shader(type,source){const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s}
const program=gl.createProgram();
gl.attachShader(program,shader(gl.VERTEX_SHADER,`attribute vec2 pos; varying vec2 uv; uniform float time;
void main(){vec2 base=(pos+1.0)*0.5;vec2 p=base*vec2(1920.,1080.);
 float x=.85*sin(p.y*.013+time*.9)+.45*sin(p.x*.008-p.y*.006-time*.55);
 float y=.70*sin(p.x*.011+time*.8)+.30*sin(p.y*.019+time*.65);
 float boil=floor(time*6.0);x+=.105*sin(p.y*.059+boil*1.7);y+=.0875*sin(p.x*.047+boil*2.1);
 uv=base+vec2(x/1920.,y/1080.);gl_Position=vec4(pos,0.,1.);}`));
gl.attachShader(program,shader(gl.FRAGMENT_SHADER,`precision highp float;uniform sampler2D world;varying vec2 uv;
void main(){gl_FragColor=texture2D(world,clamp(uv,vec2(.0008),vec2(.9992)));}`));
gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));gl.useProgram(program);
const buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);const mesh=[];for(let y=0;y<54;y++)for(let x=0;x<96;x++){const a=x/96*2-1,b=y/54*2-1,X=(x+1)/96*2-1,Y=(y+1)/54*2-1;mesh.push(a,b,X,b,a,Y,X,b,X,Y,a,Y)}gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(mesh),gl.STATIC_DRAW);
const pos=gl.getAttribLocation(program,'pos');gl.enableVertexAttribArray(pos);gl.vertexAttribPointer(pos,2,gl.FLOAT,false,0,0);
const tex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,tex);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);
const timeUniform=gl.getUniformLocation(program,'time');
function warp(t){gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,C);gl.uniform1f(timeUniform,t);gl.drawArrays(gl.TRIANGLES,0,mesh.length/2);gl.finish();g.drawImage(waveCanvas,0,0)}
