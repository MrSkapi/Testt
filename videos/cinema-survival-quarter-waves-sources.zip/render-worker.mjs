import fs from 'node:fs';import {spawn} from 'node:child_process';import {connect} from './cdp.mjs';
const worker=+(process.argv[2]||0),workers=+(process.argv[3]||1),port=+(process.argv[4]||9270),fps=24;
const data=JSON.parse(fs.readFileSync('timeline.json','utf8')),total=Math.ceil(data.duration*fps),per=480,parts=Math.ceil(total/per),hash=fs.readFileSync('build-hash.txt','utf8').trim();fs.mkdirSync('parts',{recursive:true});
const {cmd,ws}=await connect(port);
for(let part=worker;part<parts;part+=workers){
 const a=part*per,b=Math.min(total,a+per),out=`parts/part-${String(part).padStart(3,'0')}.mp4`;
 const compat=fs.existsSync('render-compatibility.json')?JSON.parse(fs.readFileSync('render-compatibility.json','utf8')):{};const reusable=old=>old===hash||compat.currentHash===hash&&compat.compatible?.some(x=>x.hash===old&&!x.excludeParts.includes(part));if(fs.existsSync(out+'.ok')&&reusable(JSON.parse(fs.readFileSync(out+'.ok','utf8')).hash)){console.log('REUSE',part);continue}
 if(fs.existsSync(out+'.ok'))fs.unlinkSync(out+'.ok');
 const ff=spawn('ffmpeg',['-y','-v','error','-f','image2pipe','-framerate','24','-i','-','-an','-c:v','libx264','-threads','1','-preset','fast','-tune','animation','-crf','19','-g','48','-pix_fmt','yuv420p','-r','24','-movflags','+faststart',out],{stdio:['pipe','inherit','inherit']});
 const done=new Promise((r,j)=>ff.on('close',c=>c?j(Error('FFmpeg '+c)):r()));const began=Date.now();
 for(let f=a;f<b;f++){
  const r=await cmd('Runtime.evaluate',{expression:`render(${f}/24); C.toDataURL('image/jpeg',.96)`,returnByValue:true});
  if(r.exceptionDetails){ff.stdin.destroy();ff.kill();throw Error(JSON.stringify(r.exceptionDetails))}
  const buf=Buffer.from(r.result.value.split(',')[1],'base64');if(!ff.stdin.write(buf))await new Promise(r=>ff.stdin.once('drain',r));
  if((f-a)%120===0)console.log(`W${worker} PART ${part+1}/${parts} ${f-a}/${b-a} t=${(f/24).toFixed(1)} fps=${((f-a+1)/((Date.now()-began)/1000)).toFixed(1)}`);
 }
 ff.stdin.end();await done;const r=await cmd('Runtime.evaluate',{expression:'JSON.stringify(audit)',returnByValue:true});fs.writeFileSync(out+'.ok',JSON.stringify({hash,frames:b-a,part,start:a/24,end:b/24,audit:JSON.parse(r.result.value)},null,2));console.log('DONE',part,((Date.now()-began)/1000).toFixed(1)+'s');
}await cmd('Page.close');ws.close();console.log('WORKER COMPLETE',worker);
