const SHOTS=DATA.shots;let current=null;
function active(t){let a=0,b=SHOTS.length-1;while(a<=b){const m=(a+b)>>1,s=SHOTS[m];if(t<s.start)b=m-1;else if(t>=s.end)a=m+1;else return s}return SHOTS[SHOTS.length-1]}
function pct(s,t,a=0,b=1){return ease((t-s.start-a)/Math.max(.01,(s.end-s.start)*b-a))}
function walkTo(id,x0,x1,y,s,t,q,o={}){const x=lerp(x0,x1,q);return person(id,x,y,s,t,{...o,walk:q>0&&q<1,distance:x-x0,dir:x1>x0?1:-1})}
function blockFreezer(x,y,q=0,fall=0){g.save();g.translate(x,y);g.rotate(fall);rect(-206,-178,412,161,'#829d92',ink,5,7);rect(-198,-191,397,28,'#b7c5aa',ink,4,5);line(-150,-181,157,-181,'#d9d6b3',4);for(const x of[-145,145])oval(x,-2,20,20,'#344f49',ink,3);if(q>0){path([[-194,7],[-223,7],[-209,-19]],'#8e7552',ink,2);path([[169,7],[201,7],[183,-19]],'#8e7552',ink,2)}g.restore()}
function sofa(x,y){rect(x-220,y-124,440,98,'#756c7c',ink,5,13);rect(x-201,y-159,403,72,'#928397',ink,3,12);rect(x-208,y-67,418,36,'#a191a0',ink,3,9);for(const xx of[x-192,x+188])line(xx,y-27,xx,y,'#493e4d',8)}
function steelDoor(x,y,w,h,amount=0,tilt=0){rect(x,y,w,h,'#263d3f',ink,4);w*=1-.45*amount;g.save();g.translate(x,y);g.rotate(tilt);rect(0,0,w,h,'#557a75',ink,5,2);rect(42,64,w-84,116,'#8fa6a0',ink,4);line(w-55,h*.55,w-55,h*.55+60,'#c6c9a5',8);for(const yy of[45,h-75])rect(-8,yy,23,34,'#b4bca0',ink,2);g.restore();}
function sceneBase(s,t){scenery(s.location,s.light);if(s.location==='office'&&(s.day>=27||['sofablock','sofamove'].includes(s.action)))rect(204,729,470,219,'#6d8678',null);if(s.location==='office'&&s.day>=10){rect(881,417,374,244,'#283e40',null);}if(s.day>=10&&['office','projection','corridor','stockroom'].includes(s.location)){g.fillStyle=s.light==='night'?'#172d3d55':'#233a3c24';g.fillRect(0,0,W,H)}hatch(40,120,1840,700,32,'#3b34271a',18)}
function drawMap(s,t){
 sceneBase(s,t);rect(260,232,1384,649,'#b19262',ink,5,5);rect(284,255,1336,599,'#dbd3b4',ink,2);label('CINEMA · STAFF ROUTE',326,303,37,'#465d53');
 const rooms=[[353,357,393,237,'SCREEN 1'],[834,354,285,236,'SCREEN 4'],[1204,354,326,236,'LOBBY'],[351,680,774,106,'REAR CORRIDOR'],[1201,677,328,108,'FRONT EXIT']];
 for(const[x,y,w,h,n]of rooms){rect(x,y,w,h,'#bac3a0','#536f61',4,3);label(n,x+w/2,y+h*.56,30,'#425f50','center')}
 line(1118,733,1200,733,'#6e8d79',21);line(549,594,549,680,'#6e8d79',21);line(1394,590,1394,677,'#6e8d79',21);
 let pen=[1140,730];const route=[[1153,742],[550,742],[550,476],[1351,476],[1351,733],[1542,733]],q=pct(s,t,.2,.7),bad=s.action==='mapblocked';
 if(bad){line(1110,704,1161,756,'#a44e3d',8);line(1161,704,1110,756,'#a44e3d',8);label('LOADING EXIT BLOCKED',973,826,28,'#a14d3d','center')}
 else{let left=q*(route.length-1);for(let i=0;i<route.length-1;i++){const z=clamp(left-i);if(z>0){const p=mix(route[i],route[i+1],z);line(...route[i],...p,'#a4663f',8)}}const k=Math.min(route.length-2,Math.floor(left)),p=mix(route[k],route[k+1],left-k);oval(...p,11,11,'#ac663f',null);pen=p}
 if(s.action==='mapbathroom'){rect(1207,354,320,80,'#8ea9a0',ink,3);label('BATHROOM ✓',1366,406,28,'#3c5e53','center')}
 g.save();const mx=pen[0]+28,my=pen[1]+44;line(mx+79,1120,mx,my,ink,29);line(mx+79,1120,mx,my,'#ad6038',20);line(mx,my,mx-28,my-44,'#4b5550',6);oval(mx,my,15,15,ink,null);g.restore();
}
function screenPhone(s,t){
 sceneBase(s,t);g.fillStyle='#1b302b45';g.fillRect(0,0,W,H);g.save();g.translate(960,533);g.rotate(-.025);rect(-222,-342,444,730,'#344b4b',ink,7,24);rect(-200,-305,400,635,'#d1d7be',ink,3,12);rect(-71,-328,142,10,'#253938',null,0,4);label(s.action==='nosignal'?'NO SIGNAL':s.action==='phonebattery'?'11% BATTERY':['pressplay','downloaded'].includes(s.action)?'OFFLINE MOVIES':['brothervideo','bentouch','volume'].includes(s.action)?'SAVED VIDEO':'CAMERA',0,-255,37,'#486458','center');
 if(['brothervideo','bentouch','volume'].includes(s.action)){
  rect(-180,-208,360,350,'#8e9e89',ink,3,4);g.save();g.beginPath();g.rect(-178,-206,356,346);g.clip();g.translate(0,0);person('ben',70,284,.57,t,{emotion:'neutral',talk:.4});person('survivor',-92,311,.64,t,{talk:.4});g.restore();label('BEN + LIAM',0,197,30,'#4a6654','center');line(-159,245,160,245,'#a0af90',7);line(-159,245,-150+296*pct(s,t),245,'#5d8271',7);
 }else if(s.action==='nosignal'){for(let i=0;i<4;i++)rect(-68+i*37,5-i*17,25,20+i*17,'#91a38a',null);line(-82,-70,89,101,'#a55943',8);label('Searching…',0,196,35,'#536c58','center')}
 else if(s.action==='phonebattery'){rect(-114,-100,228,106,null,ink,5,7);rect(114,-71,16,46,'#516c57',ink,2);rect(-104,-90,23,86,'#af7751',null);label('11%',0,95,74,'#4d6753','center')}
 else if(s.action==='downloaded'||s.action==='pressplay'){for(let i=0;i<3;i++){rect(-171,-195+i*131,342,104,['#839b8a','#9c966f','#6e9293'][i],ink,2,7);label(['OFFLINE MOVIE','AUDIENCE APPLAUSE','SAVED VIDEO'][i],0,-138+i*131,27,'#e8e3c8','center')}if(s.action==='pressplay'){const q=pct(s,t,0,.5);oval(111,124,25,25,'#4f7c69',ink,3);line(102,110,102,137,'#e7e2c6',6);line(118,110,118,137,'#e7e2c6',6)}}
 else{rect(-183,-194,366,395,'#778c82',ink,2);rect(-164,-175,328,354,'#a3b9a3',null);person('hero',0,332,.56,t,{talk:.3});oval(0,269,34,34,'#a4664d','#f0e4c6',4)}
 line(-215,217,-327,555,ink,50);line(-215,217,-327,555,'#ad6038',34);oval(-214,211,27,27,ink,null);oval(217,223,25,25,ink,null);
 if(['bentouch','volume','pressplay'].includes(s.action)){const q=pct(s,t);const p=[lerp(171,114,q),lerp(354,124,q)];line(p[0]+140,587,...p,ink,37);line(p[0]+140,587,...p,s.action==='pressplay'?'#ad6038':'#ae9944',26);oval(...p,22,22,ink,null)}
 g.restore();
}
function speakerInsert(s,t){sceneBase(s,t);const a=s.action,q=pct(s,t,.1,.7);rect(391,588,1147,39,'#988159',ink,4);rect(563,339,804,239,'#4b6966',ink,5,15);for(let i=0;i<28;i++)for(let j=0;j<7;j++)oval(590+i*27,369+j*24,2.2,2.2,'#b5bd9d40',null);oval(1299,382,12,12,a==='speakerdead'?'#636f5f':a==='speakerlow'?'#c27d48':'#b2c36e',ink,2);
 const level=a==='speakerbattery'?.5:a==='speakerlow'?.08:a==='speakerdead'?0:.4;rect(1200,505,112,36,null,'#a2b494',3,4);rect(1207,512,98*level,22,level<.1?'#af7951':'#a2b494',null);
 if(['speakerplaying','speakerlow','speakertest'].includes(a))for(let i=0;i<3;i++){const r=37+((t*31+i*42)%130);g.beginPath();g.arc(1397,461,r,-.6,.6);g.strokeStyle='#e6d19c'+Math.round(110*(1-r/180)).toString(16).padStart(2,'0');g.lineWidth=4;g.stroke()}
 if(a==='speakerplace'){line(1470,1020,1280,530-120*q,ink,31);line(1470,1020,1280,530-120*q,'#ad6038',22);oval(1280,530-120*q,20,20,ink,null)}
 if(a==='speakerready')label('CONNECTED · SILENT',963,701,38,'#d5d5b9','center');
}
function lockInsert(s,t){sceneBase(s,t);const q=pct(s,t,.05,.7);rect(495,184,930,722,'#63817a',ink,5);line(547,194,547,887,'#37574f',7);rect(798,434,349,113,'#334e4b',ink,4,8);rect(831,452,282,73,'#b8bfa2',ink,3,7);const slide=['lockturn','benlatch'].includes(s.action)?95*q:0;rect(748+slide,463,288,49,'#a7b69a',ink,3,5);oval(1012,679,41,41,'#b6ba99',ink,3);
 if(['keylock','lockturn','frontkey'].includes(s.action)){g.save();g.translate(1012,679);g.rotate((s.action==='keylock'?Math.sin(t*24)*.035:q*1.5));line(0,0,67,0,'#c7c8aa',13);oval(79,0,17,17,null,'#bfc6a5',7);line(82,11,240,340,ink,32);line(82,11,240,340,'#ad6038',22);oval(78,12,21,21,ink,null);g.restore()}
 else{const x=lerp(832,927,q);line(x+230,1110,x,493,ink,34);line(x+230,1110,x,493,s.action==='benlatch'?'#ae9944':'#ad6038',24);oval(x,493,24,24,ink,null)}
}
function hingeInsert(s,t){sceneBase(s,t);const bad=s.action==='hingefails',q=pct(s,t);rect(637,98,646,835,'#496f6a',ink,5);line(671,105,671,928,'#233f3d',15);g.save();g.translate(678,353);g.rotate((bad?.20*q:.035+.012*Math.sin(t*2)));rect(0,0,275,188,'#a2b19a',ink,4,6);line(131,7,131,181,'#48685c',10);for(const[x,y]of[[34,35],[237,35],[34,150],[237,150]]){oval(x,y,12,12,'#5f7b66',ink,2);line(x-6,y-5,x+6,y+5,'#b2c5a1',2)}if(bad){line(12,7,-30*q,-30*q,'#cad1ad',7);path([[-15,-13],[-40,-3],[-25,18],[-43,34]],null,'#282d29',4,false)}g.restore();hatch(698,577,466,280,38,'#1b333129')}
function propsInsert(s,t){
 sceneBase(s,t);const a=s.action,q=pct(s,t);rect(228,379,1460,480,'#a08257',ink,5,5);hatch(245,397,1421,440,60,'#4b42292b');
 if(['clock','rota','checklist'].includes(a)){rect(499,226,924,549,'#dbd6b7',ink,4,6);label(a==='rota'?'CLOSING SHIFT':a==='checklist'?'OUR RULES':'TIME',956,300,37,'#4a6454','center');for(const [i,row]of(s.detail||'11:46 PM').split('\n').entries())label(row,957,420+i*104,a==='clock'?89:40,'#4b6553','center');return}
 if(['watercount','watersupply','rationjugs','markwater','benwater','suppliesremain'].includes(a)){
  for(let i=0;i<4;i++)jug(510+i*293,538,1.6,.8-s.day*.013,Math.min(5,Math.floor(s.day/3)));
  if(a==='markwater'){const mx=566+q*21;line(mx+250,1110,mx,656,ink,35);line(mx+250,1110,mx,656,'#ad6038',24);oval(mx,656,22,22,ink,null);line(553,651,553+q*27,651,'#303e32',4)}return;
 }
 if(['packing','bagcontents','bagsready','missingphone'].includes(a)){pack(512,620,1.8);for(let i=0;i<2;i++){g.save();g.globalAlpha=clamp(q*4-i*.25);jug(868+i*180,524,1.14);g.restore()}snack(1220,617,1.5,'bar');rect(1121,704,87,48,'#c8bd9d',ink,3,5);rect(1230,704,87,48,'#c8bd9d',ink,3,5);if(a!=='missingphone')aidBox(1450,581,.9);else{rect(1400,559,92,148,null,'#988f7188',3,8);line(1382,542,1509,724,'#9b6551',5)}return}
 if(a==='wetpatch'){oval(947,593,110,37,'#516f6770',null);oval(1060,639,12,5,'#516f6770',null);return}
 if(a==='mugtorch'){rect(839,472,203,214,'#c7c5a6',ink,5,15);oval(1060,562,49,58,null,'#c7c5a6',18);rect(898,275,81,257,'#4e716b',ink,4,6);oval(938,277,43,17,'#e1d2a0',ink,3);path([[895,278],[686,0],[1175,0],[981,278]],'#f0db9b23',null);return}
 if(a==='foldmap'){g.save();g.translate(940,566);g.scale(1-q*.65,1-q*.45);rect(-320,-210,640,420,'#d3cbaa',ink,4);line(-280,-40,278,-40,'#678978',13);line(-100,-170,-100,170,'#6e8a75',11);g.restore();for(const x of[720,1170]){line(x+80,1110,lerp(x,950,q),680,ink,35);line(x+80,1110,lerp(x,950,q),680,'#ae9944',25);oval(lerp(x,950,q),680,22,22,ink,null)}return}
 if(a==='findtorch'){for(let i=0;i<2;i++){const x=690+i*466;rect(x,397,69,300,'#4f726b',ink,4,8);rect(x-17,364,102,79,'#9cae8c',ink,3,5)}return}
 if(a==='controls'||a==='soundcontrols'||a==='playtrailer'){rect(410,299,1100,442,'#4a6a65',ink,5,10);for(let i=0;i<4;i++){rect(473+i*255,356,210,166,i===3?'#8c9567':'#718b7e',ink,3,5);label('SCREEN '+(i+1),578+i*255,407,28,'#e3dfbc','center');oval(577+i*255,465,26,26,'#b8b58a',ink,2)}const x=1344,y=lerp(850,470,q);line(1510,1120,x,y,ink,35);line(1510,1120,x,y,'#ad6038',24);oval(x,y,22,22,ink,null);return}
}
const MAPS=new Set(['map','mapdraw','maptrace','mapbathroom','mapblocked','maproute','mapone']);
const PHONES=new Set(['nosignal','downloaded','brothervideo','bentouch','volume','pressplay','phonebattery']);
const SPEAKERS=new Set(['findspeaker','speakerbattery','speakertest','speakerplace','speakerready','speakerplaying','speakerlow','speakerdead']);
const LOCKS=new Set(['keylock','lockturn','benlatch','frontkey']);
const HINGES=new Set(['hingescrape','hingefails']);
const INSERTS=new Set(['clock','rota','checklist','watercount','rationjugs','markwater','benwater','suppliesremain','packing','bagcontents','missingphone','wetpatch','mugtorch','foldmap','findtorch','soundcontrols','playtrailer']);
function insertFor(s,t){if(MAPS.has(s.action)){drawMap(s,t);return true}if(PHONES.has(s.action)){screenPhone(s,t);return true}if(SPEAKERS.has(s.action)){speakerInsert(s,t);return true}if(LOCKS.has(s.action)){lockInsert(s,t);return true}if(HINGES.has(s.action)){hingeInsert(s,t);return true}if(INSERTS.has(s.action)){propsInsert(s,t);return true}return false}
function worldAction(s,t){
 const a=s.action,q=pct(s,t,.05,.9),u=t-s.start,hasBen=s.day>=5&&s.day!==0;
 const H=(x=1330,y=948,sc=1.04,o={})=>hero(x,y,sc,t,{badge:s.day<5,emotion:'worry',...o});
 const B=(x=880,y=948,sc=.71,o={})=>person('ben',x,y,sc,t,o);
 const Z=(x,y=948,sc=1,o={})=>person('infected',x,y,sc,t,{lean:.045,...o});
 if(['opening','torch','shock','eating','workflashback'].includes(a)){
  if(a==='eating'){person('infected',865,979,.90,t,{sit:true,hands:[[-20,-402],[20,-401]],head:.12,talk:.2+.2*Math.sin(t*7)});oval(878,592,9,4,'#81483d',null)}
  else{H(1407,948,1.04,{pose:a==='workflashback'?'phone':'torch',emotion:a==='shock'?'shock':'worry',look:[-7,4],head:a==='shock'?.025:0});if(a!=='workflashback')person('infected',865,979,.90,t,{sit:true,hands:[[-20,-402],[20,-401]],head:.12,talk:.25})}
  return;
 }
 if(['closeauditorium','steeldoor','checkdoor','impact','closefour','checkfour','fourpounding','powerpounding','runningout','closeone'].includes(a)){
  const doorX=s.location==='lobby'?1430:760,dy=314,amount=['impact','fourpounding','powerpounding'].includes(a)?Math.max(0,Math.sin(u*3.6))*2:0;
  const closing=['closeauditorium','closefour','closeone'].includes(a)?1-q:0;steelDoor(doorX+amount,dy,315,634,closing,0);label(a==='closeone'?'SCREEN 1':s.location==='lobby'?'SCREEN 4':'STAFF ACCESS',doorX+157,dy+130,24,'#d1d7b6','center');
  if(['impact','fourpounding','powerpounding'].includes(a))for(let i=0;i<3;i++){const z=(u*1.2+i*.33)%1;line(doorX-22-z*12,dy+217+i*80,doorX-34-z*30,dy+199+i*80,'#d7b784'+Math.round((1-z)*120).toString(16).padStart(2,'0'),3)}
  const grip=['checkdoor','checkfour','closefour','closeone','closeauditorium','steeldoor'].includes(a),px=doorX+130,target=[(315*(1-.45*closing)-55-130)/1.04,(dy+634*.55+30-948)/1.04];H(px,948,1.04,{pose:grip?'stand':'listen',hands:grip?[[-66,-222],target]:undefined,look:[8,2]});return;
 }
 if(a==='lobbyattack'){person('woman',630,1057,.82,t,{sit:true,head:.18,emotion:'shock'});for(let i=0;i<3;i++)Z(450+i*175,948,.87,{lean:i===1?-.09:.09,hands:[[-40,-325],[55,-324]],look:[4,8]});return}
 if(['ascend','descend','carrywater','pairascend'].includes(a)){
  const up=a!=='descend',z=up?q:1-q,x=lerp(250,1640,z),y=948-z*450;walkTo('hero',up?250:1640,up?1640:250,y,1.0,t,q,{pose:a==='carrywater'?'carry':'stand',look:[up?6:-6,0]});
  if(a==='pairascend'){const k=clamp(z+.12);person('ben',lerp(250,1640,k),948-k*450,.70,t,{walk:true,distance:k*1390,look:[7,0]})}return;
 }
 if(['buscrash','streetpanic','alleycrowd','rainalley','twopass','vanblock','ladderview'].includes(a)){
  if(a==='streetpanic'){walkTo('survivor',190,1170,948,.95,t,q);walkTo('woman',1480,420,948,.90,t,q,{emotion:'shock'});walkTo('infected',1600,680,948,1,t,q,{lean:.045})}
  if(a==='alleycrowd'){for(let i=0;i<6;i++)Z(950+i*125,948,.87,{head:.06,hands:[[-74,-313],[90,-317]]});return}
  if(a==='twopass'){walkTo('infected',580,1390,948,.91,t,q,{lean:.045});walkTo('infected',340,1110,948,.96,t,q,{lean:.035})}
  if(a==='rainalley'){for(let i=0;i<90;i++){const X=(i*79.37+t*123)%1920,Y=(i*91.17+t*287)%1080;line(X,Y,X-12,Y+32,'#c6ded440',1.5)}for(let i=0;i<5;i++)oval(320+i*290,985+i%2*25,78,8,'#a4bfb33a',null)}
  if(['ladderview','vanblock'].includes(a)){for(const x of[680,780])line(x,250,x,948,'#b1bc9f',10);for(let y=300;y<949;y+=63)line(680,y,780,y,'#aab79a',7)}
  if(a==='vanblock'){bus(1090,872,1.13);rect(1042,715,115,122,'#476d71',ink,3)}return;
 }
 if(['streetwatch','windowlock','routewatch','routeobserve'].includes(a)){H(749,948,1.04,{pose:a==='windowlock'?'door':'stand',look:[-9,0]});if(a==='routeobserve')B(972,948,.71,{look:[-8,0]});return}
 if(['sit','pairsit','bensofa','bensleep','benstory','bentalk','waitingben','sleepingshoes','pairlaugh','laughwater','benlook','onlycopy','roofsit','roofwatch','bennod','closingben','benwipe','bencamera','closing'].includes(a)){
  const roof=s.location==='roof',ground=948,hx=roof?1030:545,bx=roof?1360:310,sit=['sit','pairsit','bensofa','bensleep','benstory','roofsit','roofwatch','onlycopy','sleepingshoes'].includes(a);
  if(roof&&sit){rect(816,850,768,28,'#919d89',ink,3)}
  if(a==='waitingben'){H(1150,948,1.04,{pose:a==='waitingben'?'carry':'stand'});B(707,948,.71,{pose:a==='waitingben'?'torch':'stand',emotion:'worry'});return}
  if(a==='benwipe'){const p=mix([66,-222],[12,-425],Math.sin(q*Math.PI));B(1175,948,.80,{hands:[[-66,-222],p],emotion:'worry'});return}
  if(a==='closing'){H(1120,948,1.08,{look:[-2,4],emotion:'neutral',talk:.20+.25*Math.sin(t*17)**2});return}
  if(a==='bencamera'){B(1260,948,.73,{hands:[[-66,-222],[-37,-380]],held:(L,R)=>phoneBack(R),look:[-5,0]});H(915,948,1.04,{look:[5,0],emotion:'neutral'});return}
  H(hx,sit?1037:ground,1.04,{sit,sleep:a==='sleepingshoes',look:[a==='roofwatch'?-7:5,2],emotion:a==='pairlaugh'||a==='laughwater'?'neutral':'worry',talk:['pairlaugh','laughwater','onlycopy'].includes(a)?.3:0,pose:a==='laughwater'?'eat':'stand'});
  if(hasBen||roof)B(bx,sit?973:ground,.71,{sit,sleep:['bensleep','sleepingshoes'].includes(a),look:[-6,2],head:a==='bennod'?Math.sin(q*Math.PI)*.07:0,emotion:['bensleep','roofwatch'].includes(a)?'neutral':'worry',talk:['bentalk','benstory','pairlaugh'].includes(a)?.2+.2*Math.sin(t*13)**2:0});
  if(['bensofa','bensleep','benstory','pairsit','sleepingshoes'].includes(a)){const light=g.createRadialGradient(700,854,18,650,880,550);light.addColorStop(0,'#e3c57e3c');light.addColorStop(1,'#e3c57e00');g.fillStyle=light;g.fillRect(0,450,1400,630)}return;
 }
 if(['phone','herophone','reaction','pairready','bagsready','sunrise','frozenpair','benflinch','benphone','benreveal','benhiding','benmemory','brothermemory','bencup','checkben','givewater','benwait','blockedpair','frontplan','peekfront'].includes(a)){
  if(['benreveal','benhiding','benmemory','brothermemory'].includes(a)){
   if(a==='brothermemory'){person('survivor',770,1034,1.0,t,{sit:true,talk:.3,look:[5,4]});B(1040,1034,.71,{sit:true,talk:.2,emotion:'neutral'})}
   else{B(a==='benhiding'?260:780,948,.71,{emotion:'worry',pose:a==='benmemory'?'stand':'phone',look:[7,2]});if(a==='benreveal')H(1290,948,1.04,{pose:'torch',look:[-7,2]})}return;
  }
  if(a==='bencup'){B(910,948,.80,{hands:[[-66,-222],[13,-406]],held:(L,R)=>{rect(R[0]-15,R[1]-14,30,37,'#d9d6b6',ink,2,4)},emotion:'worry'});return}
  if(a==='givewater'){const r=mix([66,-222],[111,-309],q);H(1090,948,1.04,{hands:[[-66,-222],r],held:(L,R)=>jug(R[0],R[1],.47)});const by=Math.sin(t*1.8)*.65,bb=Math.sin(t*1.8+1)*.65,p=[(1090+1.04*r[0]-1240)/.71,(1.04*(r[1]+by))/.71-bb];B(1240,948,.71,{hands:[p,[66,-222]],look:[-6,0]});return}
  if(a==='checkben'){H(1087,948,1.04,{hands:[[-66,-222],[105,-326]],look:[6,9]});B(1346,948,.71,{hands:[[-86,-330],[86,-330]],look:[-7,2]});return}
  if(a==='peekfront'){H(1290,948,1.04,{look:[6,2],pose:'listen'});return}
  H(1130,948,1.04,{pose:['phone','herophone'].includes(a)?'phone':a==='frontplan'?'listen':'stand',look:[-5,3],emotion:a==='sunrise'?'neutral':'worry'});
  if(hasBen)B(856,948,.71,{pose:a==='benphone'?'phone':'stand',look:[6,2],emotion:['benflinch','blockedpair','frozenpair'].includes(a)?'worry':'neutral',head:a==='benflinch'?Math.sin(q*Math.PI)*-.06:0});if(['bagsready','pairready'].includes(a))pack(1030,870,1);return;
 }
 if(['inventory','foodstock','watersupply','watercount','rationjugs','hygiene','tap','fillbottle','filljugs','drytap'].includes(a)){
  if(a==='hygiene'){rect(1220,780,140,160,'#54776c',ink,3,9);rect(1211,765,157,21,'#96aa8f',ink,3);rect(1015,813,116,125,'#c1bd9b',ink,3,6);H(1500,948,1.04,{look:[-6,7]});return}
  if(['tap','fillbottle','filljugs','drytap'].includes(a)){
   H(1220,948,1.04,{hands:[[-111,-325],[60,-244]],look:[-5,7]});jug(794,616,.67,a==='drytap'?.45:.15+.7*q);
   if(a!=='drytap'){line(789,609,789,664,'#b2e0d293',5);for(let i=0;i<5;i++){const y=616+((t*74+i*11)%50);oval(789,y,1.8,3,'#d4e9c7a0',null)}}else if(u<.6){for(let i=0;i<2;i++)oval(789,615+q*60+i*12,2,3,'#c6d9c366',null)}
  }else{H(1065,948,1.04,{pose:'carry',look:[-5,5]});if(a==='inventory'){jug(850,824,.85);snack(1430,678,1.2,'bar')}if(a==='watersupply'){for(let i=0;i<4;i++)jug(1330+i*104,823,.83,.82)}}return;
 }
 if(['cctv','controls','deadmonitor','blackout','emergency'].includes(a)){
  H(1340,948,1.04,{hands:[[-66,-222],[-24,-293]],look:[-8,0]});if(a==='cctv')for(let i=0;i<8;i++)oval(935+i*37%305,507+(i%3)*31,4,4,'#344d43',null);
  if(['deadmonitor','blackout'].includes(a)){rect(881,417,374,244,'#283e40',null);if(a==='blackout'){g.fillStyle='#162a3d'+Math.round(q*120).toString(16).padStart(2,'0');g.fillRect(0,0,W,H)}}
  if(a==='emergency'){const x=1500;rect(x,223,86,35,'#d4bb76',ink,2);path([[x,261],[x-140,500],[x+210,500],[x+86,261]],'#d1b76e14',null)}return;
 }
 if(['lure','hordepass','approach','threefront','threeturn','threeenter','armsover'].includes(a)){
  if(a==='armsover'){blockFreezer(1590,930,1);for(let i=0;i<2;i++){const x=1520+i*120;line(x+35,489,x,365-22*Math.sin(u*1.8),ink,12);line(x+35,489,x,365-22*Math.sin(u*1.8),'#9aa58d',7);oval(x,365-22*Math.sin(u*1.8),14,14,'#43574a',null)}return}
  const n=['hordepass','lure'].includes(a)?7:a==='approach'?1:3;
  for(let i=0;i<n;i++){
   const x0=a==='threeenter'?1570+i*150:320+i*164,x1=a==='threeenter'?600+i*180:a==='lure'?1480+i*160:x0+250;
   if(a==='threefront')Z(650+i*300,948,.92,{look:[-5,3]});else if(a==='threeturn')Z(650+i*300,948,.92,{look:[lerp(-5,7,q),2],head:lerp(-.03,.05,q)});else walkTo('infected',x0,x1,948,.92,t,q,{lean:.04,head:.04});
  }return;
 }
 if(['knocks','listen','bottledrop','bottlebounce','carrybottles','rushdoor','handgap','doorpush','curtain'].includes(a)){
  if(a==='curtain'){const w=lerp(80,790,q);rect(720,190,w,760,'#384958',ink,4,3);for(let i=0;i<9;i++)line(730+i*w/9,204,730+i*w/9,943,'#293b4877',3);const xx=720+w-110;walkTo('hero',690,1400,948,1.04,t,q,{hands:[[-66,-222],[106,-373]],look:[7,0]});return}
  if(['bottledrop','bottlebounce'].includes(a)){
   H(1160,948,1.04,{pose:'carry',emotion:'shock'});const y=a==='bottledrop'?lerp(667,913,q):913-Math.abs(Math.sin(q*Math.PI*2))*55*(1-q);g.save();g.translate(979+q*96,y);g.rotate(q*3);jug(0,-39,.39,.7);g.restore();return;
  }
  if(a==='carrybottles'){walkTo('hero',1340,790,948,1.04,t,q,{pose:'carry'});return}
  if(['handgap','doorpush'].includes(a)){
   steelDoor(760,314,315,634,0,-.035*(1-q));line(1057,671,1130,666,'#405449',24);oval(1132,667,18,18,'#536a55',null);H(1200,948,1.04,{hands:[[-120,-325],[-24,-283]],look:[-6,2],lean:-.02});return;
  }
  if(a==='rushdoor'){walkTo('hero',1400,1200,948,1.04,t,q,{pose:'listen'});return}
  H(s.location==='stairs'?260:1240,948,1.04,{pose:'listen',look:[-7,2]});if(a==='knocks'){for(let i=0;i<3;i++){const z=(u*.8+i*.33)%1;line(450,420+i*44,470+22*z,405+i*44,'#e5c68b70',3)}}return;
 }
 if(['hingewatch','freezerroll','freezerblock','freezerwatch','freezerjump','freezerfall','loadingtry','loadingblocked','sofablock','sofamove'].includes(a)){
  if(['loadingtry','loadingblocked'].includes(a)){rect(1085,321,23,626,'#233e3e',ink,2);rect(1091,647,16,98,'#81928a',null);H(1139,948,1.04,{pose:'door',look:[-5,3],emotion:'worry'});B(1360,948,.71,{look:[-5,2]});return}
  if(['sofablock','sofamove'].includes(a)){const x=lerp(a==='sofamove'?1130:440,a==='sofamove'?460:1130,q);sofa(x,948);walkTo('hero',a==='sofamove'?1470:780,a==='sofamove'?800:1470,948,1.04,t,q,{hands:[[-118,-291],[-25,-277]],look:[-7,2]});B(1640,948,.71,{look:[-6,2]});return}
  if(a==='hingewatch'){H(1220,948,1.04,{pose:'listen',look:[6,0]});return}
  const fx=a==='freezerroll'?lerp(730,1590,q):1590,jump=a==='freezerjump'?Math.max(0,Math.sin(u*3))*5:0,fall=a==='freezerfall'?-1.4*q:0;blockFreezer(fx+jump,931,a==='freezerblock'?q:1,fall);
  if(a==='freezerroll')walkTo('hero',395,1255,948,1.04,t,q,{hands:[[-28,-285],[118,-288]],look:[8,3]});else if(a!=='freezerfall')H(1160,948,1.04,{pose:'listen',look:[8,2]});return;
 }
 if(['carryspeaker','pairenter','shortcut','paircross','pairexit','pairyard','pairclimb','hidepair','phoneslide','phoneplaying','camerapass'].includes(a)){
  if(a==='camerapass'){const r=mix([65,-318],[112,-306],q);H(1020,948,1.04,{hands:[[-66,-222],r],held:(L,R)=>phoneBack(R),look:[6,2]});B(1282,948,.71,{hands:[[-108,-325],[66,-222]],look:[-5,1]});return}
  if(a==='phoneslide'||a==='phoneplaying'){
   const x=a==='phoneslide'?lerp(1158,404,ease((q-.22)/.78)):404;if(a==='phoneslide'&&q<.45){const hy=lerp(930,610,ease((q-.2)/.25));line(1220,540,1162,hy,ink,27);line(1220,540,1162,hy,'#ae9944',18);oval(1162,hy,15,15,ink,null);}g.save();g.translate(x,939);g.rotate(Math.PI/2);phoneBack([0,0]);g.restore();for(let i=0;i<3&&a==='phoneplaying';i++){const r=24+(u*26+i*20)%95;g.beginPath();g.arc(x,918,r,-2.8,-.5);g.strokeStyle='#e0c88970';g.lineWidth=3;g.stroke()}return;
  }
  if(a==='hidepair'){H(1397,1032,.98,{sit:true,look:[-7,1]});B(1212,1046,.71,{sit:true,look:[-6,1]});seat(1310,1000,1.35);seat(1567,1000,1.35);return}
  if(a==='pairclimb'){
   for(const x of[680,780])line(x,230,x,948,'#b1bc9f',10);for(let y=277;y<949;y+=63)line(680,y,780,y,'#aab79a',7);
   const climb=(id,startRoot,endRoot,sc)=>{
    const root=lerp(startRoot,endRoot,q),travel=(startRoot-root)/63;
    const onRung=(base,phase)=>{const z=travel+phase,k=Math.floor(z),v=z-k;return base-63*(k+ease((v-.58)/.42))};
    const footBase=id==='ben'?592:907,handBase=277+Math.round((startRoot-385*sc-277)/63)*63;
    const feet=[0,.5].map((off,i)=>[(i?22:-22),(onRung(footBase,off)-root)/sc]);
    const hands=[0,.5].map((off,i)=>[(i?50:-50)/sc,(onRung(handBase,off)-root)/sc]);
    person(id,730,root,sc,t,{feet,hands,look:[-3,-2]});
   };
   climb('ben',640,63,.71);climb('hero',977,400,1);return;
  }
  const right=['pairexit','pairyard','paircross','shortcut'].includes(a),x0=right?350:1440,x1=right?1440:540;
  walkTo('hero',x0,x1,948,1.04,t,q,{pose:'stand',hands:a==='carryspeaker'?[[-49,-263],[49,-263]]:undefined,held:a==='carryspeaker'?(L,R)=>{rect(-46,-279,92,61,'#4b6966',ink,3,8);for(let i=0;i<4;i++)line(-30+i*20,-268,-30+i*20,-230,'#a3b297',2)}:undefined,look:[right?6:-6,2]});
  if(hasBen&&a!=='carryspeaker')walkTo('ben',x0+(right?170:-170),x1+(right?170:-170),948,.71,t,q,{look:[right?6:-6,2]});return;
 }
 throw Error('Unstaged action '+a);
}
const FOCUS={close:[1190,600,1.75],ben:[1030,694,1.88],medium:[1105,605,1.22],seat:[920,652,1.53],door:[1400,628,1.44],window:[680,541,1.5],screen:[1070,583,1.42],tap:[884,649,1.65],hands:[1120,710,1.72],floor:[1020,867,1.94],wide:[960,540,1]};
function fullScene(s,t){
 let f=FOCUS[s.frame||'wide']||FOCUS.wide;
 if(s.location==='stairs')f=s.action==='listen'?[310,620,1.5]:[1040,390,1.15]; // upper-body framing follows the stair ascent
 if(s.location==='roof'&&s.frame==='ben')f=[1270,690,1.7];
 if(s.action==='eating')f=[850,638,1.78];if(s.action==='shock'||s.action==='torch')f=[1395,625,s.action==='shock'?1.9:1.5];
 if(['benreveal','benhiding','benmemory'].includes(s.action))f=[s.action==='benhiding'?450:900,674,1.55];
 if(['bentalk','benstory','bensleep','bensofa','bennod','sleepingshoes'].includes(s.action))f=[s.location==='roof'?1320:510,725,1.5];
 if(['closeauditorium','steeldoor','checkdoor','impact','runningout','listen','knocks','rushdoor','handgap','doorpush'].includes(s.action)&&s.location==='corridor')f=[1080,611,s.frame==='close'?1.76:1.34];
 if(s.action==='pairclimb')f=[735,590,1.06];
 const i=SHOTS.indexOf(s),previous=SHOTS[i-1];let runStart=s.start;for(let k=i-1;k>=0&&SHOTS[k].location===s.location;k--)runStart=SHOTS[k].start;
 // Zoom progresses with a location run; it does not restart at every cut.
 const z=f[2]+.012*Math.min(12,t-runStart),cx=f[0]+Math.sin(t*.13)*2.4,cy=f[1];
 cam(cx,cy,z,()=>{sceneBase(s,t);worldAction(s,t)});
}
function overlay(s,t){g.save();g.translate(41,37);g.rotate(-.018);rect(0,0,513,115,'#f1efdc',ink,4.5,5);rect(0,0,513,23,'#e7cd55',ink,3,4);label('THE LAST SHOW · CINEMA',15,18,17,ink,'left','DejaVu Sans',true);label(s.day===0?'NIGHT 0':'DAY '+s.day,17,94,61);rect(228,33,265,66,null,'#8c5a43',3,5);label(s.location.toUpperCase(),360,77,s.location==='auditorium'||s.location==='projection'||s.location==='concession'?24:29,'#765444','center','Patrick Hand');g.restore()}
function caption(t){let a=0,b=WORDS.length-1,i=-1;while(a<=b){const m=(a+b)>>1;if(WORDS[m].start<=t){i=m;a=m+1}else b=m-1}if(i<0)return;const w=WORDS[i],next=WORDS[i+1]?.start??D;if(t>Math.min(next,w.end+.24))return;const txt=w.text.replace(/[.,?!:;]+$/,'').toUpperCase();g.save();g.font='700 94px "Patrick Hand",sans-serif';g.textAlign='center';g.lineJoin='round';g.strokeStyle='#fffef4';g.lineWidth=8;g.shadowColor='#fffef4';g.shadowBlur=18;g.strokeText(txt,960,988);g.strokeText(txt,960,988);g.shadowBlur=0;g.fillStyle='#111713';g.fillText(txt,960,988);g.restore()}
function render(t){T=clamp(t,0,D-1/24000);poseFrames=[];const s=active(T);current=s;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,W,H);g.lineCap='round';g.lineJoin='round';if(!insertFor(s,T))fullScene(s,T);finish();warp(T);overlay(s,T);caption(T);audit.frames++;return{shot:s.id,action:s.action,audit};}
window.render=render;
