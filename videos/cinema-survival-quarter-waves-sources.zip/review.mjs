import fs from 'node:fs';import {connect} from './cdp.mjs';const {cmd,ws}=await connect();fs.mkdirSync('qc',{recursive:true});const data=JSON.parse(fs.readFileSync('timeline.json','utf8'));let images=[];
for(let i=0;i<data.shots.length;i++){
 const s=data.shots[i];for(const f of [.08,.5,.92]){
  const t=s.start+(s.end-s.start)*f;const r=await cmd('Runtime.evaluate',{expression:`render(${t}); JSON.stringify({audit,shot:current.id})`,returnByValue:true});if(r.exceptionDetails)throw Error(s.id+' '+s.action+' '+JSON.stringify(r.exceptionDetails));
 }
 if(i%4===0||['pairclimb','givewater','phoneslide','eating','closing','freezerfall','handgap'].includes(s.action)){
  const t=(s.start+s.end)/2;const r=await cmd('Runtime.evaluate',{expression:`render(${t}); C.toDataURL('image/jpeg',.92)`,returnByValue:true});const name=`qc/${s.id}-${s.action}.jpg`;fs.writeFileSync(name,Buffer.from(r.result.value.split(',')[1],'base64'));images.push({file:name,...s,time:t});
 }
 if(i%24===0)console.log('REVIEW',i,'/',data.shots.length,s.action);
}
fs.writeFileSync('qc/keyframes.json',JSON.stringify(images,null,2));const a=await cmd('Runtime.evaluate',{expression:'JSON.stringify(audit)',returnByValue:true});fs.writeFileSync('qc/review-audit.json',a.result.value);ws.close();console.log('REVIEW COMPLETE');
