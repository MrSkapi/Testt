# The Last Show — 30 days inside a cinema

Complete original animated film for the supplied Carson narration. 1920×1080, native 24 FPS, 580.34 seconds of unmodified narration, 13,929 video frames. 192 narrative shots across an auditorium, lobby, staff stairs, projection corridor, projection room, office, bathroom, stockroom, concessions, street, delivery alley and warehouse roof.

The main character blends the two previous designs: teal cap and black fringe; small round cream face (#EEE7DA), resting on an orange rectangular hoodie without a visible neck; orange sleeves and black ball hands; thin black stick legs and feet. Ben is consistently shorter, in mustard clothing. Walking uses short strides, low foot lift and modest knee bend. Objects follow hand targets, ladder grips follow the rungs, and stance foot timing follows travelled distance.

World art has a subtle spatial wave at one quarter the amplitude and speed of the first jelly test. Bounds are 1.405 horizontal pixels and 1.0875 vertical pixels at 1080p. A 96×54 displacement mesh evaluates the waves, followed by screen overlays. DAY cards and spoken-word captions never pass through the displacement. The fixed overlay changes only when the narrative day/location or spoken word changes. Wave strength is independent of the camera and actor action.

Original MP3 narration is included byte-for-byte. Its gain, speed and pauses are preserved. The mix adds 35 quiet procedural Foley cues; no music. English single-word captions have dark letters and a pale halo, following the latest reference. No downloaded media or reference recording is included.

## Edit and preview

- `index.html`: complete editable browser preview. Serve the project with `python -m http.server 8773 --bind 127.0.0.1` and open `http://127.0.0.1:8773`.
- `drawing.js`, `character.js`: drawing helpers, face and limb construction.
- `sets.js`: cinema interiors, exterior sets and props.
- `actions.js`: staging, camera, inserts, day cards and captions.
- `waves.js`: subtle wave pass. Change coefficients here to adjust strength or speed.
- `plan.py`, `timeline.json`, `storyboard.txt`: narrative scene timing.
- `words.json`, `transcript.txt`: speech timing and transcript.
- `narration.mp3`: unchanged original upload. `mix.m4a`: completed soundtrack.
- `sound.py`, `audio/`, `sound-cues.json`: editable Foley mix.
- `qc/`, `motion/`, `verification.json`: reviewed frames, movement strips and validation.

## Rebuild

Requires Python 3 with NumPy, SciPy and Pillow, Node 22+, Chromium and FFmpeg. Provided font is Patrick Hand under SIL OFL. No model download or API key is required for rebuilding from the provided word timings.

```
python build.py
python sound.py
python -m http.server 8773 --bind 127.0.0.1
```

Start headless Chromium with remote debugging on port 9270. The renderer opens a dedicated page for each worker.

```
chromium --headless --no-sandbox --disable-dev-shm-usage --disable-gpu --remote-debugging-port=9270 --user-data-dir=/tmp/cinema-render about:blank
node render-worker.mjs 0 2 9270
node render-worker.mjs 1 2 9270
python assemble.py
python verify.py
python package.py
```

Native video parts are 20 seconds long, with source hashes checked before assembly. `render-compatibility.json` permits previously rendered parts only where the final ladder, seated-pose and map-pencil corrections cannot affect their pixels. Affected parts are rendered again from the final source. `rerender-final.mjs` also checks the ladder segment. The output MP4 is assembled without re-encoding the parts and checked against the original narration at multiple points.
