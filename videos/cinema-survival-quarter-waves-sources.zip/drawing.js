/* Original, deterministic 2D animation. 1920x1080, 24 FPS, 30 seconds.
   The supplied recording is a style reference; its artwork/audio are not used. */
const C=document.getElementById('scene');let g=C.getContext('2d');const W=1920,H=1080,D=DATA.duration;
let T=0,poseFrames=[];const ink='#292720';
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x)),lerp=(a,b,q)=>a+(b-a)*q;
const ease=x=>{x=clamp(x);return x*x*(3-2*x)},phase=(t,a,d)=>clamp((t-a)/d),qAt=(t,a,d)=>ease((t-a)/d);
const mix=(a,b,q)=>[lerp(a[0],b[0],q),lerp(a[1],b[1],q)];
const B={shadow:6.1149998474,close:8.7950000763,call:12.3149998093,girl:13.5549998474,hero:15.7550003052,lock:17.1949999237,flash:19.9149999237,wound:24.5549998474,aid:28.5149996948};
let audit={maxBoneError:0,maxWalkFlex:0,unreachable:[],frames:0};
function path(ps,fill=null,stroke=ink,width=4,close=true){g.beginPath();g.moveTo(...ps[0]);for(let i=1;i<ps.length;i++)g.lineTo(...ps[i]);if(close)g.closePath();if(fill){g.fillStyle=fill;g.fill()}if(stroke){g.strokeStyle=stroke;g.lineWidth=width;g.lineJoin='round';g.lineCap='round';g.stroke()}}
function line(x,y,X,Y,c=ink,w=4){g.beginPath();g.moveTo(x,y);g.lineTo(X,Y);g.strokeStyle=c;g.lineWidth=w;g.lineCap='round';g.stroke()}
function softLine(x,y,X,Y,c=ink,w=3,seed=0){const v=Math.sin(seed*4.27+Math.floor(T*6)*1.71)*.35;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo((x+X)/2+v,(y+Y)/2-v,X,Y);g.strokeStyle=c;g.lineWidth=w;g.lineCap='round';g.stroke()}
function rect(x,y,w,h,fill,stroke=ink,sw=4,r=0){g.beginPath();g.roundRect(x,y,w,h,r);if(fill){g.fillStyle=fill;g.fill()}if(stroke){g.strokeStyle=stroke;g.lineWidth=sw;g.stroke()}}
function oval(x,y,rx,ry,c,stroke=ink,sw=4){g.beginPath();g.ellipse(x,y,rx,ry,0,0,Math.PI*2);if(c){g.fillStyle=c;g.fill()}if(stroke){g.strokeStyle=stroke;g.lineWidth=sw;g.stroke()}}
function label(s,x,y,size=28,c=ink,align='left',family='Patrick Hand',bold=false){g.font=`${bold?'700':'400'} ${size}px "${family}",sans-serif`;g.fillStyle=c;g.textAlign=align;g.fillText(s,x,y)}
function hatch(x,y,w,h,n=20,c='#332e2330',seed=0){g.save();g.beginPath();g.rect(x,y,w,h);g.clip();const f=Math.floor(T*6);for(let i=0;i<n;i++){const X=x+(i*31.37+seed*17)%w+Math.sin(i*8.1+f)*.22,Y=y+(i*57.93+seed*13)%h;line(X,Y,X+8+i%6,Y-15,c,.8+i%2*.25)}g.restore()}
function cam(x,y,z,fn){g.save();g.translate(960,540);g.scale(z,z);g.translate(-x,-y);fn();g.restore()}
function rand(seed){let n=seed>>>0;return()=>{n=(Math.imul(n,1664525)+1013904223)>>>0;return n/4294967296}}
const grain=document.createElement('canvas');grain.width=640;grain.height=360;{const ctx=grain.getContext('2d'),d=ctx.createImageData(640,360),r=rand(274);for(let i=0;i<d.data.length;i+=4){const v=110+r()*100;d.data[i]=v;d.data[i+1]=v;d.data[i+2]=v;d.data[i+3]=24}ctx.putImageData(d,0,0)}
function finish(){g.save();g.globalCompositeOperation='multiply';g.globalAlpha=.72;g.drawImage(grain,0,0,W,H);g.restore();const v=g.createRadialGradient(1030,490,190,970,540,1190);v.addColorStop(0,'#26262400');v.addColorStop(.56,'#302a2320');v.addColorStop(1,'#161820a0');g.fillStyle=v;g.fillRect(0,0,W,H);for(let i=0;i<19;i++){const x=(i*107.4+Math.sin(T*.18+i)*23)%W,y=70+(i*137.3+T*(1+i%3))%930;oval(x,y,1.2+i%2,1.2+i%2,'#f7efd62b',null)} }
function joint(a,b,A=76,Bb=78,pole=[0,-290]){
 const dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy);if(d>A+Bb+.02||d<Math.abs(A-Bb)+.01){audit.unreachable.push({t:T,a,b,d});throw Error('Unreachable joint '+d)}
 const q=(A*A-Bb*Bb+d*d)/(2*d),h=Math.sqrt(Math.max(0,A*A-q*q)),mid=[a[0]+dx*q/d,a[1]+dy*q/d],perp=[dy/d,-dx/d];
 const c=clamp(((pole[0]-mid[0])*perp[0]+(pole[1]-mid[1])*perp[1])/Math.max(1,h),-1,1)*d*d/(d*d+1600),K=[mid[0]+perp[0]*h*c,mid[1]+perp[1]*h*c],z=h*Math.sqrt(1-c*c);
 const err=Math.max(Math.abs(Math.hypot(K[0]-a[0],K[1]-a[1],z)-A),Math.abs(Math.hypot(K[0]-b[0],K[1]-b[1],z)-Bb));audit.maxBoneError=Math.max(audit.maxBoneError,err);return K;
}
function legK(a,b,side){const dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy),A=88;if(d>176+.01)throw Error('Unreachable leg '+d);const h=Math.sqrt(Math.max(0,A*A-d*d/4));return[(a[0]+b[0])/2+side*dy*h/d,(a[1]+b[1])/2-side*dx*h/d]}
function cap(){g.beginPath();g.moveTo(-49,-21);g.bezierCurveTo(-58,-52,-28,-78,3,-75);g.bezierCurveTo(34,-73,53,-48,49,-19);g.closePath();g.fillStyle='#337b7c';g.fill();g.strokeStyle=ink;g.lineWidth=6;g.stroke();g.beginPath();g.moveTo(-49,-27);g.bezierCurveTo(-70,-32,-92,-25,-96,-16);g.bezierCurveTo(-94,-4,-57,-2,-31,-13);g.fillStyle='#397e7b';g.fill();g.strokeStyle=ink;g.lineWidth=6;g.stroke();softLine(-3,-72,-9,-23,'#285a5b',2,12);line(-46,-27,44,-21,'#275052',3);oval(2,-73,4,4,'#286364',ink,2)}
function head(t,o={}){g.save();g.rotate(o.head||0);oval(0,0,49,49,o.skin||'#e5e1d5',ink,5.5);
 if(o.hat){path([[-48,-14],[-43,2],[-37,-15],[-27,-22],[-17,-15],[0,-24],[21,-16],[39,-25],[48,-11],[42,-40]],'#242824',null)}
 else{g.beginPath();g.moveTo(-48,-8);g.bezierCurveTo(-53,-35,-29,-56,0,-53);g.bezierCurveTo(30,-55,50,-31,47,-5);g.lineTo(28,-22);g.quadraticCurveTo(10,-32,-10,-17);g.quadraticCurveTo(-30,-25,-48,-8);g.fillStyle=o.hair||'#4a4034';g.fill();g.strokeStyle=ink;g.lineWidth=4;g.stroke();if(o.female){g.beginPath();g.moveTo(35,-31);g.bezierCurveTo(61,-40,62,-20,62,-4);g.quadraticCurveTo(64,11,62,24);g.quadraticCurveTo(44,17,40,-2);g.fill();g.stroke()}}
 g.save();g.beginPath();g.ellipse(0,0,47,47,0,0,Math.PI*2);g.clip();path([[-55,-19],[53,-5],[53,5],[-53,-6]],'#676b6230',null);g.restore();
 const bl=(t+(o.phase||0))%4.3,blink=bl>4.12?Math.max(.08,Math.abs(bl-4.21)/.09):1,look=o.look||[0,2];
 for(const x of [-16,7]){if(o.infected){oval(x+look[0]*.5,1,9,10,'#464c42',null);oval(x+1,1,2.1,2.1,'#ced0b7',null)}else if(o.sleep)softLine(x-4,look[1]+2,x+4,look[1]+2,ink,2.5,x);else oval(x+look[0],look[1],3.8,7.1*blink,ink,null)}
 if(o.worry){softLine(-24,-13,-12,-16,ink,2,1);softLine(6,-16,18,-12,ink,2,2)}
 if(o.surprise)oval(-4,25,5,7,ink,null);else if(o.talk)oval(-4,25,5,2+5*o.talk,ink,null);else softLine(-12,25,3,24,ink,2.4,3);
 if(o.mask){path([[-33,14],[-22,6],[18,7],[31,17],[24,38],[-24,38]],'#8c9181',ink,2.5);for(const x of [-22,20])oval(x,26,10,10,'#b4b69f',ink,2.3);rect(-9,16,17,18,'#9ba28b',ink,2,3)}
 if(o.hat)cap();hatch(-38,29,70,10,5,'#66614d28');g.restore();}
const REST=[[-52,-218],[52,-218]];
function actor(id,x,y,s,t,o={}){
 const sc=s,col=o.col||'#b96d3e',walk=o.walk||0,dir=o.dir||1,gait=o.gait||0,breath=o.still?0:Math.sin(t*1.5+(o.phase||0))*.55;
 g.save();g.translate(x,y);g.scale(s,s);oval(0,3,48,6,'#211e192c',null);
 const feet=[];
 for(let i=0;i<2;i++){const hx=i?21:-20,q=(gait+i*.5)%1,stance=q<.62,v=stance?q/.62:(q-.62)/.38;
  const f=[hx+dir*(stance?30-60*v:-30+60*ease(v))*walk,stance?0:-(o.limp&&i?1.2:2.8)*Math.sin(Math.PI*v)*walk],hip=[hx,lerp(-176,-172.8,walk)];feet.push(f);
  if(walk){const k=legK(hip,f,dir),flex=2*Math.acos(Math.min(1,Math.hypot(f[0]-hip[0],f[1]-hip[1])/176))*180/Math.PI;audit.maxWalkFlex=Math.max(audit.maxWalkFlex,flex);if(flex>33)throw Error('Excessive walk flex');softLine(...hip,...k,ink,8.5,i);softLine(...k,...f,ink,8.5,i+2)}else softLine(...hip,...f,ink,8.5,i);
  softLine(...f,f[0]+18*dir,f[1],ink,9,i+3);
 }
 g.save();g.translate(0,breath);g.rotate(o.lean||0);
 path([[-42,-389],[36,-379],[45,-175],[-42,-175]],col,ink,5.5);
 path([[-27,-386],[-8,-373],[14,-382],[12,-352],[-3,-344],[-18,-365]],o.trim||'#4d554e',ink,3.2);
 rect(2,-226,29,30,null,ink,3);softLine(-32,-368,-31,-192,'#e9dec244',1.4,91);hatch(-36,-355,68,160,17,'#352d231f',5);
 let hands=(o.hands||REST).map(p=>p.slice()),elbows=[];
 if(walk&&!o.hands){const z=Math.sin(gait*2*Math.PI)*3;hands=[[-54-z,-220+z],[54+z,-220-z]]}
 const shoulders=[[-34,-365],[34,-363]];
 for(let i=0;i<2;i++){const K=joint(shoulders[i],hands[i],76,78,[i?100:-100,-288]);elbows.push(K);softLine(...shoulders[i],...K,ink,10,i+10);softLine(...K,...hands[i],ink,10,i+13);
  if(o.sleeve&&i===0){softLine(...shoulders[i],...K,col,12,i+10);softLine(...K,...hands[i],col,12,i+13);line(K[0]-4,K[1],hands[i][0]-3,hands[i][1],o.blood?'#733e35':col,6);if(o.blood){const p=mix(K,hands[i],.64);oval(p[0]+3,p[1]-4,8,10,'#6b3b34',null);line(p[0]-7,p[1]+1,p[0]-9,p[1]+17,'#814239',2)}}
 }
 if(o.held)o.held(hands[0],hands[1]);
 for(const p of hands)oval(...p,9.5,9.5,ink,null);
 g.save();g.translate(0,-440);head(t,o);g.restore();g.restore();g.restore();
 const world=p=>{const a=o.lean||0,c=Math.cos(a),sn=Math.sin(a);return[x+s*(p[0]*c-p[1]*sn),y+s*(p[0]*sn+p[1]*c+breath)]};
 poseFrames.push({id,x,y,s,hands:hands.map(world),elbows:elbows.map(world),feet:feet.map(p=>[x+p[0]*s,y+p[1]*s])});
}
function worldHand(x,y,s,p,t,phase=0){const by=Math.sin(t*1.5+phase)*.55;return[(p[0]-x)/s,(p[1]-y)/s-by]}
function phoneBack(p){rect(p[0]-12,p[1]-35,28,64,'#3c4546',ink,3.5,4);rect(p[0]-7,p[1]-30,12,20,'#252c2d',ink,1,3);oval(p[0]-2,p[1]-25,2,2,'#8b9d9a',null);oval(p[0]-2,p[1]-16,2,2,'#7d8b85',null)}
function aidBox(x,y,s=1){g.save();g.translate(x,y);g.scale(s,s);rect(-53,12,106,80,'#d8d4bd',ink,4,5);path([[-17,12],[-17,-3],[17,-3],[17,12]],null,ink,4,false);line(-18,50,18,50,'#974d40',10);line(0,32,0,68,'#974d40',10);line(-48,31,48,31,'#9e9d82',2);g.restore()}
function floor(y,col='#8e8875'){rect(-500,y,W+1000,650,col,null);softLine(-500,y,2400,y,ink,3.5,45);for(let i=-2;i<10;i++){const x=190+i*260;softLine(x,y,960+(x-960)*2.3,1400,'#4b4c4233',1.4,i)}for(let i=0;i<5;i++){const Y=y+38+i*i*23;softLine(-300,Y,2300,Y+3,'#504c3c1a',1.1,i+10)}}
function wall(col='#aaa18a'){g.fillStyle=col;g.fillRect(-500,-500,3000,1800);for(let y=55;y<960;y+=86){softLine(-200,y,2150,y+2,'#4a4b412f',1.6,y);for(let x=(y/86%2)*160;x<2000;x+=320)softLine(x,y,x+2,y+83,'#5c594e20',1.2,x+y)}hatch(0,0,W,900,95,'#524e3820',17)}
function lamp(x,y){line(x,-40,x,y-30,ink,3);path([[x-39,y],[x-16,y-30],[x+18,y-30],[x+44,y]],'#646756',ink,3.5);oval(x+3,y+3,13,4,'#e8ce8e',null);const light=g.createRadialGradient(x,y,20,x,y+200,570);light.addColorStop(0,'#edcc8050');light.addColorStop(.65,'#dfb9680d');light.addColorStop(1,'#f3dc8800');g.fillStyle=light;g.fillRect(x-600,y-50,1200,1100)}
