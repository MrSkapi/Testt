from pathlib import Path
import subprocess,json,hashlib,math,numpy as np
from PIL import Image,ImageDraw
P=Path(__file__).parent;V=P/'cinema-survival-quarter-waves.mp4';D=json.loads((P/'timeline.json').read_text())['duration'];Q=P/'final-qc';Q.mkdir(exist_ok=True)
meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_type,codec_name,width,height,r_frame_rate,nb_frames,duration:format=duration,size','-of','json',str(V)]));v=next(x for x in meta['streams'] if x['codec_type']=='video');a=next(x for x in meta['streams'] if x['codec_type']=='audio');assert (v['width'],v['height'],v['r_frame_rate'],int(v['nb_frames']))==(1920,1080,'24/1',math.ceil(D*24));assert abs(float(a['duration'])-D)<.03
# Decode the entire movie and extract distributed native frames in the same pass.
times=[1.3,6.0,9.0,29,41,52,76,110,147,160,180,215,240,269,285,308,321,337,350,371,386,406,429,447,472,491,513,525,540,555,566,578]
sel='+'.join('eq(n\\,'+str(round(t*24))+')' for t in times)
subprocess.run(['ffmpeg','-y','-v','info','-i',str(V),'-vf','blackdetect=d=0.04:pix_th=0.06:pic_th=0.90,select='+sel,'-fps_mode','vfr',str(Q/'frame-%02d.png')],check=True,stderr=(Q/'decode.log').open('w'));assert 'black_start:' not in (Q/'decode.log').read_text()
files=sorted(Q.glob('frame-*.png'));assert len(files)==len(times)
for page in range(2):
 out=Image.new('RGB',(1920,4*294),'#25332c');dr=ImageDraw.Draw(out)
 for k,(p,t) in enumerate(zip(files[page*16:page*16+16],times[page*16:page*16+16])):
  im=Image.open(p).convert('RGB');assert im.size==(1920,1080);assert np.asarray(im).std()>10;region=np.asarray(im)[200:850,200:1700];assert region.mean()>20 and region.std()>8;x=k%4*480;y=k//4*294;out.paste(im.resize((480,270)),(x,y));dr.text((x+7,y+275),f'{t:.1f} s',fill='white')
 out.save(P/f'cinema-survival-contact-{page+1}.jpg',quality=92)
# Master contact sheet for the GitHub download page.
contact=Image.new('RGB',(1920,6*294),'#25332c');dr=ImageDraw.Draw(contact)
indices=[round(i*(len(files)-1)/23) for i in range(24)]
for k,j in enumerate(indices):
 x=k%4*480;y=k//4*294;contact.paste(Image.open(files[j]).convert('RGB').resize((480,270)),(x,y));dr.text((x+7,y+275),f'{times[j]:.1f} s',fill='white')
contact.save(P/'cinema-survival-quarter-waves-contact.jpg',quality=92)
def decode(p):return np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-vn','-ar','16000','-ac','1','-f','f32le','-']),dtype=np.float32)
x=decode(P/'narration.mp3');y=decode(V);checks=[]
for t in [1,20,81,146,211,268,326,391,448,503,548,577.8]:
 k=round(t*16000);n=3200;lag=int(np.argmax(np.correlate(y[k-80:k+n+80],x[k:k+n],'valid')))-80;corr=float(np.corrcoef(x[k:k+n],y[k+lag:k+lag+n])[0,1]);checks.append(dict(at=t,lagSamples=lag,correlation=corr))
assert all(abs(c['lagSamples'])<=1 and c['correlation']>.97 for c in checks),checks
report=dict(video=meta,narrationDuration=D,voiceGain=1,timeStretch=1,quarterWaveAmplitude=True,overlaysAfterDisplacement=True,audioChecks=checks,sha256=hashlib.sha256(V.read_bytes()).hexdigest(),bytes=V.stat().st_size,narrationSha256=hashlib.sha256((P/'narration.mp3').read_bytes()).hexdigest(),sourceHash=(P/'build-hash.txt').read_text().strip())
(P/'verification.json').write_text(json.dumps(report,indent=2));print('VERIFIED',report['bytes'],'bytes; audio lags',[c['lagSamples'] for c in checks],flush=True)
