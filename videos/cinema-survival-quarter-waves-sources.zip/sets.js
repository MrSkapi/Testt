const setCache=new Map();
function poster(x,y,w,h,title,col='#678b88'){rect(x,y,w,h,'#423e39',ink,4,2);rect(x+8,y+8,w-16,h-16,col,null);oval(x+w*.5,y+h*.38,w*.23,h*.14,'#d2b876',null);path([[x+14,y+h-30],[x+w*.55,y+h*.45],[x+w-14,y+h-30]],'#394b55',null);label(title,x+w/2,y+h-10,22,'#ece1c2','center')}
function doorFrame(x,y,w,h,name='STAFF ONLY',col='#587c78'){rect(x-10,y-10,w+20,h+15,'#414c4b',ink,4);rect(x,y,w,h,col,ink,3);rect(x+32,y+48,w-64,107,'#c9cfb4',ink,2);label(name,x+w/2,y+112,27,'#3e514c','center');line(x+w-39,y+h*.56,x+w-39,y+h*.56+55,'#b9c5ad',8);hatch(x+5,y+5,w-10,h-10,25,'#1d3e3a20',5)}
function exitSign(x,y){rect(x,y,145,52,'#3b796b',ink,3,3);label('EXIT →',x+72,y+36,31,'#e2e9c8','center')}
function seat(x,y,s=1,tag=''){g.save();g.translate(x,y);g.scale(s,s);rect(-49,-223,98,185,'#783e49',ink,4,19);rect(-44,-94,90,48,'#99505b',ink,3,14);line(-39,-45,-41,0,'#40353d',7);line(38,-45,43,0,'#40353d',7);line(-63,-96,-63,-46,'#302f34',9);line(63,-96,63,-46,'#302f34',9);if(tag)label(tag,0,-171,20,'#e2c8ad','center');hatch(-38,-204,72,95,12,'#d9bd9e18');g.restore()}
function projector(x,y,s=1){g.save();g.translate(x,y);g.scale(s,s);rect(-92,-68,180,108,'#596e68',ink,5,10);oval(90,-8,34,35,'#313e41',ink,4);oval(96,-8,23,25,'#c4d4b1',ink,2);for(let i=0;i<6;i++)line(-73,-45+i*11,-13,-45+i*11,'#2f4744',3);rect(6,-49,54,30,'#a4baa0',ink,2);oval(29,-34,5,5,'#ddbc5d',null);line(-58,40,-58,111,ink,8);line(54,40,54,111,ink,8);g.restore()}
function cctv(x,y,w,h){rect(x,y,w,h,'#344c4d',ink,5,9);rect(x+12,y+12,w-24,h-24,'#647a71',ink,2);for(let j=0;j<2;j++)for(let i=0;i<2;i++){const X=x+19+i*(w-34)/2,Y=y+19+j*(h-34)/2;rect(X,Y,(w-45)/2,(h-45)/2,['#829685','#647f83','#938b71','#697e78'][i+j*2],ink,1);label(['LOBBY','SCREEN 4','LOADING','STAIRS'][i+j*2],X+10,Y+24,17,'#dbe0c6');for(let k=0;k<4;k++){const xx=X+22+k*28;oval(xx,Y+54,4,4,'#384e46',null);line(xx,Y+59,xx,Y+80,'#384e46',3)}}}
function windowView(x,y,w,h,night=false){rect(x,y,w,h,'#465d61',ink,5);rect(x+10,y+10,w-20,h-20,night?'#3b516b':'#869da6',null);for(let i=0;i<4;i++){const X=x+12+i*w/4,hh=82+i%3*37;rect(X,y+h-hh-13,w/4-4,hh,'#617878',ink,1.5);rect(X+16,y+h-hh+5,17,22,night?'#c6ac6c':'#a8c3bb',null)}line(x+w/2,y+10,x+w/2,y+h-10,'#b2bbaa',7);line(x+10,y+h*.57,x+w-10,y+h*.57,'#b2bbaa',6)}
function scenery(loc,light='day'){
 const key=loc+'|'+light;if(setCache.has(key)){g.drawImage(setCache.get(key),0,0);return}
 const old=g,c=document.createElement('canvas');c.width=W;c.height=H;g=c.getContext('2d');g.lineCap='round';g.lineJoin='round';
 const night=light==='night';
 if(loc==='auditorium'){
  wall('#4d535b');rect(-10,320,1940,620,'#384855',null);floor(948,'#47494a');rect(130,125,1150,395,'#343d43',ink,6,8);rect(146,142,1118,359,'#839497',null);label('FEATURE ENDED',705,335,44,'#c4c9b5','center');
  for(let i=0;i<6;i++)seat(210+i*215,890,.97,i===3?'F12':'F'+(9+i));
  doorFrame(1560,320,260,628,'SCREEN 1','#476662');exitSign(1613,230);lamp(1480,250);
 }else if(loc==='lobby'){
  wall('#b0a28d');rect(0,640,1920,305,'#667e79',null);floor(948,'#8e8576');
  for(let i=0;i<3;i++)poster(190+i*280,177,210,310,['THE LAST LIGHT','ORBIT','NIGHT SHIFT'][i],['#6c8998','#a48b62','#87758a'][i]);
  doorFrame(1430,315,350,633,'SCREEN 4','#3d6266');exitSign(1525,244);
  for(let i=0;i<2;i++){rect(1040+i*160,519,126,410,'#426c71',ink,4,8);rect(1054+i*160,542,98,133,'#a5bda6',ink,3);label('TICKETS',1103+i*160,598,22,'#3e5b53','center');rect(1061+i*160,727,85,17,'#293d3c',ink,2)}
  lamp(900,150);
 }else if(loc==='corridor'){
  wall('#a6a58f');rect(0,593,1920,355,'#617e78',null);floor(948,'#807f6e');
  for(let i=0;i<3;i++)doorFrame(190+i*570,300,315,648,['SCREEN 2','PROJECTION','STAFF STAIRS'][i],['#4e737b','#67877a','#566d72'][i]);
  exitSign(1516,219);line(20,692,1870,692,'#454f49',12);lamp(1070,166);
 }else if(loc==='office'){
  wall('#b0a68d');rect(0,630,1920,318,'#6d8678',null);floor(948,'#95856d');windowView(160,204,510,350,night);
  rect(770,691,890,29,'#9a7a50',ink,4,3);for(const x of[795,1619])line(x,720,x,948,ink,10);
  cctv(870,405,397,268);rect(1125,676,58,15,'#364d45',ink,2);rect(1399,577,128,113,'#a28c61',ink,3,4);label('FIRST AID',1463,623,22,'#dddebb','center');line(1462,641,1462,675,'#ab5946',10);line(1445,658,1479,658,'#ab5946',10);
  rect(1515,200,286,242,'#b8b398',ink,3);label('STAFF ROTA',1658,244,29,'#425e55','center');for(let i=0;i<5;i++)line(1540,272+i*27,1768,272+i*27,'#7c8a6c',2);
  rect(212,848,452,53,'#6e6876',ink,4,14);rect(228,739,419,121,'#8c8090',ink,3,12);for(const x of[242,624])line(x,901,x,948,ink,8);lamp(1380,161);
 }else if(loc==='projection'){
  wall('#8f9f8f');rect(0,650,1920,297,'#456e69',null);floor(948,'#777d70');
  for(let i=0;i<3;i++){rect(160+i*530,217,320,165,'#354f58',ink,4,3);rect(175+i*530,232,289,134,'#9aa89b',ink,2);projector(304+i*530,690,1.27)}
  rect(129,835,1554,23,'#7f7960',ink,3);exitSign(1702,213);lamp(1120,132);
 }else if(loc==='stairs'){
  wall('#86988f');floor(948,'#727b72');rect(0,560,1920,170,'#527774',null);
  for(let i=0;i<9;i++)path([[120+i*175,948-i*57],[120+(i+1)*175,948-i*57],[120+(i+1)*175,948-(i+1)*57]],'#8b9080',ink,3,false);
  line(135,605,1710,93,'#384e4b',12);for(let i=0;i<6;i++)line(200+i*284,584-i*92,200+i*284,920-i*92,'#415a55',6);
  doorFrame(1590,145,258,348,'UPSTAIRS','#507774');exitSign(1640,76);
 }else if(loc==='stockroom'){
  wall('#9b9f89');floor(948,'#828471');
  for(let j=0;j<2;j++){const X=130+j*1080;rect(X,209,525,734,'#5f776c',ink,5);for(let r=0;r<4;r++){const Y=370+r*166;rect(X+8,Y,509,17,'#b0aa84',ink,3);for(let k=0;k<5;k++){if(r===0||r===2)jug(X+60+k*99,Y-82,.66,.8);else snack(X+60+k*99,Y-60,1.0,k%2?'bar':'chips')}}}
  doorFrame(774,319,316,629,'LOADING','#4c706d');rect(794,380,276,126,'#8fa4a0',ink,3);lamp(1040,133);
 }else if(loc==='bathroom'){
  wall('#a6b5a1');floor(948,'#7e9b91');for(let j=0;j<6;j++)line(0,390+j*94,1920,390+j*94,'#587f7360',2);for(let i=0;i<14;i++)line(i*146,390,i*146,948,'#587f7360',2);
  rect(397,201,590,297,'#5a7979',ink,4);rect(410,214,564,270,'#abc4b4',ink,2);rect(329,690,741,70,'#c2c9ae',ink,4,12);oval(696,705,188,30,'#869f91',ink,3);path([[695,681],[695,598],[751,580],[787,598]],null,ink,12,false);line(770,600,789,600,'#b8c6ac',7);
  rect(1320,410,300,538,'#69897d',ink,4,5);label('STAFF',1470,490,31,'#d6ddc0','center');lamp(1080,125);
 }else if(loc==='roof'){
  rect(0,0,1920,1080,night?'#3f526a':'#91a5ad',null);for(let i=0;i<8;i++){const h=120+i%3*68;rect(i*265-40,720-h,234,h+200,['#657f85','#74898a','#5e7b80'][i%3],ink,2);for(let j=0;j<3;j++)rect(i*265+14+j*56,739-h,25,38,night?'#bda565':'#a8bcb0',null)}
  floor(950,'#737f7b');rect(0,765,1920,185,'#9b9d8b',ink,5);for(let i=0;i<12;i++)line(i*180,770,i*180,947,'#737d7055',2);
  rect(1470,466,281,298,'#7b8a7d',ink,4);path([[1428,467],[1515,386],[1749,386],[1790,467]],'#596f70',ink,3);rect(1556,548,105,216,'#4f706b',ink,3);line(1550,740,1680,740,'#b8b897',4);
 }else if(loc==='street'||loc==='alley'){
  rect(0,0,1920,1080,night?'#40556b':'#8aa3aa',null);floor(948,'#738285');
  for(let i=0;i<4;i++){const X=i*520-60;rect(X,155,475,650,['#a39e83','#708b91','#84978a'][i%3],ink,4);for(let j=0;j<2;j++)windowView(X+39+j*222,242,170,190,night);doorFrame(X+152,505,166,302,'', '#4a6b6d')}
  if(loc==='street'){bus(420,821,1.55);for(let i=0;i<6;i++)rect(700+i*170,1006,100,23,'#c4c7a5',null)}
  else{for(let i=0;i<12;i++)line(1110+i*65,448,1110+i*65,947,'#445d55',5);for(let i=0;i<2;i++){rect(1170+i*320,752,223,193,'#56756b',ink,4,6);rect(1155+i*320,734,254,25,'#3e5c55',ink,3);oval(1210+i*320,949,12,12,'#2e4744',ink,2)}}
 }else if(loc==='concession'){
  wall('#b2a18b');floor(948,'#8f8b75');rect(174,230,1555,202,'#516d6e',ink,4);label('POPCORN     DRINKS     CHOCOLATE',951,342,59,'#e0d8b9','center');rect(87,702,1750,241,'#9b7756',ink,4);rect(73,673,1778,34,'#c0b18b',ink,4);
  for(let i=0;i<5;i++)snack(240+i*279,635,1.8,i%2?'bar':'chips');rect(1290,447,335,225,'#a38351',ink,4);rect(1307,463,303,168,'#bdbb96',ink,2);label('POPCORN',1458,540,35,'#a17145','center');lamp(950,139);
 }else throw Error('Unknown set '+loc);
 g=old;setCache.set(key,c);g.drawImage(c,0,0);
}
function bus(x,y,s=1){g.save();g.translate(x,y);g.scale(s,s);path([[-300,-190],[260,-190],[310,-142],[310,15],[-304,15]],'#647f85',ink,5);for(let i=0;i<5;i++)rect(-275+i*112,-166,95,83,'#9bb5af',ink,3,4);rect(186,-67,101,80,'#34565f',ink,3);for(const x of[-207,201]){oval(x,13,40,40,'#303c3c',ink,3);oval(x,13,21,21,'#8f9e91',ink,2)}line(-290,-59,167,-59,'#c3baa0',7);g.restore()}
