from pathlib import Path
import json,re,difflib,subprocess,math
from plan import PLAN
P=Path(__file__).parent;words=json.loads((P/'words.json').read_text());duration=580.34
norm=lambda x:re.sub('[^a-z0-9]','',x.lower().replace('’',"'"))
# Fix orthography without changing the audio or word order.
for w in words:
 if w['text'].lower().rstrip('.,')=='bend':w['text']='Ben'+('.' if w['text'].endswith('.') else '')
 if w['text'].lower().rstrip('.,')=='ben':w['text']='Ben'+('.' if w['text'].endswith('.') else '')
words=[w for w in words if not (w['start']>578 and norm(w['text'])=='static')]
N=[norm(w['text']) for w in words];cursor=0;shots=[];issues=[];day=0;light='night'
for item in PLAN:
 q=[norm(t) for t in re.findall(r"[A-Za-z0-9]+(?:['’][A-Za-z0-9]+)*",item['anchor'])];best=(-1,None,None)
 for i in range(max(0,cursor-1),min(len(N),cursor+100)):
  for length in range(max(1,len(q)-2),len(q)+3):
   score=difflib.SequenceMatcher(None,q,N[i:i+length],autojunk=False).ratio()-.0008*max(0,i-cursor)
   if score>best[0]:best=(score,i,length)
 score,i,n=best
 if score<.68:issues.append(dict(anchor=item['anchor'],score=round(score,3),at=words[i]['start'],heard=' '.join(w['text'] for w in words[i:i+n])))
 day=item.get('day',day);light=item.get('light',light)
 shots.append(dict(item,id=f'c{len(shots)+1:03}',start=max(0,words[i]['start']-.08),day=day,light=light))
 cursor=i+max(1,n//2)
shots[0]['start']=0
for i,s in enumerate(shots):
 s['end']=shots[i+1]['start'] if i+1<len(shots) else duration
 if s['end']<=s['start']:issues.append(dict(order=s['id'],start=s['start'],end=s['end']))
(P/'timeline.json').write_text(json.dumps(dict(duration=duration,fps=24,frames=math.ceil(duration*24),shots=shots),indent=2))
(P/'anchor-issues.json').write_text(json.dumps(issues,indent=2));(P/'words.json').write_text(json.dumps(words))
(P/'storyboard.txt').write_text('\n'.join(f"{s['start']:7.2f}–{s['end']:7.2f} DAY{s['day']:02} {s['location']:12} {s['action']:19} {s['anchor']}" for s in shots))
print(len(shots),'shots',len(issues),'issues');print(json.dumps(issues,indent=2))
