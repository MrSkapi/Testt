const CAST={hero:{col:'#ad6038',hat:true},ben:{col:'#ae9944',hair:'#4f3b2f',child:true},jules:{col:'#527b84',hair:'#594a42',female:true},mother:{col:'#95687a',hair:'#4d3835',female:true},father:{col:'#4c718c',hair:'#7f8783'},infected:{col:'#7c8971',skin:'#aeb59a',hair:'#4b5249',infected:true},woman:{col:'#846d84',hair:'#4a3833',female:true},survivor:{col:'#6c8c7c',hair:'#5a5142'},staff:{col:'#8c8b79',hair:'#63675c'}};
function heldPhone(p){phoneBack(p)}
function flashlight(p,beam=true,dir=-1){
 if(beam){g.save();g.globalCompositeOperation='screen';path([[p[0]+dir*25,p[1]-5],[p[0]+dir*720,p[1]-130],[p[0]+dir*720,p[1]+110],[p[0]+dir*25,p[1]+8]],'#e8d99128',null);g.restore()}
 rect(p[0]-27,p[1]-8,54,16,'#6f8c86',ink,2,4);rect(p[0]+(dir<0?-35:22),p[1]-13,13,26,'#c7c4a1',ink,2,3);
}
function jug(x,y,s=1,level=.7,marks=0){g.save();g.translate(x,y);g.scale(s,s);rect(-40,8,80,95,'#a3c8bb',ink,3,8);rect(-18,-4,36,17,'#678e87',ink,2,4);rect(-10,0,20,10,'#d6dcbb',ink,1,3);rect(-33,8+95*(1-level),66,95*level-8,'#679b9380',null,0,4);rect(-32,33,64,25,'#d5d9b2',ink,1);label('WATER',0,52,18,'#3a5d53','center');for(let i=0;i<marks;i++)line(22,69+i*5,36,69+i*5,'#384a42',1.5);g.restore()}
function snack(x,y,s=1,type='chips'){g.save();g.translate(x,y);g.scale(s,s);if(type==='bar'){rect(-39,-9,78,28,'#c6a25e',ink,2,3);rect(-20,-8,39,26,'#6b453b',null);label('BAR',0,11,15,'#eee4c8','center')}else{path([[-25,-23],[28,-23],[24,42],[-27,41]],'#b38054',ink,2);label('CHIPS',0,11,16,'#eddfb9','center')}g.restore()}
function pack(x,y,s=1){g.save();g.translate(x,y);g.scale(s,s);path([[-34,72],[-37,6],[-21,-26],[27,-26],[41,6],[36,72]],'#698571',ink,4);rect(-25,22,52,40,'#83937a',ink,2,8);line(-17,-12,-29,31,'#344d46',3);line(23,-12,34,34,'#344d46',3);g.restore()}
function hero(x,y,s,t,o={}){return person('hero',x,y,s,t,o)}
function person(id,x,y,s,t,o={}){
 const pr=CAST[id]||CAST.survivor,col=o.col||pr.col,dir=o.dir||1,move=!!o.walk;
 const breath=Math.sin(t*1.8+(id==='ben'?1:0))*.65;
 g.save();g.translate(x,y);g.scale(s,s);oval(0,4,55,6,'#1c221e33',null);
 // The foot phase follows distance, not time, so stance feet stay planted.
 for(let i=0;i<2;i++){
  const hx=i?22:-22;let f=[hx,0],h=[hx,move?-173.1:-176];
  if(o.feet){f=o.feet[i];h=[hx,-176];const k=legK(h,f,1);softLine(...h,...k,ink,8.5,i);softLine(...k,...f,ink,8.5,i+2);line(...f,f[0]+17*dir,f[1],ink,9);continue;}
  if(o.sit){h=[hx,-173];const k=[hx+dir*88,-173],foot=[k[0],-86];softLine(...h,...k,ink,8.5,i);softLine(...k,...foot,ink,8.5,i+2);line(...foot,foot[0]+dir*17,foot[1],ink,9);continue;}
  if(move){const gait=(Math.abs(o.distance||0)/(s*(56/.64))+i*.5)%1,stance=gait<.64,v=stance?gait/.64:(gait-.64)/.36;
   f=[hx+dir*(stance?28-56*v:-28+56*ease(v)),stance?0:-2.4*Math.sin(Math.PI*v)];const k=legK(h,f,dir);softLine(...h,...k,ink,8.5,i);softLine(...k,...f,ink,8.5,i+2);
   const flex=2*Math.acos(Math.min(1,Math.hypot(f[0]-h[0],f[1]-h[1])/176))*180/Math.PI;audit.maxWalkFlex=Math.max(audit.maxWalkFlex,flex);
  }else softLine(...h,...f,ink,8.5,i);
  line(...f,f[0]+17*dir,f[1],ink,9);
 }
 const by=breath+(o.sit?0:0);g.save();g.translate(0,by);g.rotate(o.lean||0);
 path([[-50,-389],[47,-389],[53,-178],[-53,-178]],col,ink,5.2);
 path([[-44,-388],[-38,-405],[-8,-400],[30,-405],[43,-388],[23,-356],[-20,-356]],o.trim||'#6f5542',ink,3.5);
 path([[-29,-388],[0,-374],[28,-388],[16,-361],[-14,-361]],'#353e37',ink,2.6);
 rect(-48,-198,97,18,o.trim||'#794b36',null);
 path([[-28,-246],[29,-246],[36,-209],[-36,-209]],o.trim||'#885639',ink,2.5);
 if(id==='hero'){line(-23,-375,-23,-333,'#d7b98b',2);line(24,-375,24,-333,'#d7b98b',2)}
 if(o.badge){rect(8,-342,31,40,'#d3d5bc',ink,1.6,2);label('STAFF',23,-317,11,'#3e514c','center')}
 hatch(-43,-350,84,136,17,'#352b2429',8);
 let hands=o.hands?o.hands.map(p=>p.slice()):[[-66,-222],[66,-222]];
 if(move&&!o.hands){const z=Math.sin((o.distance||0)/(s*(56/.64))*2*Math.PI)*6;hands=[[-66-z,-223],[66+z,-223]]}
 const pose=o.pose||'stand';
 if(pose==='torch')hands=[[-66,-222],[116,-338]];
 if(pose==='phone')hands=[[-66,-222],[65,-318]];
 if(pose==='call')hands=[[-66,-222],[62,-429]];
 if(pose==='carry')hands=[[-49,-263],[49,-263]];
 if(pose==='eat')hands=[[-67,-230],[18,-410]];
 if(pose==='listen')hands=[[-66,-222],[85,-379]];
 if(pose==='door')hands=[[-66,-222],[124,-348]];
 if(pr.infected&&!o.hands)hands=[[-89,-321],[103,-327]];
 const shoulders=[[-43,-368],[43,-368]],ends=[];
 for(let i=0;i<2;i++){
  const k=joint(shoulders[i],hands[i],76,78,[i?110:-110,-293]);
  for(const [a,b]of[[shoulders[i],k],[k,hands[i]]]){softLine(...a,...b,ink,23,20+i);softLine(...a,...b,col,15,20+i)}
  ends.push(hands[i]);
 }
 if(pose==='phone'||pose==='call')heldPhone(hands[1]);
 if(pose==='torch')flashlight(hands[1],true,o.beamDir||-1);
 if(pose==='carry')jug(0,-262,1,.7,Math.max(0,o.marks||0));
 if(pose==='eat')snack(hands[1][0],hands[1][1],.5,'bar');
 if(o.held)o.held(hands[0],hands[1]);
 for(const h of hands)oval(...h,10.5,10.5,'#222621',null);
 g.save();g.translate(0,-441);g.scale(1.075,1.075);head(t,{...pr,skin:pr.skin||'#EEE7DA',look:o.look||[2,4],worry:o.emotion==='worry',surprise:o.emotion==='shock',talk:o.talk||0,head:o.head||0,sleep:!!o.sleep});g.restore();
 g.restore();g.restore();return ends.map(p=>[x+s*p[0],y+s*(p[1]+by)]);
}
