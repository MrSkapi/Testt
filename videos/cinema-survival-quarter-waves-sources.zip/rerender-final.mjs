import {spawn} from 'node:child_process';
const child=spawn(process.execPath,['render-worker.mjs','27','30','9270'],{stdio:'inherit'});child.on('close',code=>process.exit(code??1));
