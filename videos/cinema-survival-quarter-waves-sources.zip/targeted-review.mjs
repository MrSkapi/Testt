import fs from 'node:fs';import {connect} from './cdp.mjs';const {cmd,ws}=await connect();const shots=JSON.parse(fs.readFileSync('timeline.json','utf8')).shots;
for(const name of ['pairclimb','sleepingshoes','bensleep','roofsit']){
 const s=shots.find(s=>s.action===name);
 for(let i=0;i<8;i++){const t=s.start+(s.end-s.start)*(i+.1)/8;const r=await cmd('Runtime.evaluate',{expression:`render(${t});C.toDataURL('image/jpeg',.92)`,returnByValue:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));fs.writeFileSync(`motion/${name}-${i}.jpg`,Buffer.from(r.result.value.split(',')[1],'base64'))}
}
const r=await cmd('Runtime.evaluate',{expression:'JSON.stringify(audit)',returnByValue:true});fs.writeFileSync('qc/final-changes-audit.json',r.result.value);await cmd('Page.close');ws.close();
