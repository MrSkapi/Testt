import fs from 'node:fs';import {connect} from './cdp.mjs';const {cmd,ws}=await connect();const data=JSON.parse(fs.readFileSync('timeline.json','utf8'));fs.mkdirSync('motion',{recursive:true});
for(const name of ['givewater','closeauditorium','pairclimb','phoneslide','carryspeaker']){
 const s=data.shots.find(s=>s.action===name);for(let i=0;i<8;i++){
  const t=s.start+(s.end-s.start)*(i+.1)/8,r=await cmd('Runtime.evaluate',{expression:`render(${t});C.toDataURL('image/jpeg',.92)`,returnByValue:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));fs.writeFileSync(`motion/${name}-${i}.jpg`,Buffer.from(r.result.value.split(',')[1],'base64'));
 }
}
await cmd('Page.close');ws.close();console.log('Motion frames captured');
