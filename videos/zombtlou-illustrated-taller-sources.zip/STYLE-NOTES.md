# Uploaded-reference observations

Both accessible reference recordings were inspected using contact sheets and full-size frames. The second accessible clip is 37.33 seconds long and includes a TV bulletin, an interference transition, hallway and door action, a window shutter, emergency lighting and a row of houses.

Visual language:
- flat frontal and simple side/three-quarter room staging;
- matte dusty colours, charcoal outlines, pencil hatching along surfaces and shape edges;
- small vertical black eyes, restrained mouth changes, round pale faces;
- slender legs and rounded segmented coat sleeves; preserve segment lengths and hand-to-prop contact;
- deliberate wide, reaction and object-insert cuts; camera movement is secondary to acting;
- environment colour changes can convey an alarm, without unrelated floating particles;
- screen interference belongs to a screen/broadcast shot; warning labels sit on the represented object;
- exteriors keep the same drawn outlines, wood siding, window divisions, roof panels, paths and modest paper texture;
- white bold subtitles on compact black boxes; explanatory headings may use separate yellow/white lettering.

Continuity decisions for this story: keep the established teal cap and rust-orange hoodie. A seated pose must place the pelvis on the sofa cushion and feet on the ground; the head stays circular. In the taller revision the torso grows by 25 drawing units and the lower legs by 10 units, rather than stretching the whole character image.

Reference footage itself is not included in the delivered animation or source package.
