from pathlib import Path
import subprocess,json,sys,numpy as np
P=Path(__file__).parent;sys.path.insert(0,str(P/'audio'))
from sfx import make
from dsp import SR,place,write_wav
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(P/'narration.mp3'),'-ar','48000','-ac','2','-f','f32le','-'])
voice=np.frombuffer(raw,dtype=np.float32).reshape(-1,2).copy();fx=np.zeros_like(voice);cues=[]
def add(at,name,db=-35,duration=.12,pitch=1):
 cues.append(dict(at=at,name=name,gainDb=db,duration=duration));place(fx,make(name,dur=duration,pitch=pitch,seed=55+len(cues)),round(at*SR),10**(db/20))
for s in json.loads((P/'timeline.json').read_text())['shots']:
 a=s['action'];t=s['start'];dur=s['end']-t
 if a in ['testfail','canfall','traprelease','bagshield']:add(t+min(.4,dur/2),'hit',-38,.25,.65)
 elif a in ['handle','gate','open','close','cupboard']:add(t+dur*.75,'tick',-32,.1,.8)
 elif a=='knocks':
  for x in [.15,.45,.75]:add(t+dur*x,'hit',-38,.14,1.3)
 elif a=='bottlebounce':
  for x in [.12,.56]:add(t+dur*x,'hit',-33,.13,1.8)
 elif a=='freezerfall':add(t+dur*.78,'hit',-33,.34,.55)
 elif a=='speakerlow':add(t+.2,'blip',-35,.12,.7)
 elif a=='phoneslide':add(t+dur*.45,'swish',-41,.3)
 # Foot sounds only for the visually established flat-ground escape steps.
 elif a in ['groupwalk','pairwalk','arrive']:
  for x in np.arange(.22,dur,.51):add(t+float(x),'footstep',-39,.13)
# Keep the narration exactly at unity gain. Only the effects use available headroom.
allow=np.maximum(0,.985-np.abs(voice));fx=np.clip(fx,-allow,allow);mix=voice+fx
write_wav(str(P/'mix.wav'),mix)
(P/'sound-cues.json').write_text(json.dumps(cues,indent=2));(P/'audio-check.json').write_text(json.dumps(dict(samples=len(voice),duration=len(voice)/SR,voiceGain=1,timeStretch=1,music=False,peak=float(np.abs(mix).max()),foleyCues=len(cues)),indent=2))
subprocess.run(['ffmpeg','-y','-v','error','-i',str(P/'mix.wav'),'-c:a','aac','-b:a','192k',str(P/'mix.m4a')],check=True)
print('Original narration, gain 1, no speed/time edits;',len(cues),'quiet Foley cues, no music')
