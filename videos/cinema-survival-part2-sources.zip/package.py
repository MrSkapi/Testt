from pathlib import Path
import zipfile,hashlib,subprocess,tempfile
P=Path(__file__).parent
names=['README.md','requirements.txt','index.html','drawing.js','character.js','sets.js','actions.js','episode2.js','waves.js','plan.py','build_timeline.py','build.py','timeline.json','storyboard.txt','words.json','transcript.txt','transcript.json','narration.mp3','mix.m4a','sound.py','sound-cues.json','audio-check.json','build-hash.txt','cdp.mjs','render-worker.mjs','render-compatibility.json','assemble.py','verify.py','package.py','render-audit.json','verification.json','review.mjs','fonts/PatrickHand-Regular.ttf','fonts/OFL.txt','audio/dsp.py','audio/sfx.py','qc/review-audit.json','qc/keyframes.json']
names+=['qc/'+p.name for p in sorted((P/'qc').glob('*.jpg'))]
names+=['motion/'+p.name for p in sorted((P/'motion').glob('*-strip.jpg'))]
names+=['motion-review.mjs','qc/cover-final.png']
with zipfile.ZipFile(P/'cinema-survival-part2-sources.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in names:z.write(P/n,n)
with zipfile.ZipFile(P/'cinema-survival-part2-sources.zip') as z:
 assert z.testzip() is None
 with tempfile.TemporaryDirectory(prefix='cinema2-',dir='/tmp') as td:
  z.extractall(td);subprocess.run(['python',str(Path(td)/'build.py')],check=True);assert (Path(td)/'build-hash.txt').read_text()==(P/'build-hash.txt').read_text()
print('SOURCE ZIP VERIFIED',flush=True)
