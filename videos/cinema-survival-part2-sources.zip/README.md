# The Last Show — Part Two

Complete eight-minute animation for the original zombieCinema-silence.mp3. 1920×1080, 24 FPS. The original MP3 is included unchanged. Narration timing, pauses and speed are preserved; quiet Foley, no music.

160 narrative shots cover days 31–60: the warehouse roof, Leo’s rescue, Nell’s shelter, flooding and the journey to the bus depot. Hero and Ben retain their first-part designs. World art uses the same quarter-strength wave pass; day cards and spoken-word captions are drawn afterwards and remain undistorted.

Edit `episode2.js` for new characters, sets, actions and cameras; `character.js` for the shared rig; `waves.js` for the wave strength; `plan.py`, `timeline.json` and `words.json` for narrative timing. The older shared action library remains available for reusable props. The episode overrides its staging.

Serve this folder with `python -m http.server 8774 --bind 127.0.0.1`, then open index.html. To rebuild use Python 3 with NumPy, SciPy, Pillow, Node 22+, Chromium and FFmpeg: `python build.py`, `python sound.py`, start Chromium remote debugging at9270, run `node render-worker.mjs 0 2 9270` and `node render-worker.mjs 1 2 9270`, then `python assemble.py`, `python verify.py`, `python package.py`. Included font: Patrick Hand, SIL OFL.
