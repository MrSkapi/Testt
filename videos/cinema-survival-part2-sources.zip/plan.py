import re
PLAN=[]
rows=r'''On day 33|terrace|spot|33|wide
He opens his mouth|terrace|cover||close
Below you Leo walks|street|leostreet||wide
Ben bites your palm|terrace|palm||insert
Two days ago|terrace|pair||medium
Day 31|terrace|supplies|31|wide
The access hatch|hatch|hatch||medium
You try the handle|hatch|handle||hands
Ben sits behind|terrace|bensit||ben
Across a gap|laundry|nell||wide
Rain|terrace|raincatch||medium
Let the first dirty runoff|terrace|runoff||insert
You keep it separate|terrace|water||insert
At sunset|laundry|board||medium|NELL\nDON'T WALK ON THE GLASS
Three pale strips|terrace|glass||insert
One is cracked|terrace|crack||insert
Day 32|terrace|lowerbag|32|wide
You hook it with|terrace|hookbag||medium
Inside water purification|terrace|bagitems||insert
She points at her roof door|laundry|nellpoint||medium
You tie your work apron|terrace|apron||medium
On day 33|terrace|signal|33|medium
Leo stops outside|street|leostreet||wide
Ben waves both arms|terrace|cover||medium
You point at the six figures|street|crowd||wide
He turns|street|leoturn||medium
The nearest one catches|street|bagpull||medium
He drops it|alley|runleo||wide
The ladder starts rattling|alley|ladder||wide
You move Ben back|terrace|benback||medium
lie flat and reach down|terrace|reach||medium
Leo climbs with a gray hand|alley|climb||medium
His shoe comes off|alley|shoe||insert
You catch his wrist|terrace|rescue||hands
Together you drag|terrace|rescue||medium
He has one shoe|terrace|brothers||medium
His shin has scratches|terrace|wound||insert
You clean and dress|terrace|dressing||insert
Someone dragged Leo|street|memory||medium
He stayed at the East Bus Depot|depot|bus||wide
I told him to stay|terrace|brothers||medium
Day 34|terrace|water|34|insert
Leo s food was|terrace|emptybag||insert
Nell watches Leo|laundry|nell||medium
Returns dragging an old timber door|laundry|doorcarry||wide
She pushes one end|terrace|bridge||wide
You guide it with the brush|terrace|bridge||medium
You rope Ben to Leo|terrace|ropeben||hands
Ben crawls across|terrace|crawl||wide
Halfway he looks down|terrace|crawl||ben
Look at her|laundry|peaches||medium
The adults cross one|terrace|cross||wide
The door bends|terrace|bend||insert
Your legs shake|landing|tired||medium
Day 36|workshop|workshop|36|wide
Upstairs a kitchen|shelter|shelter||wide
Rain barrels outside|gardenroof|barrels||wide
A camping stove|gardenroof|stove||insert
A locked food cupboard|shelter|cupboard||medium
Count everything|shelter|note||insert|COUNT EVERYTHING\nASK BEFORE TAKING\nKEEP THE STREET DOOR CLOSED
A mechanic at the depot|depot|mechanic||medium
Nell won t leave|shelter|nelltalk||close
On day 38|shelter|map|38|insert|ROUTE TO EAST BUS DEPOT
Ben sleeps between|shelter|sleep||medium
Every time one|shelter|wake||ben
On day 40|laundry|pairwalk|40|wide
You promise Ben an hour|shelter|note||insert|BACK IN ONE HOUR
Return after 58 minutes|shelter|return||medium
He s waiting by the door|landing|benwait||ben
On day 42|gardenroof|rain|42|wide
Nell puts buckets|shelter|leaks||medium
You move the mattresses|shelter|mattress||medium
By morning the canal|canal|flood||wide
Leo returns from the depot|shelter|leotalk||medium
They have fuel and a driver|depot|mechanic||wide
The engine still needs|depot|hose||insert
Nell leaves the bags unpacked|shelter|bags||medium
On day 44|workshop|flood|44|wide
First under the street door|workshop|flooddoor||insert
then up through the sink|bathroom|drain||insert
You carry food|workshop|carryfood||medium
Nell carries photographs|workshop|photo||insert
Ben holds the flashlight|workshop|bentorch||medium
Nell watches water reach|workshop|sewing||medium
unlocks the food cupboard|shelter|cupboard||medium
On day 46|laundry|flood|46|wide
The rear yard is underwater|canal|flood||wide
Something moves beneath|canal|sheet||medium
You close the door|landing|close||medium
Leo swears|landing|leowall||medium
Nell turns him around|landing|nelltalk||medium
Day 48|canal|barreldrift|48|wide
It catches on a sign|canal|barreltip||medium
A backpack falls out|canal|floatingbag||insert
The laundry s front|street|highground||wide
You dismiss that exit|street|crowd||wide
You don t need a boat|shelter|map||insert|USE THE HIGH SIDE OF THE STREET
On day 50|street|truckcrowd|50|wide
A loose panel bangs|street|panel||insert
They reach for it|street|crowdturn||medium
You know what sound can do|shelter|hero||close
You also know how quickly a battery|shelter|battery||insert
So this time|gardenroof|nell||medium
A bucket beneath a roof drain|gardenroof|bucket||insert
A rope tied to empty cans|gardenroof|cans||insert
As the bucket fills|gardenroof|trap||wide
The first test makes|gardenroof|testone||insert
Nell raises an eyebrow|gardenroof|nelltalk||close
The second drops the whole shelf|gardenroof|testfail||medium
On day 54|gardenroof|traprelease|54|wide
Metal clatters down|street|canfall||wide
below three heads turn|street|crowdturn||medium
Now you need rain|shelter|note||insert|RAIN\nDAYLIGHT\nWORKING BUS
On day 56|depot|tower|56|wide
Three slow flashes|depot|flashes||insert
Leo answers with Nell s mirror|gardenroof|mirror||medium
Three means ready|shelter|note||insert|THREE = READY\nONE = WAIT
That evening you pack|shelter|packing||insert
Nell puts one photograph|shelter|photo||insert
Ben takes the cinema map|shelter|benmap||ben
58 A cart|laundry|cart|58|medium
You cannot squeeze through|landing|blocked||wide
You carry the bags upstairs|stairs|carryfood||medium
day 59|laundry|ropehook|59|medium
Drag it sideways|laundry|cartpull||wide
The noise brings two infected|street|two||medium
You pull the rope up|laundry|ropehook||medium
By evening they followed|street|crowdturn||wide
day sixty|shelter|rain|60|wide
The depot tower flashes|depot|flashes||medium
Nell steadies the shelf|gardenroof|cans||medium
Ben checks the rope|gardenroof|benrope||hands
Then he pours the first jug|gardenroof|pour||insert
The roof drain will add|gardenroof|trap||wide
Through the roof door|landing|groupwalk||wide
Down the laundry stairs|stairs|groupstairs||wide
At the front entrance|landing|wait||medium
Across the road|street|crowd||wide
Five minutes six|landing|wait||ben
Ben looks at the ceiling|landing|lookrope||ben
Then around the corner|street|canfall||wide
The crowd turns|street|crowdturn||wide
You open the door|landing|open||medium
Leo leads along the high side|street|groupwalk||wide
Nell takes Ben s hand|street|takehand||medium
Three blocks later|depot|arrive||wide
The engine coughs|depot|bus||medium
One infected in the depot entrance|depot|attack||wide
Leo steps between|depot|bagshield||medium
You pull Ben past|depot|rescueben||medium
Nell catches Leo s coat|depot|gate||medium
The woman slams|depot|gate||wide
On the bus|businside|busseats||wide
He sits in the middle|businside|holdhands||medium
A little girl points|businside|girl||medium
He opens his map|businside|map||insert|HOW WE GOT HERE
The cinema the warehouse|businside|map||insert|CINEMA → WAREHOUSE → WORKSHOP → DEPOT
A new line runs|businside|map||insert|EAST BUS DEPOT
How we got here|businside|bentalk||ben
Then he asks you for the pencil|businside|pencil||hands'''
day=33
for row in rows.splitlines():
 fields=row.split('|');anchor,loc,action=fields[:3]
 anchor=re.sub(r'\b(\w+) s\b',r"\1's",anchor).replace('don t',"don't").replace('won t',"won't").replace('He s',"He's")
 if len(fields)>3 and fields[3]:day=int(fields[3])
 item=dict(anchor=anchor,location=loc,action=action,day=day,light='day',frame=fields[4] if len(fields)>4 else 'wide')
 if len(fields)>5:item['detail']=fields[5].replace('\\n','\n');item['title']='ROUTE' if action=='map' else 'NOTES'
 PLAN.append(item)
