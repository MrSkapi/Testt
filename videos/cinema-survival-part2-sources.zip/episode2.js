// Part two shares the exact character rig, palette, linework and quarter-wave pass.
CAST.leo={col:'#617e83',hair:'#473d33'};CAST.ada={col:'#886d85',hair:'#544438',female:true};CAST.tariq={col:'#4d8380',hair:'#3b3730'};
const oldScenery=scenery;
scenery=function(loc,light='day'){
 if(['roof','street','alley','stairs','corridor','office','stockroom','bathroom'].includes(loc)){oldScenery(loc,light);return}
 const key='p2|'+loc+'|'+light;if(setCache.has(key)){g.drawImage(setCache.get(key),0,0);return}
 const original=g,c=document.createElement('canvas');c.width=W;c.height=H;g=c.getContext('2d');
 if(['terrace','laundry','hatch','gardenroof'].includes(loc)){
  rect(0,0,W,H,light==='night'?'#46576b':'#93a5aa',null);
  for(let i=0;i<6;i++){rect(i*360-20,370+i%3*75,315,420,['#847e75','#8b9b90','#788d96'][i%3],ink,3);for(let j=0;j<3;j++)rect(i*360+22+j*81,421+i%3*75,39,65,'#b5c3ac',ink,2)}
  floor(948,'#858b7b');rect(0,791,1920,157,'#9b9c87',ink,4);for(let i=0;i<12;i++)line(i*183,795,i*183,947,'#566f632c',2);
  rect(1255,532,366,259,'#758e82',ink,4,8);for(let i=0;i<9;i++)line(1280+i*37,561,1280+i*37,746,'#385b54',4);
  if(loc==='hatch'){rect(505,830,486,97,'#566f68',ink,5,5);line(529,849,968,849,'#b8c1a3',3);rect(711,859,100,24,null,ink,5,5)}
  if(loc==='laundry'){for(const x of[320,1540])line(x,315,x,946,ink,9);line(320,382,1540,424,'#424e45',4);for(let i=0;i<4;i++){path([[425+i*245,388+i*8],[605+i*245,394+i*8],[610+i*245,719],[418+i*245,706]],['#d4d1b7','#859b92','#a08d83','#b4ae90'][i],ink,3);rect(439+i*245,385+i*8,7,23,'#86704e',ink,1)}}
  if(loc==='gardenroof'){for(let i=0;i<5;i++){rect(320+i*230,812,166,136,'#9a7656',ink,3);for(let j=0;j<3;j++){line(351+i*230+j*36,817,340+i*230+j*36,742,'#4b7251',5);oval(342+i*230+j*36,759,20,8,'#658c5b',ink,1)}}}
 }else if(['apartment','shelter','landing'].includes(loc)){
  wall('#b6ab8f');floor(948,'#928570');rect(0,628,1920,320,'#71887a',null);floor(948,'#928570');windowView(180,206,460,327,light==='night');doorFrame(1510,320,272,628,'ROOF ACCESS','#53756f');
  rect(829,713,559,25,'#9d7d52',ink,4);for(const x of[855,1254])line(x,740,x,948,ink,9);rect(202,830,434,98,'#81717c',ink,4,12);rect(218,755,400,108,'#9d8994',ink,3,11);lamp(1095,166);
 }else throw Error('Unknown new set '+loc);
 g=original;setCache.set(key,c);g.drawImage(c,0,0);
};
sceneBase=function(s,t){scenery(s.location,s.light);hatch(35,120,1850,700,45,'#3c3a2b19',17)};
function cityMap(s,t){sceneBase(s,t);rect(257,246,1400,645,'#b19266',ink,5);rect(280,269,1354,597,'#dbd4b7',ink,2);label(s.title||'ROOFTOP ROUTE',330,324,39,'#466455');const boxes=[[380,418,250,179,'WAREHOUSE'],[744,414,250,180,'NELL'],[1140,412,318,182,'COURTYARD']];for(const[x,y,w,h,n]of boxes){rect(x,y,w,h,'#a9b59b','#5c7865',4);label(n,x+w/2,y+h*.56,28,'#3f6050','center')}const points=[[500,759],[500,510],[864,510],[864,752],[1290,752],[1290,510]],v=pct(s,t)*5;let tip=points[0];for(let i=0;i<5;i++){const q=clamp(v-i);if(q>0){tip=mix(points[i],points[i+1],q);line(...points[i],...tip,'#a96a44',8)}}const p=[tip[0]+28,tip[1]+44];line(p[0]+90,1120,...p,ink,33);line(p[0]+90,1120,...p,'#ae9944',23);oval(...p,16,16,ink,null);line(...p,...tip,'#44554b',6);if(s.detail)label(s.detail,956,827,30,'#6b694e','center')}
function note(s,t){sceneBase(s,t);rect(400,261,1120,570,'#dad4b4',ink,4,7);label(s.title||'NOTES',960,337,39,'#446252','center');const rows=(s.detail||s.anchor).split('\n');for(let i=0;i<rows.length;i++){const a=clamp((t-s.start-i*.35)/.6);g.save();g.globalAlpha=a;label(rows[i],960,442+i*74,38,'#4f6754','center');g.restore()}}
function waterInsert(s,t){sceneBase(s,t);rect(290,608,1339,166,'#947d58',ink,4);for(let i=0;i<4;i++)jug(500+i*287,446,1.35,s.action==='emptywater'?.08:.70,Math.min(8,s.day-30));if(s.action==='mark'){const q=pct(s,t);line(1260,1100,818,578,ink,35);line(1260,1100,818,578,'#ad6038',25);oval(818,578,22,22,ink,null);line(801,570,801+q*36,570,'#394a3c',4)}if(s.detail)label(s.detail,960,835,35,'#ddd5b6','center')}
function rain(t){for(let i=0;i<90;i++){const x=(i*79.1+t*123)%1920,y=(i*91.7+t*278)%1080;line(x,y,x-10,y+29,'#d6e7d13b',1.5)}}
const roofScenery=scenery;
scenery=function(loc,light='day'){
 if(!['workshop','canal','depot','businside'].includes(loc)){roofScenery(loc,light);return}
 if(loc==='workshop'){
  roofScenery('apartment',light);for(let i=0;i<3;i++){const x=260+i*480;rect(x,718,342,22,'#9c8056',ink,4);line(x+18,740,x+18,948,ink,8);line(x+322,740,x+322,948,ink,8);rect(x+89,620,181,80,'#4b7269',ink,4,8);rect(x+86,681,31,36,'#4b7269',ink,3);oval(x+268,657,28,28,'#76958a',ink,3);line(x+269,620,x+269,583,ink,3)}return;
 }
 if(loc==='canal'){
  roofScenery('alley',light);rect(10,720,1900,360,'#597b7f',null);for(let i=0;i<36;i++){const x=(i*87+tGlobal()*20)%1920,y=750+i%7*45;softLine(x,y,x+66,y,'#b1c1a54a',2,i)}return;
 }
 if(loc==='depot'){
  rect(0,0,W,H,'#90a6a7',null);floor(948,'#818d7e');rect(123,208,1035,583,'#a3a78b',ink,4);rect(184,385,890,406,'#425e5c',ink,3);label('EAST BUS DEPOT',634,316,55,'#405b53','center');bus(970,840,1.9);for(const x of[1460,1772])line(x,340,x,948,'#4c665c',10);for(let i=0;i<5;i++)line(1480+i*60,449,1480+i*60,948,'#46665a',4);rect(1380,118,216,95,'#80958a',ink,4);for(const x of[1415,1563])line(x,214,x,449,'#5c7467',8);return;
 }
 rect(0,0,W,H,'#a8b5a0',null);floor(948,'#647d75');for(let i=0;i<4;i++){rect(105+i*470,142,421,313,'#4b686a',ink,5,8);rect(120+i*470,157,391,283,'#9cafa6',ink,2);path([[124+i*470,378],[235+i*470,269],[334+i*470,319],[506+i*470,242],[506+i*470,438],[124+i*470,438]],'#758f87',null)}for(let i=0;i<4;i++){rect(204+i*385,731,288,171,'#547d7d',ink,5,14);rect(219+i*385,673,259,107,'#7b9e92',ink,3,10);line(235+i*385,902,235+i*385,948,ink,9)}
};
function tGlobal(){return T}
function bucket(x,y,sc=1,fill=.6){g.save();g.translate(x,y);g.scale(sc,sc);path([[-44,0],[44,0],[34,100],[-33,100]],'#7d9b8d',ink,4);rect(-33,100*(1-fill),65,fill*86,'#527f7a88',null);g.beginPath();g.ellipse(0,0,44,12,0,0,Math.PI*2);g.strokeStyle=ink;g.lineWidth=3;g.stroke();g.beginPath();g.arc(0,-12,41,Math.PI,Math.PI*2);g.stroke();g.restore()}
function tinyCan(x,y,sc=1){g.save();g.translate(x,y);g.scale(sc,sc);rect(-14,-34,28,34,'#a0ad95',ink,2,3);oval(0,-34,14,4,'#c4c7a6',ink,1.5);line(-12,-25,13,-25,'#6c7f66',2);g.restore()}
function trap(s,t){sceneBase(s,t);const q=pct(s,t),release=['traprelease','testfail','canfall'].includes(s.action),yy=release?lerp(430,730,q):lerp(420,560,q);line(480,280,480,yy,'#c7bb8d',5);line(480,280,1370,280,'#c7bb8d',5);line(1370,280,1370,412+(release?240*q:0),'#c7bb8d',5);rect(1190,420+(s.action==='testfail'?q*250:0),390,24,'#8d7553',ink,4);for(let i=0;i<6;i++){const fall=release?q*(220+i*27):0;tinyCan(1215+i*63,420+fall,1.6)}bucket(480,yy,1.9,.2+.7*q);path([[212,153],[280,153],[280,320],[474,320],[474,yy-20]],null,'#405b56',17,false);if(s.action==='pour'){line(492,144,492,yy-20,'#b5d7b6a0',7);jug(475,103,.9)}label('GRAVITY · NO BATTERY',897,835,31,'#dcd5b5','center')}
function specialInsert(s,t){const a=s.action,q=pct(s,t);sceneBase(s,t);rect(326,332,1267,517,'#a08259',ink,4);
 if(['palm','wound','dressing'].includes(a)){path([[510,1080],[671,568],[855,472],[1107,599],[1180,823],[1060,1080]],'#272d28',ink,5);line(843,633,959,664,'#884f40',9);if(a==='dressing'){g.save();g.globalAlpha=q;rect(790,591,244,123,'#dedcc0',ink,3,7);g.restore()}return}
 if(['bagitems','emptybag','packing','bags','photo'].includes(a)){pack(589,594,1.5);if(a!=='emptybag'){for(let i=0;i<2;i++)tinyCan(900+i*220,655,2.4);rect(1188,477,206,177,'#d9d3b2',ink,3);label('TREATMENT',1291,526,27,'#4c6754','center');label('FOLLOW LABEL',1291,572,23,'#4c6754','center');line(1120,753,1370,753,'#a4824c',9)}if(a==='photo'){rect(849,452,287,273,'#dfd5b6',ink,4);rect(870,475,246,178,'#89a08e',ink,2);oval(943,540,29,29,'#e4dec4',ink,2);oval(1041,541,28,28,'#e4dec4',ink,2)}return}
 if(['glass','crack'].includes(a)){for(let i=0;i<3;i++)rect(415+i*341,442,212,280,'#a4b5ac',ink,3);if(a==='crack')path([[819,448],[857,496],[827,555],[899,584],[864,713]],null,'#45625b',5,false);pack(998,517,1.3);return}
 if(a==='stove'){rect(634,564,672,90,'#697d67',ink,4,9);for(const x of[824,1118]){oval(x,570,85,24,'#354d42',ink,3);line(x,519,x,551,'#d2ab56',8)}return}
 if(['hose','battery'].includes(a)){if(a==='battery'){rect(699,473,493,190,null,ink,7,8);rect(1191,522,25,91,'#698369',ink,3);rect(716,489,39,158,'#bb7852',null);label('LOW',943,756,56,'#3f594a','center')}else{g.beginPath();g.moveTo(636,694);g.bezierCurveTo(650,361,1150,824,1245,466);g.strokeStyle=ink;g.lineWidth=56;g.stroke();g.strokeStyle='#698f83';g.lineWidth=42;g.stroke();for(const[x,y]of[[636,694],[1245,466]])oval(x,y,30,20,'#a6bba1',ink,4)}return}
 if(a==='shoe'){path([[640,622],[771,544],[874,563],[932,645],[1145,695],[1140,760],[640,760]],'#514f43',ink,5);line(663,744,1130,744,'#999c7f',8);return}
 if(['floatingbag','barreltip','barreldrift'].includes(a)){rect(325,332,1275,518,'#658684',null);const x=lerp(650,1070,q);g.save();g.translate(x,540);g.rotate(a==='barreldrift'?.05*Math.sin(t):q);rect(-93,-87,186,183,'#8b9875',ink,5,24);for(const y of[-53,54])line(-92,y,92,y,'#536e57',12);g.restore();if(a!=='barreldrift')pack(x+107,623,1.1);return}
 if(a==='pencil'){const tip=mix([1120,645],[860,535],q);line(460,1110,...tip,ink,37);line(460,1110,...tip,'#ad6038',26);oval(...tip,20,20,ink,null);line(tip[0],tip[1],tip[0]+122,tip[1]-44,'#bb9256',10);line(1360,1110,tip[0]+110,tip[1]-40,ink,26);line(1360,1110,tip[0]+110,tip[1]-40,'#ae9944',17);oval(tip[0]+110,tip[1]-40,17,17,ink,null);return}
 note(s,t)
}
insertFor=function(s,t){const a=s.action;if(a==='map'){cityMap(s,t);return true}if(['note','board'].includes(a)){note(s,t);return true}if(['water','mark','emptywater','supplies'].includes(a)){waterInsert(s,t);return true}if(['bucket','cans','trap','traprelease','testone','testfail','pour','canfall'].includes(a)){trap(s,t);return true}if(['palm','wound','dressing','bagitems','emptybag','packing','photo','glass','crack','stove','hose','battery','shoe','floatingbag','barreldrift','barreltip','pencil'].includes(a)){specialInsert(s,t);return true}return false};
worldAction=function(s,t){const a=s.action,q=pct(s,t),H=(x=1120,o={})=>hero(x,948,1.04,t,{emotion:'worry',...o}),B=(x=867,o={})=>person('ben',x,948,.71,t,o),L=(x=1420,o={})=>person('leo',x,948,1.0,t,{...o}),N=(x=642,o={})=>person('ada',x,948,.96,t,o);const fam=()=>{H();B();L();if(s.day>=34)N()};
 if(['pairwalk','runleo','groupwalk','groupstairs','return','arrive','carryfood'].includes(a)){
  let dist=Math.min(650,(s.end-s.start)*145),x0=380,x1=x0+dist;walkTo(a==='runleo'?'leo':'hero',x0,x1,948,1.04,t,q,{pose:a==='carryfood'?'carry':'stand'});if(a!=='runleo'){walkTo('ben',x0+180,x1+180,948,.71,t,q);if(['groupwalk','groupstairs','arrive'].includes(a)){walkTo('leo',x0+350,x1+350,948,1,t,q);walkTo('ada',x0-180,x1-180,948,.96,t,q)}}return;
 }
 if(['crowd','truckcrowd','crowdturn','two','leostreet','leoturn','bagpull','attack','memory','highground'].includes(a)){
  if(a==='truckcrowd')bus(980,816,1.7);const n=a==='two'?2:a==='crowd'||a==='truckcrowd'?7:a==='crowdturn'?3:5;for(let i=0;i<n;i++){const x=240+i*235;person('infected',x,948,.91,t,{head:a==='crowdturn'?q*.08:.03,look:[a==='crowdturn'?7:-4,2],walk:!['crowd','truckcrowd','highground'].includes(a),distance:q*80,lean:.035})}if(['leostreet','leoturn','bagpull','memory'].includes(a)){L(1270,{look:[-6,2]});pack(1370,825,1.0)}return;
 }
 if(['cover','benback','spot','hero'].includes(a)){const bx=1250;if(a==='cover')B(bx,{hands:[[-65,-222],[60,-310]],emotion:'shock',look:[-7,4]});H(a==='cover'?1115:1067,{hands:a==='cover'?[[-66,-222],[130,-282]]:undefined,look:[-4,6]});if(a!=='cover')B(bx,{hands:a==='cover'?[[-65,-222],[60,-310]]:undefined,emotion:'shock',look:[-7,4]});return}
 if(['brothers','rescueben','takehand'].includes(a)){H(734);person('leo',1210,948,1,t,{hands:[[-116,-277],[66,-222]],look:[-6,8]});B(1030,{hands:[[-65,-222],[106,-318]],look:[6,1]});if(a==='takehand')N(1385,{hands:[[-110,-310],[66,-222]],look:[-6,7]});return}
 if(['reach','rescue','climb','ladder'].includes(a)){
  for(const x of[710,810])line(x,290,x,947,'#afba9f',9);for(let y=320;y<948;y+=63)line(710,y,810,y,'#a4b399',7);
  const y=lerp(1020,650,q);if(['reach','rescue'].includes(a)){const grip=mix([-113,-310],[-70,-380],q),gx=990+1.04*grip[0],gy=1006+1.04*grip[1];person('leo',gx-50,gy+430,1,t,{hands:[[-66,-222],[50,-430]],look:[4,0]});hero(990,1006,1.04,t,{sit:true,hands:[grip,[66,-222]],look:[-6,9]});person('ben',1000,948,.71,t,{hands:[[(gx+12-1000)/.71,(gy+70-948)/.71],[66,-222]],look:[-6,4]});return;}person('leo',760,y,1,t,{hands:[[-49,-394],[50,-400]],look:[-2,1]});if(['reach','rescue'].includes(a)){hero(990,1006,1.04,t,{sit:true,hands:[[-113,-310],[66,-222]],look:[-8,12]});B(1190,{hands:[[-99,-329],[66,-222]],look:[-8,8]})}else person('infected',762,1170,.91,t,{hands:[[-56,-337],[65,-430]],look:[4,-3]});return;
 }
 if(['bridge','doorcarry','ropeben','crawl','cross','bend'].includes(a)){
  rect(0,840,630,240,'#a0a18a',ink,4);rect(1280,840,640,240,'#a0a18a',ink,4);rect(631,840,648,240,'#3b5260',null);const drop=a==='bend'?6*Math.sin(q*Math.PI):0;path([[562,839],[1347,839+drop],[1344,873+drop],[563,873]],'#9a8057',ink,5);line(580,850,1329,850+drop,'#c0ad82',3);N(1440,{hands:[[-108,-320],[66,-222]],look:[-7,6]});L(340);if(a==='crawl'){g.save();g.translate(lerp(450,1000,q),805);g.rotate(Math.PI/2);const k=Math.sin(q*18*Math.PI);person('ben',0,0,.71,t,{crawl:true,feet:[[0,-30-8*k],[25,-15+8*k]],hands:[[49,-390+12*k],[49,-305-12*k]],head:0,look:[3,3]});g.restore();H(450)}else if(a==='cross')walkTo('hero',560,1320,865,1.04,t,q,{look:[6,3]});else{H(520,{hands:[[-66,-222],[115,-320]]});B(320)}return;
 }
 if(['hatch','handle','close','open','cupboard','gate','blocked'].includes(a)){
  const x=1190;rect(x,315,318,633,'#53776e',ink,4);rect(x+52,387,209,102,'#a1b49e',ink,3);const target=[(x+257-1320)/1.04,(690-948)/1.04];H(1320,{hands:[[-66,-222],target],look:[6,2]});B(992);if(['gate','open'].includes(a)){rect(x+Math.sin(q*1.4)*135,319,316*(1-.45*q),627,'#64887a',ink,4)}return;
 }
 if(['rain','flood','flooddoor','sheet','drain','leaks','sewing','mattress'].includes(a)){
  fam();if(a==='rain'||a==='leaks')rain(t);if(a==='leaks'){for(const x of[670,1240]){bucket(x,835,1.0,.5);line(x,250,x,850,'#b0cfb46a',3)}}if(['flood','flooddoor','sheet','drain','sewing'].includes(a)){const y=lerp(915,835,q);rect(0,y,W,H-y,'#63898a99',null);for(let i=0;i<18;i++)softLine(i*119+(t*21)%80,y+20+i%3*34,i*119+80+(t*21)%80,y+21+i%3*34,'#c4d9c346',2,i)}if(a==='sheet'){path([[509,872],[781,851+Math.sin(t)*12],[882,933],[559,949]],'#b3bfa3',ink,3)}return;
 }
 if(['cart','ropehook','cartpull'].includes(a)){const x=lerp(970,a==='cartpull'?1430:1000,q);rect(x,723,345,165,'#657f74',ink,4);for(const xx of[x+50,x+288])oval(xx,911,24,24,'#354c43',ink,3);H(632,{hands:[[-55,-266],[55,-266]],look:[7,8]});line(655,671,x+42,746,'#d0be88',5);B(382);return}
 if(['raincatch','runoff','barrels'].includes(a)){H(1110,{pose:'carry'});B();bucket(720,833,1.0,.3+.5*q);if(a!=='barrels'){rain(t);path([[640,653],[887,661],[834,775],[715,835]],'#3d5146',ink,4);line(745,798,745,856,'#b9d1b590',5)}else for(let i=0;i<3;i++)bucket(580+i*350,740,1.5,.8);return}
 if(['lowerbag','hookbag','apron','signal'].includes(a)){N(1420,{hands:[[-115,-310],[66,-222]],look:[-8,3]});H(650,{hands:[[-66,-222],[115,-322]],look:[7,3]});const yy=lerp(550,735,q);line(1330,501,1110,yy,'#c6b17f',4);pack(1110,yy,1);line(770,612,1110,yy+20,'#9e8e64',10);if(a==='apron'){path([[640,501],[732,501],[770,688],[608,688]],'#ad6038',ink,3);rect(654,536,51,61,'#d3d1b3',ink,2);label('STAFF',680,575,16,'#40594b','center')}return}
 if(['panel','tower','flashes','mirror'].includes(a)){if(a==='panel'){bus(960,810,1.65);g.save();g.translate(1118,741);g.rotate(Math.sin(t*2)*.09);rect(-110,-75,220,150,'#9da78c',ink,4);g.restore();return}if(a==='mirror'){L(1070,{hands:[[-66,-222],[111,-345]],held:(l,r)=>rect(r[0]-17,r[1]-28,34,43,'#d3e3c0',ink,3)});}else{const on=Math.sin(t*4)>0;rect(1380,118,216,95,'#82998c',ink,4);if(on){oval(1487,165,27,27,'#eed99b',null);line(1434,165,1366,165,'#e9d6a97a',4);line(1540,165,1602,165,'#e9d6a97a',4)}}return}
 if(a==='bensit'){person('ben',1430,973,.71,t,{sit:true,pose:'phone',look:[-5,5]});rect(1255,750,366,198,'#758e82',ink,3,6);return;}if(['busseats','holdhands','girl','bentalk','sleep','wake'].includes(a)){
  const y=1037;hero(800,y,1.04,t,{sit:true,look:[4,3]});person('ben',1030,973,.71,t,{sit:true,sleep:a==='sleep',look:[-3,3],talk:a==='bentalk'?.35:0});person('leo',1280,y,1,t,{sit:true,look:[-5,3]});if(a==='girl')person('jules',1550,948,.62,t,{hands:[[-90,-320],[66,-222]],look:[-5,2]});return;
 }
 if(['bagshield'].includes(a)){person('leo',1260,948,1,t,{hands:[[-66,-222],[113,-337]],held:(l,r)=>pack(r[0],r[1],.9)});person('infected',1460,948,.91,t,{hands:[[-105,-317],[90,-321]],head:-.03});H(820);B(1010);return}
 // Conversation and observation shots keep hands relaxed; speech changes only the face.
 H(1130,{pose:a==='bentorch'?'stand':'stand',look:[-5,3]});B(870,{pose:a==='bentorch'?'torch':'stand',look:[6,3]});if(s.day>=34||(s.day===33&&t>115))L(1400,{talk:a==='leotalk'?.3:0});if(s.day>=34)N(620,{talk:a==='nelltalk'?.3:0,look:[5,3]});if(a==='peaches')tinyCan(780,601,1.2);
};
fullScene=function(s,t){const f=FOCUS[s.frame||'wide']||FOCUS.wide;let z=f[2],cx=f[0],cy=f[1];if(s.frame==='ben'){cx=1020;cy=682;z=1.6}if(s.frame==='close'){cx=s.action==='nelltalk'?640:1130;cy=600;z=1.65}z+=Math.min(.10,t*.00025);cx=clamp(cx,960/z,W-960/z);cy=clamp(cy,540/z,H-540/z);cam(cx,cy,z,()=>{sceneBase(s,t);worldAction(s,t)})};
overlay=function(s,t){g.save();g.translate(41,37);g.rotate(-.018);rect(0,0,513,115,'#f1efdc',ink,4.5,5);rect(0,0,513,23,'#e7cd55',ink,3,4);label('THE LAST SHOW · PART TWO',15,18,17,ink,'left','DejaVu Sans',true);label('DAY '+s.day,17,94,61);rect(228,33,265,66,null,'#8c5a43',3,5);label(s.location.toUpperCase(),360,77,27,'#765444','center');g.restore()};
