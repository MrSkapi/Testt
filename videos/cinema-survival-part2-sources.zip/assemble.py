from pathlib import Path
import json,subprocess,math,hashlib
P=Path(__file__).parent;data=json.loads((P/'timeline.json').read_text());N=math.ceil(data['duration']*24);build=(P/'build-hash.txt').read_text().strip();compat=json.loads((P/'render-compatibility.json').read_text()) if (P/'render-compatibility.json').exists() else {}
parts=[];audits=[]
for k in range(math.ceil(N/480)):
 p=P/'parts'/f'part-{k:03}.mp4';m=json.loads(p.with_suffix('.mp4.ok').read_text());allowed=m['hash']==build or compat.get('currentHash')==build and any(x['hash']==m['hash'] and k not in x['excludeParts'] for x in compat['compatible']);assert allowed,(k,'stale source')
 v=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=width,height,r_frame_rate,nb_frames','-of','json',str(p)]))['streams'][0];assert (v['width'],v['height'],v['r_frame_rate'])==(1920,1080,'24/1');assert int(v['nb_frames'])==m['frames']==min(480,N-k*480);assert not m['audit']['unreachable'];assert m['audit']['maxBoneError']<1e-6;assert m['audit']['maxWalkFlex']<=32
 parts.append(p);audits.append(m)
(P/'parts.txt').write_text('\n'.join("file '"+str(p)+"'" for p in parts)+'\n')
out=P/'cinema-survival-part2.mp4';subprocess.run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(P/'parts.txt'),'-i',str(P/'mix.m4a'),'-map','0:v:0','-map','1:a:0','-c','copy','-movflags','+faststart',str(out)],check=True)
(P/'render-audit.json').write_text(json.dumps(dict(buildHash=build,frames=N,parts=audits),indent=2));print('ASSEMBLED',out.stat().st_size,'bytes',N,'native frames',flush=True)
